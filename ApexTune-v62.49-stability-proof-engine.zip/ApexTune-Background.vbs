Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
shell.Environment("PROCESS")("APEXTUNE_SUPPRESS_OPEN") = "1"
shell.Environment("PROCESS")("APEXTUNE_SUPPRESS_CMD") = "1"
cmd = "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File """ & root & "\ApexTune.CommandCenter.ps1"""
shell.Run cmd, 0, False
