param(
  [string]$ManifestUrl = "",
  [string]$ManifestPath = "",
  [string]$PackagePath = "",
  [string]$InstallDir = $PSScriptRoot,
  [switch]$Force,
  [switch]$CheckOnly,
  [switch]$Gui,
  [switch]$NoPause
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem

$Colors = @{
  Bg = [System.Drawing.Color]::FromArgb(6,10,18)
  Panel = [System.Drawing.Color]::FromArgb(12,18,31)
  Card = [System.Drawing.Color]::FromArgb(15,24,40)
  Field = [System.Drawing.Color]::FromArgb(7,12,21)
  Line = [System.Drawing.Color]::FromArgb(34,48,74)
  Text = [System.Drawing.Color]::FromArgb(247,250,255)
  Muted = [System.Drawing.Color]::FromArgb(170,181,200)
  Green = [System.Drawing.Color]::FromArgb(51,240,120)
  Red = [System.Drawing.Color]::FromArgb(255,77,94)
  Amber = [System.Drawing.Color]::FromArgb(255,174,52)
  Violet = [System.Drawing.Color]::FromArgb(124,92,255)
  Teal = [System.Drawing.Color]::FromArgb(63,232,208)
}

function New-Font($Size, $Style = [System.Drawing.FontStyle]::Regular) {
  return New-Object System.Drawing.Font("Segoe UI", [float]$Size, $Style)
}

$script:Form = $null
$script:Status = $null
$script:Details = $null
$script:Bar = $null
$script:OldVersionLabel = $null
$script:NewVersionLabel = $null
$script:ActionButton = $null
$script:CloseButton = $null
$script:LatestManifest = $null
$script:UpdateAvailable = $false
$script:PackageVersion = "unknown"
$script:Installing = $false

function Log-Line([string]$Text) {
  $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Text
  Write-Host $line
  if ($script:Details) { $script:Details.AppendText($line + [Environment]::NewLine) }
  if ($script:Status) { $script:Status.Text = $Text }
  if ($script:Form) { [System.Windows.Forms.Application]::DoEvents() }
}

function Set-Progress([int]$Value, [string]$Text) {
  if ($script:Bar) { $script:Bar.Value = [Math]::Min(100, [Math]::Max(0, $Value)) }
  if ($Text) { Log-Line $Text }
}

function Fail([string]$Message) { throw $Message }

function Resolve-FullPath([string]$PathValue) {
  if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
  return [System.IO.Path]::GetFullPath((Resolve-Path -LiteralPath $PathValue).Path)
}

function Convert-ToApexVersion([string]$Value) {
  if ([string]::IsNullOrWhiteSpace($Value)) { return [version]"0.0.0" }
  $clean = ([string]$Value).Trim()
  if ($clean -match '(\d+(\.\d+)+)') { $clean = $matches[1] }
  elseif ($clean -match '^(\d+)$') { $clean = "$($matches[1]).0.0" }
  $parts = @($clean.Split('.') | Where-Object { $_ -match '^\d+$' })
  while ($parts.Count -lt 2) { $parts += '0' }
  if ($parts.Count -gt 4) { $parts = $parts[0..3] }
  try { return [version]($parts -join '.') } catch { return [version]"0.0.0" }
}

function Get-CurrentVersionText([string]$InstallDir) {
  $vf = Join-Path $InstallDir "VERSION.txt"
  if (Test-Path -LiteralPath $vf) {
    $raw = (Get-Content -Raw -LiteralPath $vf).Trim()
    if ($raw -match '(\d+(\.\d+)+)') { return $matches[1] }
    return $raw
  }
  return "0.0.0"
}

function Test-PlaceholderUrl([string]$Url) {
  if ([string]::IsNullOrWhiteSpace($Url)) { return $true }
  $bad = @("PUT_REAL_HTTPS", "PUT_DOWNLOAD", "PUT_SHA256", "your-domain.com", "example.com", "localhost/replace", "ApexTune_Latest.zip")
  foreach ($item in $bad) { if ($Url.IndexOf($item, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) { return $true } }
  return $false
}

function Get-SourceManifestUrl([string]$InstallDir) {
  if ($ManifestUrl) { return $ManifestUrl }
  $sourceFile = Join-Path $InstallDir "UPDATE-SOURCE.json"
  if (Test-Path -LiteralPath $sourceFile) {
    try { $s = Get-Content -Raw -LiteralPath $sourceFile | ConvertFrom-Json; if ($s.manifestUrl) { return [string]$s.manifestUrl } } catch {}
  }
  $local = Join-Path $InstallDir "UPDATE-MANIFEST.json"
  if (Test-Path -LiteralPath $local) {
    try { $m = Get-Content -Raw -LiteralPath $local | ConvertFrom-Json; if ($m.manifestUrl) { return [string]$m.manifestUrl } } catch {}
  }
  return ""
}

function Get-ManifestObject([string]$InstallDir) {
  if ($ManifestPath) {
    $path = Resolve-FullPath $ManifestPath
    Log-Line "Reading manifest file: $path"
    return (Get-Content -Raw -LiteralPath $path | ConvertFrom-Json)
  }

  $url = Get-SourceManifestUrl $InstallDir
  if (-not (Test-PlaceholderUrl $url)) {
    Log-Line "Checking hosted update manifest..."
    if ($url.StartsWith("file://", [System.StringComparison]::OrdinalIgnoreCase)) {
      $uri = [Uri]$url
      return (Get-Content -Raw -LiteralPath $uri.LocalPath | ConvertFrom-Json)
    }
    if ($url -match '^[A-Za-z]:\\') {
      return (Get-Content -Raw -LiteralPath $url | ConvertFrom-Json)
    }
    if ($url -notmatch '^https://') { Fail "Manifest URL must be HTTPS or file://. Current value: $url" }
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add('Cache-Control','no-cache')
    return (($wc.DownloadString($url)) | ConvertFrom-Json)
  }

  $localManifest = Join-Path $InstallDir "UPDATE-MANIFEST.json"
  if (Test-Path -LiteralPath $localManifest) {
    Log-Line "Reading local update manifest."
    return (Get-Content -Raw -LiteralPath $localManifest | ConvertFrom-Json)
  }
  return $null
}

function Test-ZipSignature([string]$ZipPath) {
  if (!(Test-Path -LiteralPath $ZipPath)) { return $false }
  $file = Get-Item -LiteralPath $ZipPath
  if ($file.Length -lt 22) { return $false }
  $fs = [System.IO.File]::Open($ZipPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
  try {
    $bytes = New-Object byte[] 4
    [void]$fs.Read($bytes, 0, 4)
    if (-not ($bytes[0] -eq 0x50 -and $bytes[1] -eq 0x4B)) { return $false }
    $tailLength = [Math]::Min($file.Length, 66000)
    [void]$fs.Seek(-1 * $tailLength, [System.IO.SeekOrigin]::End)
    $tail = New-Object byte[] $tailLength
    [void]$fs.Read($tail, 0, $tailLength)
    for ($i = $tailLength - 22; $i -ge 0; $i--) {
      if ($tail[$i] -eq 0x50 -and $tail[$i+1] -eq 0x4B -and $tail[$i+2] -eq 0x05 -and $tail[$i+3] -eq 0x06) { return $true }
    }
    return $false
  } finally { $fs.Dispose() }
}

function Test-ZipReadable([string]$ZipPath) {
  if (-not (Test-ZipSignature $ZipPath)) { return $false }
  $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
  try { return ($zip.Entries.Count -gt 0) } finally { $zip.Dispose() }
}

function Test-ZipEntryPathsSafe([string]$ZipPath) {
  $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
  try {
    foreach ($entry in $zip.Entries) {
      $name = ([string]$entry.FullName).Replace('\','/')
      if ([string]::IsNullOrWhiteSpace($name)) { continue }
      if ($name.StartsWith('/') -or $name -match '^[A-Za-z]:' -or $name -match '(^|/)\.\.(/|$)') { return $false }
    }
    return $true
  } finally { $zip.Dispose() }
}

function Get-ObjectPropertyValue($Object, [string]$Name) {
  if ($null -eq $Object) { return $null }
  $prop = $Object.PSObject.Properties[$Name]
  if ($null -eq $prop) { return $null }
  return $prop.Value
}

function Get-ManifestDownloadUrl($Manifest) {
  foreach ($name in @('downloadUrl','packageUrl','url')) {
    $value = Get-ObjectPropertyValue $Manifest $name
    if (-not [string]::IsNullOrWhiteSpace([string]$value)) { return [string]$value }
  }
  return ""
}

function Get-UpdateZip($Manifest, [string]$PackagePath) {
  $tempZip = Join-Path $env:TEMP ("ApexTune-update-" + [Guid]::NewGuid().ToString("N") + ".zip")
  if ($PackagePath) {
    $sourcePackage = Resolve-FullPath $PackagePath
    Log-Line "Using local package: $sourcePackage"
    Copy-Item -LiteralPath $sourcePackage -Destination $tempZip -Force
    return $tempZip
  }
  if ($null -eq $Manifest) { Fail "No update manifest is configured. Add UPDATE-SOURCE.json with a real manifestUrl or drag a ZIP onto the updater." }
  $url = Get-ManifestDownloadUrl $Manifest
  if (Test-PlaceholderUrl $url) { Fail "Manifest has no real downloadUrl yet. Put a real HTTPS ZIP URL in the hosted manifest, or use a local ZIP." }
  if ($url.StartsWith("file://", [System.StringComparison]::OrdinalIgnoreCase)) {
    $uri = [Uri]$url
    Log-Line "Copying update package from file URL..."
    Copy-Item -LiteralPath $uri.LocalPath -Destination $tempZip -Force
    return $tempZip
  }
  if ($url -match '^[A-Za-z]:\\') {
    Log-Line "Copying update package from local path..."
    Copy-Item -LiteralPath $url -Destination $tempZip -Force
    return $tempZip
  }
  if ($url -notmatch '^https://') { Fail "Refusing unsafe update URL. Use HTTPS or file://." }
  Log-Line "Downloading newest ApexTune package..."
  $response = Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $tempZip -PassThru -TimeoutSec 180 -ErrorAction Stop
  if ($response.StatusCode -lt 200 -or $response.StatusCode -ge 300) { Fail "Download failed. HTTP status: $($response.StatusCode)" }
  return $tempZip
}

function Get-PackageRoot([string]$StagingDir) {
  if (Test-Path -LiteralPath (Join-Path $StagingDir "ApexTune.Desktop.ps1")) { return $StagingDir }
  foreach ($dir in (Get-ChildItem -LiteralPath $StagingDir -Directory -ErrorAction SilentlyContinue)) {
    if (Test-Path -LiteralPath (Join-Path $dir.FullName "ApexTune.Desktop.ps1")) { return $dir.FullName }
  }
  Fail "The ZIP extracted, but ApexTune.Desktop.ps1 was not found at the package root."
}

function Test-PackageContent([string]$PackageRoot) {
  $required = @('ApexTune.Desktop.ps1','ApexTune-Updater.ps1','VERSION.txt')
  foreach ($name in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $PackageRoot $name))) { Fail "Update package is missing required file: $name" }
  }
  $desktop = Get-Item -LiteralPath (Join-Path $PackageRoot 'ApexTune.Desktop.ps1')
  if ($desktop.Length -lt 10000) { Fail "ApexTune.Desktop.ps1 in the package is suspiciously small." }
  return $true
}

function Get-PackageVersion([string]$PackageRoot) {
  $vf = Join-Path $PackageRoot "VERSION.txt"
  if (Test-Path -LiteralPath $vf) {
    $raw = (Get-Content -Raw -LiteralPath $vf).Trim()
    if ($raw -match '(\d+(\.\d+)+)') { return $matches[1] }
    return $raw
  }
  return "unknown"
}

function Remove-OldAppFiles([string]$InstallDir) {
  $preserve = @('owner.json','UPDATE-SOURCE.json')
  Get-ChildItem -LiteralPath $InstallDir -Force -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -notlike 'backup-before-update-*' -and ($preserve -notcontains $_.Name)
  } | ForEach-Object {
    try { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop } catch { Log-Line ("Could not remove old file/folder now: " + $_.Name) }
  }
}

function Copy-NewAppFiles([string]$PackageRoot, [string]$InstallDir) {
  foreach ($item in (Get-ChildItem -LiteralPath $PackageRoot -Force)) {
    if ($item.Name -in @('owner.json','UPDATE-SOURCE.json')) { continue }
    $target = Join-Path $InstallDir $item.Name
    Copy-Item -LiteralPath $item.FullName -Destination $target -Recurse -Force -ErrorAction Stop
  }
}

function Install-UpdatePackage($Manifest) {
  $InstallDir = [System.IO.Path]::GetFullPath($InstallDir)
  if (!(Test-Path -LiteralPath $InstallDir)) { Fail "InstallDir does not exist: $InstallDir" }
  Set-Progress 5 "Preparing update..."
  $zipPath = Get-UpdateZip -Manifest $Manifest -PackagePath $PackagePath
  $zipItem = Get-Item -LiteralPath $zipPath
  Log-Line ("Package size: {0:N0} bytes" -f $zipItem.Length)

  Set-Progress 20 "Validating ZIP package..."
  if (-not (Test-ZipReadable $zipPath)) { Fail "Downloaded file is not a valid ZIP. Nothing was installed." }
  if (-not (Test-ZipEntryPathsSafe $zipPath)) { Fail "Update ZIP contains unsafe paths. Nothing was installed." }

  $manifestSha256 = Get-ObjectPropertyValue $Manifest 'sha256'
  if ($Manifest -and $manifestSha256 -and ([string]$manifestSha256) -notmatch 'PUT_SHA256') {
    Set-Progress 30 "Checking SHA256 hash..."
    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $zipPath).Hash.ToLowerInvariant()
    if ($hash -ne ([string]$manifestSha256).ToLowerInvariant()) { Fail "Hash mismatch. Expected $manifestSha256, got $hash." }
  } else { Log-Line "No SHA256 hash configured. ZIP structure was validated." }

  $stage = Join-Path $env:TEMP ("ApexTune-stage-" + [Guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $stage -Force | Out-Null
  Set-Progress 45 "Extracting to staging folder..."
  Expand-Archive -LiteralPath $zipPath -DestinationPath $stage -Force -ErrorAction Stop
  $packageRoot = Get-PackageRoot $stage
  [void](Test-PackageContent $packageRoot)
  $script:PackageVersion = Get-PackageVersion $packageRoot

  $backup = Join-Path $InstallDir ("backup-before-update-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
  Set-Progress 58 "Creating backup..."
  New-Item -ItemType Directory -Path $backup -Force | Out-Null
  Get-ChildItem -LiteralPath $InstallDir -Force | Where-Object { $_.Name -notlike 'backup-before-update-*' } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $backup $_.Name) -Recurse -Force -ErrorAction Stop
  }

  Set-Progress 72 "Removing old app files..."
  Remove-OldAppFiles $InstallDir
  Set-Progress 86 "Installing newest files..."
  Copy-NewAppFiles $packageRoot $InstallDir
  Set-Progress 100 "Update installed. Restart ApexTune. Backup: $backup"
}

function Compare-UpdateState {
  $InstallDir = [System.IO.Path]::GetFullPath($InstallDir)
  $currentText = Get-CurrentVersionText $InstallDir
  $manifest = $null
  if ($PackagePath) {
    $script:LatestManifest = $null
    return [pscustomobject]@{ CurrentText = $currentText; LatestText = "local package"; Available = $true; Manifest = $null; Notes = "Local update package selected." }
  }
  $manifest = Get-ManifestObject $InstallDir
  $script:LatestManifest = $manifest
  if ($null -eq $manifest) { return [pscustomobject]@{ CurrentText=$currentText; LatestText='not configured'; Available=$false; Manifest=$null; Notes='No update source configured.' } }
  $latestText = [string](Get-ObjectPropertyValue $manifest 'version')
  $notesText = [string](Get-ObjectPropertyValue $manifest 'notes')
  $available = ((Convert-ToApexVersion $latestText) -gt (Convert-ToApexVersion $currentText))
  return [pscustomobject]@{ CurrentText = $currentText; LatestText = $latestText; Available = $available; Manifest = $manifest; Notes = $notesText }
}

function Build-UpdaterGui {
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $script:Form = New-Object System.Windows.Forms.Form
  $script:Form.Text = "ApexTune Professional Updater"
  $script:Form.Size = New-Object System.Drawing.Size(720, 520)
  $script:Form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
  $script:Form.BackColor = $Colors.Bg
  $script:Form.ForeColor = $Colors.Text
  $script:Form.Font = New-Font 9
  $script:Form.MinimumSize = New-Object System.Drawing.Size(680, 480)

  $root = New-Object System.Windows.Forms.TableLayoutPanel
  $root.Dock = 'Fill'; $root.BackColor = $Colors.Bg; $root.Padding = New-Object System.Windows.Forms.Padding(22)
  $root.ColumnCount = 1; $root.RowCount = 7
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 56))) | Out-Null
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 82))) | Out-Null
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 32))) | Out-Null
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 30))) | Out-Null
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) | Out-Null
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 46))) | Out-Null
  $root.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 52))) | Out-Null
  $script:Form.Controls.Add($root)

  $title = New-Object System.Windows.Forms.Label
  $title.Text = "ApexTune Updater"; $title.Dock = 'Fill'; $title.ForeColor = $Colors.Text; $title.Font = New-Font 22 ([System.Drawing.FontStyle]::Bold); $title.TextAlign = 'MiddleLeft'
  $root.Controls.Add($title,0,0)

  $versionPanel = New-Object System.Windows.Forms.TableLayoutPanel
  $versionPanel.Dock = 'Fill'; $versionPanel.BackColor = $Colors.Card; $versionPanel.Padding = New-Object System.Windows.Forms.Padding(16,10,16,10); $versionPanel.ColumnCount = 3; $versionPanel.RowCount = 1
  $versionPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,45))) | Out-Null
  $versionPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,70))) | Out-Null
  $versionPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,45))) | Out-Null
  $script:OldVersionLabel = New-Object System.Windows.Forms.Label
  $script:OldVersionLabel.Dock='Fill'; $script:OldVersionLabel.TextAlign='MiddleCenter'; $script:OldVersionLabel.ForeColor=$Colors.Red; $script:OldVersionLabel.Font=New-Font 19 ([System.Drawing.FontStyle]::Bold)
  $arrow = New-Object System.Windows.Forms.Label
  $arrow.Dock='Fill'; $arrow.Text='---->'; $arrow.TextAlign='MiddleCenter'; $arrow.ForeColor=$Colors.Muted; $arrow.Font=New-Font 16 ([System.Drawing.FontStyle]::Bold)
  $script:NewVersionLabel = New-Object System.Windows.Forms.Label
  $script:NewVersionLabel.Dock='Fill'; $script:NewVersionLabel.TextAlign='MiddleCenter'; $script:NewVersionLabel.ForeColor=$Colors.Green; $script:NewVersionLabel.Font=New-Font 19 ([System.Drawing.FontStyle]::Bold)
  $versionPanel.Controls.Add($script:OldVersionLabel,0,0); $versionPanel.Controls.Add($arrow,1,0); $versionPanel.Controls.Add($script:NewVersionLabel,2,0)
  $root.Controls.Add($versionPanel,0,1)

  $script:Status = New-Object System.Windows.Forms.Label
  $script:Status.Dock='Fill'; $script:Status.ForeColor=$Colors.Teal; $script:Status.Font=New-Font 10 ([System.Drawing.FontStyle]::Bold); $script:Status.TextAlign='MiddleLeft'
  $root.Controls.Add($script:Status,0,2)

  $script:Bar = New-Object System.Windows.Forms.ProgressBar
  $script:Bar.Dock='Fill'; $script:Bar.Style='Continuous'; $script:Bar.Minimum=0; $script:Bar.Maximum=100
  $root.Controls.Add($script:Bar,0,3)

  $script:Details = New-Object System.Windows.Forms.TextBox
  $script:Details.Dock='Fill'; $script:Details.Multiline=$true; $script:Details.ScrollBars='Vertical'; $script:Details.ReadOnly=$true; $script:Details.BorderStyle='FixedSingle'; $script:Details.BackColor=$Colors.Field; $script:Details.ForeColor=$Colors.Muted; $script:Details.Font=New-Font 9
  $root.Controls.Add($script:Details,0,4)

  $note = New-Object System.Windows.Forms.Label
  $note.Dock='Fill'; $note.ForeColor=$Colors.Muted; $note.TextAlign='MiddleLeft'; $note.Text='The updater validates the ZIP, checks SHA256 when configured, creates a backup, removes old app files, then extracts the newest files.'
  $root.Controls.Add($note,0,5)

  $actions = New-Object System.Windows.Forms.TableLayoutPanel
  $actions.Dock='Fill'; $actions.BackColor=$Colors.Bg; $actions.ColumnCount=3; $actions.RowCount=1
  $actions.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100))) | Out-Null
  $actions.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,150))) | Out-Null
  $actions.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,150))) | Out-Null
  $script:CloseButton = New-Object System.Windows.Forms.Button
  $script:CloseButton.Text='Close'; $script:CloseButton.Dock='Fill'; $script:CloseButton.FlatStyle='Flat'; $script:CloseButton.ForeColor=$Colors.Text; $script:CloseButton.BackColor=$Colors.Card
  $script:CloseButton.Add_Click({ $script:Form.Close() })
  $script:ActionButton = New-Object System.Windows.Forms.Button
  $script:ActionButton.Text='Update now'; $script:ActionButton.Dock='Fill'; $script:ActionButton.FlatStyle='Flat'; $script:ActionButton.ForeColor=$Colors.Text; $script:ActionButton.BackColor=$Colors.Violet
  $script:ActionButton.Add_Click({
    if ($script:Installing) { return }
    $script:Installing = $true
    $script:ActionButton.Enabled = $false
    try { Install-UpdatePackage $script:LatestManifest; $script:CloseButton.Text='Done' }
    catch {
      Log-Line ("FAILED: " + $_.Exception.Message)
      $logDir = Join-Path $env:APPDATA 'ApexTune'; New-Item -ItemType Directory -Path $logDir -Force | Out-Null
      $logPath = Join-Path $logDir 'ApexTune-Updater-LastError.txt'
      ("$(Get-Date -Format o)`r`n$($_ | Out-String)") | Set-Content -Path $logPath -Encoding UTF8
      [System.Windows.Forms.MessageBox]::Show($script:Form, $_.Exception.Message, 'Update failed', 'OK', 'Error') | Out-Null
      $script:ActionButton.Enabled = $true
      $script:Installing = $false
    }
  })
  $actions.Controls.Add($script:CloseButton,1,0); $actions.Controls.Add($script:ActionButton,2,0)
  $root.Controls.Add($actions,0,6)

  $script:Form.Add_Shown({
    try {
      $state = Compare-UpdateState
      $script:OldVersionLabel.Text = $state.CurrentText
      $script:NewVersionLabel.Text = $state.LatestText
      if ($state.Available -or $PackagePath -or $Force) {
        $script:UpdateAvailable = $true
        $script:Status.Text = "Update ready. Review the version change, then click Update now."
        if ($state.Notes) { Log-Line $state.Notes }
      } else {
        $script:Status.Text = "ApexTune is already up to date."
        $script:ActionButton.Enabled = $false
        $script:ActionButton.Text = "No update"
        Log-Line "No update available."
      }
    } catch {
      $script:Status.Text = "Update check failed."
      Log-Line ("FAILED: " + $_.Exception.Message)
      $script:ActionButton.Enabled = $false
    }
  })
  [void]$script:Form.ShowDialog()
}

function Run-ConsoleUpdater {
  try {
    Write-Host "ApexTune updater"
    $state = Compare-UpdateState
    Write-Host ("Current: {0} ----> Latest: {1}" -f $state.CurrentText, $state.LatestText)
    if (-not $state.Available -and -not $PackagePath -and -not $Force) { Write-Host "ApexTune is already up to date." -ForegroundColor Green; return }
    Install-UpdatePackage $state.Manifest
  } catch {
    Write-Host ("Update failed: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
  } finally {
    if (-not $NoPause) { Write-Host "Press any key to continue . . ."; $null = $PSHost.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown') }
  }
}

if ($Gui) { Build-UpdaterGui } else { Run-ConsoleUpdater }
