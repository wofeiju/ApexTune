param(
    [string]$JobId,
    [string]$JobType,
    [string]$Root,
    [string]$AppDir
)
$ErrorActionPreference='Continue'
$jobsDir=Join-Path $AppDir 'Jobs'
$reportsDir=Join-Path $AppDir 'Reports'
$logsDir=Join-Path $AppDir 'Logs'
foreach($d in @($jobsDir,$reportsDir,$logsDir)){ New-Item -ItemType Directory -Path $d -Force | Out-Null }
$jobPath=Join-Path $jobsDir ($JobId+'.json')
function Save-Job($status,$message,$resultPath=''){
  [pscustomobject]@{ id=$JobId; type=$JobType; status=$status; message=$message; resultPath=$resultPath; updated=(Get-Date).ToString('o') } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jobPath -Encoding UTF8
}
Save-Job 'running' 'Background job started.'
try{
  $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
  $path=Join-Path $reportsDir ("ApexTune-Async-$JobType-$stamp.json")
  $cpu=(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
  $os=Get-CimInstance Win32_OperatingSystem
  $ram=[math]::Round((($os.TotalVisibleMemorySize-$os.FreePhysicalMemory)/$os.TotalVisibleMemorySize)*100)
  $ping=$null; try{ $p=New-Object System.Net.NetworkInformation.Ping; $r=$p.Send('1.1.1.1',900); if($r.Status -eq 'Success'){$ping=$r.RoundtripTime} }catch{}
  [pscustomobject]@{ ok=$true; jobId=$JobId; type=$JobType; cpu=[math]::Round($cpu); ram=$ram; ping=$ping; windows=$os.Caption; generated=(Get-Date).ToString('o') } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $path -Encoding UTF8
  Save-Job 'complete' 'Background job completed.' $path
}catch{
  Save-Job 'failed' $_.Exception.Message
  Add-Content -Path (Join-Path $logsDir 'crash.log') -Value ("{0} [ASYNC] {1}" -f (Get-Date).ToString('s'),$_.Exception.Message) -Encoding UTF8
}
