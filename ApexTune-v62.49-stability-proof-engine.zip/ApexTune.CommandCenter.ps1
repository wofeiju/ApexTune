Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:Version = '62.49 Stability + Proof Engine / 1.62490'
$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:WebRoot = Join-Path $script:Root 'web'
$script:DataRoot = Join-Path $script:Root 'data'
$script:AppDir = if (-not [string]::IsNullOrWhiteSpace($env:APPDATA)) { Join-Path $env:APPDATA 'ApexTune' } else { Join-Path $script:Root 'AppData\ApexTune' }
$script:ReportsDir = Join-Path $script:AppDir 'Reports'
$script:BackupDir = Join-Path $script:AppDir 'Backups'
$script:RollbackDir = Join-Path $script:AppDir 'Rollbacks'
$script:DiagDir = Join-Path $script:AppDir 'Diagnostics'
$script:DriverToolsDir = Join-Path $script:AppDir 'DriverTools'
$script:GamesDir = Join-Path $script:AppDir 'Games'
$script:DisabledStartupDir = Join-Path $script:AppDir 'DisabledStartup'
$script:StartupStatePath = Join-Path $script:AppDir 'StartupDisabled.json'
$script:TweakStatePath = Join-Path $script:AppDir 'TweakState.json'
$script:SettingsPath = Join-Path $script:AppDir 'Settings.json'
$script:RunKeyPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$script:RunValueName = 'ApexTune'
$script:GameManualPath = Join-Path $script:GamesDir 'ManualGamePaths.json'
$script:PowerDir = Join-Path $script:AppDir 'PowerPlans'
$script:PowerStatePath = Join-Path $script:PowerDir 'PowerPlanState.json'
$script:IntelligenceDir = Join-Path $script:AppDir 'Intelligence'
$script:SessionDir = Join-Path $script:AppDir 'Sessions'
$script:RuntimeSessionPath = Join-Path $script:SessionDir 'RuntimeSession.json'
$script:LogsDir = Join-Path $script:AppDir 'Logs'
$script:DoctorDir = Join-Path $script:AppDir 'Doctor'
$script:ProofDir = Join-Path $script:AppDir 'Proof'
$script:RestoreVaultDir = Join-Path $script:AppDir 'RestoreVault'
$script:RepairDir = Join-Path $script:AppDir 'Repair'
$script:JobsDir = Join-Path $script:AppDir 'Jobs'
$script:UpdaterStageDir = Join-Path $script:AppDir 'UpdaterStage'
$script:UpdaterBackupDir = Join-Path $script:AppDir 'UpdaterBackups'
$script:CrashLogPath = Join-Path $script:LogsDir 'crash.log'
$script:AppLogPath = Join-Path $script:LogsDir 'app.log'
$script:DoctorLogPath = Join-Path $script:LogsDir 'doctor.log'
$script:RestoreVaultIndexPath = Join-Path $script:RestoreVaultDir 'restore-vault.json'
$script:DriverTimelinePath = Join-Path $script:IntelligenceDir 'DriverTimeline.json'
$script:LastUrlPath = Join-Path $script:DiagDir 'LastUrl.txt'
$script:LaunchStatePath = Join-Path $script:DiagDir 'LaunchState.json'
$script:DriverPresetDir = Join-Path $script:DriverToolsDir 'Presets'
$script:ServerStop = $false
$script:Port = 0
$script:GameScanIndexCache = $null
$script:GameScanIndexCacheAt = [datetime]::MinValue
$script:StartupCache = $null
$script:StartupCacheAt = [datetime]::MinValue
$script:GpuDriverCache = $null
$script:GpuDriverCacheAt = [datetime]::MinValue
$script:StatusCache = $null
$script:StatusCacheAt = [datetime]::MinValue
$script:HardwareCache = $null
$script:HardwareCacheAt = [datetime]::MinValue
$script:IntelligenceCache = $null
$script:IntelligenceCacheAt = [datetime]::MinValue

foreach ($dir in @($script:AppDir, $script:ReportsDir, $script:BackupDir, $script:RollbackDir, $script:DiagDir, $script:DriverToolsDir, $script:DriverPresetDir, $script:GamesDir, $script:DisabledStartupDir, $script:PowerDir, $script:IntelligenceDir, $script:SessionDir, $script:LogsDir, $script:DoctorDir, $script:ProofDir, $script:RestoreVaultDir, $script:RepairDir, $script:JobsDir, $script:UpdaterStageDir, $script:UpdaterBackupDir)) {
    try {
        if (-not [string]::IsNullOrWhiteSpace([string]$dir)) {
            New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
        }
    } catch {
        try { Write-Host ("ApexTune could not create folder: {0} :: {1}" -f $dir, $_.Exception.Message) -ForegroundColor Yellow } catch {}
    }
}

function Test-IsAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Write-ApexLog($Message, $Level = 'INFO') {
    $path = Join-Path $script:DiagDir 'CommandCenter.log'
    $line = '{0} [{1}] {2}' -f (Get-Date).ToString('s'), $Level, $Message
    Add-Content -Path $path -Value $line -Encoding UTF8
}

function Write-ApexFileLog([string]$Path, [string]$Message, [string]$Level = 'INFO') {
    try {
        $line = '{0} [{1}] {2}' -f (Get-Date).ToString('s'), $Level, $Message
        Add-Content -Path $Path -Value $line -Encoding UTF8 -ErrorAction Stop
    } catch {}
}

function Write-ApexAppLog([string]$Message, [string]$Level = 'INFO') { Write-ApexFileLog $script:AppLogPath $Message $Level }
function Write-ApexDoctorLog([string]$Message, [string]$Level = 'INFO') { Write-ApexFileLog $script:DoctorLogPath $Message $Level }
function Write-ApexCrashLog([System.Exception]$Exception, [string]$Area = 'Runtime') {
    try {
        $status = $null
        try { $status = Get-Status } catch {}
        $obj = [pscustomobject]@{
            at = (Get-Date).ToString('o')
            version = $script:Version
            area = $Area
            message = $Exception.Message
            type = $Exception.GetType().FullName
            stack = [string]$Exception.StackTrace
            windows = if ($status) { $status.osCaption } else { '' }
            build = if ($status) { $status.osBuild } else { '' }
            gpu = if ($status) { $status.gpu } else { '' }
            ram = if ($status) { $status.ram } else { $null }
            admin = (Test-IsAdmin)
            lastUrl = if (Test-Path -LiteralPath $script:LastUrlPath -PathType Leaf) { (Get-Content -Raw -LiteralPath $script:LastUrlPath -ErrorAction SilentlyContinue).Trim() } else { '' }
        }
        Add-Content -Path $script:CrashLogPath -Value ($obj | ConvertTo-Json -Depth 8 -Compress) -Encoding UTF8 -ErrorAction Stop
    } catch {}
}

function ConvertTo-JsonResponse($Obj) {
    return ($Obj | ConvertTo-Json -Depth 20 -Compress)
}

function Set-NoCacheHeaders($Context) {
    try {
        $Context.Response.Headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        $Context.Response.Headers['Pragma'] = 'no-cache'
        $Context.Response.Headers['Expires'] = '0'
    } catch {}
}

function Send-Text($Context, [string]$Text, [string]$ContentType = 'text/plain; charset=utf-8', [int]$Status = 200) {
    $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
    try {
        if ($Context.Response.OutputStream -and $Context.Response.OutputStream.CanWrite) {
            $Context.Response.StatusCode = $Status
            Set-NoCacheHeaders $Context
            $Context.Response.ContentType = $ContentType
            $Context.Response.ContentLength64 = $bytes.Length
            $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        }
    } catch {
        # Browser/app windows can cancel a request while refreshing. That should not kill or pollute the server loop.
        Write-ApexLog ('Response send skipped: {0}' -f $_.Exception.Message) 'WARN'
    } finally {
        try { $Context.Response.OutputStream.Close() } catch {}
    }
}

function Send-Json($Context, $Obj, [int]$Status = 200) {
    Send-Text $Context (ConvertTo-JsonResponse $Obj) 'application/json; charset=utf-8' $Status
}

function Get-MimeType([string]$Path) {
    switch ([IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        '.html' { 'text/html; charset=utf-8' }
        '.css'  { 'text/css; charset=utf-8' }
        '.js'   { 'application/javascript; charset=utf-8' }
        '.json' { 'application/json; charset=utf-8' }
        '.svg'  { 'image/svg+xml' }
        '.png'  { 'image/png' }
        '.jpg'  { 'image/jpeg' }
        '.jpeg' { 'image/jpeg' }
        '.webp' { 'image/webp' }
        '.avif' { 'image/avif' }
        '.ico'  { 'image/x-icon' }
        '.webmanifest' { 'application/manifest+json; charset=utf-8' }
        default { 'application/octet-stream' }
    }
}

function Send-File($Context, [string]$Path) {
    if (-not (Test-Path $Path -PathType Leaf)) {
        Send-Json $Context @{ error = 'Not found' } 404
        return
    }
    $bytes = [IO.File]::ReadAllBytes($Path)
    try {
        if ($Context.Response.OutputStream -and $Context.Response.OutputStream.CanWrite) {
            $Context.Response.StatusCode = 200
            Set-NoCacheHeaders $Context
            $Context.Response.ContentType = Get-MimeType $Path
            $Context.Response.ContentLength64 = $bytes.Length
            $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        }
    } catch {
        Write-ApexLog ('File response send skipped: {0}' -f $_.Exception.Message) 'WARN'
    } finally {
        try { $Context.Response.OutputStream.Close() } catch {}
    }
}

function Read-BodyJson($Context) {
    $reader = New-Object IO.StreamReader($Context.Request.InputStream, $Context.Request.ContentEncoding)
    $body = $reader.ReadToEnd()
    if ([string]::IsNullOrWhiteSpace($body)) { return @{} }
    return ($body | ConvertFrom-Json)
}

function Get-Tweaks {
    $path = Join-Path $script:DataRoot 'tweaks.json'
    if (-not (Test-Path $path)) { return @() }
    return @(Get-Content -Raw -Path $path | ConvertFrom-Json)
}


function Get-OsInfo {
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $caption = ([string]$os.Caption).Trim()
        if ([string]::IsNullOrWhiteSpace($caption)) { $caption = 'Microsoft Windows' }
        $short = $caption -replace '^Microsoft\s+', ''
        $short = $short -replace '^Windows\s+11', 'Win 11'
        $short = $short -replace '^Windows\s+10', 'Win 10'
        return [pscustomobject]@{
            caption = $caption
            short = $short.Trim()
            version = [string]$os.Version
            build = [string]$os.BuildNumber
            architecture = [string]$os.OSArchitecture
            computer = [string]$os.CSName
        }
    } catch {
        return [pscustomobject]@{ caption='Windows'; short='Windows'; version=''; build=''; architecture=''; computer=$env:COMPUTERNAME }
    }
}

function Get-SystemKind {
    try {
        $enc = Get-CimInstance Win32_SystemEnclosure -ErrorAction Stop | Select-Object -First 1
        $types = @($enc.ChassisTypes)
        $laptopTypes = @(8,9,10,11,12,14,18,21,30,31,32)
        foreach ($t in $types) { if ($laptopTypes -contains [int]$t) { return 'Laptop' } }
        return 'Desktop'
    } catch { return 'PC' }
}

function Get-ConnectionProfile {
    try {
        $adapter = Get-CimInstance Win32_NetworkAdapter -Filter "NetEnabled=True" -ErrorAction Stop |
            Where-Object { $_.Name -notmatch 'Virtual|Hyper-V|Bluetooth|Loopback|TAP|VPN' } |
            Select-Object -First 1
        if ($adapter) {
            if (($adapter.Name + ' ' + $adapter.AdapterType) -match 'Wi-?Fi|Wireless|802\.11') { return 'Wi-Fi' }
            if (($adapter.Name + ' ' + $adapter.AdapterType) -match 'Ethernet|802\.3|Gigabit|2\.5G|10G') { return 'Ethernet' }
            return [string]$adapter.Name
        }
    } catch {}
    return 'Network'
}


function Get-GpuUsagePercent {
    try {
        $samples = @(Get-Counter '\GPU Engine(*)\Utilization Percentage' -ErrorAction Stop).CounterSamples |
            Where-Object { $_.InstanceName -match 'engtype_3d|engtype_compute' } |
            Select-Object -First 24
        if ($samples.Count -gt 0) {
            $sum = ($samples | Measure-Object -Property CookedValue -Sum).Sum
            return [math]::Min(100, [math]::Max(0, [math]::Round([double]$sum)))
        }
    } catch {}
    return 0
}

function Get-FastPingMs {
    try {
        $p = New-Object System.Net.NetworkInformation.Ping
        try {
            $reply = $p.Send('1.1.1.1', 650)
            if ($reply -and $reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
                return [int][math]::Round([double]$reply.RoundtripTime)
            }
        } finally { $p.Dispose() }
    } catch {}
    return 0
}

function Get-PrimaryGpuInfo {
    $gpus = @()
    try {
        $raw = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Video\*\*' -ErrorAction SilentlyContinue |
            Where-Object { $_.DriverDesc -and ([string]$_.DriverDesc) -notmatch 'Microsoft Basic|Remote Display|Virtual|Indirect' } |
            Select-Object -First 6
        foreach ($r in @($raw)) {
            $descProp = $r.PSObject.Properties['DriverDesc']
            $verProp = $r.PSObject.Properties['DriverVersion']
            $adapterProp = $r.PSObject.Properties['HardwareInformation.AdapterString']
            if (-not $adapterProp) { $adapterProp = $r.PSObject.Properties['HardwareInformation_AdapterString'] }
            $desc = if ($descProp) { [string]$descProp.Value } else { '' }
            if ([string]::IsNullOrWhiteSpace($desc)) { continue }
            $gpus += [pscustomobject]@{
                Name = $desc.Trim()
                DriverVersion = if ($verProp) { [string]$verProp.Value } else { '' }
                VideoProcessor = if ($adapterProp) { [string]$adapterProp.Value } else { '' }
                AdapterRAM = 0
                PNPDeviceID = ''
            }
        }
    } catch {}
    if (-not $gpus.Count) {
        try {
            $raw = @(Get-CimInstance Win32_VideoController -OperationTimeoutSec 2 -ErrorAction Stop |
                Where-Object { $_.Name -and ([string]$_.Name) -notmatch 'Microsoft Basic|Remote Display|Virtual|Indirect' } |
                Sort-Object @{Expression={ if(([string]$_.Name) -match 'NVIDIA|GeForce|RTX|GTX|AMD|Radeon|Intel|Arc|Iris|UHD'){0}else{1} }} |
                Select-Object -First 6 Name,DriverVersion,VideoProcessor,AdapterRAM,PNPDeviceID)
            $gpus = @($raw)
        } catch {}
    }
    $primary = if ($gpus.Count) { $gpus[0] } else { $null }
    $name = if ($primary -and $primary.Name) { ([string]$primary.Name).Trim() } else { 'Detected GPU' }
    $vendor = if ($name -match 'NVIDIA|GeForce|RTX|GTX|Quadro') { 'NVIDIA' } elseif ($name -match 'AMD|Radeon|RX\s?\d|Vega') { 'AMD' } elseif ($name -match 'Intel|Arc|Iris|UHD|Xe') { 'Intel' } else { 'GPU' }
    $ramGB = 0
    try { if ($primary -and $primary.AdapterRAM) { $ramGB = [math]::Round(([double]$primary.AdapterRAM / 1GB), 1) } } catch {}
    return [pscustomobject]@{
        name = $name
        vendor = $vendor
        driverVersion = if ($primary) { [string]$primary.DriverVersion } else { '' }
        videoProcessor = if ($primary) { [string]$primary.VideoProcessor } else { '' }
        adapterRamGB = $ramGB
        adapters = @($gpus)
        count = @($gpus).Count
    }
}

function Get-CpuHardwareInfo {
    try {
        $p = Get-CimInstance Win32_Processor -OperationTimeoutSec 2 -ErrorAction Stop | Select-Object -First 1
        $name = ([string]$p.Name).Trim()
        if ([string]::IsNullOrWhiteSpace($name)) { $name = 'Detected CPU' }
        $vendor = if ($name -match 'AMD|Ryzen|Threadripper|EPYC') { 'AMD' } elseif ($name -match 'Intel|Core|Xeon|Celeron|Pentium') { 'Intel' } elseif ($name -match 'ARM|Snapdragon|Qualcomm') { 'ARM' } else { ([string]$p.Manufacturer).Trim() }
        if ([string]::IsNullOrWhiteSpace($vendor)) { $vendor = 'CPU' }
        return [pscustomobject]@{
            name = $name
            vendor = $vendor
            cores = [int]($p.NumberOfCores)
            logicalProcessors = [int]($p.NumberOfLogicalProcessors)
            maxClockMHz = [int]($p.MaxClockSpeed)
            socket = [string]$p.SocketDesignation
            load = [int]($p.LoadPercentage)
        }
    } catch {
        return [pscustomobject]@{ name='Detected CPU'; vendor='CPU'; cores=0; logicalProcessors=0; maxClockMHz=0; socket=''; load=0 }
    }
}

function Get-HardwareSnapshot {
    $now = [datetime]::UtcNow
    if ($script:HardwareCache -and (($now - $script:HardwareCacheAt).TotalSeconds -lt 30)) { return $script:HardwareCache }
    $osInfo = Get-OsInfo
    $cpuInfo = Get-CpuHardwareInfo
    $gpuInfo = Get-PrimaryGpuInfo
    $systemKind = Get-SystemKind
    $connection = Get-ConnectionProfile
    $snap = [pscustomobject]@{ os=$osInfo; cpu=$cpuInfo; gpu=$gpuInfo; system=$systemKind; connection=$connection }
    $script:HardwareCache = $snap
    $script:HardwareCacheAt = $now
    return $snap
}

function Get-Status {
    $now = [datetime]::UtcNow
    if ($script:StatusCache -and (($now - $script:StatusCacheAt).TotalSeconds -lt 2)) { return $script:StatusCache }
    $hw = Get-HardwareSnapshot
    $cpu = 0
    try {
        if ($hw.cpu.load -ne $null -and [int]$hw.cpu.load -ge 0) { $cpu = [int]$hw.cpu.load }
        if ($cpu -eq 0) { $cpu = [int]((Get-CimInstance Win32_Processor -OperationTimeoutSec 1 -ErrorAction Stop | Measure-Object -Property LoadPercentage -Average).Average) }
    } catch { $cpu = 0 }
    $ram = 0
    try {
        $os = Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 2 -ErrorAction Stop
        $total = [double]$os.TotalVisibleMemorySize
        $free = [double]$os.FreePhysicalMemory
        if ($total -gt 0) { $ram = [math]::Round((($total - $free) / $total) * 100) }
    } catch { $ram = 0 }
    $profile = if ($hw.gpu.vendor -and $hw.gpu.vendor -ne 'GPU') { [string]$hw.gpu.vendor } else { 'GPU' }
    $pingMs = Get-FastPingMs
    $gpuLoad = Get-GpuUsagePercent
    $score = [int][math]::Round(100 - ([double]$cpu * 0.22) - ([double]$ram * 0.18) - ([double]$gpuLoad * 0.08) - ([double]([math]::Min(220, [math]::Max(0, $pingMs))) * 0.12))
    if ($score -lt 38) { $score = 38 }
    if ($score -gt 99) { $score = 99 }
    $systemState = if ($score -ge 86) { 'Optimal' } elseif ($score -ge 72) { 'Stable' } elseif ($score -ge 58) { 'Tunable' } else { 'Needs attention' }
    $result = [pscustomobject]@{
        version = $script:Version
        user = $env:USERNAME
        admin = (Test-IsAdmin)
        cpu = $cpu
        cpuName = $hw.cpu.name
        cpuVendor = $hw.cpu.vendor
        cpuCores = $hw.cpu.cores
        cpuLogicalProcessors = $hw.cpu.logicalProcessors
        cpuMaxClockMHz = $hw.cpu.maxClockMHz
        cpuSocket = $hw.cpu.socket
        ram = $ram
        ping = $pingMs
        fps = '+41 FPS'
        score = $score
        profile = $profile
        gpu = $hw.gpu.name
        gpuVendor = $hw.gpu.vendor
        gpuDriverVersion = $hw.gpu.driverVersion
        gpuVideoProcessor = $hw.gpu.videoProcessor
        gpuAdapterRamGB = $hw.gpu.adapterRamGB
        gpuAdapterCount = $hw.gpu.count
        gpuUsage = $gpuLoad
        connection = $hw.connection
        system = $hw.system
        systemState = $systemState
        rigName = if ($hw.os.computer) { $hw.os.computer } else { $env:COMPUTERNAME }
        osCaption = $hw.os.caption
        osShort = $hw.os.short
        osBuild = $hw.os.build
        osVersion = $hw.os.version
        osArchitecture = $hw.os.architecture
        restorePoint = $true
        registryBackup = $true
        strictSafety = $true
    }
    $script:StatusCache = $result
    $script:StatusCacheAt = $now
    return $result
}


function Get-ApexPropValue($Obj, [string]$Name, $Default = $null) {
    if ($null -eq $Obj -or [string]::IsNullOrWhiteSpace($Name)) { return $Default }
    try {
        $prop = $Obj.PSObject.Properties[$Name]
        if ($prop -and $null -ne $prop.Value) { return $prop.Value }
    } catch {}
    return $Default
}

function Format-ApexBytes([double]$Bytes) {
    if ($Bytes -ge 1GB) { return ('{0:N1} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N1} KB' -f ($Bytes / 1KB)) }
    return ('{0:N0} B' -f $Bytes)
}

function Get-ApexDirectoryStats([string]$Path, [string]$Label, [string]$Role) {
    $exists = $false
    $files = @()
    $bytes = [double]0
    $latest = $null
    try {
        $exists = (Test-Path -LiteralPath $Path -PathType Container)
        if ($exists) {
            $files = @(Get-ChildItem -LiteralPath $Path -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 7500)
            foreach ($f in $files) { $bytes += [double]$f.Length }
            $latest = $files | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        }
    } catch {}
    $ageHours = $null
    if ($latest) {
        try { $ageHours = [math]::Round(((Get-Date) - $latest.LastWriteTime).TotalHours, 1) } catch { $ageHours = $null }
    }
    $pressure = if (-not $exists) { 'Unavailable' } elseif ($bytes -gt 8GB) { 'Heavy' } elseif ($bytes -gt 2GB) { 'Moderate' } elseif ($files.Count -gt 0) { 'Healthy' } else { 'Empty' }
    return [pscustomobject]@{
        label = $Label
        role = $Role
        path = $Path
        exists = $exists
        files = [int]$files.Count
        sizeBytes = [long]$bytes
        size = (Format-ApexBytes $bytes)
        latestWrite = if ($latest) { $latest.LastWriteTime.ToString('o') } else { $null }
        ageHours = $ageHours
        pressure = $pressure
    }
}

function Get-ApexShaderCaches {
    $local = [Environment]::GetFolderPath('LocalApplicationData')
    $programData = [Environment]::GetFolderPath('CommonApplicationData')
    $caches = @(
        [pscustomobject]@{ label='DirectX Shader Cache'; role='Windows D3D cache'; path=(Join-Path $local 'D3DSCache') },
        [pscustomobject]@{ label='NVIDIA DXCache'; role='NVIDIA DirectX pipelines'; path=(Join-Path $local 'NVIDIA\DXCache') },
        [pscustomobject]@{ label='NVIDIA GLCache'; role='NVIDIA OpenGL/Vulkan cache'; path=(Join-Path $local 'NVIDIA\GLCache') },
        [pscustomobject]@{ label='AMD DXCache'; role='AMD DirectX pipelines'; path=(Join-Path $local 'AMD\DxCache') },
        [pscustomobject]@{ label='Intel Shader Cache'; role='Intel graphics pipelines'; path=(Join-Path $local 'Intel\ShaderCache') },
        [pscustomobject]@{ label='Steam shader cache'; role='Steam pre-cached shaders'; path=(Join-Path $programData 'Steam\shadercache') }
    )
    $items = @()
    foreach ($cache in $caches) { $items += (Get-ApexDirectoryStats ([string]$cache.path) ([string]$cache.label) ([string]$cache.role)) }
    $totalBytes = [double]0
    $existing = 0
    $oldCaches = 0
    $heavyCaches = 0
    foreach ($item in $items) {
        if ($item.exists) { $existing++ }
        $totalBytes += [double]$item.sizeBytes
        if ($item.ageHours -ne $null -and [double]$item.ageHours -gt 720) { $oldCaches++ }
        if ([double]$item.sizeBytes -gt 4GB) { $heavyCaches++ }
    }
    $score = 92
    if ($existing -eq 0) { $score -= 16 }
    $score -= [math]::Min(20, $oldCaches * 4)
    $score -= [math]::Min(18, $heavyCaches * 6)
    if ($totalBytes -gt 12GB) { $score -= 10 }
    if ($score -lt 35) { $score = 35 }
    if ($score -gt 99) { $score = 99 }
    $state = if ($score -ge 86) { 'Ready' } elseif ($score -ge 70) { 'Healthy' } elseif ($score -ge 54) { 'Watch' } else { 'Rebuild likely' }
    $notes = @()
    if ($existing -eq 0) { $notes += 'No shader cache folders were detected yet. This is normal before launching games after a fresh install.' }
    if ($heavyCaches -gt 0) { $notes += 'One or more shader caches are very large. Do not clear them before a competitive session because games may need to rebuild.' }
    if ($oldCaches -gt 0) { $notes += 'Some caches have not been updated recently. A driver or game update may rebuild them on next launch.' }
    if (-not $notes.Count) { $notes += 'Shader cache state looks stable. Clearing is not recommended unless a specific game is broken.' }
    return [pscustomobject]@{
        score = [int]$score
        state = $state
        totalBytes = [long]$totalBytes
        totalSize = (Format-ApexBytes $totalBytes)
        existingCaches = $existing
        heavyCaches = $heavyCaches
        staleCaches = $oldCaches
        caches = $items
        notes = $notes
        generatedAt = (Get-Date).ToString('o')
    }
}

function Get-ApexRuntimeProcesses {
    $definitions = @(
        [pscustomobject]@{ match='discord|DiscordCanary|DiscordPTB'; label='Discord'; type='Chat / overlay'; baseImpact=15; canArbitrate=$false; advice='Disable the in-game overlay or hardware acceleration if frame pacing gets unstable.' },
        [pscustomobject]@{ match='obs64|obs32|obs'; label='OBS / replay capture'; type='Capture hook'; baseImpact=20; canArbitrate=$false; advice='Replay buffers are useful, but they can add encoding and GPU hook pressure.' },
        [pscustomobject]@{ match='overwolf|medal|outplayed|steelseries|moments'; label='Game overlay / clip tool'; type='Overlay hook'; baseImpact=24; canArbitrate=$false; advice='Test with clip overlays disabled when chasing micro-stutter.' },
        [pscustomobject]@{ match='chrome|msedge|brave|firefox|opera|vivaldi'; label='Browser'; type='GPU decode / tabs'; baseImpact=14; canArbitrate=$true; advice='Close streams, disable hardware acceleration, or let Session Mode lower priority.' },
        [pscustomobject]@{ match='OneDrive|GoogleDriveFS|Dropbox'; label='Cloud sync'; type='Storage/network sync'; baseImpact=18; canArbitrate=$true; advice='Pause syncing during ranked sessions or heavy downloads.' },
        [pscustomobject]@{ match='steam|EpicGamesLauncher|Battle.net|EADesktop|UbisoftConnect|RiotClientServices'; label='Game launcher'; type='Launcher / updater'; baseImpact=10; canArbitrate=$true; advice='Avoid downloads and client updates while playing.' },
        [pscustomobject]@{ match='iCUE|Razer|Synapse|ArmouryCrate|Aura|GHUB|LCore|MysticLight|RGBFusion'; label='RGB / peripheral suite'; type='Polling / telemetry'; baseImpact=12; canArbitrate=$true; advice='Reduce polling effects or close RGB dashboards if periodic spikes appear.' },
        [pscustomobject]@{ match='MsMpEng|NisSrv|SecurityHealthService'; label='Windows security scan'; type='Antivirus'; baseImpact=16; canArbitrate=$false; advice='Schedule scans away from gaming. Do not disable protection permanently.' }
    )
    $all = @()
    try { $all = @(Get-Process -ErrorAction SilentlyContinue) } catch {}
    $hits = @()
    foreach ($def in $definitions) {
        $matched = @($all | Where-Object { $_.ProcessName -match ([string]$def.match) })
        if (-not $matched.Count) { continue }
        $memMB = 0.0
        $cpuSec = 0.0
        foreach ($p in $matched) {
            try { $memMB += ([double]$p.WorkingSet64 / 1MB) } catch {}
            try { if ($p.CPU -ne $null) { $cpuSec += [double]$p.CPU } } catch {}
        }
        $severity = [int][math]::Round([double]$def.baseImpact + [math]::Min(24, ($memMB / 700)) + [math]::Min(10, ($matched.Count - 1) * 2))
        if ($severity -gt 100) { $severity = 100 }
        $hits += [pscustomobject]@{
            label = [string]$def.label
            type = [string]$def.type
            count = [int]$matched.Count
            memoryMB = [int][math]::Round($memMB)
            cpuSeconds = [int][math]::Round($cpuSec)
            impact = $severity
            canArbitrate = [bool]$def.canArbitrate
            advice = [string]$def.advice
            processes = @($matched | Select-Object -First 6 -Property Id,ProcessName)
        }
    }
    return @($hits | Sort-Object impact -Descending)
}

function Get-ApexDriverTimeline {
    $hw = Get-HardwareSnapshot
    $events = @()
    if (Test-Path -LiteralPath $script:DriverTimelinePath -PathType Leaf) {
        try {
            $raw = Get-Content -Raw -LiteralPath $script:DriverTimelinePath -ErrorAction Stop
            if (-not [string]::IsNullOrWhiteSpace($raw)) { $events = @($raw | ConvertFrom-Json) }
        } catch { $events = @() }
    }
    $driverDate = ''
    try {
        $gpuName = [string]$hw.gpu.name
        $drv = Get-CimInstance Win32_PnPSignedDriver -OperationTimeoutSec 3 -ErrorAction SilentlyContinue |
            Where-Object { $_.DeviceName -and ($_.DeviceName -eq $gpuName -or [string]$_.DeviceName -match 'NVIDIA|AMD|Radeon|Intel|Arc|GeForce|RTX|GTX') } |
            Select-Object -First 1
        if ($drv) { $driverDate = [string]$drv.DriverDate }
    } catch {}
    $currentKey = (([string]$hw.gpu.name) + '|' + ([string]$hw.gpu.driverVersion)).Trim('|')
    $known = $false
    foreach ($event in @($events)) {
        if ([string](Get-ApexPropValue $event 'key' '') -eq $currentKey) { $known = $true; break }
    }
    if (-not $known -and -not [string]::IsNullOrWhiteSpace($currentKey)) {
        $events += [pscustomobject]@{
            key = $currentKey
            kind = 'Detected driver'
            gpu = [string]$hw.gpu.name
            version = [string]$hw.gpu.driverVersion
            driverDate = $driverDate
            detectedAt = (Get-Date).ToString('o')
            effect = 'Baseline saved for future regression comparisons.'
        }
        try { @($events | Select-Object -Last 30) | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:DriverTimelinePath -Encoding UTF8 } catch {}
    }
    return [pscustomobject]@{
        current = [pscustomobject]@{ gpu=$hw.gpu.name; vendor=$hw.gpu.vendor; version=$hw.gpu.driverVersion; driverDate=$driverDate }
        events = @($events | Select-Object -Last 12)
        path = $script:DriverTimelinePath
    }
}

function Get-ApexHardwareConstraints([object]$Status, [object]$Shader, [object[]]$Runtime) {
    $items = @()
    $ram = [int](Get-ApexPropValue $Status 'ram' 0)
    $cpu = [int](Get-ApexPropValue $Status 'cpu' 0)
    $gpuUsage = [int](Get-ApexPropValue $Status 'gpuUsage' 0)
    $gpuRam = [double](Get-ApexPropValue $Status 'gpuAdapterRamGB' 0)
    $system = [string](Get-ApexPropValue $Status 'system' 'PC')
    if ($ram -ge 88) { $items += [pscustomobject]@{ label='Memory pressure'; severity='High'; detail="RAM usage is $ram%. Paging or compression can cause hitches." } }
    elseif ($ram -ge 76) { $items += [pscustomobject]@{ label='Memory pressure'; severity='Medium'; detail="RAM usage is $ram%. Close browsers or launchers before ranked games." } }
    if ($cpu -ge 88) { $items += [pscustomobject]@{ label='CPU scheduling pressure'; severity='High'; detail="CPU load is $cpu%. Shader compilation and input responsiveness may suffer." } }
    elseif ($cpu -ge 72) { $items += [pscustomobject]@{ label='CPU scheduling pressure'; severity='Medium'; detail="CPU load is $cpu%. Watch for queue starvation during fights." } }
    if ($gpuUsage -ge 96) { $items += [pscustomobject]@{ label='GPU saturation'; severity='High'; detail='GPU is near saturation. FPS caps or lower GPU-heavy settings can reduce latency.' } }
    if ($gpuRam -gt 0 -and $gpuRam -le 4) { $items += [pscustomobject]@{ label='VRAM budget'; severity='Medium'; detail="Adapter VRAM is reported as $gpuRam GB. Texture settings can cause residency churn." } }
    if ($system -match 'Laptop') { $items += [pscustomobject]@{ label='Laptop thermal watch'; severity='Info'; detail='Laptop boost clocks can oscillate under heat. Keep AC power and cooling stable.' } }
    if ([int](Get-ApexPropValue $Shader 'score' 100) -lt 70) { $items += [pscustomobject]@{ label='Shader cache health'; severity='Medium'; detail='Shader state indicates possible rebuild or cache pressure.' } }
    if (@($Runtime).Count -ge 3) { $items += [pscustomobject]@{ label='Runtime interference'; severity='Medium'; detail='Multiple overlay/background systems are active while tuning.' } }
    if (-not $items.Count) { $items += [pscustomobject]@{ label='No major hardware constraint detected'; severity='Good'; detail='Current telemetry does not show a hard software-visible bottleneck.' } }
    return $items
}

function Get-ApexRuntimeSessionState {
    if (-not (Test-Path -LiteralPath $script:RuntimeSessionPath -PathType Leaf)) {
        return [pscustomobject]@{ active=$false; path=$script:RuntimeSessionPath; startedAt=$null; endedAt=$null; restored=@(); changed=@(); errors=@() }
    }
    try {
        $raw = Get-Content -Raw -LiteralPath $script:RuntimeSessionPath -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { throw 'Empty session state' }
        return ($raw | ConvertFrom-Json)
    } catch {
        return [pscustomobject]@{ active=$false; path=$script:RuntimeSessionPath; startedAt=$null; endedAt=$null; restored=@(); changed=@(); errors=@('Session state could not be read: ' + $_.Exception.Message) }
    }
}

function Save-ApexRuntimeSessionState($State) {
    $State | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $script:RuntimeSessionPath -Encoding UTF8
    return $script:RuntimeSessionPath
}

function Invoke-ApexRuntimeSessionStart($Body) {
    $existing = Get-ApexRuntimeSessionState
    if ([bool](Get-ApexPropValue $existing 'active' $false)) { return [pscustomobject]@{ ok=$true; message='Gaming Session Mode is already active.'; session=$existing } }
    $aggressive = [bool](Get-ApexPropValue $Body 'aggressive' $false)
    $allowed = @('chrome','msedge','brave','firefox','opera','vivaldi','OneDrive','GoogleDriveFS','Dropbox','steam','EpicGamesLauncher','Battle.net','EADesktop','UbisoftConnect','RiotClientServices','iCUE','Razer','Synapse','ArmouryCrate','Aura','GHUB','LCore','MysticLight','RGBFusion')
    if ($aggressive) { $allowed += @('Discord','DiscordCanary','DiscordPTB','obs64','obs32','obs','Overwolf','Medal') }
    $changed = @()
    $errors = @()
    $procs = @()
    try { $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $allowed -contains $_.ProcessName }) } catch {}
    foreach ($p in $procs) {
        try {
            $old = [string]$p.PriorityClass
            if ($old -ne 'Idle' -and $old -ne 'BelowNormal') {
                $p.PriorityClass = 'BelowNormal'
                $changed += [pscustomobject]@{ id=[int]$p.Id; name=[string]$p.ProcessName; oldPriority=$old; newPriority='BelowNormal' }
            }
        } catch { $errors += "Could not tune $($p.ProcessName)#$($p.Id): $($_.Exception.Message)" }
    }
    $state = [pscustomobject]@{
        active = $true
        aggressive = $aggressive
        startedAt = (Get-Date).ToString('o')
        endedAt = $null
        changed = $changed
        restored = @()
        errors = $errors
        path = $script:RuntimeSessionPath
    }
    Save-ApexRuntimeSessionState $state | Out-Null
    $msg = if ($changed.Count) { "Gaming Session Mode active. Lowered priority for $($changed.Count) background process(es)." } else { 'Gaming Session Mode active. No safe background process priority changes were needed.' }
    return [pscustomobject]@{ ok=$true; message=$msg; session=$state }
}

function Invoke-ApexRuntimeSessionStop {
    $state = Get-ApexRuntimeSessionState
    if (-not [bool](Get-ApexPropValue $state 'active' $false)) { return [pscustomobject]@{ ok=$true; message='Gaming Session Mode is not active.'; session=$state } }
    $restored = @()
    $errors = @()
    foreach ($entry in @($state.changed)) {
        try {
            $id = [int](Get-ApexPropValue $entry 'id' 0)
            if ($id -le 0) { continue }
            $p = Get-Process -Id $id -ErrorAction SilentlyContinue
            if ($p) {
                $old = [string](Get-ApexPropValue $entry 'oldPriority' 'Normal')
                $p.PriorityClass = $old
                $restored += [pscustomobject]@{ id=$id; name=[string]$p.ProcessName; restoredPriority=$old }
            }
        } catch { $errors += "Could not restore process ${id}: $($_.Exception.Message)" }
    }
    $state | Add-Member -NotePropertyName active -NotePropertyValue $false -Force
    $state | Add-Member -NotePropertyName endedAt -NotePropertyValue (Get-Date).ToString('o') -Force
    $state | Add-Member -NotePropertyName restored -NotePropertyValue $restored -Force
    $state | Add-Member -NotePropertyName errors -NotePropertyValue (@($state.errors) + $errors) -Force
    Save-ApexRuntimeSessionState $state | Out-Null
    return [pscustomobject]@{ ok=$true; message="Gaming Session Mode restored $($restored.Count) process(es)."; session=$state }
}

function Get-ApexFrameSyncInfo([object]$Status) {
    $refresh = 0
    try {
        $v = Get-CimInstance Win32_VideoController -OperationTimeoutSec 2 -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($v -and $v.CurrentRefreshRate) { $refresh = [int]$v.CurrentRefreshRate }
    } catch {}
    $gpuVendor = [string](Get-ApexPropValue $Status 'gpuVendor' 'GPU')
    $score = 78
    if ($refresh -ge 120) { $score += 8 } elseif ($refresh -gt 0 -and $refresh -lt 75) { $score -= 8 }
    if ($gpuVendor -match 'NVIDIA|AMD|Intel') { $score += 4 }
    if ($score -gt 96) { $score = 96 }
    if ($score -lt 45) { $score = 45 }
    $state = if ($score -ge 88) { 'Locked' } elseif ($score -ge 74) { 'Active' } elseif ($score -ge 58) { 'Watch' } else { 'Fragmented' }
    return [pscustomobject]@{
        score = [int]$score
        state = $state
        refreshRate = $refresh
        vrrGuidance = 'Use an FPS cap slightly below refresh rate when VRR is active, then test frame pacing.'
    }
}

function Get-ApexIntelligenceCenter([switch]$Refresh) {
    $now = [datetime]::UtcNow
    if (-not $Refresh -and $script:IntelligenceCache -and (($now - $script:IntelligenceCacheAt).TotalSeconds -lt 3)) { return $script:IntelligenceCache }
    $status = Get-Status
    $shader = Get-ApexShaderCaches
    $runtime = @(Get-ApexRuntimeProcesses)
    $driver = Get-ApexDriverTimeline
    $session = Get-ApexRuntimeSessionState
    $sync = Get-ApexFrameSyncInfo $status
    $cpu = [int](Get-ApexPropValue $status 'cpu' 0)
    $ram = [int](Get-ApexPropValue $status 'ram' 0)
    $gpu = [int](Get-ApexPropValue $status 'gpuUsage' 0)
    $ping = [int](Get-ApexPropValue $status 'ping' 0)
    $runtimePenalty = 0
    foreach ($r in $runtime) { $runtimePenalty += [int](Get-ApexPropValue $r 'impact' 0) }
    if ($runtimePenalty -gt 34) { $runtimePenalty = 34 }
    $latencyPenalty = if ($ping -le 0) { 8 } elseif ($ping -le 35) { 0 } elseif ($ping -le 70) { 7 } elseif ($ping -le 120) { 15 } else { 24 }
    $shaderScore = [int](Get-ApexPropValue $shader 'score' 100)
    $syncScore = [int](Get-ApexPropValue $sync 'score' 78)
    $frameScore = [int][math]::Round(100 - ($cpu * 0.16) - ($ram * 0.12) - ($gpu * 0.08) - $latencyPenalty - ($runtimePenalty * 0.34) - ((100 - $shaderScore) * 0.18))
    if ($frameScore -gt 99) { $frameScore = 99 }
    if ($frameScore -lt 30) { $frameScore = 30 }
    $smoothScore = [int][math]::Round(($frameScore * 0.42) + ($shaderScore * 0.24) + ($syncScore * 0.18) + ((100 - [math]::Min(100, $runtimePenalty * 2)) * 0.16))
    if ($smoothScore -gt 99) { $smoothScore = 99 }
    if ($smoothScore -lt 30) { $smoothScore = 30 }
    $latencyScore = [int](100 - $latencyPenalty - [math]::Min(25, $runtimePenalty * 0.30) - [math]::Min(18, $gpu * 0.08))
    if ($latencyScore -gt 99) { $latencyScore = 99 }
    if ($latencyScore -lt 28) { $latencyScore = 28 }
    $traversalScore = [int][math]::Round(($shaderScore * 0.56) + ((100 - $ram) * 0.22) + ((100 - [math]::Min(100, $runtimePenalty * 2)) * 0.22))
    if ($traversalScore -gt 99) { $traversalScore = 99 }
    if ($traversalScore -lt 30) { $traversalScore = 30 }
    $frameState = if ($frameScore -ge 88) { 'Locked' } elseif ($frameScore -ge 74) { 'Stable' } elseif ($frameScore -ge 58) { 'Watch' } else { 'Unstable' }
    $smoothState = if ($smoothScore -ge 88) { 'Excellent' } elseif ($smoothScore -ge 74) { 'Good' } elseif ($smoothScore -ge 58) { 'Tunable' } else { 'Critical' }
    $latencyState = if ($latencyScore -ge 88) { 'Excellent' } elseif ($latencyScore -ge 74) { 'Good' } elseif ($latencyScore -ge 58) { 'Watch' } else { 'High jitter risk' }
    $traversalState = if ($traversalScore -ge 84) { 'Ready' } elseif ($traversalScore -ge 68) { 'Watch' } else { 'Hitch risk' }
    $issues = @()
    if ($ping -gt 80) { $issues += [pscustomobject]@{ severity='High'; title='Latency instability'; detail="Current ping is $ping ms. Run the Latency Center probe and check downloads." } }
    if ($ram -gt 84) { $issues += [pscustomobject]@{ severity='High'; title='Memory pressure'; detail="RAM is $ram%. This can cause paging or texture streaming hitches." } }
    if ($shaderScore -lt 72) { $issues += [pscustomobject]@{ severity='Medium'; title='Shader cache watch'; detail='Shader cache state suggests rebuild, stale cache, or heavy cache pressure.' } }
    if ($runtime.Count -gt 0) { $issues += [pscustomobject]@{ severity='Medium'; title='Runtime interference'; detail="$($runtime.Count) overlay/background category/categories are active." } }
    if (-not $issues.Count) { $issues += [pscustomobject]@{ severity='Good'; title='Runtime looks stable'; detail='No severe frame integrity problem was detected from safe telemetry.' } }
    $recommendations = @(
        [pscustomobject]@{ title='Use Session Mode before ranked play'; detail='Temporarily lowers safe background process priority and restores it when stopped.'; action='session:start' },
        [pscustomobject]@{ title='Avoid blind shader cache clearing'; detail='Analyze shader cache health first. Clearing can make the next launch stutter while shaders rebuild.'; action='shader:report' },
        [pscustomobject]@{ title='Test overlays one at a time'; detail='Disable Discord, capture, and launcher overlays individually to isolate frametime problems.'; action='overlay:audit' }
    )
    $constraints = Get-ApexHardwareConstraints $status $shader $runtime
    $result = [pscustomobject]@{
        ok = $true
        version = $script:Version
        generatedAt = (Get-Date).ToString('o')
        status = $status
        frameIntegrity = [pscustomobject]@{ score=$frameScore; state=$frameState; detail='Weighted from CPU, RAM, GPU, ping, shader health, and background interference.' }
        smoothness = [pscustomobject]@{ score=$smoothScore; state=$smoothState; detail='Micro-stutter probability estimate from safe runtime telemetry.' }
        latency = [pscustomobject]@{ score=$latencyScore; state=$latencyState; ping=$ping; detail='Input/network responsiveness risk estimate.' }
        traversal = [pscustomobject]@{ score=$traversalScore; state=$traversalState; detail='Traversal stutter risk using shader, memory, and background pressure.' }
        frameSync = $sync
        shader = $shader
        runtime = [pscustomobject]@{ totalImpact=$runtimePenalty; items=$runtime }
        driver = $driver
        session = $session
        constraints = $constraints
        issues = $issues
        recommendations = $recommendations
        folders = [pscustomobject]@{ intelligence=$script:IntelligenceDir; sessions=$script:SessionDir }
    }
    $script:IntelligenceCache = $result
    $script:IntelligenceCacheAt = $now
    return $result
}

function New-ApexIntelligenceReport {
    $data = Get-ApexIntelligenceCenter -Refresh
    $file = Join-Path $script:IntelligenceDir ('ApexTune-Intelligence-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $data | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $file -Encoding UTF8
    return $file
}

function New-ApexShaderReport {
    $data = Get-ApexShaderCaches
    $file = Join-Path $script:IntelligenceDir ('ApexTune-ShaderHealth-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $data | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $file -Encoding UTF8
    return $file
}

function Convert-RegHiveName([string]$Key) {
    if ($Key -like 'HKLM\*') { return $Key -replace '^HKLM', 'HKEY_LOCAL_MACHINE' }
    if ($Key -like 'HKCU\*') { return $Key -replace '^HKCU', 'HKEY_CURRENT_USER' }
    if ($Key -like 'HKCR\*') { return $Key -replace '^HKCR', 'HKEY_CLASSES_ROOT' }
    if ($Key -like 'HKU\*') { return $Key -replace '^HKU', 'HKEY_USERS' }
    return $Key
}

function Get-SafeName([string]$Name) {
    return ($Name -replace '[^A-Za-z0-9._-]+', '_').Trim('_')
}


function Get-ApexHash([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return (($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)) | ForEach-Object { $_.ToString('x2') }) -join '').Substring(0, 32)
    } finally { $sha.Dispose() }
}

function Read-StartupState {
    if (-not (Test-Path $script:StartupStatePath -PathType Leaf)) { return @() }
    try {
        $raw = Get-Content -Raw -Path $script:StartupStatePath -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw | ConvertFrom-Json)
    } catch {
        Write-ApexLog "Startup state read failed: $($_.Exception.Message)" 'WARN'
        return @()
    }
}

function Save-StartupState($Items) {
    @($Items) | ConvertTo-Json -Depth 10 | Set-Content -Path $script:StartupStatePath -Encoding UTF8
}

function Read-TweakStateMap {
    $map = @{}
    if (-not (Test-Path $script:TweakStatePath -PathType Leaf)) { return $map }
    try {
        $raw = Get-Content -Raw -Path $script:TweakStatePath -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { return $map }
        $obj = $raw | ConvertFrom-Json
        if ($obj) {
            foreach ($p in @($obj.PSObject.Properties)) {
                if ($p.Name) { $map[([string]$p.Name)] = $p.Value }
            }
        }
    } catch {
        Write-ApexLog "Tweak state read failed: $($_.Exception.Message)" 'WARN'
    }
    return $map
}

function Save-TweakStateMap([hashtable]$Map) {
    $ordered = [ordered]@{}
    foreach ($k in @($Map.Keys | Sort-Object)) { $ordered[([string]$k)] = $Map[$k] }
    ($ordered | ConvertTo-Json -Depth 16) | Set-Content -Path $script:TweakStatePath -Encoding UTF8
}

function Get-TweakState {
    return [pscustomobject]@{ states = (Read-TweakStateMap); path = $script:TweakStatePath; saved = (Test-Path $script:TweakStatePath -PathType Leaf) }
}

function Set-TweakStateRecords($Tweaks, [string]$Status, [hashtable]$Extra = @{}) {
    $map = Read-TweakStateMap
    $now = (Get-Date).ToString('o')
    foreach ($t in @($Tweaks)) {
        if (-not $t -or [string]::IsNullOrWhiteSpace([string]$t.id)) { continue }
        $rec = [ordered]@{
            id = [string]$t.id
            title = [string]$t.title
            category = [string]$t.category
            risk = [string]$t.risk
            status = $Status
            updatedAt = $now
        }
        if ($Status -eq 'applied') { $rec['appliedAt'] = $now }
        elseif ($Status -eq 'disabled') { $rec['disabledAt'] = $now }
        elseif ($Status -eq 'rollback_failed') { $rec['rollbackFailedAt'] = $now }
        elseif ($Status -eq 'queued') { $rec['queuedAt'] = $now }
        foreach ($key in @($Extra.Keys)) { $rec[([string]$key)] = $Extra[$key] }
        $map[([string]$t.id)] = [pscustomobject]$rec
    }
    Save-TweakStateMap $map
    return $script:TweakStatePath
}

function Get-RegStartupItems([string]$ProviderPath, [string]$DisplayLocation, [bool]$NeedsAdmin) {
    $items = @()
    try {
        if (-not (Test-Path $ProviderPath)) { return @() }
        $props = Get-ItemProperty -LiteralPath $ProviderPath -ErrorAction Stop
        foreach ($p in @($props.PSObject.Properties)) {
            if (@('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') -contains $p.Name) { continue }
            if ($null -eq $p.Value) { continue }
            $name = [string]$p.Name
            $cmd = [string]$p.Value
            $id = Get-ApexHash ("registry|$ProviderPath|$name")
            $items += [pscustomobject]@{
                id = $id
                type = 'registry'
                name = $name
                command = $cmd
                location = $DisplayLocation
                providerPath = $ProviderPath
                valueName = $name
                enabled = $true
                disabled = $false
                needsAdmin = $NeedsAdmin
                source = 'Registry Run key'
            }
        }
    } catch { Write-ApexLog "Startup registry scan failed for $ProviderPath : $($_.Exception.Message)" 'WARN' }
    return $items
}

function Get-StartupFolderPath([string]$Kind) {
    try {
        if ($Kind -eq 'CommonStartup') { return [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonStartup) }
        return [Environment]::GetFolderPath([Environment+SpecialFolder]::Startup)
    } catch { return $null }
}

function Get-FileStartupItems([string]$Folder, [string]$DisplayLocation, [bool]$NeedsAdmin) {
    $items = @()
    if ([string]::IsNullOrWhiteSpace($Folder) -or -not (Test-Path $Folder -PathType Container)) { return @() }
    try {
        foreach ($f in @(Get-ChildItem -LiteralPath $Folder -File -ErrorAction Stop)) {
            $id = Get-ApexHash ("file|$($f.FullName)")
            $items += [pscustomobject]@{
                id = $id
                type = 'file'
                name = $f.BaseName
                command = $f.FullName
                location = $DisplayLocation
                path = $f.FullName
                enabled = $true
                disabled = $false
                needsAdmin = $NeedsAdmin
                source = 'Startup folder'
            }
        }
    } catch { Write-ApexLog "Startup folder scan failed for $Folder : $($_.Exception.Message)" 'WARN' }
    return $items
}

function Get-StartupItemsRaw {
    $items = @()
    $items += Get-RegStartupItems 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run' 'HKCU Run' $false
    $items += Get-RegStartupItems 'Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\RunOnce' 'HKCU RunOnce' $false
    $items += Get-RegStartupItems 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run' 'HKLM Run' $true
    $items += Get-RegStartupItems 'Registry::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\RunOnce' 'HKLM RunOnce' $true
    $items += Get-RegStartupItems 'Registry::HKEY_LOCAL_MACHINE\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' 'HKLM WOW6432 Run' $true
    $items += Get-FileStartupItems (Get-StartupFolderPath 'Startup') 'Startup folder' $false
    $items += Get-FileStartupItems (Get-StartupFolderPath 'CommonStartup') 'Common Startup folder' $true

    $disabled = @()
    foreach ($d in @(Read-StartupState)) {
        $disabled += [pscustomobject]@{
            id = [string]$d.id
            type = [string]$d.type
            name = [string]$d.name
            command = [string]$d.command
            location = [string]$d.location
            providerPath = [string]$d.providerPath
            valueName = [string]$d.valueName
            path = [string]$d.path
            disabledPath = [string]$d.disabledPath
            enabled = $false
            disabled = $true
            needsAdmin = [bool]$d.needsAdmin
            source = 'Disabled by ApexTune'
            disabledAt = [string]$d.disabledAt
        }
    }
    return @($items + $disabled | Sort-Object @{Expression='enabled';Descending=$true}, name)
}

function Clear-StartupCache {
    $script:StartupCache = $null
    $script:StartupCacheAt = [datetime]::MinValue
}

function Clear-GpuDriverCache {
    $script:GpuDriverCache = $null
    $script:GpuDriverCacheAt = [datetime]::MinValue
$script:StatusCache = $null
$script:StatusCacheAt = [datetime]::MinValue
$script:HardwareCache = $null
$script:HardwareCacheAt = [datetime]::MinValue
$script:IntelligenceCache = $null
$script:IntelligenceCacheAt = [datetime]::MinValue
}

function Get-StartupItems([switch]$Refresh) {
    $now = [datetime]::UtcNow
    if ((-not $Refresh) -and $script:StartupCache -and (($now - $script:StartupCacheAt).TotalSeconds -lt 60)) {
        return @($script:StartupCache)
    }
    $items = @(Get-StartupItemsRaw)
    $script:StartupCache = $items
    $script:StartupCacheAt = $now
    return @($items)
}

function Disable-StartupItem([string]$Id) {
    $item = @(Get-StartupItems -Refresh | Where-Object { $_.id -eq $Id -and $_.enabled } | Select-Object -First 1)
    if (-not $item) { throw 'Startup item was not found or is already disabled.' }
    if ($item.needsAdmin -and -not (Test-IsAdmin)) { throw 'Launch ApexTune as Administrator to change machine-wide startup entries.' }
    $state = @(Read-StartupState | Where-Object { $_.id -ne $Id })
    $record = [pscustomobject]@{
        id = $item.id
        type = $item.type
        name = $item.name
        command = $item.command
        location = $item.location
        providerPath = $item.providerPath
        valueName = $item.valueName
        path = $item.path
        disabledPath = $null
        needsAdmin = $item.needsAdmin
        disabledAt = (Get-Date).ToString('o')
    }
    if ($item.type -eq 'registry') {
        Remove-ItemProperty -LiteralPath $item.providerPath -Name $item.valueName -Force -ErrorAction Stop
    } elseif ($item.type -eq 'file') {
        New-Item -ItemType Directory -Path $script:DisabledStartupDir -Force | Out-Null
        $target = Join-Path $script:DisabledStartupDir ((Get-SafeName ($item.id + '-' + (Split-Path $item.path -Leaf))) )
        Move-Item -LiteralPath $item.path -Destination $target -Force -ErrorAction Stop
        $record.disabledPath = $target
    } else { throw 'Unsupported startup entry type.' }
    $state += $record
    Save-StartupState $state
    Clear-StartupCache
    return [pscustomobject]@{ ok=$true; message="Disabled startup item: $($item.name)"; item=$record }
}

function Enable-StartupItem([string]$Id) {
    $state = @(Read-StartupState)
    $record = @($state | Where-Object { $_.id -eq $Id } | Select-Object -First 1)
    if (-not $record) { throw 'Disabled startup item was not found.' }
    if ([bool]$record.needsAdmin -and -not (Test-IsAdmin)) { throw 'Launch ApexTune as Administrator to restore machine-wide startup entries.' }
    if ($record.type -eq 'registry') {
        New-Item -Path $record.providerPath -Force | Out-Null
        New-ItemProperty -LiteralPath $record.providerPath -Name $record.valueName -PropertyType String -Value $record.command -Force | Out-Null
    } elseif ($record.type -eq 'file') {
        $folder = Split-Path ([string]$record.path) -Parent
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
        if (-not (Test-Path ([string]$record.disabledPath) -PathType Leaf)) { throw 'Saved startup shortcut was not found in the ApexTune disabled startup folder.' }
        Move-Item -LiteralPath ([string]$record.disabledPath) -Destination ([string]$record.path) -Force -ErrorAction Stop
    } else { throw 'Unsupported startup entry type.' }
    $state = @($state | Where-Object { $_.id -ne $Id })
    Save-StartupState $state
    Clear-StartupCache
    return [pscustomobject]@{ ok=$true; message="Restored startup item: $($record.name)" }
}



function Get-ApexGameProp($Obj, [string]$Name, $Default = $null) {
    if ($null -eq $Obj -or [string]::IsNullOrWhiteSpace($Name)) { return $Default }
    try {
        $prop = $Obj.PSObject.Properties[$Name]
        if ($prop) { return $prop.Value }
    } catch {}
    return $Default
}

function Get-GameCatalog {
    $path = Join-Path $script:DataRoot 'games.json'
    if (-not (Test-Path $path -PathType Leaf)) { return @() }
    try { return @(Get-Content -Raw -Path $path | ConvertFrom-Json) } catch { Write-ApexLog "Game catalog read failed: $($_.Exception.Message)" 'WARN'; return @() }
}

function Get-GameCatalogForUi {
    $out = @()
    foreach ($g in @(Get-GameCatalog)) {
        $out += [pscustomobject]@{
            id=$g.id; name=$g.name; short=$g.short; genre=$g.genre; steamAppIds=$g.steamAppIds; exeNames=$g.exeNames; folderNames=$g.folderNames; accent=$g.accent; accent2=$g.accent2; thumbnail=$g.thumbnail; thumbnailUrl=$g.thumbnailUrl; thumbnailUrls=(Get-ApexGameProp $g 'thumbnailUrls' @()); profiles=$g.profiles; tags=$g.tags; detected=$false; manual=$false; installPath=$null; exePath=$null; detectionSource='Catalog'; confidence=0; scanError=$null
        }
    }
    return @($out)
}

function Get-GameOverrideMap {
    $map = @{}
    if (-not (Test-Path $script:GameManualPath -PathType Leaf)) { return $map }
    try {
        $raw = Get-Content -Raw -Path $script:GameManualPath -ErrorAction Stop
        if (-not $raw.Trim()) { return $map }
        $obj = $raw | ConvertFrom-Json
        if ($obj) {
            foreach ($p in @($obj.PSObject.Properties)) {
                if ($p.Name) { $map[([string]$p.Name)] = $p.Value }
            }
        }
    } catch {
        Write-ApexLog "Manual game path store read failed: $($_.Exception.Message)" 'WARN'
    }
    return $map
}

function Save-GameOverrideMap([hashtable]$Map) {
    $ordered = [ordered]@{}
    foreach ($k in @($Map.Keys | Sort-Object)) { $ordered[([string]$k)] = $Map[$k] }
    ($ordered | ConvertTo-Json -Depth 12) | Set-Content -Path $script:GameManualPath -Encoding UTF8
}

function Get-GameManualOverride([string]$GameId) {
    if ([string]::IsNullOrWhiteSpace($GameId)) { return $null }
    $map = Get-GameOverrideMap
    if ($map.ContainsKey($GameId)) { return $map[$GameId] }
    return $null
}

function Show-GamePathDialog([object]$Game) {
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        $ofd = New-Object System.Windows.Forms.OpenFileDialog
        $ofd.Title = "Select $($Game.name) game executable"
        $ofd.Filter = 'Game executable (*.exe)|*.exe|All files (*.*)|*.*'
        $ofd.CheckFileExists = $true
        $ofd.Multiselect = $false
        $result = $ofd.ShowDialog()
        if ($result -eq [System.Windows.Forms.DialogResult]::OK -and $ofd.FileName) { return [string]$ofd.FileName }
        $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
        $fbd.Description = "Select the $($Game.name) install folder"
        $fbd.ShowNewFolderButton = $false
        $folderResult = $fbd.ShowDialog()
        if ($folderResult -eq [System.Windows.Forms.DialogResult]::OK -and $fbd.SelectedPath) { return [string]$fbd.SelectedPath }
    } catch {
        Write-ApexLog "Game picker dialog failed: $($_.Exception.Message)" 'WARN'
    }
    return $null
}

function Normalize-GameText([object]$Value) {
    $s = ([string]$Value).Trim().ToLowerInvariant()
    if (-not $s) { return '' }
    $s = $s -replace '&',' and '
    $s = $s -replace '[^a-z0-9]+',' '
    return ($s -replace '\s+',' ').Trim()
}

function Get-GameNeedles([object]$Game) {
    $items = @([string]$Game.name)
    try { $items += @($Game.folderNames | ForEach-Object { [string]$_ }) } catch {}
    try { $items += @($Game.exeNames | ForEach-Object { [IO.Path]::GetFileNameWithoutExtension([string]$_) }) } catch {}
    return @($items | ForEach-Object { Normalize-GameText $_ } | Where-Object { $_ -and $_.Length -ge 2 } | Select-Object -Unique)
}

function Test-GameNameMatch([object]$Game, [string]$Haystack) {
    $hay = (Normalize-GameText $Haystack)
    if (-not $hay) { return $false }
    foreach ($needle in @(Get-GameNeedles $Game)) {
        if ($needle -and ($hay -eq $needle -or $hay.Contains($needle) -or $needle.Contains($hay))) { return $true }
    }
    return $false
}

function New-GameInstallRecord([string]$Source, [string]$Name, [string]$InstallPath, [string]$ExePath=$null, [string]$AppId=$null, [int]$Confidence=0, [string]$MatchedBy='') {
    return [pscustomobject]@{
        source=$Source
        name=$Name
        normalizedName=(Normalize-GameText $Name)
        installPath=$InstallPath
        exePath=$ExePath
        appId=$AppId
        confidence=$Confidence
        matchedBy=$MatchedBy
    }
}

function Read-ValveAcfValue([string]$Raw, [string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Raw) -or [string]::IsNullOrWhiteSpace($Name)) { return $null }
    $m = [regex]::Match($Raw, '"' + [regex]::Escape($Name) + '"\s+"([^"]*)"')
    if ($m.Success) { return $m.Groups[1].Value }
    return $null
}

function Get-SteamRootCandidates {
    $roots = @()
    try { $v = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath; if ($v) { $roots += $v } } catch {}
    try { $v = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction Stop).InstallPath; if ($v) { $roots += $v } } catch {}
    $roots += @("${env:ProgramFiles(x86)}\Steam", "$env:ProgramFiles\Steam", 'C:\Steam')
    try {
        foreach ($drive in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
            if ($drive.Root) {
                $roots += (Join-Path $drive.Root 'Steam')
                $roots += (Join-Path $drive.Root 'SteamLibrary')
            }
        }
    } catch {}
    return @($roots | ForEach-Object { ([string]$_).Replace('/', '\') } | Where-Object { $_ -and (Test-Path $_ -PathType Container) } | Select-Object -Unique)
}

function Get-SteamLibraries {
    $libs = @()
    foreach ($rootPath in @(Get-SteamRootCandidates)) {
        if (Test-Path (Join-Path $rootPath 'steamapps') -PathType Container) { $libs += $rootPath }
        $vdf = Join-Path $rootPath 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf -PathType Leaf) {
            try {
                $raw = Get-Content -Raw -Path $vdf
                foreach ($m in [regex]::Matches($raw, '"path"\s+"([^"]+)"')) {
                    $p = $m.Groups[1].Value -replace '\\\\','\'
                    $p = $p.Replace('/', '\')
                    if ($p -and (Test-Path $p -PathType Container)) { $libs += $p }
                }
            } catch { Write-ApexLog "Steam libraryfolders read failed for ${rootPath}: $($_.Exception.Message)" 'WARN' }
        }
    }
    return @($libs | Select-Object -Unique)
}

function Get-SteamInstallRecords {
    $records = @()
    foreach ($lib in @(Get-SteamLibraries)) {
        $steamapps = Join-Path $lib 'steamapps'
        if (-not (Test-Path $steamapps -PathType Container)) { continue }
        foreach ($manifest in @(Get-ChildItem -LiteralPath $steamapps -Filter 'appmanifest_*.acf' -File -ErrorAction SilentlyContinue)) {
            try {
                $raw = Get-Content -Raw -LiteralPath $manifest.FullName -ErrorAction Stop
                $appId = Read-ValveAcfValue $raw 'appid'
                if (-not $appId -and $manifest.BaseName -match 'appmanifest_(\d+)') { $appId = $Matches[1] }
                $name = Read-ValveAcfValue $raw 'name'
                $dir = Read-ValveAcfValue $raw 'installdir'
                $install = if ($dir) { Join-Path (Join-Path $steamapps 'common') $dir } else { $null }
                $records += New-GameInstallRecord 'Steam' $name $install $null $appId 98 'steam-appmanifest'
            } catch { Write-ApexLog "Steam manifest scan failed for $($manifest.FullName): $($_.Exception.Message)" 'WARN' }
        }
    }
    return @($records)
}

function Get-EpicManifestRoots {
    $roots = @('C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests')
    try {
        $appDataPath = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Epic Games\EpicGamesLauncher' -ErrorAction Stop).AppDataPath
        if ($appDataPath) { $roots += (Join-Path $appDataPath 'Manifests') }
    } catch {}
    return @($roots | Where-Object { $_ -and (Test-Path $_ -PathType Container) } | Select-Object -Unique)
}

function Get-EpicInstallRecords {
    $records = @()
    foreach ($manifestRoot in @(Get-EpicManifestRoots)) {
        foreach ($file in @(Get-ChildItem -Path $manifestRoot -Filter '*.item' -File -ErrorAction SilentlyContinue)) {
            try {
                $json = Get-Content -Raw -Path $file.FullName | ConvertFrom-Json
                $name = [string]$json.DisplayName
                if ([string]::IsNullOrWhiteSpace($name)) { $name = [string]$json.AppName }
                $install = [string]$json.InstallLocation
                if ($name -or $install) { $records += New-GameInstallRecord 'Epic' $name $install $null ([string]$json.AppName) 95 'epic-manifest' }
            } catch { Write-ApexLog "Epic manifest scan failed for $($file.FullName): $($_.Exception.Message)" 'WARN' }
        }
    }
    foreach ($dat in @('C:\ProgramData\Epic\UnrealEngineLauncher\LauncherInstalled.dat','C:\ProgramData\Epic\EpicGamesLauncher\Data\LauncherInstalled.dat')) {
        if (-not (Test-Path $dat -PathType Leaf)) { continue }
        try {
            $json = Get-Content -Raw -Path $dat | ConvertFrom-Json
            foreach ($app in @($json.InstallationList)) {
                $name = [string]$app.AppName
                if ([string]::IsNullOrWhiteSpace($name)) { try { $name = [string]$app.AppVersionString } catch {} }
                $install = [string]$app.InstallLocation
                if ($name -or $install) { $records += New-GameInstallRecord 'Epic' $name $install $null ([string]$app.AppName) 90 'epic-launcherinstalled' }
            }
        } catch { Write-ApexLog "Epic LauncherInstalled scan failed for ${dat}: $($_.Exception.Message)" 'WARN' }
    }
    return @($records)
}

function Get-UninstallGameRecords {
    $records = @()
    $keys = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    foreach ($key in $keys) {
        try {
            foreach ($app in @(Get-ItemProperty $key -ErrorAction SilentlyContinue)) {
                $displayName = [string]$app.DisplayName
                if ([string]::IsNullOrWhiteSpace($displayName)) { continue }
                if ($displayName -match 'runtime|redistributable|driver|sdk|launcher|anti-cheat|webview|update|service') { continue }
                $paths = @()
                if ($app.InstallLocation) { $paths += [string]$app.InstallLocation }
                if ($app.DisplayIcon) {
                    try {
                        $iconPath = ([string]$app.DisplayIcon).Trim('"')
                        if ($iconPath -match ',') { $iconPath = ($iconPath -split ',')[0] }
                        if ($iconPath -and (Test-Path $iconPath -PathType Leaf)) { $paths += (Split-Path $iconPath -Parent) }
                    } catch {}
                }
                foreach ($p in @($paths | Where-Object { $_ } | Select-Object -Unique)) {
                    $records += New-GameInstallRecord 'Windows uninstall' $displayName $p $null $null 72 'uninstall-record'
                }
            }
        } catch { Write-ApexLog "Uninstall record scan failed for ${key}: $($_.Exception.Message)" 'WARN' }
    }
    return @($records)
}

function Get-CommonGameRoots {
    $roots = @($env:ProgramFiles, ${env:ProgramFiles(x86)})
    try { $roots += [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData) } catch {}
    try { $roots += [Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments) } catch {}
    try {
        foreach ($drive in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
            if (-not $drive.Root) { continue }
            foreach ($folder in @('Games','SteamLibrary\steamapps\common','Steam\steamapps\common','Epic Games','Riot Games','XboxGames','EA Games','Battle.net','GOG Games','Ubisoft Game Launcher\games','Program Files\EA Games','Program Files\Epic Games','Program Files\Riot Games','Program Files (x86)\Steam\steamapps\common')) {
                $roots += (Join-Path $drive.Root $folder)
            }
        }
    } catch {}
    return @($roots | Where-Object { $_ -and (Test-Path $_ -PathType Container) } | Select-Object -Unique)
}

function Find-ExecutableInGamePath([string]$Path, [object]$Game, [switch]$Deep) {
    if (-not $Path -or -not (Test-Path $Path -PathType Container)) { return $null }
    $exeNames = @($Game.exeNames | ForEach-Object { [string]$_ } | Where-Object { $_ })
    $subFolders = @('', 'Binaries\Win64', 'Binaries\WinGDK', 'bin', 'game', 'retail', 'x64', 'Win64', 'live')
    foreach ($exe in $exeNames) {
        foreach ($sub in $subFolders) {
            $candidate = if ($sub) { Join-Path (Join-Path $Path $sub) $exe } else { Join-Path $Path $exe }
            if (Test-Path $candidate -PathType Leaf) { return $candidate }
        }
    }
    if (-not $Deep) { return $null }
    try {
        foreach ($exe in $exeNames) {
            $found = Get-ChildItem -LiteralPath $Path -Filter $exe -File -Recurse -Depth 4 -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($found) { return $found.FullName }
        }
    } catch {}
    return $null
}

function Get-GameExecutableScore([System.IO.FileInfo]$File, [object]$Game) {
    $score = 0
    $name = $File.Name.ToLowerInvariant()
    $base = [IO.Path]::GetFileNameWithoutExtension($File.Name).ToLowerInvariant()
    $full = $File.FullName.ToLowerInvariant()
    $gameName = ([string]$Game.name).ToLowerInvariant()
    foreach ($exe in @($Game.exeNames | ForEach-Object { ([string]$_).ToLowerInvariant() })) { if ($exe -and $name -eq $exe) { $score += 10000 } }
    foreach ($folder in @($Game.folderNames | ForEach-Object { ([string]$_).ToLowerInvariant() })) { if ($folder -and $full.Contains($folder)) { $score += 350 } }
    foreach ($word in @($gameName -split '[^a-z0-9]+' | Where-Object { $_.Length -ge 4 })) { if ($base.Contains($word)) { $score += 180 } }
    if ($full -match 'binaries\\win64|win64|x64|shipping|game\\bin|retail') { $score += 160 }
    if ($File.Length -gt 5MB) { $score += 80 }
    if ($File.Length -gt 30MB) { $score += 60 }
    if ($name -match 'launcher|bootstrap|updater|setup|install|unins|crash|report|eac|easyanticheat|battleye|vcredist|redist|dxsetup|cef|helper|unitycrashhandler') { $score -= 850 }
    if ($full -match 'redist|_commonredist|installer|support|crash|launcher') { $score -= 450 }
    return $score
}

function Find-BestExecutableInGamePath([string]$Path, [object]$Game) {
    if (-not $Path -or -not (Test-Path $Path -PathType Container)) { return $null }
    try {
        $candidates = @(Get-ChildItem -LiteralPath $Path -Filter '*.exe' -File -Recurse -Depth 4 -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch '\\(redist|_CommonRedist|installer|support|crashdumps|logs)\\' } | Select-Object -First 220)
        if (-not $candidates.Count) { return $null }
        $best = $candidates | Sort-Object @{Expression={Get-GameExecutableScore $_ $Game};Descending=$true}, @{Expression={$_.Length};Descending=$true} | Select-Object -First 1
        if ($best) { return [string]$best.FullName }
    } catch {
        Write-ApexLog "Best executable scan failed for ${Path}: $($_.Exception.Message)" 'WARN'
    }
    return $null
}

function Get-ManualGameRecords([object[]]$Catalog) {
    $records = @()
    $map = Get-GameOverrideMap
    foreach ($g in @($Catalog)) {
        $id = [string]$g.id
        if (-not $id -or -not $map.ContainsKey($id)) { continue }
        $m = $map[$id]
        $install = [string]$m.installPath
        $exe = [string]$m.exePath
        if (($exe -and (Test-Path $exe -PathType Leaf)) -or ($install -and (Test-Path $install -PathType Container))) {
            $records += New-GameInstallRecord 'Manual' ([string]$g.name) $install $exe $id 100 'manual-override'
        }
    }
    return @($records)
}

function Get-CommonRootGameRecords([object[]]$Catalog) {
    $records = @()
    $roots = @(Get-CommonGameRoots)
    foreach ($g in @($Catalog)) {
        foreach ($rootPath in $roots) {
            foreach ($folder in @($g.folderNames | ForEach-Object { [string]$_ } | Where-Object { $_ })) {
                $p = Join-Path $rootPath $folder
                if (Test-Path $p -PathType Container) {
                    $records += New-GameInstallRecord 'Common folder' ([string]$g.name) $p $null ([string]$g.id) 82 'common-root-folder'
                }
            }
        }
    }

    # Bounded one-level folder index: catches common installs like "Call of Duty HQ"
    # without doing a recursive all-drive search that can freeze the local server.
    $children = @()
    foreach ($rootPath in $roots) {
        try {
            $children += @(Get-ChildItem -LiteralPath $rootPath -Directory -ErrorAction SilentlyContinue | Select-Object -First 450)
        } catch {}
    }
    # Keep full DirectoryInfo objects. Select-Object -Unique FullName strips .Name on
    # Windows PowerShell 5.1, which caused scan-status warnings like
    # "The property 'Name/FullName' cannot be found on this object" and blocked
    # detected games from merging cleanly into the catalog.
    $seenChildDirs = @{}
    $uniqueChildren = @()
    foreach ($dir in @($children)) {
        if (-not $dir) { continue }
        $full = $null
        try { $full = [string]$dir.FullName } catch {}
        if ([string]::IsNullOrWhiteSpace($full)) { continue }
        $key = $full.ToLowerInvariant()
        if ($seenChildDirs.ContainsKey($key)) { continue }
        $seenChildDirs[$key] = $true
        $uniqueChildren += $dir
    }
    foreach ($dir in @($uniqueChildren)) {
        $dirName = $null
        $dirFullName = $null
        try { $dirName = [string]$dir.Name } catch {}
        try { $dirFullName = [string]$dir.FullName } catch {}
        if ([string]::IsNullOrWhiteSpace($dirName) -and -not [string]::IsNullOrWhiteSpace($dirFullName)) { $dirName = [IO.Path]::GetFileName(($dirFullName.TrimEnd('\'))) }
        $dirNorm = Normalize-GameText $dirName
        $fullNorm = Normalize-GameText $dirFullName
        if (-not $dirNorm -and -not $fullNorm) { continue }
        foreach ($g in @($Catalog)) {
            foreach ($needle in @(Get-GameNeedles $g)) {
                $dirHit = $false
                if ($needle) {
                    if ($dirNorm -and ($dirNorm -eq $needle -or $dirNorm.Contains($needle) -or $needle.Contains($dirNorm))) { $dirHit = $true }
                    if ((-not $dirHit) -and $fullNorm -and $fullNorm.Contains($needle)) { $dirHit = $true }
                }
                if ($dirHit) {
                    $records += New-GameInstallRecord 'Common folder' ([string]$g.name) ([string]$dirFullName) $null ([string]$g.id) 76 'bounded-folder-match'
                    break
                }
            }
        }
    }
    return @($records | Sort-Object source, name, installPath -Unique)
}


function Get-ExactCommonRootGameRecords([object[]]$Catalog) {
    $records = @()
    $roots = @(Get-CommonGameRoots)
    foreach ($g in @($Catalog)) {
        foreach ($rootPath in $roots) {
            foreach ($folder in @($g.folderNames | ForEach-Object { [string]$_ } | Where-Object { $_ })) {
                try {
                    $p = Join-Path $rootPath $folder
                    if (Test-Path $p -PathType Container) {
                        $records += New-GameInstallRecord 'Common folder' ([string]$g.name) $p $null ([string]$g.id) 82 'exact-common-folder'
                    }
                } catch {}
            }
        }
    }
    return @($records | Sort-Object source, name, installPath -Unique)
}
function Get-GameScanIndexFast([switch]$Refresh) {
    $now = [datetime]::UtcNow
    if ((-not $Refresh) -and $script:GameScanIndexCache -and (($now - $script:GameScanIndexCacheAt).TotalSeconds -lt 90)) {
        return @($script:GameScanIndexCache)
    }
    $catalog = @(Get-GameCatalog)
    $records = @()
    try { $records += Get-ManualGameRecords $catalog } catch { Write-ApexLog "Manual game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-SteamInstallRecords } catch { Write-ApexLog "Steam game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-EpicInstallRecords } catch { Write-ApexLog "Epic game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-ExactCommonRootGameRecords $catalog } catch { Write-ApexLog "Exact common-root game index failed: $($_.Exception.Message)" 'WARN' }
    $clean = @($records | Where-Object { $_ -and ($_.installPath -or $_.exePath -or $_.appId -or $_.name) } | Sort-Object source, appId, name, installPath -Unique)
    $script:GameScanIndexCache = $clean
    $script:GameScanIndexCacheAt = $now
    return @($clean)
}

function Get-GameScanIndex([switch]$Refresh) {
    $now = [datetime]::UtcNow
    if ((-not $Refresh) -and $script:GameScanIndexCache -and (($now - $script:GameScanIndexCacheAt).TotalSeconds -lt 90)) {
        return @($script:GameScanIndexCache)
    }
    $catalog = @(Get-GameCatalog)
    $records = @()
    try { $records += Get-ManualGameRecords $catalog } catch { Write-ApexLog "Manual game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-SteamInstallRecords } catch { Write-ApexLog "Steam game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-EpicInstallRecords } catch { Write-ApexLog "Epic game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-UninstallGameRecords } catch { Write-ApexLog "Uninstall game index failed: $($_.Exception.Message)" 'WARN' }
    try { $records += Get-CommonRootGameRecords $catalog } catch { Write-ApexLog "Common-root game index failed: $($_.Exception.Message)" 'WARN' }
    $clean = @($records | Where-Object { $_ -and ($_.installPath -or $_.exePath -or $_.appId -or $_.name) } | Sort-Object source, appId, name, installPath -Unique)
    $script:GameScanIndexCache = $clean
    $script:GameScanIndexCacheAt = $now
    return @($clean)
}

function Test-GameRecordMatch([object]$Game, [object]$Record) {
    if (-not $Game -or -not $Record) { return $false }
    try {
        $appId = [string]$Record.appId
        if ($appId) {
            foreach ($sid in @($Game.steamAppIds | ForEach-Object { [string]$_ })) { if ($sid -and $sid -eq $appId) { return $true } }
        }
    } catch {}
    $hay = @([string]$Record.name, [string]$Record.installPath, [string]$Record.exePath, [string]$Record.appId) -join ' '
    return (Test-GameNameMatch $Game $hay)
}

function Get-GameRecordScore([object]$Game, [object]$Record) {
    $score = [int]$Record.confidence
    $source = ([string]$Record.source).ToLowerInvariant()
    if ($source -eq 'manual') { $score += 10000 }
    if ($source -eq 'steam') { $score += 5000 }
    if ($source -eq 'epic') { $score += 4500 }
    if ($source -eq 'windows uninstall') { $score += 2600 }
    if ($source -eq 'common folder') { $score += 1800 }
    try {
        $appId = [string]$Record.appId
        foreach ($sid in @($Game.steamAppIds | ForEach-Object { [string]$_ })) { if ($sid -and $appId -and $sid -eq $appId) { $score += 20000 } }
    } catch {}
    $rName = Normalize-GameText $Record.name
    foreach ($needle in @(Get-GameNeedles $Game)) {
        if ($rName -and $needle -and $rName -eq $needle) { $score += 2200 }
        elseif ($rName -and $needle -and ($rName.Contains($needle) -or $needle.Contains($rName))) { $score += 900 }
        $pathNorm = Normalize-GameText $Record.installPath
        if ($pathNorm -and $needle -and $pathNorm.Contains($needle)) { $score += 450 }
    }
    return $score
}

function Resolve-ManualGamePath([object]$Game, [string]$ManualPath) {
    if ([string]::IsNullOrWhiteSpace($ManualPath)) { throw 'No game path was selected or pasted.' }
    $path = [Environment]::ExpandEnvironmentVariables(([string]$ManualPath).Trim().Trim('"'))
    if ([string]::IsNullOrWhiteSpace($path)) { throw 'No game path was selected or pasted.' }
    if (Test-Path $path -PathType Leaf) {
        if ([IO.Path]::GetExtension($path) -ne '.exe') { throw 'Select the game .exe or the game install folder.' }
        $folder = Split-Path -Parent $path
        return [pscustomobject]@{ installPath=$folder; exePath=$path; detected=$true; manual=$true; error=$null }
    }
    if (Test-Path $path -PathType Container) {
        $exe = Find-ExecutableInGamePath $path $Game -Deep
        if (-not $exe) { $exe = Find-BestExecutableInGamePath $path $Game }
        if (-not $exe) { throw "ApexTune found the folder but could not identify a game .exe inside: $path" }
        return [pscustomobject]@{ installPath=$path; exePath=$exe; detected=$true; manual=$true; error=$null }
    }
    throw "Path does not exist: $path"
}

function Set-GameManualOverride([string]$GameId, [string]$ManualPath) {
    $game = @(Get-GameCatalog | Where-Object { [string]$_.id -eq $GameId } | Select-Object -First 1)
    if (-not $game) { throw 'Game was not found in the ApexTune catalog.' }
    $resolved = Resolve-ManualGamePath $game $ManualPath
    $map = Get-GameOverrideMap
    $map[([string]$GameId)] = [pscustomobject]@{
        gameId=[string]$GameId
        gameName=[string]$game.name
        installPath=[string]$resolved.installPath
        exePath=[string]$resolved.exePath
        setAt=(Get-Date).ToString('o')
        source='manual'
    }
    Save-GameOverrideMap $map
    $script:GameScanIndexCache = $null
    $script:GameScanIndexCacheAt = [datetime]::MinValue
    return [pscustomobject]@{ ok=$true; game=$game.name; gameId=$GameId; installPath=$resolved.installPath; exePath=$resolved.exePath; message="Saved manual install path for $($game.name)." }
}

function Invoke-GameLocate([string]$GameId, [string]$ManualPath) {
    $game = @(Get-GameCatalog | Where-Object { [string]$_.id -eq $GameId } | Select-Object -First 1)
    if (-not $game) { throw 'Game was not found in the ApexTune catalog.' }
    $target = $ManualPath
    if ([string]::IsNullOrWhiteSpace($target)) { $target = Show-GamePathDialog $game }
    if ([string]::IsNullOrWhiteSpace($target)) { throw 'No path was selected. Paste the game .exe path or install folder path and try again.' }
    return (Set-GameManualOverride $GameId $target)
}

function Resolve-GameInstall([object]$Game, [object[]]$Index=$null, [switch]$Deep) {
    if (-not $Index) { $Index = @(Get-GameScanIndex) }
    $matches = @($Index | Where-Object { Test-GameRecordMatch $Game $_ })
    if (-not $matches.Count) { return [pscustomobject]@{ installPath=$null; exePath=$null; detected=$false; manual=$false; error=$null; detectionSource=$null; confidence=0 } }
    $best = $matches | Sort-Object @{Expression={Get-GameRecordScore $Game $_};Descending=$true} | Select-Object -First 1
    if (-not $best) { return [pscustomobject]@{ installPath=$null; exePath=$null; detected=$false; manual=$false; error=$null; detectionSource=$null; confidence=0 } }
    $install = [string]$best.installPath
    $exe = [string]$best.exePath
    if ($exe -and -not (Test-Path $exe -PathType Leaf)) { $exe = $null }
    if ($install -and (Test-Path $install -PathType Container)) {
        if (-not $exe) { $exe = Find-ExecutableInGamePath $install $Game -Deep:$Deep }
        if ((-not $exe) -and $Deep) { $exe = Find-BestExecutableInGamePath $install $Game }
        return [pscustomobject]@{ installPath=$install; exePath=$exe; detected=$true; manual=(([string]$best.source) -eq 'Manual'); error=$null; detectionSource=[string]$best.source; confidence=[int]$best.confidence }
    }
    if ($exe -and (Test-Path $exe -PathType Leaf)) {
        return [pscustomobject]@{ installPath=(Split-Path -Parent $exe); exePath=$exe; detected=$true; manual=(([string]$best.source) -eq 'Manual'); error=$null; detectionSource=[string]$best.source; confidence=[int]$best.confidence }
    }
    return [pscustomobject]@{ installPath=$install; exePath=$exe; detected=$false; manual=$false; error='Matched a launcher record, but the install path no longer exists.'; detectionSource=[string]$best.source; confidence=[int]$best.confidence }
}

function Get-GamesCenter([switch]$Refresh, [switch]$Fast) {
    $catalog = @(Get-GameCatalog)
    $index = if ($Fast) { @(Get-GameScanIndexFast -Refresh:$Refresh) } else { @(Get-GameScanIndex -Refresh:$Refresh) }
    $out = @()
    foreach ($g in $catalog) {
        try {
            $r = Resolve-GameInstall $g $index
            $out += [pscustomobject]@{
                id=$g.id; name=$g.name; short=$g.short; genre=$g.genre; steamAppIds=$g.steamAppIds; exeNames=$g.exeNames; folderNames=$g.folderNames; accent=$g.accent; accent2=$g.accent2; thumbnail=$g.thumbnail; thumbnailUrl=$g.thumbnailUrl; thumbnailUrls=(Get-ApexGameProp $g 'thumbnailUrls' @()); profiles=$g.profiles; tags=$g.tags; detected=[bool]$r.detected; manual=[bool]$r.manual; installPath=$r.installPath; exePath=$r.exePath; detectionSource=$r.detectionSource; confidence=$r.confidence; scanError=$r.error
            }
        } catch {
            Write-ApexLog "Game card scan failed for $($g.name): $($_.Exception.Message)" 'WARN'
            $out += [pscustomobject]@{
                id=$g.id; name=$g.name; short=$g.short; genre=$g.genre; steamAppIds=$g.steamAppIds; exeNames=$g.exeNames; folderNames=$g.folderNames; accent=$g.accent; accent2=$g.accent2; thumbnail=$g.thumbnail; thumbnailUrl=$g.thumbnailUrl; thumbnailUrls=(Get-ApexGameProp $g 'thumbnailUrls' @()); profiles=$g.profiles; tags=$g.tags; detected=$false; manual=$false; installPath=$null; exePath=$null; detectionSource=$null; confidence=0; scanError=$_.Exception.Message
            }
        }
    }
    return @($out)
}

function Get-RegValueSnapshot([string]$Path, [string]$Name) {
    try {
        $v = Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop
        return [pscustomobject]@{ path=$Path; name=$Name; exists=$true; value=$v.$Name }
    } catch { return [pscustomobject]@{ path=$Path; name=$Name; exists=$false; value=$null } }
}

function Set-ApexRegString([string]$Path, [string]$Name, [string]$Value) {
    New-Item -Path $Path -Force | Out-Null
    New-ItemProperty -LiteralPath $Path -Name $Name -PropertyType String -Value $Value -Force | Out-Null
}
function Set-ApexRegDword([string]$Path, [string]$Name, [int]$Value) {
    New-Item -Path $Path -Force | Out-Null
    New-ItemProperty -LiteralPath $Path -Name $Name -PropertyType DWord -Value $Value -Force | Out-Null
}

function ConvertTo-ApexPsSingleQuoted([string]$Text) {
    if ($null -eq $Text) { return "''" }
    return "'" + ($Text -replace "'", "''") + "'"
}

function Start-ApexWebPageFast([string]$Url) {
    try { Start-Process -FilePath $Url -WindowStyle Normal | Out-Null; return $true } catch { Write-ApexLog "Open URL failed: $Url :: $($_.Exception.Message)" 'WARN'; return $false }
}

function Start-ApexBackgroundPowerShell([string]$Name, [string[]]$Lines) {
    $safe = if ([string]::IsNullOrWhiteSpace($Name)) { 'ApexTune-Task.ps1' } else { ($Name -replace '[^A-Za-z0-9._-]+','-') }
    if (-not $safe.ToLowerInvariant().EndsWith('.ps1')) { $safe += '.ps1' }
    $scriptPath = Join-Path $script:DriverToolsDir $safe
    New-Item -ItemType Directory -Path $script:DriverToolsDir -Force | Out-Null
    $Lines | Set-Content -LiteralPath $scriptPath -Encoding UTF8
    $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $psExe -PathType Leaf)) {
        $cmd = Get-Command powershell.exe -ErrorAction SilentlyContinue
        if ($cmd) { $psExe = $cmd.Source }
    }
    if (-not (Test-Path -LiteralPath $psExe -PathType Leaf)) { throw 'Windows PowerShell was not found.' }
    Start-Process -FilePath $psExe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$scriptPath) -WindowStyle Normal | Out-Null
    return $scriptPath
}

function Find-NvidiaProfileInspector {
    $candidates = @()
    $candidates += Join-Path $script:DriverToolsDir 'nvidiaProfileInspector\nvidiaProfileInspector.exe'
    $candidates += Join-Path $script:DriverToolsDir 'nvidiaProfileInspector.exe'
    try {
        $toolRoot = Join-Path $script:DriverToolsDir 'nvidiaProfileInspector'
        if (Test-Path -LiteralPath $toolRoot -PathType Container) {
            $candidates += @(Get-ChildItem -LiteralPath $toolRoot -Recurse -Filter 'nvidiaProfileInspector.exe' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
        }
    } catch {}
    try { $cmd = Get-Command nvidiaProfileInspector.exe -ErrorAction SilentlyContinue; if ($cmd) { $candidates += $cmd.Source } } catch {}
    return @($candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -Unique | Select-Object -First 1)
}

function Get-DriverDownloadDir {
    $dir = Join-Path $script:DriverToolsDir 'Downloads'
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    return $dir
}

function Start-ApexFile([string]$Path, [string]$WorkingDirectory = $null) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "File was not found: $Path" }
    try { Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue } catch {}
    if ([string]::IsNullOrWhiteSpace($WorkingDirectory)) { $WorkingDirectory = Split-Path $Path -Parent }
    Start-Process -FilePath $Path -WorkingDirectory $WorkingDirectory -WindowStyle Normal | Out-Null
}

function Open-ApexTextFile([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    try { Start-Process -FilePath 'notepad.exe' -ArgumentList @($Path) -WindowStyle Normal | Out-Null; return $true } catch { try { Invoke-Item -LiteralPath $Path; return $true } catch { return $false } }
}

function Open-ApexFolder([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
    try { Start-Process -FilePath 'explorer.exe' -ArgumentList @($Path) -WindowStyle Normal | Out-Null; return $true } catch { return $false }
}

function Invoke-ApexDownload([string]$Url, [string]$OutFile, [string[]]$AllowedHosts) {
    $uri = [uri]$Url
    $hostName = $uri.Host.ToLowerInvariant()
    $allowed = $false
    foreach ($h in $AllowedHosts) {
        $hh = ([string]$h).ToLowerInvariant()
        if ($hostName -eq $hh -or $hostName.EndsWith('.' + $hh)) { $allowed = $true }
    }
    if (-not $allowed) { throw "Blocked download host: $hostName" }
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
    New-Item -ItemType Directory -Path (Split-Path $OutFile -Parent) -Force | Out-Null
    Invoke-WebRequest -Uri $Url -OutFile $OutFile -UseBasicParsing -Headers @{ 'User-Agent' = 'ApexTune/1.59' }
    if (-not (Test-Path -LiteralPath $OutFile -PathType Leaf)) { throw 'Download did not create a file.' }
    return $OutFile
}

function Find-ExeInPaths([string[]]$Paths) {
    $candidates = @()
    foreach ($p in $Paths) { if (-not [string]::IsNullOrWhiteSpace($p)) { $candidates += $p } }
    return @($candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -Unique | Select-Object -First 1)
}

function Find-NVCleanstall {
    $paths = @(
        (Join-Path $script:DriverToolsDir 'NVCleanstall\NVCleanstall.exe'),
        (Join-Path $script:DriverToolsDir 'NVCleanstall.exe'),
        (Join-Path $env:ProgramFiles 'NVCleanstall\NVCleanstall.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'NVCleanstall\NVCleanstall.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\NVCleanstall\NVCleanstall.exe')
    )
    try { $cmd = Get-Command NVCleanstall.exe -ErrorAction SilentlyContinue; if ($cmd) { $paths += $cmd.Source } } catch {}
    return Find-ExeInPaths $paths
}

function Find-NvidiaApp {
    $paths = @(
        (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVIDIA App\CEF\NVIDIA app.exe'),
        (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVIDIA App\NVIDIA app.exe'),
        (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVIDIA GeForce Experience\NVIDIA GeForce Experience.exe'),
        (Join-Path $env:ProgramFiles 'NVIDIA Corporation\NVIDIA GeForce Experience\GeForceExperience.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'NVIDIA Corporation\NVIDIA App\NVIDIA app.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'NVIDIA Corporation\NVIDIA GeForce Experience\GeForceExperience.exe')
    )
    return Find-ExeInPaths $paths
}

function Find-AmdSoftware {
    $paths = @(
        (Join-Path $env:ProgramFiles 'AMD\CNext\CNext\RadeonSoftware.exe'),
        (Join-Path $env:ProgramFiles 'AMD\CNext\CNext\AMDSoftware.exe'),
        (Join-Path $env:ProgramFiles 'AMD\CIM\Bin64\AMDSoftwareInstaller.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'AMD\CNext\CNext\RadeonSoftware.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'AMD\CIM\Bin64\AMDSoftwareInstaller.exe')
    )
    return Find-ExeInPaths $paths
}

function Start-WinGetInstallFast([string[]]$PackageIds, [string]$Title) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) { return [pscustomobject]@{ started=$false; message='winget is not available on this PC.' } }
    $ids = @($PackageIds | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if (-not $ids.Count) { return [pscustomobject]@{ started=$false; message='No package IDs were provided.' } }
    $lines = @('@echo off', ('title ApexTune install - {0}' -f $Title), 'echo ApexTune is starting the vendor installer...', 'echo You can close this window after the installer finishes.', '')
    foreach ($id in $ids) {
        $safeId = ([string]$id).Replace('&','^&')
        $lines += ('echo Trying {0}' -f $safeId)
        $lines += ('winget install --id "{0}" -e --accept-source-agreements --accept-package-agreements' -f $safeId)
        $lines += 'if %ERRORLEVEL% EQU 0 goto done'
    }
    $lines += ':done'
    $lines += 'echo.'
    $lines += 'echo ApexTune install helper finished. If the app did not install, use the official page opened by ApexTune.'
    $lines += 'pause'
    $bat = Join-Path $script:DriverToolsDir (('Install-{0}.cmd' -f ($Title -replace '[^A-Za-z0-9._-]+','-')))
    $lines | Set-Content -LiteralPath $bat -Encoding ASCII
    Start-Process -FilePath $bat -WindowStyle Normal | Out-Null
    return [pscustomobject]@{ started=$true; message='Started winget install helper in a separate window.'; script=$bat; packages=$ids }
}

function Start-NvidiaProfileInspectorDownloadFast {
    $existing = Find-NvidiaProfileInspector
    if ($existing) { Start-ApexFile $existing; return [pscustomobject]@{ ok=$true; message='NVIDIA Profile Inspector was found and opened.'; path=$existing; started=$false } }
    $target = Join-Path $script:DriverToolsDir 'nvidiaProfileInspector'
    $downloads = Get-DriverDownloadDir
    $lines = @(
        '$ErrorActionPreference = "Continue"',
        '[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12',
        ('$target = {0}' -f (ConvertTo-ApexPsSingleQuoted $target)),
        ('$downloads = {0}' -f (ConvertTo-ApexPsSingleQuoted $downloads)),
        'New-Item -ItemType Directory -Path $target -Force | Out-Null',
        'New-Item -ItemType Directory -Path $downloads -Force | Out-Null',
        '$headers = @{ "User-Agent" = "ApexTune/1.59" }',
        'Write-Host "ApexTune: downloading NVIDIA Profile Inspector..."',
        '$release = Invoke-RestMethod -Uri "https://api.github.com/repos/Orbmu2k/nvidiaProfileInspector/releases/latest" -Headers $headers',
        '$asset = @($release.assets | Where-Object { $_.name -match "\.zip$" } | Select-Object -First 1)',
        'if (-not $asset) { throw "No NVIDIA Profile Inspector zip release was found." }',
        '$zip = Join-Path $downloads ([string]$asset.name)',
        'Invoke-WebRequest -Uri ([string]$asset.browser_download_url) -OutFile $zip -UseBasicParsing -Headers $headers',
        'Expand-Archive -LiteralPath $zip -DestinationPath $target -Force',
        '$exe = Get-ChildItem -LiteralPath $target -Recurse -Filter "nvidiaProfileInspector.exe" -ErrorAction SilentlyContinue | Select-Object -First 1',
        'if ($exe) { Unblock-File -LiteralPath $exe.FullName -ErrorAction SilentlyContinue; Start-Process -FilePath $exe.FullName -WorkingDirectory (Split-Path $exe.FullName -Parent) } else { throw "nvidiaProfileInspector.exe was not found after extraction." }',
        'Write-Host "Done. You can close this window."',
        'Start-Sleep -Seconds 3'
    )
    $scriptPath = Start-ApexBackgroundPowerShell 'Download-NVIDIA-Profile-Inspector.ps1' $lines
    Start-ApexWebPageFast 'https://github.com/Orbmu2k/nvidiaProfileInspector/releases/latest' | Out-Null
    return [pscustomobject]@{ ok=$true; message='Started NVIDIA Profile Inspector download in a separate window and opened the official releases page as a fallback.'; path=$null; started=$true; script=$scriptPath }
}

function Install-NvidiaProfileInspector {
    return (Start-NvidiaProfileInspectorDownloadFast)
}

function Install-NVCleanstall {
    $existing = Find-NVCleanstall
    if ($existing) { Start-ApexFile $existing; return [pscustomobject]@{ ok=$true; message='NVCleanstall was found and opened.'; path=$existing; installed=$false; quick=$true } }
    $winget = Start-WinGetInstallFast @('TechPowerUp.NVCleanstall','TechPowerUp.NVCleanInstall') 'NVCleanstall'
    Start-ApexWebPageFast 'https://www.techpowerup.com/download/techpowerup-nvcleanstall/' | Out-Null
    return [pscustomobject]@{ ok=$true; message='Started NVCleanstall install/download helper and opened the official TechPowerUp page. This returns immediately so ApexTune does not freeze.'; winget=$winget; quick=$true }
}

function Install-NvidiaAppDriverAssistant {
    $existing = Find-NvidiaApp
    if ($existing) { Start-ApexFile $existing; return [pscustomobject]@{ ok=$true; message='NVIDIA App was found and opened. Use its Drivers page for automatic detection.'; path=$existing; installed=$false; quick=$true } }
    $winget = Start-WinGetInstallFast @('Nvidia.NVIDIAApp','NVIDIA.NVIDIAApp','Nvidia.GeForceExperience') 'NVIDIA-App'
    Start-ApexWebPageFast 'https://www.nvidia.com/en-us/software/nvidia-app/' | Out-Null
    return [pscustomobject]@{ ok=$true; message='Started NVIDIA App install helper and opened the official NVIDIA App page. This is the quickest safe automatic driver-detection route.'; winget=$winget; quick=$true }
}

function Install-AmdDriverAssistant {
    $existing = Find-AmdSoftware
    if ($existing) { Start-ApexFile $existing; return [pscustomobject]@{ ok=$true; message='AMD Software was found and opened. Use its driver/update screen for automatic detection.'; path=$existing; installed=$false; quick=$true } }
    $winget = Start-WinGetInstallFast @('AdvancedMicroDevices.AMDSoftware','AMD.AMDSoftware','AdvancedMicroDevicesInc.AMDRadeonSoftware') 'AMD-Software'
    Start-ApexWebPageFast 'https://www.amd.com/en/support/download/drivers.html' | Out-Null
    return [pscustomobject]@{ ok=$true; message='Started AMD Software install helper and opened the official AMD driver page. This returns immediately so ApexTune does not freeze.'; winget=$winget; quick=$true }
}

function Get-ApexGpuPresetSettings([string]$Vendor, [string]$Preset) {
    $p = if ([string]::IsNullOrWhiteSpace($Preset)) { 'Balanced' } else { $Preset }
    if ($Vendor -eq 'NVIDIA') {
        switch ($p) {
            'Competitive' { return @(
                [pscustomobject]@{ setting='Power management mode'; value='Prefer maximum performance'; reason='Keeps the GPU out of lower power states during competitive play.' },
                [pscustomobject]@{ setting='Low Latency Mode'; value='Ultra'; reason='Queues fewer frames where supported for latency-focused play.' },
                [pscustomobject]@{ setting='Vertical sync'; value='Off'; reason='Avoids driver-level V-Sync latency unless using a separate VRR/frame-cap setup.' },
                [pscustomobject]@{ setting='Texture filtering - Quality'; value='High performance'; reason='Biases driver filtering toward FPS.' },
                [pscustomobject]@{ setting='Shader Cache Size'; value='Driver Default or Unlimited'; reason='Keeps shader cache enabled for smoother repeat launches.' },
                [pscustomobject]@{ setting='Threaded optimization'; value='Auto'; reason='Lets the driver use multithreaded optimization where appropriate.' },
                [pscustomobject]@{ setting='Preferred refresh rate'; value='Highest available'; reason='Prioritizes high-refresh displays for supported titles.' },
                [pscustomobject]@{ setting='Triple buffering'; value='Off'; reason='Avoids extra buffering in latency-first profiles.' }
            ) }
            'Maximum FPS' { return @(
                [pscustomobject]@{ setting='Power management mode'; value='Prefer maximum performance'; reason='Keeps GPU clocks ready during FPS-first gaming.' },
                [pscustomobject]@{ setting='Low Latency Mode'; value='On'; reason='Balances queue reduction with broad compatibility.' },
                [pscustomobject]@{ setting='Vertical sync'; value='Off'; reason='Removes driver cap/latency for raw FPS mode.' },
                [pscustomobject]@{ setting='Texture filtering - Quality'; value='High performance'; reason='Reduces filtering cost.' },
                [pscustomobject]@{ setting='Anisotropic sample optimization'; value='On when available'; reason='FPS-first filtering choice.' },
                [pscustomobject]@{ setting='Shader Cache Size'; value='Unlimited when available'; reason='Prioritizes cache reuse for large game libraries.' },
                [pscustomobject]@{ setting='Threaded optimization'; value='Auto'; reason='Maintains compatibility while using driver threading.' }
            ) }
            'Quality' { return @(
                [pscustomobject]@{ setting='Power management mode'; value='Normal'; reason='Avoids forcing maximum clocks when quality/thermals matter.' },
                [pscustomobject]@{ setting='Low Latency Mode'; value='Off or On'; reason='Keeps image-quality features prioritized; use On only if the game feels delayed.' },
                [pscustomobject]@{ setting='Vertical sync'; value='Use the 3D application setting'; reason='Lets game/VRR choices control presentation.' },
                [pscustomobject]@{ setting='Texture filtering - Quality'; value='Quality'; reason='Preserves texture filtering quality.' },
                [pscustomobject]@{ setting='Shader Cache Size'; value='Driver Default'; reason='Safe quality default.' },
                [pscustomobject]@{ setting='Threaded optimization'; value='Auto'; reason='Safe default.' }
            ) }
            default { return @(
                [pscustomobject]@{ setting='Power management mode'; value='Normal'; reason='Balanced default.' },
                [pscustomobject]@{ setting='Low Latency Mode'; value='On'; reason='Sensible latency improvement for many games.' },
                [pscustomobject]@{ setting='Vertical sync'; value='Use the 3D application setting'; reason='Avoids globally overriding game/monitor setup.' },
                [pscustomobject]@{ setting='Texture filtering - Quality'; value='Performance'; reason='Light FPS bias without going fully quality-off.' },
                [pscustomobject]@{ setting='Shader Cache Size'; value='Driver Default'; reason='Safe default.' },
                [pscustomobject]@{ setting='Threaded optimization'; value='Auto'; reason='Safe default.' }
            ) }
        }
    }
    if ($Vendor -eq 'AMD') {
        switch ($p) {
            'Competitive' { return @(
                [pscustomobject]@{ setting='Radeon Anti-Lag'; value='On when supported'; reason='Latency-first profile for GPU-bound games.' },
                [pscustomobject]@{ setting='Radeon Chill'; value='Off'; reason='Avoids dynamic FPS limiting during competitive play.' },
                [pscustomobject]@{ setting='Wait for Vertical Refresh'; value='Always off unless the application specifies'; reason='Avoids V-Sync latency.' },
                [pscustomobject]@{ setting='Texture Filtering Quality'; value='Performance'; reason='FPS and latency bias.' },
                [pscustomobject]@{ setting='Radeon Boost'; value='Off unless user wants dynamic resolution'; reason='Avoids sudden quality shifts in competitive titles.' },
                [pscustomobject]@{ setting='Surface Format Optimization'; value='On'; reason='Common AMD performance-oriented toggle.' }
            ) }
            'Maximum FPS' { return @(
                [pscustomobject]@{ setting='HYPR-RX'; value='On when supported'; reason='AMD one-click performance profile on supported GPUs/games.' },
                [pscustomobject]@{ setting='Radeon Anti-Lag'; value='On when supported'; reason='Helps latency under GPU pressure.' },
                [pscustomobject]@{ setting='Radeon Chill'; value='Off'; reason='No frame limiter in FPS-first mode.' },
                [pscustomobject]@{ setting='Radeon Boost'; value='On only if visual scaling is acceptable'; reason='Can increase FPS in supported games by lowering resolution during fast motion.' },
                [pscustomobject]@{ setting='Texture Filtering Quality'; value='Performance'; reason='FPS-first filtering.' },
                [pscustomobject]@{ setting='Surface Format Optimization'; value='On'; reason='Performance-oriented default.' }
            ) }
            'Quality' { return @(
                [pscustomobject]@{ setting='HYPR-RX'; value='Off unless wanted'; reason='Preserves quality-first manual control.' },
                [pscustomobject]@{ setting='Radeon Anti-Lag'; value='On if needed'; reason='Latency improvement without heavy quality tradeoff.' },
                [pscustomobject]@{ setting='Radeon Chill'; value='Optional'; reason='Can lower heat/noise when quality is prioritized.' },
                [pscustomobject]@{ setting='Wait for Vertical Refresh'; value='Application controlled'; reason='Lets the game/monitor setup decide.' },
                [pscustomobject]@{ setting='Texture Filtering Quality'; value='Quality'; reason='Preserves image quality.' },
                [pscustomobject]@{ setting='Surface Format Optimization'; value='Off/Default'; reason='Quality-first choice.' }
            ) }
            default { return @(
                [pscustomobject]@{ setting='Radeon Anti-Lag'; value='On when supported'; reason='Balanced latency improvement.' },
                [pscustomobject]@{ setting='Radeon Chill'; value='Off by default'; reason='Avoids unexpected caps unless the user wants lower heat/noise.' },
                [pscustomobject]@{ setting='Wait for Vertical Refresh'; value='Application controlled'; reason='Safe default.' },
                [pscustomobject]@{ setting='Texture Filtering Quality'; value='Standard/Performance'; reason='Balanced performance choice.' },
                [pscustomobject]@{ setting='Surface Format Optimization'; value='On'; reason='Balanced performance-oriented default.' }
            ) }
        }
    }
    return @()
}

function New-GpuPresetPackage([string]$Vendor, [string]$Preset, [object]$Game = $null) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $safeVendor = ($Vendor -replace '[^A-Za-z0-9]+','-')
    $safePreset = ($Preset -replace '[^A-Za-z0-9]+','-')
    $dir = Join-Path $script:DriverPresetDir "$safeVendor-$safePreset-$stamp"
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $target = if ($Game) { [string]$Game.name } else { 'Global profile' }
    $settings = @(Get-ApexGpuPresetSettings $Vendor $Preset)
    $json = Join-Path $dir 'ApexTune-GPU-Preset.json'
    [pscustomobject]@{
        generated=(Get-Date).ToString('o')
        vendor=$Vendor
        preset=$Preset
        target=$target
        settings=$settings
        note='ApexTune applies supported Windows graphics preferences automatically and opens supported vendor tools for vendor-control-panel profile changes. It never imports fake or malformed driver profile files.'
    } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $json -Encoding UTF8

    $txt = Join-Path $dir "ApexTune-$safeVendor-$safePreset-Profile-Guide.txt"
    $lines = @(
        "ApexTune $Vendor Profile Guide",
        "Generated: $(Get-Date -Format o)",
        "Target: $target",
        "Preset: $Preset",
        '',
        'Recommended settings prepared:'
    )
    foreach ($set in $settings) { $lines += ('- {0}: {1} -- {2}' -f $set.setting, $set.value, $set.reason) }
    if ($Vendor -eq 'NVIDIA') {
        $lines += @(
            '',
            'NVIDIA workflow:',
            '1. ApexTune opens NVIDIA Profile Inspector when available.',
            '2. ApexTune exports customized profiles before changing anything when the tool supports it.',
            '3. If a valid .nip preset exists in this package, ApexTune imports it using NVIDIA Profile Inspector supported .nip command-line import.',
            '4. If no valid .nip exists, ApexTune opens Profile Inspector and this guide instead of trying to import an invalid text file.'
        )
    } elseif ($Vendor -eq 'AMD') {
        $lines += @(
            '',
            'AMD workflow:',
            '1. ApexTune opens AMD Software when installed.',
            '2. ApexTune applies supported Windows graphics preferences where available.',
            '3. AMD Adrenalin profile settings are reviewed in AMD Software because AMD does not expose a stable public Profile-Inspector-style importer.'
        )
    }
    Set-Content -LiteralPath $txt -Value $lines -Encoding UTF8

    $cmd = Join-Path $dir "Open-$safeVendor-$safePreset-Guide.cmd"
    @(
        '@echo off',
        "title ApexTune $Vendor $Preset Profile Guide",
        'setlocal',
        ('set "GUIDE={0}"' -f $txt),
        'if exist "%GUIDE%" (',
        '  start "" notepad.exe "%GUIDE%"',
        ') else (',
        '  echo ApexTune guide file was not found:',
        '  echo %GUIDE%',
        '  pause',
        ')',
        'exit /b 0'
    ) | Set-Content -LiteralPath $cmd -Encoding ASCII

    $validNip = $null
    try { $validNip = @(Get-ChildItem -LiteralPath $dir -Filter '*.nip' -File -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName) } catch {}
    return [pscustomobject]@{ dir=$dir; json=$json; guide=$txt; command=$cmd; settings=$settings; nip=$validNip }
}

function Invoke-NvidiaPresetImport([string]$NpiPath, [string]$Preset, [object]$Pack) {
    $result = [ordered]@{ attempted=$false; launched=$false; imported=$false; method=$null; error=$null; openedGuide=$false; openedFolder=$false }
    if (-not $NpiPath -or -not (Test-Path -LiteralPath $NpiPath -PathType Leaf)) { return [pscustomobject]$result }
    try { Unblock-File -LiteralPath $NpiPath -ErrorAction SilentlyContinue } catch {}
    $work = Split-Path $NpiPath -Parent
    try {
        $result.attempted = $true
        $nip = $null
        if ($Pack -and $Pack.PSObject.Properties.Name -contains 'nip') { $nip = [string]$Pack.nip }
        if (-not [string]::IsNullOrWhiteSpace($nip) -and (Test-Path -LiteralPath $nip -PathType Leaf) -and $nip.ToLowerInvariant().EndsWith('.nip')) {
            # NVIDIA Profile Inspector documents .nip command-line import and -silentImport.
            $p = Start-Process -FilePath $NpiPath -ArgumentList @('-silentImport', $nip) -WorkingDirectory $work -Wait -PassThru -WindowStyle Normal
            $result.launched = $true
            $result.imported = ($p.ExitCode -eq 0 -or $null -eq $p.ExitCode)
            $result.method = '-silentImport .nip'
            if (-not $result.imported) { $result.error = "NVIDIA Profile Inspector exited with code $($p.ExitCode)." }
            return [pscustomobject]$result
        }

        # Do not pass ApexTune text guides to Profile Inspector as imports. Older builds pop Notepad/errors when the file is not a real .nip.
        Start-Process -FilePath $NpiPath -WorkingDirectory $work -WindowStyle Normal | Out-Null
        $result.launched = $true
        $result.method = 'open-tool-no-fake-import'
        if ($Pack -and $Pack.guide) { $result.openedGuide = [bool](Open-ApexTextFile ([string]$Pack.guide)) }
        if ($Pack -and $Pack.dir) { $result.openedFolder = [bool](Open-ApexFolder ([string]$Pack.dir)) }
    } catch {
        $result.error = $_.Exception.Message
        if ($Pack -and $Pack.guide) { $result.openedGuide = [bool](Open-ApexTextFile ([string]$Pack.guide)) }
        if ($Pack -and $Pack.dir) { $result.openedFolder = [bool](Open-ApexFolder ([string]$Pack.dir)) }
    }
    return [pscustomobject]$result
}

function Invoke-AmdPreset([string]$Preset, [object]$Game = $null) {
    $pack = New-GpuPresetPackage 'AMD' $Preset $Game
    $app = Find-AmdSoftware
    $download = $null
    if (-not $app) {
        $download = Install-AmdDriverAssistant
        $app = Find-AmdSoftware
    }
    $openedApp = $false
    if ($app) { try { Start-ApexFile $app; $openedApp = $true } catch {} }
    $openedGuide = Open-ApexTextFile ([string]$pack.guide)
    $openedFolder = Open-ApexFolder ([string]$pack.dir)
    $msg = if ($openedApp) {
        'AMD setup package created. AMD Software opened with a clear guide for Radeon game settings.'
    } else {
        'AMD preset package created. ApexTune opened the preset guide/folder and routed to official AMD driver tooling because AMD Software was not detected.'
    }
    return [pscustomobject]@{ ok=$true; message=$msg; vendor='AMD'; preset=$Preset; guidePath=$pack.guide; presetPath=$pack.json; commandPath=$pack.command; packageDir=$pack.dir; app=$app; download=$download; openedGuide=$openedGuide; openedFolder=$openedFolder }
}

function New-NvidiaProfileGuide([string]$Preset, [object]$Game) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $path = Join-Path $script:ReportsDir "ApexTune-NVIDIA-Profile-$($Preset -replace '[^A-Za-z0-9]+','-')-$stamp.txt"
    $target = if ($Game) { [string]$Game.name } else { 'Global profile' }
    $lines = @(
        'ApexTune NVIDIA Profile Preset',
        "Generated: $(Get-Date -Format o)",
        "Target: $target",
        "Preset: $Preset",
        '',
        'Recommended NVIDIA Control Panel / NVIDIA Profile Inspector choices:',
        '- Power management mode: Prefer maximum performance for Competitive/Maximum FPS; Normal for Balanced/Quality.',
        '- Low Latency Mode: Ultra for Competitive; On for Maximum FPS; Off/Default for Quality.',
        '- Vertical Sync: Off for Competitive/Maximum FPS unless using G-SYNC with a frame cap.',
        '- Texture filtering quality: High performance for Maximum FPS; Quality for Quality preset.',
        '- Shader Cache Size: Driver Default or Unlimited when available.',
        '- Max Frame Rate: use a stable cap only if needed for latency/thermals.',
        '',
        'ApexTune already applied reversible Windows-side game profile keys when a game executable was found.'
    )
    Set-Content -Path $path -Value $lines -Encoding UTF8
    return $path
}

function Invoke-NvidiaProfilePreset([string]$Preset, [bool]$IncludeHidden, [object]$Game = $null) {
    $guide = New-NvidiaProfileGuide $Preset $Game
    $pack = New-GpuPresetPackage 'NVIDIA' $Preset $Game
    $npi = Find-NvidiaProfileInspector
    $backupPath = $null
    $downloadResult = $null
    if (-not $npi -and $IncludeHidden) {
        $downloadResult = Install-NvidiaProfileInspector
        # The downloader now runs in a separate window. Re-check quickly, but do not block ApexTune.
        Start-Sleep -Milliseconds 150
        $npi = Find-NvidiaProfileInspector
    }
    $import = $null
    if ($npi) {
        try {
            $p = Start-Process -FilePath $npi -ArgumentList @('-exportCustomized') -WorkingDirectory (Split-Path $npi -Parent) -Wait -PassThru -WindowStyle Hidden
            $backupPath = Split-Path $npi -Parent
        } catch { Write-ApexLog "NVIDIA Profile Inspector backup/export failed: $($_.Exception.Message)" 'WARN' }
        if ($IncludeHidden) { $import = Invoke-NvidiaPresetImport $npi $Preset $pack } else { $null = Open-ApexTextFile ([string]$pack.guide); $null = Open-ApexFolder ([string]$pack.dir) }
        $msg = if ($import -and $import.imported) {
            'NVIDIA preset imported with NVIDIA Profile Inspector and a backup/report package was saved.'
        } elseif ($downloadResult -and $downloadResult.installed) {
            'NVIDIA preset package created. NVIDIA Profile Inspector was downloaded/opened. No invalid text import was attempted; ApexTune opened the guide/package for the supported manual profile step.'
        } else {
            'NVIDIA setup package created. Profile Inspector opened with a guide for Control Panel and per-game settings.'
        }
        return [pscustomobject]@{ ok=$true; message=$msg; guidePath=$guide; presetGuide=$pack.guide; presetPath=$pack.json; commandPath=$pack.command; packageDir=$pack.dir; backupPath=$backupPath; tool=$npi; hidden=[bool]$IncludeHidden; import=$import; download=$downloadResult }
    }
    $openedGuide = Open-ApexTextFile ([string]$pack.guide)
    $openedFolder = Open-ApexFolder ([string]$pack.dir)
    return [pscustomobject]@{ ok=$true; message='NVIDIA preset package saved. Profile Inspector is downloading/opening in a separate window when needed, and ApexTune opened the preset guide/package immediately.'; guidePath=$guide; presetGuide=$pack.guide; presetPath=$pack.json; commandPath=$pack.command; packageDir=$pack.dir; backupPath=$null; tool=$null; hidden=[bool]$IncludeHidden; import=$null; download=$downloadResult; openedGuide=$openedGuide; openedFolder=$openedFolder }
}

function Invoke-GameOptimize([string]$GameId, [string]$Profile, [string]$GpuProvider = 'auto', [bool]$UseNvidiaHidden = $false) {
    $game = @(Get-GameCatalog | Where-Object { [string]$_.id -eq $GameId } | Select-Object -First 1)
    if (-not $game) { throw 'Game was not found in the ApexTune catalog.' }
    $resolve = Resolve-GameInstall $game -Deep
    if (-not [bool]$resolve.detected) { throw "ApexTune could not find $($game.name). Install it first or place it in a common launcher folder, then refresh Games." }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $profileSafe = ($Profile -replace '[^A-Za-z0-9]+','-')
    $backup = Join-Path $script:GamesDir "GameProfile-$($game.id)-$profileSafe-$stamp.json"
    $actions = @()
    $snapshots = @()
    $gameModeKey = 'HKCU:\Software\Microsoft\GameBar'
    $gcsKey = 'HKCU:\System\GameConfigStore'
    $gpuPrefKey = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    $layersKey = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
    foreach ($s in @(
        (Get-RegValueSnapshot $gameModeKey 'AutoGameModeEnabled'),
        (Get-RegValueSnapshot $gameModeKey 'AllowAutoGameMode'),
        (Get-RegValueSnapshot $gcsKey 'GameDVR_Enabled'),
        (Get-RegValueSnapshot $gcsKey 'GameDVR_FSEBehaviorMode'),
        (Get-RegValueSnapshot $gcsKey 'GameDVR_HonorUserFSEBehaviorMode')
    )) { $snapshots += $s }
    Set-ApexRegDword $gameModeKey 'AllowAutoGameMode' 1; $actions += 'Enabled Game Mode eligibility.'
    Set-ApexRegDword $gameModeKey 'AutoGameModeEnabled' 1; $actions += 'Enabled automatic Game Mode.'
    Set-ApexRegDword $gcsKey 'GameDVR_Enabled' 0; $actions += 'Disabled Game DVR capture overhead.'
    if ($Profile -in @('Competitive','Maximum FPS')) { Set-ApexRegDword $gcsKey 'GameDVR_FSEBehaviorMode' 2; Set-ApexRegDword $gcsKey 'GameDVR_HonorUserFSEBehaviorMode' 1; $actions += 'Applied fullscreen/frame pacing registry profile.' }
    if ($resolve.exePath) {
        $snapshots += Get-RegValueSnapshot $gpuPrefKey ([string]$resolve.exePath)
        $snapshots += Get-RegValueSnapshot $layersKey ([string]$resolve.exePath)
        if ($Profile -ne 'Balanced') { Set-ApexRegString $gpuPrefKey ([string]$resolve.exePath) 'GpuPreference=2;'; $actions += 'Set Windows high-performance GPU preference for the game executable.' }
        $layerValue = if ($Profile -in @('Competitive','Maximum FPS')) { '~ DISABLEDXMAXIMIZEDWINDOWEDMODE HIGHDPIAWARE' } else { '~ HIGHDPIAWARE' }
        Set-ApexRegString $layersKey ([string]$resolve.exePath) $layerValue; $actions += 'Applied per-game compatibility/fullscreen profile.'
        $procName = [IO.Path]::GetFileNameWithoutExtension([string]$resolve.exePath)
        $prio = if ($Profile -eq 'Quality') { 'AboveNormal' } else { 'High' }
        try { Get-Process -Name $procName -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = $prio }; $actions += "Applied $prio process priority to running instances when present." } catch {}
        $launcher = Join-Path $script:GamesDir ("Launch-$($game.id)-$profileSafe.ps1")
        $escapedExe = ([string]$resolve.exePath).Replace('"','`"')
        @(
            "# ApexTune launch profile for $($game.name)",
            ('`$exe = "' + $escapedExe + '"'),
            '`$p = Start-Process -FilePath `$exe -PassThru',
            'Start-Sleep -Seconds 3',
            "try { `$p.Refresh(); `$p.PriorityClass = '$prio' } catch {}"
        ) | Set-Content -Path $launcher -Encoding UTF8
        $actions += "Created launch profile: $launcher"
    }
    $effectiveProvider = if ($UseNvidiaHidden -and ([string]::IsNullOrWhiteSpace($GpuProvider) -or $GpuProvider -eq 'windows')) { 'nvidia' } else { Resolve-GameGpuProvider $GpuProvider }
    $vendorPackage = $null
    if ($effectiveProvider -ne 'windows') {
        $vendorPackage = Invoke-GpuVendorPreset $effectiveProvider $Profile $true $game
        if ($vendorPackage -and $vendorPackage.message) { $actions += ([string]$vendorPackage.message) }
    } else {
        $actions += 'Skipped vendor package by request; Windows-side game profile only.'
    }
    [pscustomobject]@{ game=$game.name; gameId=$game.id; profile=$Profile; gpuProvider=$effectiveProvider; installPath=$resolve.installPath; exePath=$resolve.exePath; snapshots=$snapshots; actions=$actions; vendorPackage=$vendorPackage; generated=(Get-Date).ToString('o') } | ConvertTo-Json -Depth 12 | Set-Content -Path $backup -Encoding UTF8
    $providerLabel = if ($effectiveProvider -eq 'nvidia') { 'NVIDIA' } elseif ($effectiveProvider -eq 'amd') { 'AMD' } elseif ($effectiveProvider -eq 'intel') { 'Intel' } else { 'Windows only' }
    return [pscustomobject]@{ ok=$true; game=$game.name; profile=$Profile; gpuProvider=$providerLabel; installPath=$resolve.installPath; exePath=$resolve.exePath; actions=$actions; vendorPackage=$vendorPackage; reportPath=$backup; message="Applied $Profile profile for $($game.name) with $providerLabel package mode." }
}

function Invoke-GameAction([string]$Action, [string]$GameId) {
    $game = @(Get-GameCatalog | Where-Object { [string]$_.id -eq $GameId } | Select-Object -First 1)
    if (-not $game) { throw 'Game was not found.' }
    $resolve = Resolve-GameInstall $game
    if ($Action -eq 'open') {
        if (-not [bool]$resolve.detected) { throw 'Game install folder was not found.' }
        Start-Process explorer.exe ([string]$resolve.installPath) | Out-Null
        return [pscustomobject]@{ ok=$true; message="Opened $($game.name) folder." }
    }
    return [pscustomobject]@{ ok=$true; message='Game action completed.' }
}

function New-GpuDriverActionList([string]$Vendor) {
    return @(
        [pscustomobject]@{ id='gpu:npi-install'; vendor='NVIDIA'; title='Profile Inspector'; description='Open NVIDIA Profile Inspector for advanced per-game driver profiles.'; recommended=($Vendor -eq 'NVIDIA'); label='Open' },
        [pscustomobject]@{ id='gpu:nvidia-control-panel'; vendor='NVIDIA'; title='NVIDIA Control Panel'; description='Open NVIDIA global and per-game 3D settings.'; recommended=($Vendor -eq 'NVIDIA'); label='Open' },
        [pscustomobject]@{ id='gpu:nvidia-settings-guide'; vendor='NVIDIA'; title='NVIDIA settings guide'; description='Create an ApexTune guide for Control Panel + Profile Inspector settings.'; recommended=($Vendor -eq 'NVIDIA'); label='Create' },
        [pscustomobject]@{ id='gpu:nvidia-official'; vendor='NVIDIA'; title='NVIDIA App / Driver'; description='Open NVIDIA app or driver setup.'; recommended=($Vendor -eq 'NVIDIA'); label='Open' },
        [pscustomobject]@{ id='gpu:amd-software'; vendor='AMD'; title='AMD Software'; description='Open AMD Software for Radeon game graphics settings.'; recommended=($Vendor -eq 'AMD'); label='Open' },
        [pscustomobject]@{ id='gpu:amd-settings-guide'; vendor='AMD'; title='AMD settings guide'; description='Create an ApexTune guide for AMD Software game/profile settings.'; recommended=($Vendor -eq 'AMD'); label='Create' },
        [pscustomobject]@{ id='gpu:amd-tuning'; vendor='AMD'; title='AMD tuning'; description='Open AMD performance tuning guidance and Radeon controls.'; recommended=($Vendor -eq 'AMD'); label='Open' },
        [pscustomobject]@{ id='gpu:amd-autodetect'; vendor='AMD'; title='AMD Driver'; description='Open AMD driver setup for Radeon graphics.'; recommended=($Vendor -eq 'AMD'); label='Open' },
        [pscustomobject]@{ id='gpu:intel-graphics'; vendor='Intel'; title='Intel Graphics'; description='Open Intel or Windows graphics controls.'; recommended=($Vendor -eq 'Intel'); label='Open' },
        [pscustomobject]@{ id='gpu:intel-settings-guide'; vendor='Intel'; title='Intel settings guide'; description='Create an ApexTune guide for Intel game/display graphics settings.'; recommended=($Vendor -eq 'Intel'); label='Create' },
        [pscustomobject]@{ id='gpu:windows-graphics'; vendor='All'; title='Windows graphics'; description='Open per-app Windows GPU preference settings.'; recommended=$false; label='Open' },
        [pscustomobject]@{ id='gpu:display-settings'; vendor='All'; title='Advanced display'; description='Open refresh-rate and monitor settings.'; recommended=$false; label='Open' },
        [pscustomobject]@{ id='gpu:device-manager'; vendor='All'; title='Device Manager'; description='Open Windows Device Manager for driver checks.'; recommended=$false; label='Open' },
        [pscustomobject]@{ id='gpu:inventory'; vendor='All'; title='Save GPU snapshot'; description='Save GPU names, driver versions, and display info to Reports.'; recommended=$true; label='Save' }
    )
}

function Find-NvidiaControlPanel {
    $paths = @(
        (Join-Path $env:ProgramFiles 'NVIDIA Corporation\Control Panel Client\nvcplui.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'NVIDIA Corporation\Control Panel Client\nvcplui.exe'),
        (Join-Path $env:SystemRoot 'System32\nvcplui.exe')
    ) | Where-Object { $_ }
    foreach ($path in $paths) { if (Test-Path -LiteralPath $path -PathType Leaf) { return $path } }
    try { $cmd = Get-Command 'nvcplui.exe' -ErrorAction SilentlyContinue; if ($cmd -and $cmd.Source) { return [string]$cmd.Source } } catch {}
    return $null
}

function Open-NvidiaControlPanel {
    $app = Find-NvidiaControlPanel
    if ($app) { Start-Process -FilePath $app | Out-Null; return [pscustomobject]@{ ok=$true; message='NVIDIA Control Panel opened.'; app=$app } }
    try { Start-Process 'ms-settings:display-advancedgraphics' | Out-Null } catch {}
    return [pscustomobject]@{ ok=$true; message='NVIDIA Control Panel was not found. Windows graphics settings opened instead.'; app=$null }
}

function Open-AmdSoftwarePanel {
    $app = Find-AmdSoftware
    if ($app) { Start-ApexFile $app; return [pscustomobject]@{ ok=$true; message='AMD Software opened.'; app=$app } }
    try { Start-Process 'ms-settings:display-advancedgraphics' | Out-Null } catch {}
    return [pscustomobject]@{ ok=$true; message='AMD Software was not found. Windows graphics settings opened instead.'; app=$null }
}

function Open-IntelGraphicsPanel {
    try { Start-Process 'ms-settings:display-advancedgraphics' | Out-Null } catch { try { Start-Process 'ms-settings:display-advanced' | Out-Null } catch {} }
    return [pscustomobject]@{ ok=$true; message='Intel / Windows graphics settings opened.' }
}


function Get-GpuDriverCenter {
    $now = [datetime]::UtcNow
    if ($script:GpuDriverCache -and (($now - $script:GpuDriverCacheAt).TotalSeconds -lt 180)) { return $script:GpuDriverCache }
    $gpuInfo = (Get-HardwareSnapshot).gpu
    $gpus = @($gpuInfo.adapters)
    $primaryName = if ($gpuInfo.name) { [string]$gpuInfo.name } else { 'Detected GPU' }
    $vendor = if ($gpuInfo.vendor -and $gpuInfo.vendor -ne 'GPU') { [string]$gpuInfo.vendor } else { if ($primaryName -match 'NVIDIA|GeForce|RTX|GTX|Quadro') { 'NVIDIA' } elseif ($primaryName -match 'AMD|Radeon') { 'AMD' } elseif ($primaryName -match 'Intel|Arc|Iris|UHD') { 'Intel' } else { 'Unknown' } }
    $actions = @(New-GpuDriverActionList $vendor)
    $result = [pscustomobject]@{ vendor=$vendor; primary=$primaryName; gpus=$gpus; actions=$actions; cached=$false; generated=(Get-Date).ToString('o') }
    $script:GpuDriverCache = $result
    $script:GpuDriverCacheAt = $now
    return $result
}

function New-GpuSettingsGuide([string]$Vendor, [string]$Preset = 'Competitive') {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $safeVendor = ($Vendor -replace '[^A-Za-z0-9]+','-')
    $dir = Join-Path $script:DriverPresetDir "$safeVendor-Settings-$stamp"
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $guide = Join-Path $dir "ApexTune-$safeVendor-Settings-Guide.txt"
    $lines = @()
    if ($Vendor -eq 'NVIDIA') {
        $lines = @(
            'ApexTune NVIDIA Settings Guide',
            "Generated: $(Get-Date -Format o)",
            "Preset: $Preset",
            '',
            'Open NVIDIA Control Panel > Manage 3D settings > Program Settings for game-specific settings.',
            'Use NVIDIA Profile Inspector only when you need advanced profile values not exposed in Control Panel.',
            'Good starting points: prefer maximum performance for selected games, low-latency mode when stable, shader cache on, and monitor refresh rate set correctly.'
        )
    } elseif ($Vendor -eq 'AMD') {
        $lines = @(
            'ApexTune AMD Settings Guide',
            "Generated: $(Get-Date -Format o)",
            "Preset: $Preset",
            '',
            'Open AMD Software > Gaming. Choose the game or global profile, then adjust Radeon graphics settings.',
            'Good starting points: use a Gaming/Performance profile, enable Anti-Lag when it helps the game, avoid capture/overlay features you do not use, and keep driver cache/default shader behavior enabled.'
        )
    } else {
        $lines = @(
            'ApexTune Intel Settings Guide',
            "Generated: $(Get-Date -Format o)",
            "Preset: $Preset",
            '',
            'Open Intel Graphics Software or Windows Graphics settings, then set the game to the high-performance adapter where available.',
            'Good starting points: use high-performance graphics preference for games, keep the driver current, and use Intel low-latency/frame options only when stable for that game.'
        )
    }
    Set-Content -Path $guide -Value $lines -Encoding UTF8
    [void](Open-ApexTextFile $guide)
    [void](Open-ApexFolder $dir)
    return [pscustomobject]@{ ok=$true; message="$Vendor settings guide created."; vendor=$Vendor; guidePath=$guide; packageDir=$dir }
}

function Invoke-GpuDriverAction([string]$Action) {
    switch ($Action) {
        'gpu:nvidia-profile-competitive' { return (Invoke-NvidiaProfilePreset 'Competitive' $true $null) }
        'gpu:nvidia-profile-maxfps' { return (Invoke-NvidiaProfilePreset 'Maximum FPS' $true $null) }
        'gpu:npi-install' { return (Install-NvidiaProfileInspector) }
        'gpu:nvidia-control-panel' { return (Open-NvidiaControlPanel) }
        'gpu:nvcleaninstall' { return (Install-NVCleanstall) }
        'gpu:nvidia-official' { return (Install-NvidiaAppDriverAssistant) }
        'gpu:amd-software' { return (Open-AmdSoftwarePanel) }
        'gpu:amd-autodetect' { return (Install-AmdDriverAssistant) }
        'gpu:amd-cleanup' { Start-Process 'https://www.amd.com/en/support/kb/faq/gpu-601' | Out-Null; return [pscustomobject]@{ ok=$true; message='AMD cleanup guidance opened.' } }
        'gpu:nvidia-settings-guide' { return (New-GpuSettingsGuide 'NVIDIA' 'Competitive') }
        'gpu:amd-settings-guide' { return (New-GpuSettingsGuide 'AMD' 'Competitive') }
        'gpu:amd-tuning' { Start-Process 'https://www.amd.com/en/resources/support-articles/faqs/DH3-020.html' | Out-Null; return [pscustomobject]@{ ok=$true; message='AMD performance tuning guidance opened.' } }
        'gpu:intel-settings-guide' { return (New-GpuSettingsGuide 'Intel' 'Competitive') }
        'gpu:intel-graphics' { return (Open-IntelGraphicsPanel) }
        'gpu:windows-graphics' { Start-Process 'ms-settings:display-advancedgraphics' | Out-Null; return [pscustomobject]@{ ok=$true; message='Windows graphics settings opened.' } }
        'gpu:amd-profile-competitive' { return (Invoke-AmdPreset 'Competitive') }
        'gpu:amd-profile-maxfps' { return (Invoke-AmdPreset 'Maximum FPS') }
        'gpu:inventory' { $file = New-InventoryReport 'gpu'; return [pscustomobject]@{ ok=$true; message='GPU snapshot saved'; path=$file } }
        'gpu:device-manager' { Start-Process 'devmgmt.msc' | Out-Null; return [pscustomobject]@{ ok=$true; message='Device Manager opened.' } }
        'gpu:official-driver-page' { $vendor=(Get-GpuDriverCenter).vendor; if ($vendor -match 'NVIDIA') { return (Invoke-GpuDriverAction 'gpu:nvidia-official') } elseif ($vendor -match 'AMD') { return (Invoke-GpuDriverAction 'gpu:amd-autodetect') } elseif ($vendor -match 'Intel') { return (Invoke-GpuDriverAction 'gpu:intel-graphics') } else { return (Invoke-GpuDriverAction 'gpu:device-manager') } }
        'gpu:display-settings' { Start-Process 'ms-settings:display-advanced' | Out-Null; return [pscustomobject]@{ ok=$true; message='Advanced display settings opened.' } }
        default { throw 'Unknown GPU driver action.' }
    }
}

function New-ApexPlanFiles($Tweaks) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $planPath = Join-Path $script:ReportsDir "ApexTune-Plan-$stamp.json"
    $rollbackPath = Join-Path $script:RollbackDir "ApexTune-Rollback-$stamp.ps1"
    $backupRoot = Join-Path $script:BackupDir $stamp
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

    $rollbackLines = @(
        '# ApexTune rollback script',
        "# Generated: $(Get-Date -Format o)",
        'Set-StrictMode -Version 2.0',
        '$ErrorActionPreference = ''Continue''',
        ''
    )
    foreach ($t in $Tweaks) {
        $rollbackLines += "# $($t.title)"
        foreach ($line in @($t.rollback)) { $rollbackLines += [string]$line }
        $rollbackLines += ''
    }
    Set-Content -Path $rollbackPath -Value $rollbackLines -Encoding UTF8

    $manifest = [pscustomobject]@{
        generated = (Get-Date).ToString('o')
        version = $script:Version
        user = $env:USERNAME
        admin = (Test-IsAdmin)
        tweakCount = @($Tweaks).Count
        tweaks = @($Tweaks | Select-Object id,title,tier,category,risk,fps,ping,restart)
        backupRoot = $backupRoot
        rollbackPath = $rollbackPath
    }
    $manifest | ConvertTo-Json -Depth 12 | Set-Content -Path $planPath -Encoding UTF8
    return [pscustomobject]@{ planPath = $planPath; rollbackPath = $rollbackPath; backupRoot = $backupRoot }
}


function Backup-BcdStore($Tweaks, [string]$BackupRoot) {
    $needsBcd = $false
    foreach ($t in @($Tweaks)) {
        foreach ($cmd in @($t.commands)) {
            if ([string]$cmd -match '(?i)\bbcdedit\b') { $needsBcd = $true }
        }
        foreach ($tag in @($t.tags)) {
            if ([string]$tag -match '(?i)BCDEdit|BCD|Boot') { $needsBcd = $true }
        }
    }
    if (-not $needsBcd) { return $null }
    try {
        $file = Join-Path $BackupRoot 'ApexTune-Bcd-Before.bak'
        $p = Start-Process -FilePath bcdedit.exe -ArgumentList @('/export', $file) -Wait -PassThru -WindowStyle Hidden
        if ($p.ExitCode -eq 0) { return $file }
        Write-ApexLog "BCD backup failed with exit code $($p.ExitCode)" 'WARN'
    } catch { Write-ApexLog "BCD backup failed: $($_.Exception.Message)" 'WARN' }
    return $null
}

function Backup-RegistryKeys($Tweaks, [string]$BackupRoot) {
    $exported = @()
    foreach ($key in @($Tweaks | ForEach-Object { $_.backupKeys } | Where-Object { $_ } | Sort-Object -Unique)) {
        try {
            $native = Convert-RegHiveName ([string]$key)
            $file = Join-Path $BackupRoot ((Get-SafeName $key) + '.reg')
            $p = Start-Process -FilePath reg.exe -ArgumentList @('export', $native, $file, '/y') -Wait -PassThru -WindowStyle Hidden
            if ($p.ExitCode -eq 0) { $exported += $file }
        } catch { Write-ApexLog "Registry backup failed for $key : $($_.Exception.Message)" 'WARN' }
    }
    return $exported
}

function Invoke-TweakCommand([string]$Command) {
    if ([string]::IsNullOrWhiteSpace($Command)) { return 0 }
    $trim = $Command.Trim()
    switch ($trim) {
        'gpu:download-npi' { [void](Install-NvidiaProfileInspector); return 0 }
        'gpu:download-nvcleanstall' { [void](Install-NVCleanstall); return 0 }
        'gpu:nvidia-app' { [void](Install-NvidiaAppDriverAssistant); return 0 }
        'gpu:amd-driver' { [void](Install-AmdDriverAssistant); return 0 }
    }
    $psLike = $trim.StartsWith('$') -or $trim -match '^(Write-Output|New-Item|Set-Item|Get-Item|Start-Process|Remove-Item|Copy-Item|Join-Path|powercfg\s|Get-CimInstance)'
    if ($psLike -and $trim -notmatch '^(reg|netsh|ipconfig|sc|bcdedit)\s') {
        $p = Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-Command', $trim) -Wait -PassThru -WindowStyle Hidden
        return $p.ExitCode
    } else {
        $p = Start-Process -FilePath cmd.exe -ArgumentList @('/c', $trim) -Wait -PassThru -WindowStyle Hidden
        return $p.ExitCode
    }
}

function Apply-Tweaks($Ids, [bool]$Confirmed) {
    $all = Get-Tweaks
    $selected = @($all | Where-Object { $Ids -contains $_.id })
    if (-not $selected.Count) { throw 'No selected tweaks were found.' }
    $maxRisk = 1
    foreach ($t in $selected) {
        $r = ([string]$t.risk).ToLowerInvariant()
        if ($r -eq 'high') { $maxRisk = [math]::Max($maxRisk, 3) }
        elseif ($r -eq 'medium') { $maxRisk = [math]::Max($maxRisk, 2) }
    }
    if ($maxRisk -ge 2 -and -not $Confirmed) { throw 'This plan includes medium/high risk tweaks and needs confirmation.' }
    if (-not (Test-IsAdmin)) { throw 'ApexTune must be launched as Administrator to apply system tweaks.' }

    $files = New-ApexPlanFiles $selected
    $vault = New-ApexRestoreVaultSession $selected $files 'tweak-apply'
    $restoreResult = 'Skipped'
    try {
        Checkpoint-Computer -Description 'ApexTune Command Center apply' -RestorePointType 'MODIFY_SETTINGS' | Out-Null
        $restoreResult = 'Created'
    } catch { $restoreResult = 'Unavailable: ' + $_.Exception.Message }
    $backupFiles = Backup-RegistryKeys $selected $files.backupRoot
    $bcdBackup = Backup-BcdStore $selected $files.backupRoot

    $applied = 0; $failed = 0; $results = @()
    foreach ($t in $selected) {
        foreach ($cmd in @($t.commands)) {
            try {
                $exit = Invoke-TweakCommand ([string]$cmd)
                if ($exit -eq 0) { $applied++ } else { $failed++ }
                $results += [pscustomobject]@{ id=$t.id; title=$t.title; command=$cmd; exitCode=$exit }
            } catch {
                $failed++
                $results += [pscustomobject]@{ id=$t.id; title=$t.title; command=$cmd; error=$_.Exception.Message }
            }
        }
    }

    $summary = [pscustomobject]@{
        applied = $applied
        failed = $failed
        restorePoint = $restoreResult
        backupCount = @($backupFiles).Count
        bcdBackup = $bcdBackup
        backupRoot = $files.backupRoot
        rollbackPath = $files.rollbackPath
        restoreVaultPath = $vault.path
        restoreVaultId = $vault.id
        planPath = $files.planPath
        restartRequired = [bool](@($selected | Where-Object { $_.restart }).Count)
        results = $results
    }
    $summaryPath = Join-Path $script:ReportsDir ('ApexTune-ApplySummary-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $statePath = Set-TweakStateRecords $selected 'applied' @{ planPath=$files.planPath; rollbackPath=$files.rollbackPath; summaryPath=$summaryPath; appliedCommands=$applied; failedCommands=$failed; restartRequired=[bool](@($selected | Where-Object { $_.restart }).Count) }
    $summary | Add-Member -NotePropertyName summaryPath -NotePropertyValue $summaryPath -Force
    $summary | Add-Member -NotePropertyName tweakStatePath -NotePropertyValue $statePath -Force
    $summary | ConvertTo-Json -Depth 12 | Set-Content -Path $summaryPath -Encoding UTF8
    return $summary
}

function Disable-Tweaks($Ids, [bool]$Confirmed) {
    $all = Get-Tweaks
    $selected = @($all | Where-Object { $Ids -contains $_.id })
    if (-not $selected.Count) { throw 'No selected tweaks were found.' }
    if (-not (Test-IsAdmin)) { throw 'ApexTune must be launched as Administrator to disable applied system tweaks.' }

    $files = New-ApexPlanFiles $selected
    $applied = 0; $failed = 0; $skipped = 0; $results = @()
    foreach ($t in $selected) {
        $rollback = @($t.rollback | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        if (-not $rollback.Count) {
            $skipped++
            $results += [pscustomobject]@{ id=$t.id; title=$t.title; skipped=$true; reason='No rollback commands listed for this tweak.' }
            continue
        }
        foreach ($cmd in $rollback) {
            try {
                $exit = Invoke-TweakCommand ([string]$cmd)
                if ($exit -eq 0) { $applied++ } else { $failed++ }
                $results += [pscustomobject]@{ id=$t.id; title=$t.title; command=$cmd; exitCode=$exit }
            } catch {
                $failed++
                $results += [pscustomobject]@{ id=$t.id; title=$t.title; command=$cmd; error=$_.Exception.Message }
            }
        }
    }
    $summaryPath = Join-Path $script:ReportsDir ('ApexTune-DisableSummary-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $stateStatus = if ($failed -gt 0) { 'rollback_failed' } else { 'disabled' }
    $statePath = Set-TweakStateRecords $selected $stateStatus @{ rollbackPath=$files.rollbackPath; summaryPath=$summaryPath; rollbackCommands=$applied; failedCommands=$failed; skippedTweaks=$skipped }
    $summary = [pscustomobject]@{
        ok = ($failed -eq 0)
        disabled = @($selected).Count
        applied = $applied
        failed = $failed
        skipped = $skipped
        rollbackPath = $files.rollbackPath
        planPath = $files.planPath
        summaryPath = $summaryPath
        tweakStatePath = $statePath
        stateStatus = $stateStatus
        results = $results
    }
    $summary | ConvertTo-Json -Depth 12 | Set-Content -Path $summaryPath -Encoding UTF8
    return $summary
}

function Save-Plan($Ids) {
    $all = Get-Tweaks
    $selected = @($all | Where-Object { $Ids -contains $_.id })
    if (-not $selected.Count) { throw 'No selected tweaks were found.' }
    $files = New-ApexPlanFiles $selected
    $statePath = Set-TweakStateRecords $selected 'queued' @{ planPath=$files.planPath; rollbackPath=$files.rollbackPath }
    return [pscustomobject]@{ saved = $true; planPath = $files.planPath; rollbackPath = $files.rollbackPath; tweakStatePath = $statePath }
}


function New-SystemSnapshotReport {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $path = Join-Path $script:ReportsDir "ApexTune-SystemSnapshot-$stamp.json"
    $payload = [pscustomobject]@{
        generated = (Get-Date).ToString('o')
        version = $script:Version
        user = $env:USERNAME
        admin = (Test-IsAdmin)
        status = (Get-Status)
        processes = @(Get-Process | Sort-Object CPU -Descending | Select-Object -First 15 Name,Id,CPU,WorkingSet64)
        services = @(Get-CimInstance Win32_Service | Where-Object { $_.State -eq 'Running' } | Select-Object -First 80 Name,DisplayName,State,StartMode)
    }
    $payload | ConvertTo-Json -Depth 8 | Set-Content -Path $path -Encoding UTF8
    return $path
}

function New-LatencyProbeReport {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $path = Join-Path $script:ReportsDir "ApexTune-LatencyProbe-$stamp.json"
    $targets = @('1.1.1.1','8.8.8.8')
    $results = foreach ($target in $targets) {
        try {
            $p = Test-Connection -ComputerName $target -Count 4 -ErrorAction Stop
            [pscustomobject]@{ target=$target; avgMs=[math]::Round((@($p | ForEach-Object ResponseTime) | Measure-Object -Average).Average,2); samples=@($p | Select-Object Address,ResponseTime) }
        } catch { [pscustomobject]@{ target=$target; error=$_.Exception.Message } }
    }
    [pscustomobject]@{ generated=(Get-Date).ToString('o'); results=@($results) } | ConvertTo-Json -Depth 8 | Set-Content -Path $path -Encoding UTF8
    return $path
}

function New-InventoryReport([string]$Kind) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $safe = Get-SafeName $Kind
    $path = Join-Path $script:ReportsDir "ApexTune-$safe-Inventory-$stamp.json"
    $data = switch ($Kind) {
        'gpu' { @(Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,AdapterRAM,VideoProcessor,CurrentHorizontalResolution,CurrentVerticalResolution) }
        'startup' { @(Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User) }
        'network' { @(Get-CimInstance Win32_NetworkAdapter | Select-Object Name,NetConnectionID,AdapterType,MACAddress,Speed,NetEnabled) }
        default { @(Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,LastBootUpTime) }
    }
    [pscustomobject]@{ generated=(Get-Date).ToString('o'); kind=$Kind; data=$data } | ConvertTo-Json -Depth 8 | Set-Content -Path $path -Encoding UTF8
    return $path
}



function Quote-ApexCmdArgument([string]$Value) {
    $s = [string]$Value
    if ($s -eq '') { return '""' }
    if ($s -match '\s') {
        return '"' + ($s -replace '"','\"') + '"'
    }
    return $s
}

function Join-ApexPowerCfgCommand([string]$Exe, [string[]]$PowerArgs) {
    $parts = @((Quote-ApexCmdArgument $Exe))
    foreach ($a in @($PowerArgs)) { $parts += (Quote-ApexCmdArgument ([string]$a)) }
    return ($parts -join ' ')
}

function Invoke-ApexPowerCfg {
    param(
        [Parameter(Mandatory=$true)]
        [Alias('Args')]
        [string[]]$PowerArgs,
        [switch]$IgnoreErrors
    )
    $exe = Join-Path $env:SystemRoot 'System32\powercfg.exe'
    if (-not (Test-Path $exe -PathType Leaf)) { $exe = 'powercfg.exe' }
    $argList = @($PowerArgs | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($argList.Count -lt 1) {
        if ($IgnoreErrors) { return 'No powercfg arguments were supplied.' }
        throw 'No powercfg arguments were supplied.'
    }

    $lastText = ''
    $lastExit = 0
    try {
        Write-ApexLog ("powercfg direct: {0}" -f ($argList -join ' ')) 'DEBUG'
        $out = & $exe @argList 2>&1
        $lastExit = $LASTEXITCODE
        $lastText = (@($out) -join "`n").Trim()
    } catch {
        $lastExit = 1
        $lastText = ([string]$_.Exception.Message).Trim()
    }

    $needsRetry = ($lastExit -ne 0) -or (Test-ApexPowerCfgFailed $lastText)
    if ($needsRetry) {
        try {
            $cmd = Join-ApexPowerCfgCommand $exe $argList
            Write-ApexLog ("powercfg cmd fallback: $cmd") 'DEBUG'
            $out2 = & cmd.exe /d /s /c $cmd 2>&1
            $exit2 = $LASTEXITCODE
            $text2 = (@($out2) -join "`n").Trim()
            if (($exit2 -eq 0) -and (-not (Test-ApexPowerCfgFailed $text2))) { return $text2 }
            if (-not [string]::IsNullOrWhiteSpace($text2)) { $lastText = $text2; $lastExit = $exit2 }
        } catch {
            $fallbackText = ([string]$_.Exception.Message).Trim()
            if (-not [string]::IsNullOrWhiteSpace($fallbackText)) { $lastText = $fallbackText; $lastExit = 1 }
        }
    }

    if (($lastExit -ne 0 -or (Test-ApexPowerCfgFailed $lastText)) -and (-not $IgnoreErrors)) { throw $lastText }
    return $lastText
}

function Get-ApexGuidFromText([string]$Text) {
    if ($Text -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { return $Matches[1].ToLowerInvariant() }
    return $null
}

function Get-ApexPowerSchemeAliases {
    return [ordered]@{
        balanced = '381b4222-f694-41f0-9685-ff5bb260df2e'
        saver = 'a1841308-3541-4fab-bc81-f71556f20b4a'
        high = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
        ultimate = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
    }
}

function Resolve-ApexPowerBaseGuid([string]$Base) {
    $aliases = Get-ApexPowerSchemeAliases
    $b = ([string]$Base).Trim().ToLowerInvariant()
    if ($b -match '^[0-9a-fA-F-]{36}$') { return $b }
    if ($b -match 'ultimate|apex|performance') { return $aliases.ultimate }
    if ($b -match 'high') { return $aliases.high }
    if ($b -match 'saver|battery') { return $aliases.saver }
    return $aliases.balanced
}

function Read-ApexPowerState {
    if (-not (Test-Path $script:PowerStatePath -PathType Leaf)) {
        return [pscustomobject]@{ templates=@(); history=@(); lastApplied=$null; previous=$null }
    }
    try {
        $raw = Get-Content -Raw -Path $script:PowerStatePath -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($raw)) { return [pscustomobject]@{ templates=@(); history=@(); lastApplied=$null; previous=$null } }
        return ($raw | ConvertFrom-Json)
    } catch {
        Write-ApexLog "Power state read failed: $($_.Exception.Message)" 'WARN'
        return [pscustomobject]@{ templates=@(); history=@(); lastApplied=$null; previous=$null }
    }
}

function Save-ApexPowerState($State) {
    $State | ConvertTo-Json -Depth 20 | Set-Content -Path $script:PowerStatePath -Encoding UTF8
    return $script:PowerStatePath
}

function Get-ApexActivePowerScheme {
    $out = Invoke-ApexPowerCfg -Args @('/getactivescheme') -IgnoreErrors
    $guid = Get-ApexGuidFromText $out
    $name = ''
    if ($out -match '\(([^\)]+)\)') { $name = $Matches[1] }
    if (-not $guid) { $guid = '' }
    if ([string]::IsNullOrWhiteSpace($name)) { $name = 'Unknown power plan' }
    return [pscustomobject]@{ guid=$guid; name=$name; raw=$out }
}

function Get-ApexPowerSchemes {
    $out = Invoke-ApexPowerCfg -Args @('/list') -IgnoreErrors
    $items = @()
    foreach ($line in ($out -split "`r?`n")) {
        if ($line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}).*\(([^\)]+)\)(\s*\*)?') {
            $items += [pscustomobject]@{ guid=$Matches[1].ToLowerInvariant(); name=$Matches[2]; active=([string]$Matches[3]).Contains('*') }
        }
    }
    return @($items)
}

function Find-ApexPowerSchemeByName([string]$Name) {
    $needle = ([string]$Name).Trim().ToLowerInvariant()
    return @(Get-ApexPowerSchemes | Where-Object { ([string](Get-ApexObjectValue $_ 'name' '')).Trim().ToLowerInvariant() -eq $needle } | Select-Object -First 1)
}

function Export-ApexPowerSchemeBackup([string]$Guid, [string]$Label) {
    if ([string]::IsNullOrWhiteSpace($Guid)) { return $null }
    $safe = ([string]$Label -replace '[^a-zA-Z0-9_-]', '_')
    $path = Join-Path $script:PowerDir ("{0}_{1}.pow" -f (Get-Date -Format 'yyyyMMdd_HHmmss'), $safe)
    Invoke-ApexPowerCfg -Args @('/export', $path, $Guid) -IgnoreErrors | Out-Null
    if (Test-Path $path -PathType Leaf) { return $path }
    return $null
}

function Reset-ApexPowerApplyLog {
    $script:ApexPowerApplyLog = [ordered]@{ applied=@(); skipped=@() }
}

function Add-ApexPowerApplyResult([string]$Label, [bool]$Ok, [string]$Output = '') {
    if ($null -eq $script:ApexPowerApplyLog) { Reset-ApexPowerApplyLog }
    $item = [pscustomobject]@{ setting=$Label; output=([string]$Output).Trim() }
    if ($Ok) { $script:ApexPowerApplyLog.applied += $item } else { $script:ApexPowerApplyLog.skipped += $item }
}

function Invoke-ApexPowerCfgSoft {
    param(
        [Parameter(Mandatory=$true)]
        [Alias('Args')]
        [string[]]$PowerArgs,
        [string]$Label = 'Power setting'
    )
    $argList = @($PowerArgs | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($argList.Count -lt 1) {
        Add-ApexPowerApplyResult $Label $false 'No powercfg arguments were supplied.'
        return $false
    }
    $out = Invoke-ApexPowerCfg -PowerArgs $argList -IgnoreErrors
    $text = ([string]$out).Trim()
    $failed = Test-ApexPowerCfgFailed $text
    Add-ApexPowerApplyResult $Label (-not $failed) $text
    return (-not $failed)
}

function Test-ApexPowerCfgFailed([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return $false }
    return ($Text -match '(?i)Invalid Parameters|parameter is incorrect|not supported|unable|error|denied|cannot|could not|not recognized|requires elevation|access is denied|The power scheme, subgroup or setting specified does not exist')
}

function Invoke-ApexPowerSetActiveSoft([string]$Guid, [string]$Label = 'Activate power plan') {
    if ([string]::IsNullOrWhiteSpace($Guid)) {
        Add-ApexPowerApplyResult $Label $false 'Missing power plan GUID.'
        return $false
    }
    return (Invoke-ApexPowerCfgSoft -Args @('/setactive', $Guid) -Label $Label)
}

function Test-ApexPowerSchemeExists([string]$Guid) {
    if ([string]::IsNullOrWhiteSpace($Guid)) { return $false }
    $g = $Guid.Trim().ToLowerInvariant()
    return [bool](@(Get-ApexPowerSchemes | Where-Object { ([string]$_.guid).ToLowerInvariant() -eq $g } | Select-Object -First 1))
}

function Set-ApexPowerValue([string]$SchemeGuid, [string]$SubGroup, [string]$Setting, $Ac, $Dc, [string]$Label = '') {
    if ([string]::IsNullOrWhiteSpace($SchemeGuid) -or [string]::IsNullOrWhiteSpace($SubGroup) -or [string]::IsNullOrWhiteSpace($Setting)) {
        $missingLabel = $Label
        if ([string]::IsNullOrWhiteSpace($missingLabel)) { $missingLabel = 'Power setting' }
        Add-ApexPowerApplyResult $missingLabel $false 'Missing scheme/subgroup/setting GUID.'
        return
    }
    if ([string]::IsNullOrWhiteSpace($Label)) { $Label = $Setting }
    if ($null -ne $Ac -and ([string]$Ac) -ne '') {
        Invoke-ApexPowerCfgSoft -Args @('/setacvalueindex', $SchemeGuid, $SubGroup, $Setting, ([string][int]$Ac)) -Label "$Label plugged in" | Out-Null
    }
    if ($null -ne $Dc -and ([string]$Dc) -ne '') {
        Invoke-ApexPowerCfgSoft -Args @('/setdcvalueindex', $SchemeGuid, $SubGroup, $Setting, ([string][int]$Dc)) -Label "$Label battery" | Out-Null
    }
}

function Invoke-ApexPowerUnhide {
    $processor = '54533251-82be-4824-96c1-47b60b740d00'
    $settings = @(
        @($processor,'be337238-0d82-4146-a960-4f3749d470c7','Processor boost mode'),
        @($processor,'893dee8e-2bef-41e0-89c6-b55d0929964c','Processor minimum state'),
        @($processor,'bc5038f7-23e0-4960-96da-33abaf5935ec','Processor maximum state'),
        @($processor,'0cc5b647-c1df-4637-891a-dec35c318583','Core parking minimum cores'),
        @($processor,'ea062031-0e34-4ff1-9b6d-eb1059334028','Core parking maximum cores'),
        @($processor,'94d3a615-a899-4ac5-ae2b-e4d8f634367f','System cooling policy'),
        @('501a4d13-42af-4429-9fd1-a8218c268e20','ee12f906-d277-404b-b6da-e5fa1a576df5','PCIe link state power management'),
        @('2a737441-1930-4402-8d77-b2bebba308a3','48e6b7a6-50f5-4782-a5d4-53bb8f07e226','USB selective suspend'),
        @('7516b95f-f776-4464-8c53-06167f40cc99','3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e','Turn display off'),
        @('238c9fa8-0aad-41ed-83f4-97be242c8f20','29f6c1db-86da-48c5-9fdb-f2b67b1f44da3','Sleep after'),
        @('238c9fa8-0aad-41ed-83f4-97be242c8f20','9d7815a6-7ee4-497e-8888-515a05f02364','Hibernate after'),
        @('238c9fa8-0aad-41ed-83f4-97be242c8f20','94ac6d29-73ce-41a6-809f-6363ba21b47e','Hybrid sleep')
    )
    $shown = 0; $skipped = 0
    foreach ($s in $settings) {
        $out = Invoke-ApexPowerCfg -Args @('/attributes', [string]$s[0], [string]$s[1], '-ATTRIB_HIDE') -IgnoreErrors
        if (([string]$out) -match '(?i)Invalid Parameters|not supported|error|denied') { $skipped++ } else { $shown++ }
    }
    return [pscustomobject]@{ ok=$true; message='Advanced power settings are ready where Windows supports them.'; count=$shown; skipped=$skipped }
}


function New-ApexPowerScheme([string]$Base, [string]$Name, [string]$Description) {
    $aliases = Get-ApexPowerSchemeAliases
    $candidates = @()

    try {
        $active = Get-ApexActivePowerScheme
        if ($active -and $active.guid) { $candidates += ([string]$active.guid) }
    } catch {}

    $resolved = Resolve-ApexPowerBaseGuid $Base
    if (-not [string]::IsNullOrWhiteSpace($resolved)) { $candidates += $resolved }

    try {
        $listed = @(Get-ApexPowerSchemes)
        $balancedListed = @($listed | Where-Object { ([string]$_.name) -match '(?i)balanced' } | Select-Object -First 1)
        $highListed = @($listed | Where-Object { ([string]$_.name) -match '(?i)high|performance|ultimate' } | Select-Object -First 1)
        if ($balancedListed -and $balancedListed[0].guid) { $candidates += ([string]$balancedListed[0].guid) }
        if ($highListed -and $highListed[0].guid) { $candidates += ([string]$highListed[0].guid) }
    } catch {}

    $candidates += @(
        $aliases.balanced,
        $aliases.high,
        'SCHEME_CURRENT',
        'SCHEME_BALANCED',
        'SCHEME_MAX'
    )

    if (([string]$Base) -match '(?i)ultimate|apex|performance') { $candidates += $aliases.ultimate }

    $candidates = @($candidates | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { ([string]$_).Trim() } | Select-Object -Unique)
    $lastOutput = ''
    $attemptLog = @()

    foreach ($baseGuid in $candidates) {
        $destGuid = ([guid]::NewGuid()).Guid.ToLowerInvariant()
        $attempts = @(
            @('/duplicatescheme', $baseGuid),
            @('/duplicatescheme', $baseGuid, $destGuid),
            @('-duplicatescheme', $baseGuid),
            @('-duplicatescheme', $baseGuid, ([guid]::NewGuid()).Guid.ToLowerInvariant())
        )
        foreach ($dupArgs in $attempts) {
            $attemptLabel = ($dupArgs -join ' ')
            $out = Invoke-ApexPowerCfg -PowerArgs $dupArgs -IgnoreErrors
            $lastOutput = ([string]$out).Trim()
            $attemptLog += ([pscustomobject]@{ command=$attemptLabel; output=$lastOutput })
            if (Test-ApexPowerCfgFailed $lastOutput) { continue }
            $createdGuid = Get-ApexGuidFromText $lastOutput
            if ([string]::IsNullOrWhiteSpace($createdGuid) -and $dupArgs.Count -ge 3 -and ([string]$dupArgs[2]) -match '^[0-9a-fA-F-]{36}$') { $createdGuid = [string]$dupArgs[2] }
            if ([string]::IsNullOrWhiteSpace($createdGuid)) { continue }

            Invoke-ApexPowerCfg -PowerArgs @('/changename', $createdGuid, $Name) -IgnoreErrors | Out-Null
            if (-not [string]::IsNullOrWhiteSpace($Description)) {
                Invoke-ApexPowerCfg -PowerArgs @('/changename', $createdGuid, $Name, $Description) -IgnoreErrors | Out-Null
            }
            Start-Sleep -Milliseconds 180
            $named = Find-ApexPowerSchemeByName $Name
            if ($named -and $named.guid) { return ([string]$named.guid) }
            if (Test-ApexPowerSchemeExists $createdGuid) { return $createdGuid }
            return $createdGuid
        }
    }

    $existing = Find-ApexPowerSchemeByName $Name
    if ($existing -and $existing.guid) { return ([string]$existing.guid) }

    try {
        $diagPath = Join-Path $script:PowerDir ('PowerPlanCreateFailure-{0}.json' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
        [pscustomobject]@{ requestedName=$Name; base=$Base; candidates=$candidates; attempts=$attemptLog } | ConvertTo-Json -Depth 8 | Set-Content -Path $diagPath -Encoding UTF8
        Write-ApexLog "Power plan create diagnostics saved: $diagPath" 'WARN'
    } catch {}
    throw "Could not create the Windows power plan. Last powercfg output: $lastOutput"
}

function Ensure-ApexPowerScheme([string]$Name, [string]$Base, [string]$Description) {
    $existing = Find-ApexPowerSchemeByName $Name
    if ($existing -and $existing.guid) { return ([string]$existing.guid) }
    return (New-ApexPowerScheme $Base $Name $Description)
}

function Get-ApexPowerDefaults {
    return [pscustomobject]@{
        name='My ApexTune Plan'; base='balanced'; setActive=$true;
        processorMinAc=35; processorMinDc=5; processorMaxAc=100; processorMaxDc=100;
        boostModeAc=2; boostModeDc=4; coreParkingMinAc=100; coreParkingMinDc=10; coreParkingMaxAc=100; coreParkingMaxDc=100;
        coolingAc=0; coolingDc=1; pcieAc=0; pcieDc=1; usbAc=0; usbDc=1;
        displayOffAc=0; displayOffDc=10; sleepAc=0; sleepDc=20; hibernateAc=0; hibernateDc=60
    }
}

function ConvertTo-ApexPowerInt($Value, [int]$Default, [int]$Min, [int]$Max) {
    try { $n = [int]$Value } catch { $n = $Default }
    if ($n -lt $Min) { return $Min }
    if ($n -gt $Max) { return $Max }
    return $n
}

function Set-ApexPowerTuning([string]$SchemeGuid, $Spec, [bool]$Activate = $true) {
    Reset-ApexPowerApplyLog
    $processor = '54533251-82be-4824-96c1-47b60b740d00'
    $display = '7516b95f-f776-4464-8c53-06167f40cc99'
    $sleep = '238c9fa8-0aad-41ed-83f4-97be242c8f20'
    $pcie = '501a4d13-42af-4429-9fd1-a8218c268e20'
    $usb = '2a737441-1930-4402-8d77-b2bebba308a3'
    Set-ApexPowerValue $SchemeGuid $processor '893dee8e-2bef-41e0-89c6-b55d0929964c' $Spec.processorMinAc $Spec.processorMinDc 'CPU minimum state'
    Set-ApexPowerValue $SchemeGuid $processor 'bc5038f7-23e0-4960-96da-33abaf5935ec' $Spec.processorMaxAc $Spec.processorMaxDc 'CPU maximum state'
    Set-ApexPowerValue $SchemeGuid $processor 'be337238-0d82-4146-a960-4f3749d470c7' $Spec.boostModeAc $Spec.boostModeDc 'CPU boost mode'
    Set-ApexPowerValue $SchemeGuid $processor '0cc5b647-c1df-4637-891a-dec35c318583' $Spec.coreParkingMinAc $Spec.coreParkingMinDc 'Core parking minimum cores'
    Set-ApexPowerValue $SchemeGuid $processor 'ea062031-0e34-4ff1-9b6d-eb1059334028' $Spec.coreParkingMaxAc $Spec.coreParkingMaxDc 'Core parking maximum cores'
    Set-ApexPowerValue $SchemeGuid $processor '94d3a615-a899-4ac5-ae2b-e4d8f634367f' $Spec.coolingAc $Spec.coolingDc 'Cooling policy'
    Set-ApexPowerValue $SchemeGuid $pcie 'ee12f906-d277-404b-b6da-e5fa1a576df5' $Spec.pcieAc $Spec.pcieDc 'PCIe link power saving'
    Set-ApexPowerValue $SchemeGuid $usb '48e6b7a6-50f5-4782-a5d4-53bb8f07e226' $Spec.usbAc $Spec.usbDc 'USB selective suspend'
    Set-ApexPowerValue $SchemeGuid $display '3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e' ($Spec.displayOffAc * 60) ($Spec.displayOffDc * 60) 'Turn display off after'
    Set-ApexPowerValue $SchemeGuid $sleep '29f6c1db-86da-48c5-9fdb-f2b67b1f44da3' ($Spec.sleepAc * 60) ($Spec.sleepDc * 60) 'Sleep after'
    Set-ApexPowerValue $SchemeGuid $sleep '9d7815a6-7ee4-497e-8888-515a05f02364' ($Spec.hibernateAc * 60) ($Spec.hibernateDc * 60) 'Hibernate after'
    Set-ApexPowerValue $SchemeGuid $sleep '94ac6d29-73ce-41a6-809f-6363ba21b47e' 0 0 'Hybrid sleep'
    $activeOk = $false
    if ($Activate) { $activeOk = Invoke-ApexPowerSetActiveSoft $SchemeGuid 'Activate power plan' }
    return [pscustomobject]@{ applied=@($script:ApexPowerApplyLog.applied); skipped=@($script:ApexPowerApplyLog.skipped); active=$activeOk }
}


function Get-ApexObjectValue($Obj, [string]$Name, $Default = $null) {
    if ($null -eq $Obj -or [string]::IsNullOrWhiteSpace($Name)) { return $Default }
    try {
        $prop = $Obj.PSObject.Properties[$Name]
        if ($prop) { return $prop.Value }
    } catch {}
    return $Default
}

function New-ApexPowerSpecFromBody($Body) {
    $d = Get-ApexPowerDefaults
    $name = ([string](Get-ApexObjectValue $Body 'name' $d.name)).Trim()
    if ([string]::IsNullOrWhiteSpace($name)) { $name = $d.name }
    $name = ($name -replace '[\r\n\t]', ' ').Trim()
    if ($name.Length -gt 64) { $name = $name.Substring(0,64) }
    $setActiveRaw = Get-ApexObjectValue $Body 'setActive' $true
    return [pscustomobject]@{
        name=$name; base=([string](Get-ApexObjectValue $Body 'base' $d.base)); setActive=[bool]$setActiveRaw;
        processorMinAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'processorMinAc' $d.processorMinAc) $d.processorMinAc 0 100
        processorMinDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'processorMinDc' $d.processorMinDc) $d.processorMinDc 0 100
        processorMaxAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'processorMaxAc' $d.processorMaxAc) $d.processorMaxAc 1 100
        processorMaxDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'processorMaxDc' $d.processorMaxDc) $d.processorMaxDc 1 100
        boostModeAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'boostModeAc' $d.boostModeAc) $d.boostModeAc 0 5
        boostModeDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'boostModeDc' $d.boostModeDc) $d.boostModeDc 0 5
        coreParkingMinAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'coreParkingMinAc' $d.coreParkingMinAc) $d.coreParkingMinAc 0 100
        coreParkingMinDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'coreParkingMinDc' $d.coreParkingMinDc) $d.coreParkingMinDc 0 100
        coreParkingMaxAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'coreParkingMaxAc' $d.coreParkingMaxAc) $d.coreParkingMaxAc 0 100
        coreParkingMaxDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'coreParkingMaxDc' $d.coreParkingMaxDc) $d.coreParkingMaxDc 0 100
        coolingAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'coolingAc' $d.coolingAc) $d.coolingAc 0 1
        coolingDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'coolingDc' $d.coolingDc) $d.coolingDc 0 1
        pcieAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'pcieAc' $d.pcieAc) $d.pcieAc 0 2
        pcieDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'pcieDc' $d.pcieDc) $d.pcieDc 0 2
        usbAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'usbAc' $d.usbAc) $d.usbAc 0 1
        usbDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'usbDc' $d.usbDc) $d.usbDc 0 1
        displayOffAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'displayOffAc' $d.displayOffAc) $d.displayOffAc 0 240
        displayOffDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'displayOffDc' $d.displayOffDc) $d.displayOffDc 0 240
        sleepAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'sleepAc' $d.sleepAc) $d.sleepAc 0 240
        sleepDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'sleepDc' $d.sleepDc) $d.sleepDc 0 240
        hibernateAc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'hibernateAc' $d.hibernateAc) $d.hibernateAc 0 1440
        hibernateDc=ConvertTo-ApexPowerInt (Get-ApexObjectValue $Body 'hibernateDc' $d.hibernateDc) $d.hibernateDc 0 1440
    }
}
function Get-ApexPowerCenter {
    $active = Get-ApexActivePowerScheme
    $schemes = @(Get-ApexPowerSchemes)
    $state = Read-ApexPowerState
    $created = @(Get-ApexCreatedPowerSchemes -State $state -Schemes $schemes)
    return [pscustomobject]@{
        ok=$true
        active=$active
        schemes=$schemes
        created=$created
        saved=$state
        defaults=(Get-ApexPowerDefaults)
        powerStatePath=$script:PowerStatePath
        note='Power plans use Windows powercfg. ApexTune saves the active plan, backup path, and custom templates before applying changes.'
    }
}


function Test-ApexBuiltInPowerGuid([string]$Guid) {
    if ([string]::IsNullOrWhiteSpace($Guid)) { return $false }
    $g = $Guid.Trim().ToLowerInvariant()
    $aliases = Get-ApexPowerSchemeAliases
    return @($aliases.balanced, $aliases.saver, $aliases.high, $aliases.ultimate) -contains $g
}

function Normalize-ApexPowerGuid([object]$Value) {
    $g = ([string]$Value).Trim().ToLowerInvariant()
    if ($g -match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') { return $g }
    return $null
}

function Add-ApexCreatedPowerCandidate([hashtable]$Map, [object]$Item, [string]$Kind, [string]$Source) {
    if ($null -eq $Item) { return }
    $guid = Normalize-ApexPowerGuid (Get-ApexObjectValue $Item 'guid' '')
    if ([string]::IsNullOrWhiteSpace($guid) -or (Test-ApexBuiltInPowerGuid $guid)) { return }
    if ($Map.ContainsKey($guid)) { return }
    $name = ([string](Get-ApexObjectValue $Item 'name' '')).Trim()
    if ([string]::IsNullOrWhiteSpace($name)) { $name = 'ApexTune power plan' }
    $createdAt = [string](Get-ApexObjectValue $Item 'createdAt' '')
    $appliedAt = [string](Get-ApexObjectValue $Item 'appliedAt' '')
    $Map[$guid] = [pscustomobject]@{
        guid=$guid
        name=$name
        kind=$Kind
        source=$Source
        createdAt=$createdAt
        appliedAt=$appliedAt
    }
}

function Get-ApexCreatedPowerSchemes {
    param(
        $State = $null,
        $Schemes = $null
    )
    if ($null -eq $State) { $State = Read-ApexPowerState }
    if ($null -eq $Schemes) { $Schemes = @(Get-ApexPowerSchemes) }

    $candidateMap = @{}
    foreach ($template in @(Get-ApexObjectValue $State 'templates' @())) { Add-ApexCreatedPowerCandidate $candidateMap $template 'Custom' 'Saved custom plan' }
    foreach ($entry in @(Get-ApexObjectValue $State 'history' @())) {
        $kind = [string](Get-ApexObjectValue $entry 'kind' '')
        if ($kind -match '^(ApexTune|Custom)$') { Add-ApexCreatedPowerCandidate $candidateMap $entry $kind 'ApexTune history' }
    }
    $lastApplied = Get-ApexObjectValue $State 'lastApplied' $null
    if ($null -ne $lastApplied) {
        $kind = [string](Get-ApexObjectValue $lastApplied 'kind' 'ApexTune')
        if ($kind -match '^(ApexTune|Custom)$') { Add-ApexCreatedPowerCandidate $candidateMap $lastApplied $kind 'Last applied' }
    }

    $liveByGuid = @{}
    foreach ($scheme in @($Schemes)) {
        $guid = Normalize-ApexPowerGuid (Get-ApexObjectValue $scheme 'guid' '')
        if (-not [string]::IsNullOrWhiteSpace($guid)) { $liveByGuid[$guid] = $scheme }
    }

    foreach ($scheme in @($Schemes)) {
        $guid = Normalize-ApexPowerGuid (Get-ApexObjectValue $scheme 'guid' '')
        $name = [string](Get-ApexObjectValue $scheme 'name' '')
        if ([string]::IsNullOrWhiteSpace($guid) -or (Test-ApexBuiltInPowerGuid $guid)) { continue }
        if ($candidateMap.ContainsKey($guid)) { continue }
        if ($name -match '(?i)\bApexTune\b|My Competitive Power Plan|My Laptop Safe Plan') {
            $candidateMap[$guid] = [pscustomobject]@{
                guid=$guid
                name=$name
                kind='Detected'
                source='Detected by name'
                createdAt=''
                appliedAt=''
            }
        }
    }

    $created = @()
    foreach ($key in @($candidateMap.Keys | Sort-Object)) {
        $candidate = $candidateMap[$key]
        $live = if ($liveByGuid.ContainsKey($key)) { $liveByGuid[$key] } else { $null }
        $liveName = if ($live) { [string](Get-ApexObjectValue $live 'name' '') } else { '' }
        $displayName = if (-not [string]::IsNullOrWhiteSpace($liveName)) { $liveName } else { [string]$candidate.name }
        $isActive = if ($live) { [bool](Get-ApexObjectValue $live 'active' $false) } else { $false }
        $exists = [bool]$live
        $created += [pscustomobject]@{
            guid=$key
            name=$displayName
            kind=[string]$candidate.kind
            source=[string]$candidate.source
            createdAt=[string]$candidate.createdAt
            appliedAt=[string]$candidate.appliedAt
            active=$isActive
            exists=$exists
            deletable=$exists
        }
    }
    return @($created | Sort-Object @{Expression='exists';Descending=$true}, @{Expression='active';Descending=$true}, @{Expression='name';Ascending=$true})
}

function Remove-ApexPowerSchemeSoft([string]$Guid) {
    $attempts = @(
        @('/delete', $Guid),
        @('-delete', $Guid),
        @('/deletescheme', $Guid),
        @('-deletescheme', $Guid)
    )
    $last = ''
    foreach ($args in $attempts) {
        $out = Invoke-ApexPowerCfg -PowerArgs $args -IgnoreErrors
        $last = ([string]$out).Trim()
        if ((-not (Test-ApexPowerCfgFailed $last)) -and (-not (Test-ApexPowerSchemeExists $Guid))) {
            return [pscustomobject]@{ ok=$true; output=$last; command=($args -join ' ') }
        }
    }
    return [pscustomobject]@{ ok=$false; output=$last; command='powercfg delete' }
}

function Remove-ApexCreatedPowerPlans($Body) {
    $rawGuids = @(Get-ApexObjectValue $Body 'guids' @())
    if ($rawGuids.Count -eq 1 -and ($rawGuids[0] -is [array])) { $rawGuids = @($rawGuids[0]) }
    $requested = @($rawGuids | ForEach-Object { Normalize-ApexPowerGuid $_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
    if ($requested.Count -lt 1) { throw 'Select at least one ApexTune-created power plan to delete.' }

    $schemes = @(Get-ApexPowerSchemes)
    $state = Read-ApexPowerState
    $managed = @(Get-ApexCreatedPowerSchemes -State $state -Schemes $schemes | Where-Object { $_.exists -and $_.deletable })
    $allowed = @{}
    foreach ($plan in $managed) { $allowed[[string]$plan.guid] = $plan }

    $targets = @()
    $blocked = @()
    foreach ($guid in $requested) {
        if ($allowed.ContainsKey($guid)) { $targets += $allowed[$guid] }
        else { $blocked += [pscustomobject]@{ guid=$guid; reason='Not an ApexTune-created/deletable plan, or it no longer exists.' } }
    }
    if ($targets.Count -lt 1) { throw 'No selected plans are eligible for deletion. ApexTune only deletes plans it created or can verify as ApexTune plans.' }

    $active = Get-ApexActivePowerScheme
    $activeGuid = Normalize-ApexPowerGuid $active.guid
    $targetGuids = @($targets | ForEach-Object { [string]$_.guid })
    $restoredBeforeDelete = $false
    if (-not [string]::IsNullOrWhiteSpace($activeGuid) -and ($targetGuids -contains $activeGuid)) {
        $restoreGuid = Resolve-ApexPowerBaseGuid 'balanced'
        $restoredBeforeDelete = Invoke-ApexPowerSetActiveSoft $restoreGuid 'Switch to Balanced before deleting active ApexTune plan'
        if (-not $restoredBeforeDelete) {
            $fallback = @($schemes | Where-Object {
                $g = Normalize-ApexPowerGuid (Get-ApexObjectValue $_ 'guid' '')
                -not [string]::IsNullOrWhiteSpace($g) -and ($targetGuids -notcontains $g)
            } | Select-Object -First 1)
            if ($fallback -and $fallback[0].guid) { $restoredBeforeDelete = Invoke-ApexPowerSetActiveSoft ([string]$fallback[0].guid) 'Switch away before deleting active ApexTune plan' }
        }
        if (-not $restoredBeforeDelete) { throw 'The selected plan is currently active and Windows would not switch away from it. Activate Balanced or another plan, then delete again.' }
    }

    $deleted = @()
    $failed = @()
    foreach ($target in $targets) {
        $remove = Remove-ApexPowerSchemeSoft ([string]$target.guid)
        $item = [pscustomobject]@{ guid=[string]$target.guid; name=[string]$target.name; output=[string]$remove.output }
        if ($remove.ok) { $deleted += $item } else { $failed += $item }
    }

    $deletedGuids = @($deleted | ForEach-Object { [string]$_.guid })
    if ($deletedGuids.Count -gt 0) {
        $state = Read-ApexPowerState
        $currentTemplates = @(Get-ApexObjectValue $state 'templates' @())
        $currentHistory = @(Get-ApexObjectValue $state 'history' @())
        $state | Add-Member -NotePropertyName templates -NotePropertyValue @($currentTemplates | Where-Object { $deletedGuids -notcontains (Normalize-ApexPowerGuid (Get-ApexObjectValue $_ 'guid' '')) }) -Force
        $state | Add-Member -NotePropertyName history -NotePropertyValue @($currentHistory | Where-Object { $deletedGuids -notcontains (Normalize-ApexPowerGuid (Get-ApexObjectValue $_ 'guid' '')) }) -Force
        $lastApplied = Get-ApexObjectValue $state 'lastApplied' $null
        if (($null -ne $lastApplied) -and ($deletedGuids -contains (Normalize-ApexPowerGuid (Get-ApexObjectValue $lastApplied 'guid' '')))) {
            $state | Add-Member -NotePropertyName lastApplied -NotePropertyValue $null -Force
        }
        $deletions = @(Get-ApexObjectValue $state 'deletions' @())
        $deletions += [pscustomobject]@{ deletedAt=(Get-Date).ToString('o'); plans=$deleted }
        $state | Add-Member -NotePropertyName deletions -NotePropertyValue @($deletions | Select-Object -Last 25) -Force
        Save-ApexPowerState $state | Out-Null
    }

    $message = if ($failed.Count -gt 0) { "Deleted $($deleted.Count) plan(s); $($failed.Count) could not be deleted." } else { "Deleted $($deleted.Count) ApexTune-created power plan(s)." }
    return [pscustomobject]@{
        ok=($failed.Count -eq 0)
        message=$message
        deleted=$deleted
        failed=$failed
        blocked=$blocked
        restoredBeforeDelete=$restoredBeforeDelete
        statePath=$script:PowerStatePath
    }
}

function Invoke-ApexTunePowerPlan {
    $previous = Get-ApexActivePowerScheme
    $backup = Export-ApexPowerSchemeBackup $previous.guid 'before_apextune_power_plan'
    Invoke-ApexPowerUnhide | Out-Null
    $guid = Ensure-ApexPowerScheme 'ApexTune Power Plan' 'ultimate' 'ApexTune high-performance gaming plan with reversible advanced power settings.'
    $spec = [pscustomobject]@{
        processorMinAc=100; processorMinDc=5; processorMaxAc=100; processorMaxDc=100; boostModeAc=2; boostModeDc=4;
        coreParkingMinAc=100; coreParkingMinDc=10; coreParkingMaxAc=100; coreParkingMaxDc=100; coolingAc=0; coolingDc=1;
        pcieAc=0; pcieDc=1; usbAc=0; usbDc=1; displayOffAc=0; displayOffDc=10; sleepAc=0; sleepDc=20; hibernateAc=0; hibernateDc=60
    }
    $tuning = Set-ApexPowerTuning $guid $spec $true
    $state = Read-ApexPowerState
    $entry = [pscustomobject]@{ kind='ApexTune'; name='ApexTune Power Plan'; guid=$guid; previous=$previous; backup=$backup; appliedAt=(Get-Date).ToString('o'); settings=$spec; appliedSettings=$tuning.applied; skippedSettings=$tuning.skipped }
    $state | Add-Member -NotePropertyName lastApplied -NotePropertyValue $entry -Force
    $state | Add-Member -NotePropertyName previous -NotePropertyValue $previous -Force
    $history = @($state.history)
    $history += $entry
    $state | Add-Member -NotePropertyName history -NotePropertyValue @($history | Select-Object -Last 25) -Force
    Save-ApexPowerState $state | Out-Null
    $activeNow = [bool]$tuning.active
    $msg = if ($activeNow) { 'ApexTune Power Plan is active.' } else { 'ApexTune Power Plan was created and added to Windows power plans. Some Windows settings or activation steps were skipped, so you can select the plan manually if needed.' }
    return [pscustomobject]@{ ok=$true; message=$msg; plan='ApexTune Power Plan'; guid=$guid; active=$activeNow; available=(Test-ApexPowerSchemeExists $guid); previous=$previous; backup=$backup; statePath=$script:PowerStatePath; appliedSettings=$tuning.applied; skippedSettings=$tuning.skipped }
}

function Invoke-ApexCustomPowerPlan($Body) {
    $previous = Get-ApexActivePowerScheme
    $backup = Export-ApexPowerSchemeBackup $previous.guid 'before_custom_power_plan'
    Invoke-ApexPowerUnhide | Out-Null
    $spec = New-ApexPowerSpecFromBody $Body
    $guid = Ensure-ApexPowerScheme $spec.name $spec.base 'Custom ApexTune power plan made in the Power Plan Studio.'
    $tuning = Set-ApexPowerTuning $guid $spec ([bool]$spec.setActive)
    if (-not $spec.setActive -and $previous.guid) { Invoke-ApexPowerCfg -Args @('/setactive', $previous.guid) -IgnoreErrors | Out-Null }
    $state = Read-ApexPowerState
    $template = [pscustomobject]@{ name=$spec.name; guid=$guid; createdAt=(Get-Date).ToString('o'); settings=$spec }
    $templates = @($state.templates)
    $templates = @($templates | Where-Object { [string]$_.name -ne [string]$spec.name }) + $template
    $entry = [pscustomobject]@{ kind='Custom'; name=$spec.name; guid=$guid; previous=$previous; backup=$backup; appliedAt=(Get-Date).ToString('o'); settings=$spec; appliedSettings=$tuning.applied; skippedSettings=$tuning.skipped }
    $history = @($state.history)
    $history += $entry
    $state | Add-Member -NotePropertyName templates -NotePropertyValue @($templates | Select-Object -Last 20) -Force
    $state | Add-Member -NotePropertyName lastApplied -NotePropertyValue $entry -Force
    $state | Add-Member -NotePropertyName previous -NotePropertyValue $previous -Force
    $state | Add-Member -NotePropertyName history -NotePropertyValue @($history | Select-Object -Last 25) -Force
    Save-ApexPowerState $state | Out-Null
    $activeNow = [bool]$tuning.active
    $availableNow = Test-ApexPowerSchemeExists $guid
    $msg = if ($activeNow) { "Custom power plan created and activated: $($spec.name)" } elseif ($availableNow) { "Custom power plan created: $($spec.name). It is available in Windows power plans." } else { "Custom power plan saved, but Windows did not confirm it in the plan list yet." }
    return [pscustomobject]@{ ok=$true; message=$msg; plan=$spec.name; guid=$guid; active=$activeNow; available=$availableNow; backup=$backup; statePath=$script:PowerStatePath; appliedSettings=$tuning.applied; skippedSettings=$tuning.skipped }
}

function Restore-ApexPowerPlan([string]$Target) {
    $state = Read-ApexPowerState
    $guid = $null
    $name = 'previous plan'
    if (-not [string]::IsNullOrWhiteSpace($Target)) {
        $guid = Resolve-ApexPowerBaseGuid $Target
        $name = $Target
    } elseif ($state.previous -and $state.previous.guid) {
        $guid = [string]$state.previous.guid
        $name = [string]$state.previous.name
    } else {
        $guid = (Get-ApexPowerSchemeAliases).balanced
        $name = 'Balanced'
    }
    $restoreOk = Invoke-ApexPowerSetActiveSoft $guid 'Restore power plan'
    $state | Add-Member -NotePropertyName lastRestored -NotePropertyValue ([pscustomobject]@{ guid=$guid; name=$name; ok=$restoreOk; restoredAt=(Get-Date).ToString('o') }) -Force
    Save-ApexPowerState $state | Out-Null
    $msg = if ($restoreOk) { "Power plan restored: $name" } else { "Power plan restore request was saved, but Windows did not activate it. You can select it manually from Windows power options." }
    return [pscustomobject]@{ ok=$true; message=$msg; guid=$guid; name=$name; active=$restoreOk; statePath=$script:PowerStatePath }
}


function Format-ApexFileSize([long]$Bytes) {
    if ($Bytes -ge 1GB) { return ('{0:N1} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N1} KB' -f ($Bytes / 1KB)) }
    return ("$Bytes B")
}

function ConvertTo-ApexActivityFile([System.IO.FileInfo]$File, [string]$Kind) {
    return [pscustomobject]@{
        kind = $Kind
        name = $File.Name
        path = $File.FullName
        modified = $File.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')
        modifiedRaw = $File.LastWriteTime.ToString('o')
        size = (Format-ApexFileSize ([long]$File.Length))
        sizeBytes = [long]$File.Length
    }
}

function Get-ApexActivityCenter([int]$Limit = 24) {
    if ($Limit -lt 1) { $Limit = 24 }
    if ($Limit -gt 100) { $Limit = 100 }
    $sources = @(
        [pscustomobject]@{ key='reports'; kind='Report'; dir=$script:ReportsDir },
        [pscustomobject]@{ key='rollbacks'; kind='Rollback'; dir=$script:RollbackDir },
        [pscustomobject]@{ key='diagnostics'; kind='Diagnostic'; dir=$script:DiagDir },
        [pscustomobject]@{ key='intelligence'; kind='Intelligence'; dir=$script:IntelligenceDir },
        [pscustomobject]@{ key='power'; kind='Power'; dir=$script:PowerDir },
        [pscustomobject]@{ key='backups'; kind='Backup'; dir=$script:BackupDir }
    )
    $counts = [ordered]@{ reports=0; rollbacks=0; diagnostics=0; intelligence=0; power=0; backups=0 }
    $items = @()
    foreach ($source in $sources) {
        $dir = [string]$source.dir
        if ([string]::IsNullOrWhiteSpace($dir) -or -not (Test-Path $dir)) { continue }
        $files = @(Get-ChildItem -Path $dir -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
        $counts[$source.key] = $files.Count
        foreach ($file in ($files | Select-Object -First $Limit)) {
            $items += (ConvertTo-ApexActivityFile $file ([string]$source.kind))
        }
    }
    $recent = @($items | Sort-Object @{Expression='modifiedRaw';Descending=$true} | Select-Object -First $Limit)
    return [pscustomobject]@{
        ok = $true
        generatedAt = (Get-Date).ToString('o')
        appDir = $script:AppDir
        counts = $counts
        recent = $recent
        folders = [pscustomobject]@{
            reports = $script:ReportsDir
            rollbacks = $script:RollbackDir
            diagnostics = $script:DiagDir
            intelligence = $script:IntelligenceDir
            power = $script:PowerDir
            backups = $script:BackupDir
        }
    }
}



function Get-ApexDefaultSettings {
    return [ordered]@{
        runOnStartup = $false
        launchMode = 'app-window'
        defaultPage = 'dashboard'
        safeMode = $true
        advancedMode = $false
        simpleDescriptions = $true
        autoOpenBrowser = $true
        autoCheckUpdates = $false
        updateChannel = 'stable'
        gamingSessionAutoRestore = $true
        networkResetRequiresConfirm = $true
        notifications = $true
        reduceMotion = $false
    }
}

function Get-ApexStartupCommand {
    $launcher = Join-Path $script:Root 'ApexTune.vbs'
    if (-not (Test-Path -LiteralPath $launcher -PathType Leaf)) { $launcher = Join-Path $script:Root 'Launch-ApexTune.bat' }
    if (-not (Test-Path -LiteralPath $launcher -PathType Leaf)) { $launcher = Join-Path $script:Root 'Launch-ApexTune-Recovery.bat' }
    return ('"{0}"' -f $launcher)
}

function Test-ApexRunOnStartup {
    try {
        $props = Get-ItemProperty -Path $script:RunKeyPath -Name $script:RunValueName -ErrorAction SilentlyContinue
        if ($null -eq $props) { return $false }
        $prop = $props.PSObject.Properties[$script:RunValueName]
        return ($null -ne $prop -and -not [string]::IsNullOrWhiteSpace([string]$prop.Value))
    } catch { return $false }
}

function Set-ApexRunOnStartup([bool]$Enabled) {
    try {
        if ($Enabled) {
            New-Item -Path $script:RunKeyPath -Force -ErrorAction Stop | Out-Null
            New-ItemProperty -Path $script:RunKeyPath -Name $script:RunValueName -PropertyType String -Value (Get-ApexStartupCommand) -Force -ErrorAction Stop | Out-Null
            return [pscustomobject]@{ ok=$true; enabled=$true; message='ApexTune will start when you sign in to Windows.' }
        }
        Remove-ItemProperty -Path $script:RunKeyPath -Name $script:RunValueName -ErrorAction SilentlyContinue
        return [pscustomobject]@{ ok=$true; enabled=$false; message='ApexTune startup entry removed.' }
    } catch {
        return [pscustomobject]@{ ok=$false; enabled=(Test-ApexRunOnStartup); message=('Could not change startup setting: {0}' -f $_.Exception.Message) }
    }
}

function Convert-ApexStrictBool($Value) {
    if ($null -eq $Value) { return $false }
    if ($Value -is [bool]) { return [bool]$Value }
    if ($Value -is [int] -or $Value -is [long] -or $Value -is [double]) { return ([double]$Value -ne 0) }
    $text = ([string]$Value).Trim().ToLowerInvariant()
    if (@('1','true','yes','on','enabled') -contains $text) { return $true }
    if (@('0','false','no','off','disabled','') -contains $text) { return $false }
    return $false
}

function Convert-ApexSettingValue([string]$Key, $Value) {
    switch ($Key) {
        'runOnStartup' { return (Convert-ApexStrictBool $Value) }
        'safeMode' { return (Convert-ApexStrictBool $Value) }
        'advancedMode' { return (Convert-ApexStrictBool $Value) }
        'simpleDescriptions' { return (Convert-ApexStrictBool $Value) }
        'autoOpenBrowser' { return (Convert-ApexStrictBool $Value) }
        'autoCheckUpdates' { return (Convert-ApexStrictBool $Value) }
        'gamingSessionAutoRestore' { return (Convert-ApexStrictBool $Value) }
        'networkResetRequiresConfirm' { return (Convert-ApexStrictBool $Value) }
        'notifications' { return (Convert-ApexStrictBool $Value) }
        'reduceMotion' { return (Convert-ApexStrictBool $Value) }
        'launchMode' {
            $v = ([string]$Value).Trim().ToLowerInvariant()
            if (@('none','server-only','app-window','default-browser','recovery') -contains $v) { if ($v -eq 'server-only') { return 'none' }; return $v }
            return 'none'
        }
        'defaultPage' {
            $v = ([string]$Value).Trim().ToLowerInvariant()
            if (@('dashboard','optimize','intelligence','network','performance','games','power','gpu','startup','activity','settings') -contains $v) { return $v }
            return 'dashboard'
        }
        'updateChannel' {
            $v = ([string]$Value).Trim().ToLowerInvariant()
            if (@('stable','beta','local') -contains $v) { return $v }
            return 'stable'
        }
        default { return $Value }
    }
}

function Read-ApexSettingsFile {
    $defaults = Get-ApexDefaultSettings
    $merged = [ordered]@{}
    foreach ($k in $defaults.Keys) { $merged[$k] = $defaults[$k] }
    try {
        if (Test-Path -LiteralPath $script:SettingsPath -PathType Leaf) {
            $loaded = Get-Content -Raw -LiteralPath $script:SettingsPath -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            foreach ($k in @($defaults.Keys)) {
                if ($loaded.PSObject.Properties.Name -contains $k) { $merged[$k] = Convert-ApexSettingValue $k (($loaded.PSObject.Properties[$k]).Value) }
            }
        }
    } catch {
        Write-ApexLog ('Settings load failed: {0}' -f $_.Exception.Message) 'WARN'
    }
    $merged['runOnStartup'] = [bool](Test-ApexRunOnStartup)
    return $merged
}

function Save-ApexSettingsFile([System.Collections.IDictionary]$Settings) {
    $persist = [ordered]@{}
    foreach ($k in (Get-ApexDefaultSettings).Keys) {
        if ($Settings.Contains($k)) { $persist[$k] = $Settings[$k] }
    }
    $persist['updatedAt'] = (Get-Date).ToString('o')
    $persist | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
}

function Get-ApexSettings {
    $settings = Read-ApexSettingsFile
    return [pscustomobject]@{
        ok = $true
        version = $script:Version
        settings = [pscustomobject]$settings
        startup = [pscustomobject]@{
            enabled = [bool]$settings['runOnStartup']
            registryKey = $script:RunKeyPath
            valueName = $script:RunValueName
            command = (Get-ApexStartupCommand)
        }
        folders = [pscustomobject]@{
            appData = $script:AppDir
            diagnostics = $script:DiagDir
            reports = $script:ReportsDir
            rollbacks = $script:RollbackDir
            settingsFile = $script:SettingsPath
        }
        admin = (Test-IsAdmin)
    }
}

function Set-ApexSetting([string]$Key, $Value) {
    $allowed = @((Get-ApexDefaultSettings).Keys)
    if ($allowed -notcontains $Key) { return [pscustomobject]@{ ok=$false; message='Unknown setting.'; settings=(Get-ApexSettings).settings } }
    $settings = Read-ApexSettingsFile
    $settings[$Key] = Convert-ApexSettingValue $Key $Value
    $startupResult = $null
    if ($Key -eq 'runOnStartup') {
        $startupResult = Set-ApexRunOnStartup (Convert-ApexStrictBool $settings[$Key])
        $settings['runOnStartup'] = [bool]$startupResult.enabled
    }
    Save-ApexSettingsFile $settings
    $ok = $true
    if ($startupResult -and $startupResult.ok -eq $false) { $ok = $false }
    $message = if ($startupResult -and $startupResult.message) {
        $startupResult.message
    } elseif ($Key -eq 'autoOpenBrowser' -or $Key -eq 'launchMode') {
        'Saved. This launch behavior applies the next time ApexTune starts.'
    } elseif ($Key -eq 'simpleDescriptions') {
        'Saved. Tweak cards now use plain-English explanations.'
    } elseif ($Key -eq 'reduceMotion') {
        'Saved. Motion preference updated.'
    } else {
        ('Saved setting: {0}' -f $Key)
    }
    return [pscustomobject]@{ ok=$ok; message=$message; settings=(Get-ApexSettings).settings; startup=$startupResult }
}

function Reset-ApexSettings {
    try { if (Test-Path -LiteralPath $script:SettingsPath -PathType Leaf) { Remove-Item -LiteralPath $script:SettingsPath -Force -ErrorAction SilentlyContinue } } catch {}
    Set-ApexRunOnStartup $false | Out-Null
    return [pscustomobject]@{ ok=$true; message='ApexTune settings reset to safe defaults.'; settings=(Get-ApexSettings).settings }
}

function Invoke-ApexNetworkReset([string]$Mode) {
    $modeName = if ([string]::IsNullOrWhiteSpace($Mode)) { 'quick' } else { $Mode.ToLowerInvariant() }
    $isFull = $modeName -eq 'full'
    if ($isFull -and -not (Test-IsAdmin)) {
        return [pscustomobject]@{ ok=$false; message='Full network reset needs Admin mode. Open Launch-ApexTune-Admin.bat, then run it again.'; requiresAdmin=$true; requiresRestart=$true }
    }
    $steps = @()
    if ($isFull) {
        $steps += [pscustomobject]@{ label='Clear DNS cache'; file='ipconfig.exe'; args=@('/flushdns') }
        $steps += [pscustomobject]@{ label='Reset Winsock sockets'; file='netsh.exe'; args=@('winsock','reset') }
        $steps += [pscustomobject]@{ label='Reset TCP/IP stack'; file='netsh.exe'; args=@('int','ip','reset') }
    } else {
        $steps += [pscustomobject]@{ label='Clear DNS cache'; file='ipconfig.exe'; args=@('/flushdns') }
        $steps += [pscustomobject]@{ label='Refresh DNS registration'; file='ipconfig.exe'; args=@('/registerdns') }
        $steps += [pscustomobject]@{ label='Renew DHCP lease'; file='ipconfig.exe'; args=@('/renew') }
    }
    $results = @()
    foreach ($step in $steps) {
        $out = ''
        $code = 0
        try {
            $cmdArgs = @($step.args)
            $out = (& $step.file @cmdArgs 2>&1 | Out-String).Trim()
            if ($LASTEXITCODE -ne $null) { $code = [int]$LASTEXITCODE }
            $results += [pscustomobject]@{ step=$step.label; command=('{0} {1}' -f $step.file, ($cmdArgs -join ' ')); exitCode=$code; output=$out; ok=($code -eq 0) }
        } catch {
            $results += [pscustomobject]@{ step=$step.label; command=('{0} {1}' -f $step.file, (@($step.args) -join ' ')); exitCode=1; output=$_.Exception.Message; ok=$false }
        }
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $file = Join-Path $script:ReportsDir ("NetworkReset-{0}-{1}.json" -f $modeName, $stamp)
    $payload = [pscustomobject]@{
        mode = $modeName
        at = (Get-Date).ToString('o')
        admin = (Test-IsAdmin)
        requiresRestart = $isFull
        steps = $results
    }
    try { $payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $file -Encoding UTF8 } catch {}
    $failed = @($results | Where-Object { -not $_.ok }).Count
    $message = if ($isFull) { 'Full network reset completed. Restart Windows before judging ping.' } else { 'Quick network refresh completed. Test your game/server ping again.' }
    if ($failed -gt 0) { $message = ('Network reset finished with {0} warning(s). Report saved.' -f $failed) }
    return [pscustomobject]@{ ok=($failed -eq 0); message=$message; mode=$modeName; requiresRestart=$isFull; path=$file; steps=$results }
}

function Get-ApexStartupDiagnostics {
    $lastUrl = ''
    try { if (Test-Path -LiteralPath $script:LastUrlPath -PathType Leaf) { $lastUrl = (Get-Content -Raw -LiteralPath $script:LastUrlPath -ErrorAction SilentlyContinue).Trim() } } catch {}
    $executionPolicy = ''
    try { $executionPolicy = [string](Get-ExecutionPolicy -Scope Process -ErrorAction SilentlyContinue) } catch {}
    $effectivePolicy = ''
    try { $effectivePolicy = [string](Get-ExecutionPolicy -ErrorAction SilentlyContinue) } catch {}
    $webIndex = Join-Path $script:WebRoot 'index.html'
    $webJs = Join-Path $script:WebRoot 'app.js'
    $webCss = Join-Path $script:WebRoot 'styles.css'
    $tweaks = Join-Path $script:DataRoot 'tweaks.json'
    $games = Join-Path $script:DataRoot 'games.json'
    return [pscustomobject]@{
        ok = $true
        version = $script:Version
        root = $script:Root
        webRoot = $script:WebRoot
        dataRoot = $script:DataRoot
        appDir = $script:AppDir
        diagnosticsDir = $script:DiagDir
        intelligenceDir = $script:IntelligenceDir
        sessionDir = $script:SessionDir
        port = $script:Port
        lastUrl = $lastUrl
        admin = (Test-IsAdmin)
        powershell = [string]$PSVersionTable.PSVersion
        executionPolicyProcess = $executionPolicy
        executionPolicyEffective = $effectivePolicy
        checks = [pscustomobject]@{
            webIndex = (Test-Path -LiteralPath $webIndex -PathType Leaf)
            webApp = (Test-Path -LiteralPath $webJs -PathType Leaf)
            webStyles = (Test-Path -LiteralPath $webCss -PathType Leaf)
            tweaks = (Test-Path -LiteralPath $tweaks -PathType Leaf)
            games = (Test-Path -LiteralPath $games -PathType Leaf)
            diagnosticsDir = (Test-Path -LiteralPath $script:DiagDir -PathType Container)
            intelligenceDir = (Test-Path -LiteralPath $script:IntelligenceDir -PathType Container)
            sessionDir = (Test-Path -LiteralPath $script:SessionDir -PathType Container)
        }
    }
}

function Write-ApexLaunchState([string]$Url, [string]$State, [string]$Message = '') {
    try {
        $obj = [pscustomobject]@{
            version = $script:Version
            state = $State
            message = $Message
            url = $Url
            root = $script:Root
            webRoot = $script:WebRoot
            appDir = $script:AppDir
            diagnosticsDir = $script:DiagDir
            port = $script:Port
            at = (Get-Date).ToString('o')
        }
        $obj | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:LaunchStatePath -Encoding UTF8
    } catch {}
}

function Invoke-ApexOpenLastUrl {
    $url = ''
    try { if (Test-Path -LiteralPath $script:LastUrlPath -PathType Leaf) { $url = (Get-Content -Raw -LiteralPath $script:LastUrlPath -ErrorAction Stop).Trim() } } catch {}
    if ([string]::IsNullOrWhiteSpace($url) -and $script:Port -gt 0) { $url = "http://127.0.0.1:$script:Port/" }
    if ([string]::IsNullOrWhiteSpace($url)) { return [pscustomobject]@{ ok=$false; message='No ApexTune URL has been recorded yet.' } }
    $opened = Open-CommandCenter $url
    return [pscustomobject]@{ ok=[bool]$opened; message='Open command sent to browser.'; url=$url }
}


function Convert-ApexRegPath([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $Path }
    $p = $Path.Trim()
    $p = $p -replace '^HKLM\\', 'Registry::HKEY_LOCAL_MACHINE\\'
    $p = $p -replace '^HKCU\\', 'Registry::HKEY_CURRENT_USER\\'
    $p = $p -replace '^HKCR\\', 'Registry::HKEY_CLASSES_ROOT\\'
    $p = $p -replace '^HKU\\', 'Registry::HKEY_USERS\\'
    return $p
}

function Get-ApexRegistrySnapshot([string[]]$Keys) {
    $items = @()
    foreach ($key in @($Keys | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Sort-Object -Unique)) {
        $native = [string]$key
        $psPath = Convert-ApexRegPath $native
        $exists = $false
        $values = @{}
        try {
            if (Test-Path -LiteralPath $psPath) {
                $exists = $true
                $props = Get-ItemProperty -LiteralPath $psPath -ErrorAction Stop
                foreach ($p in $props.PSObject.Properties) {
                    if ($p.Name -notmatch '^PS(Path|ParentPath|ChildName|Drive|Provider)$') { $values[$p.Name] = [string]$p.Value }
                }
            }
        } catch { $values['snapshotError'] = $_.Exception.Message }
        $items += [pscustomobject]@{ key=$native; exists=$exists; values=[pscustomobject]$values }
    }
    return $items
}

function New-ApexRestoreVaultSession($Tweaks, $Files = $null, [string]$Source = 'tweak-apply') {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $id = 'vault-' + $stamp
    $path = Join-Path $script:RestoreVaultDir ($id + '.json')
    $entries = @()
    foreach ($t in @($Tweaks)) {
        $keys = @($t.backupKeys | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        $entries += [pscustomobject]@{
            id = [string]$t.id
            name = [string]$t.title
            risk = [string]$t.risk
            category = [string]$t.category
            before = Get-ApexRegistrySnapshot $keys
            commands = @($t.commands | ForEach-Object { [string]$_ })
            restoreCommands = @($t.rollback | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
            timestamp = (Get-Date).ToString('o')
        }
    }
    $session = [pscustomobject]@{
        ok = $true
        id = $id
        source = $Source
        created = (Get-Date).ToString('o')
        version = $script:Version
        user = $env:USERNAME
        admin = (Test-IsAdmin)
        planPath = if ($Files) { [string]$Files.planPath } else { '' }
        rollbackPath = if ($Files) { [string]$Files.rollbackPath } else { '' }
        backupRoot = if ($Files) { [string]$Files.backupRoot } else { '' }
        tweakCount = @($entries).Count
        entries = $entries
    }
    $session | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $path -Encoding UTF8
    Update-ApexRestoreVaultIndex $session $path | Out-Null
    return [pscustomobject]@{ id=$id; path=$path; tweakCount=@($entries).Count }
}

function Update-ApexRestoreVaultIndex($Session, [string]$Path) {
    $items = @()
    try { if (Test-Path -LiteralPath $script:RestoreVaultIndexPath -PathType Leaf) { $items = @(Get-Content -Raw -LiteralPath $script:RestoreVaultIndexPath | ConvertFrom-Json) } } catch { $items=@() }
    $items = @($items | Where-Object { $_.id -ne $Session.id })
    $items = @([pscustomobject]@{ id=$Session.id; created=$Session.created; source=$Session.source; tweakCount=$Session.tweakCount; path=$Path; rollbackPath=$Session.rollbackPath; backupRoot=$Session.backupRoot }, $items) | Select-Object -First 80
    $items | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $script:RestoreVaultIndexPath -Encoding UTF8
    return $items
}

function Get-ApexRestoreVaultCenter {
    $sessions = @()
    try { if (Test-Path -LiteralPath $script:RestoreVaultIndexPath -PathType Leaf) { $sessions = @(Get-Content -Raw -LiteralPath $script:RestoreVaultIndexPath | ConvertFrom-Json) } } catch { $sessions=@() }
    if (-not @($sessions).Count) {
        try {
            $sessions = @(Get-ChildItem -LiteralPath $script:RestoreVaultDir -Filter 'vault-*.json' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 80 | ForEach-Object {
                $data = Get-Content -Raw -LiteralPath $_.FullName | ConvertFrom-Json
                [pscustomobject]@{ id=$data.id; created=$data.created; source=$data.source; tweakCount=$data.tweakCount; path=$_.FullName; rollbackPath=$data.rollbackPath; backupRoot=$data.backupRoot }
            })
        } catch { $sessions=@() }
    }
    return [pscustomobject]@{ ok=$true; sessions=$sessions; vaultPath=$script:RestoreVaultDir; indexPath=$script:RestoreVaultIndexPath }
}

function Invoke-ApexRestoreVault($Body) {
    if (-not (Test-IsAdmin)) { return [pscustomobject]@{ ok=$false; requiresAdmin=$true; message='Restore Vault needs Admin mode to run rollback commands.' } }
    $id = [string]$Body.id
    $mode = if ($Body.PSObject.Properties.Name -contains 'mode') { [string]$Body.mode } else { 'selected' }
    if ([string]::IsNullOrWhiteSpace($id) -or $id -eq 'latest') {
        $center = Get-ApexRestoreVaultCenter
        $id = [string](@($center.sessions | Select-Object -First 1).id)
    }
    if ([string]::IsNullOrWhiteSpace($id)) { return [pscustomobject]@{ ok=$false; message='No restore vault sessions are available yet.' } }
    $path = Join-Path $script:RestoreVaultDir ($id + '.json')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return [pscustomobject]@{ ok=$false; message='Restore vault session file was not found.'; id=$id } }
    $data = Get-Content -Raw -LiteralPath $path | ConvertFrom-Json
    $wanted = @()
    if ($mode -eq 'all' -or -not ($Body.PSObject.Properties.Name -contains 'tweakIds')) { $wanted = @($data.entries) }
    else { $ids = @($Body.tweakIds | ForEach-Object { [string]$_ }); $wanted = @($data.entries | Where-Object { $ids -contains $_.id }) }
    $results=@(); $okCount=0; $failCount=0; $skipCount=0
    foreach ($entry in $wanted) {
        $cmds = @($entry.restoreCommands | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if (-not $cmds.Count) { $skipCount++; $results += [pscustomobject]@{ id=$entry.id; name=$entry.name; skipped=$true; reason='No restore commands recorded.' }; continue }
        foreach ($cmd in $cmds) {
            try {
                $exit = Invoke-TweakCommand $cmd
                if ($exit -eq 0) { $okCount++ } else { $failCount++ }
                $results += [pscustomobject]@{ id=$entry.id; name=$entry.name; command=$cmd; exitCode=$exit; ok=($exit -eq 0) }
            } catch { $failCount++; $results += [pscustomobject]@{ id=$entry.id; name=$entry.name; command=$cmd; error=$_.Exception.Message; ok=$false } }
        }
    }
    $reportPath = Join-Path $script:ReportsDir ('ApexTune-RestoreVault-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $report=[pscustomobject]@{ ok=($failCount -eq 0); id=$id; restored=$okCount; failed=$failCount; skipped=$skipCount; results=$results; reportPath=$reportPath; restartRecommended=$true }
    $report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    return $report
}

function Get-ApexStartupPressureCount {
    try { return @((Get-StartupItems -Refresh:$false) | Where-Object { $_.enabled }).Count } catch { return $null }
}

function Get-ApexDnsMs {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try { [void][System.Net.Dns]::GetHostAddresses('cloudflare.com'); $sw.Stop(); return [math]::Round($sw.Elapsed.TotalMilliseconds) } catch { $sw.Stop(); return $null }
}

function Get-ApexActivePowerPlanName {
    try {
        $out = (& powercfg /getactivescheme 2>&1 | Out-String).Trim()
        if ($out -match '\(([^\)]+)\)') { return $matches[1] }
        return $out
    } catch { return 'Unknown' }
}

function Get-ApexGameBarState {
    $enabled = $null
    try { $enabled = (Get-ItemProperty -Path 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -ErrorAction Stop).GameDVR_Enabled } catch {}
    $capture = $null
    try { $capture = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -ErrorAction Stop).AppCaptureEnabled } catch {}
    return [pscustomobject]@{ gameDvrEnabled=$enabled; appCaptureEnabled=$capture; captureLikelyOn=($enabled -eq 1 -or $capture -eq 1) }
}

function Get-ApexDriverAgeDays($GpuCenter) {
    try {
        $dates = @($GpuCenter.gpus | ForEach-Object { $_.driverDate } | Where-Object { $_ })
        if ($dates.Count) {
            $dt = [datetime]::Parse([string]$dates[0])
            return [math]::Max(0, [int]([datetime]::Now - $dt).TotalDays)
        }
    } catch {}
    return $null
}

function New-ApexProofSnapshot([string]$Label = 'snapshot') {
    $status = Get-Status
    $hw = Get-HardwareSnapshot
    $gpu = Get-GpuDriverCenter
    $startupCount = Get-ApexStartupPressureCount
    $dnsMs = Get-ApexDnsMs
    $power = Get-ApexActivePowerPlanName
    $gameBar = Get-ApexGameBarState
    $freeDisk = $null
    try { $drive = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction Stop; if ($drive.Size -gt 0) { $freeDisk = [math]::Round(([double]$drive.FreeSpace / 1GB),1) } } catch {}
    $obj = [pscustomobject]@{
        ok = $true
        label = $Label
        at = (Get-Date).ToString('o')
        version = $script:Version
        cpu = $status.cpu
        ram = $status.ram
        ping = $status.ping
        dnsMs = $dnsMs
        startupApps = $startupCount
        powerPlan = $power
        gpu = $status.gpu
        gpuVendor = $gpu.vendor
        gpuDriverVersion = $status.gpuDriverVersion
        driverAgeDays = (Get-ApexDriverAgeDays $gpu)
        windows = $status.osCaption
        build = $status.osBuild
        gameBar = $gameBar
        freeDiskGB = $freeDisk
        admin = (Test-IsAdmin)
        score = $status.score
    }
    $safe = ($Label -replace '[^A-Za-z0-9]+','-').Trim('-')
    if ([string]::IsNullOrWhiteSpace($safe)) { $safe='snapshot' }
    $path = Join-Path $script:ProofDir ('ApexTune-Proof-' + $safe + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $obj | Add-Member -NotePropertyName path -NotePropertyValue $path -Force
    $obj | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $path -Encoding UTF8
    return $obj
}

function Get-ApexPerformanceDoctorScan {
    $proof = New-ApexProofSnapshot 'doctor-before'
    $gpu = Get-GpuDriverCenter
    $issues = @()
    $recommendations = @()
    $score = 100
    if ($proof.ram -ge 78) { $score -= 12; $issues += [pscustomobject]@{ severity='Medium'; problem='High memory pressure'; why='Games can hitch when Windows is tight on RAM.'; evidence=("RAM usage is {0}%" -f $proof.ram); fix='Close heavy background apps or use Startup Manager.'; risk='Low'; undo='No system change required.' } }
    if ($proof.startupApps -ne $null -and $proof.startupApps -ge 12) { $score -= 10; $issues += [pscustomobject]@{ severity='Medium'; problem='Startup load is high'; why='Too many apps starting with Windows can steal CPU, disk, and RAM before games launch.'; evidence=("{0} startup entries are enabled" -f $proof.startupApps); fix='Review Startup Manager and disable apps you do not need every boot.'; risk='Low'; undo='Restore disabled entries from Startup Manager.' } }
    if ($proof.ping -ge 70) { $score -= 10; $issues += [pscustomobject]@{ severity='Medium'; problem='Ping is elevated'; why='Higher ping and jitter can make online games feel delayed.'; evidence=("Ping probe returned {0} ms" -f $proof.ping); fix='Run Quick network refresh and test Cloudflare/Google DNS.'; risk='Low'; undo='Restart or restore adapter defaults.' } }
    if ($proof.dnsMs -ne $null -and $proof.dnsMs -ge 120) { $score -= 6; $issues += [pscustomobject]@{ severity='Low'; problem='DNS lookup is slow'; why='Slow name lookup can delay game launchers, voice chat, and server lists.'; evidence=("DNS lookup took {0} ms" -f $proof.dnsMs); fix='Run DNS/socket refresh or test another DNS provider.'; risk='Low'; undo='Network settings can be restored from Windows.' } }
    if ($proof.gameBar.captureLikelyOn) { $score -= 8; $issues += [pscustomobject]@{ severity='Low'; problem='Xbox capture may be enabled'; why='Background recording can cost FPS or create frame-time spikes.'; evidence='Windows Game DVR/App Capture registry values look enabled.'; fix='Queue Disable Xbox capture overhead.'; risk='Low'; undo='Use Restore Vault or re-enable capture in Windows settings.' } }
    if ($proof.driverAgeDays -ne $null -and $proof.driverAgeDays -gt 120) { $score -= 8; $issues += [pscustomobject]@{ severity='Medium'; problem='GPU driver may be old'; why='Older drivers can miss game fixes, shader fixes, and stability updates.'; evidence=("Driver age estimate: {0} days" -f $proof.driverAgeDays); fix='Open Driver Health Center and check the official GPU driver page.'; risk='Low'; undo='Use Device Manager or vendor installer rollback if a new driver is worse.' } }
    if ($proof.freeDiskGB -ne $null -and $proof.freeDiskGB -lt 20) { $score -= 8; $issues += [pscustomobject]@{ severity='Medium'; problem='Low disk space'; why='Low free space can hurt updates, shader caches, captures, and game streaming.'; evidence=("C: free space is {0} GB" -f $proof.freeDiskGB); fix='Clear temp files, old downloads, or move games to a larger drive.'; risk='Low'; undo='No tweak needed; free space management only.' } }
    if ($issues.Count -eq 0) { $issues += [pscustomobject]@{ severity='Good'; problem='No major safe issues found'; why='The quick scan did not find obvious startup, RAM, ping, driver, or capture problems.'; evidence='Baseline checks are healthy.'; fix='Use Safe Gaming or Competitive FPS only if you want a controlled profile.'; risk='Low'; undo='Profiles create rollback data before applying.' } }
    $recommendations = @($issues | ForEach-Object { [pscustomobject]@{ title=$_.fix; risk=$_.risk; reason=$_.why; problem=$_.problem } })
    if ($score -lt 35) { $score=35 }
    $result = [pscustomobject]@{ ok=$true; score=[math]::Min(99,$score); proof=$proof; issues=$issues; recommendations=$recommendations; generated=(Get-Date).ToString('o') }
    $path = Join-Path $script:DoctorDir ('ApexTune-Doctor-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $result | Add-Member -NotePropertyName reportPath -NotePropertyValue $path -Force
    $result | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $path -Encoding UTF8
    Write-ApexDoctorLog ('Doctor scan saved: {0}' -f $path)
    return $result
}

function Get-ApexProfileDefinitions {
    return @(
        [pscustomobject]@{ id='safe-gaming'; name='Safe Gaming'; title='Safe Gaming'; description='Everyday gaming boost using reversible low/medium risk tweaks.'; focus='Stable FPS, less background load, safer defaults'; risk='Low/Medium' },
        [pscustomobject]@{ id='competitive-fps'; name='Competitive FPS'; title='Competitive FPS'; description='Latency-first setup for Siege, Fortnite, Valorant, CS-style games.'; focus='Input feel, frame pacing, network responsiveness'; risk='Medium' },
        [pscustomobject]@{ id='streaming-gaming'; name='Streaming + Gaming'; title='Streaming + Gaming'; description='Keeps gaming smooth while avoiding extreme capture/streaming conflicts.'; focus='Balanced background control, cache health, network stability'; risk='Low/Medium' },
        [pscustomobject]@{ id='laptop-balanced'; name='Laptop Balanced'; title='Laptop Balanced'; description='Laptop-safe profile that avoids heat-heavy extreme desktop-only changes.'; focus='Battery-aware smoothness, lower heat risk'; risk='Low' },
        [pscustomobject]@{ id='undo-default'; name='Undo / Windows Default'; title='Undo / Windows Default'; description='Restores the latest ApexTune Restore Vault session where rollback commands exist.'; focus='Rollback and recovery'; risk='Low' }
    )
}

function Select-ApexProfileTweaks([string]$ProfileId) {
    $all = @(Get-Tweaks)
    $rx = switch ($ProfileId) {
        'safe-gaming' { 'game mode|xbox|capture|power|background|delivery|dns|shader|visual effects' }
        'competitive-fps' { 'latency|network|dns|socket|game mode|xbox|capture|power|foreground|priority|mouse|input|fullscreen|timer|multimedia' }
        'streaming-gaming' { 'power|network|dns|shader|cache|background|delivery|memory|audio|driver|overlay' }
        'laptop-balanced' { 'game mode|xbox|capture|background|dns|delivery|visual effects|shader|driver|latency' }
        default { '' }
    }
    if ([string]::IsNullOrWhiteSpace($rx)) { return @() }
    $selected = @($all | Where-Object {
        $risk = ([string]$_.risk).ToLowerInvariant()
        $hay = (([string]$_.id) + ' ' + ([string]$_.title) + ' ' + ([string]$_.summary) + ' ' + ([string]$_.category) + ' ' + (@($_.tags) -join ' ')).ToLowerInvariant()
        $ok = $hay -match $rx -and $risk -ne 'high'
        if ($ProfileId -eq 'laptop-balanced') { $ok = $ok -and ($risk -eq 'low' -or @($_.systems) -contains 'laptop' -or $hay -notmatch 'ultimate performance|desktop') }
        if ($ProfileId -eq 'streaming-gaming') { $ok = $ok -and $hay -notmatch 'disable.*capture|xbox capture off' }
        $ok
    })
    $selected | Sort-Object @{Expression={ if(([string]$_.risk).ToLowerInvariant() -eq 'low'){0}else{1} }}, @{Expression={ -1 * ([int]$_.fps + [int]$_.ping) }}, title | Select-Object -First 10
}

function Get-ApexProfileCenter {
    $defs = @(Get-ApexProfileDefinitions)
    $profiles = @($defs | ForEach-Object {
        $tw = @(Select-ApexProfileTweaks $_.id)
        [pscustomobject]@{
            id=$_.id; name=$_.name; title=$_.title; description=$_.description; focus=$_.focus; risk=$_.risk
            tweakCount=$tw.Count
            estimatedFps=($tw | Measure-Object -Property fps -Sum).Sum
            estimatedPing=($tw | Measure-Object -Property ping -Sum).Sum
            tweaks=@($tw | Select-Object id,title,risk,category,fps,ping,restart)
        }
    })
    return [pscustomobject]@{ ok=$true; profiles=$profiles; admin=(Test-IsAdmin); generated=(Get-Date).ToString('o') }
}

function Invoke-ApexSafeProfile([string]$ProfileId) {
    if ($ProfileId -eq 'undo-default') { return (Invoke-ApexRestoreVault ([pscustomobject]@{ id='latest'; mode='all' })) }
    $tw = @(Select-ApexProfileTweaks $ProfileId)
    if (-not $tw.Count) { return [pscustomobject]@{ ok=$false; message='No matching safe tweaks were found for this profile.'; profile=$ProfileId } }
    $before = New-ApexProofSnapshot ("before-$ProfileId")
    if (-not (Test-IsAdmin)) { return [pscustomobject]@{ ok=$false; requiresAdmin=$true; message='Launch ApexTune as Admin to apply a Safe Performance Profile. The profile preview is ready.'; profile=$ProfileId; before=$before; tweakCount=$tw.Count; tweaks=@($tw | Select-Object id,title,risk) } }
    $ids = @($tw | ForEach-Object { [string]$_.id })
    $apply = Apply-Tweaks $ids $true
    $after = New-ApexProofSnapshot ("after-$ProfileId")
    $reportPath = Join-Path $script:ReportsDir ('ApexTune-Profile-' + $ProfileId + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $result = [pscustomobject]@{ ok=($apply.failed -eq 0); profile=$ProfileId; tweakCount=$tw.Count; before=$before; after=$after; apply=$apply; reportPath=$reportPath }
    $result | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    return $result
}

function Get-ApexDriverHealthCenter {
    $gpu = Get-GpuDriverCenter
    $age = Get-ApexDriverAgeDays $gpu
    $vendor = [string]$gpu.vendor
    $links = @()
    if ($vendor -match 'NVIDIA') { $links += [pscustomobject]@{ label='Open NVIDIA driver page'; action='gpu:nvidia-official' }; $links += [pscustomobject]@{ label='Open Device Manager'; action='gpu:device-manager' } }
    elseif ($vendor -match 'AMD') { $links += [pscustomobject]@{ label='Open AMD driver page'; action='gpu:amd-autodetect' }; $links += [pscustomobject]@{ label='Open Device Manager'; action='gpu:device-manager' } }
    elseif ($vendor -match 'Intel') { $links += [pscustomobject]@{ label='Open Intel graphics tools'; action='gpu:intel-graphics' }; $links += [pscustomobject]@{ label='Open Device Manager'; action='gpu:device-manager' } }
    else { $links += [pscustomobject]@{ label='Open Device Manager'; action='gpu:device-manager' } }
    $status = if ($age -eq $null) { 'Unknown' } elseif ($age -gt 180) { 'Old' } elseif ($age -gt 90) { 'Check soon' } else { 'Looks current' }
    return [pscustomobject]@{ ok=$true; vendor=$vendor; primary=$gpu.primary; gpus=$gpu.gpus; driverAgeDays=$age; status=$status; actions=$links; raw=$gpu }
}

function Repair-ApexTuneInstall {
    $created=@(); $checked=@(); $fixed=@(); $problems=@()
    foreach ($dir in @($script:AppDir,$script:ReportsDir,$script:BackupDir,$script:RollbackDir,$script:DiagDir,$script:LogsDir,$script:DoctorDir,$script:ProofDir,$script:RestoreVaultDir,$script:RepairDir,$script:JobsDir,$script:UpdaterStageDir,$script:UpdaterBackupDir)) {
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null; $created += $dir } else { $checked += $dir }
    }
    foreach ($file in @('VERSION.txt','UPDATE-SOURCE.json','UPDATE-MANIFEST.json','ApexTune.CommandCenter.ps1','ApexTune-Updater.ps1','web\index.html','web\app.js','web\styles.css','data\tweaks.json','data\games.json')) {
        $p = Join-Path $script:Root $file
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { $problems += "Missing $file" } else { $checked += $p }
    }
    try { Get-Content -Raw -LiteralPath (Join-Path $script:DataRoot 'tweaks.json') | ConvertFrom-Json | Out-Null } catch { $problems += 'tweaks.json is invalid JSON: ' + $_.Exception.Message }
    try { Get-Content -Raw -LiteralPath (Join-Path $script:DataRoot 'games.json') | ConvertFrom-Json | Out-Null } catch { $problems += 'games.json is invalid JSON: ' + $_.Exception.Message }
    foreach ($log in @($script:CrashLogPath,$script:AppLogPath,$script:DoctorLogPath)) { if (-not (Test-Path -LiteralPath $log -PathType Leaf)) { New-Item -ItemType File -Path $log -Force | Out-Null; $fixed += $log } }
    $reportPath = Join-Path $script:RepairDir ('repair-report-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $obj=[pscustomobject]@{ ok=($problems.Count -eq 0); created=$created; checkedCount=$checked.Count; fixed=$fixed; problems=$problems; reportPath=$reportPath; version=$script:Version; generated=(Get-Date).ToString('o') }
    $obj | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    return $obj
}

function Test-ApexUpdaterIntegrity {
    $issues=@(); $warnings=@(); $source=$null; $manifest=$null
    $sourcePath=Join-Path $script:Root 'UPDATE-SOURCE.json'
    $manifestPath=Join-Path $script:Root 'UPDATE-MANIFEST.json'
    try { $source=Get-Content -Raw -LiteralPath $sourcePath | ConvertFrom-Json } catch { $issues += 'UPDATE-SOURCE.json is missing or invalid: ' + $_.Exception.Message }
    try { $manifest=Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json } catch { $issues += 'UPDATE-MANIFEST.json is missing or invalid: ' + $_.Exception.Message }
    $downloadUrl = if ($source -and ($source.PSObject.Properties.Name -contains 'downloadUrl')) { [string]$source.downloadUrl } else { '' }
    $sha = if ($source -and ($source.PSObject.Properties.Name -contains 'sha256')) { [string]$source.sha256 } else { '' }
    if ([string]::IsNullOrWhiteSpace($downloadUrl)) { $warnings += 'No download URL is configured yet.' }
    elseif ($downloadUrl -match 'example|placeholder|YOUR_|localhost') { $issues += 'Download URL looks like a placeholder.' }
    elseif ($downloadUrl -match '^http://' -and $downloadUrl -notmatch '^http://127\.0\.0\.1|^http://localhost') { $issues += 'Updater URL should use HTTPS unless this is a local test.' }
    if ([string]::IsNullOrWhiteSpace($sha)) { $warnings += 'No SHA-256 is configured. The updater should block public installs without a hash.' }
    elseif ($sha -notmatch '^[A-Fa-f0-9]{64}$') { $issues += 'SHA-256 value is not a valid 64-character hex hash.' }
    $free = $null
    try { $d=Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -ErrorAction Stop; $free=[math]::Round($d.FreeSpace/1GB,1); if($free -lt 1){ $issues+='Less than 1 GB free on C: for staging/backup.' } } catch {}
    $reportPath=Join-Path $script:ReportsDir ('ApexTune-UpdaterIntegrity-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
    $obj=[pscustomobject]@{ ok=($issues.Count -eq 0); issues=$issues; warnings=$warnings; source=$source; manifest=$manifest; freeDiskGB=$free; stageDir=$script:UpdaterStageDir; backupDir=$script:UpdaterBackupDir; reportPath=$reportPath; generated=(Get-Date).ToString('o') }
    $obj | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $reportPath -Encoding UTF8
    return $obj
}

function New-ApexAsyncJob([string]$Type) {
    $id = 'job-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
    $jobPath = Join-Path $script:JobsDir ($id + '.json')
    $worker = Join-Path $script:Root 'ApexTune-Worker.ps1'
    $obj=[pscustomobject]@{ id=$id; type=$Type; status='queued'; created=(Get-Date).ToString('o'); jobPath=$jobPath; worker=$worker }
    $obj | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jobPath -Encoding UTF8
    try {
        if (Test-Path -LiteralPath $worker -PathType Leaf) {
            Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',$worker,'-JobId',$id,'-JobType',$Type,'-Root',$script:Root,'-AppDir',$script:AppDir) -WindowStyle Hidden | Out-Null
            $obj.status='started'; $obj | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jobPath -Encoding UTF8
        } else { $obj.status='missing-worker'; $obj | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jobPath -Encoding UTF8 }
    } catch { $obj.status='failed-to-start'; $obj.error=$_.Exception.Message; $obj | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jobPath -Encoding UTF8 }
    return $obj
}

function Get-ApexAsyncJob([string]$JobId) {
    if ([string]::IsNullOrWhiteSpace($JobId)) { return [pscustomobject]@{ ok=$false; message='Missing job id.' } }
    $path=Join-Path $script:JobsDir ($JobId + '.json')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return [pscustomobject]@{ ok=$false; message='Job not found.'; id=$JobId } }
    return (Get-Content -Raw -LiteralPath $path | ConvertFrom-Json)
}

function Invoke-PanelAction([string]$Action) {
    switch ($Action) {
        'performance:0' { $file = New-SystemSnapshotReport; return [pscustomobject]@{ ok=$true; message="Performance snapshot saved"; path=$file } }
        'performance:1' { $file = New-SystemSnapshotReport; return [pscustomobject]@{ ok=$true; message="Benchmark prep snapshot saved"; path=$file } }
        'proof:before' { return (New-ApexProofSnapshot 'before-manual') }
        'proof:after' { return (New-ApexProofSnapshot 'after-manual') }
        'doctor:scan' { return (Get-ApexPerformanceDoctorScan) }
        'repair:run' { return (Repair-ApexTuneInstall) }
        'updater:verify' { return (Test-ApexUpdaterIntegrity) }
        'performance:2' { return [pscustomobject]@{ ok=$true; message='Shader cache cleanup is available in the tweak library; select it from Optimize to queue safely.' } }
        'network:0' { $file = New-LatencyProbeReport; return [pscustomobject]@{ ok=$true; message='Latency probe report saved'; path=$file } }
        'network:1' { return [pscustomobject]@{ ok=$true; message='DNS/socket refresh is available in the tweak library; select it from Optimize to queue safely.' } }
        'network:2' { $file = New-InventoryReport 'network'; return [pscustomobject]@{ ok=$true; message='Network adapter inventory saved'; path=$file } }
        'network:3' { return (Invoke-ApexNetworkReset 'quick') }
        'network:4' { return (Invoke-ApexNetworkReset 'full') }
        'startup:0' { $file = New-InventoryReport 'startup'; return [pscustomobject]@{ ok=$true; message='Startup inventory saved'; path=$file } }
        'startup:1' { Start-Process 'ms-settings:startupapps' | Out-Null; return [pscustomobject]@{ ok=$true; message='Windows Startup Apps settings opened.' } }
        'startup:2' { Start-Process explorer.exe $script:RollbackDir | Out-Null; return [pscustomobject]@{ ok=$true; message='Rollback folder opened'; path=$script:RollbackDir } }
        'gpu:0' { return (Invoke-GpuDriverAction 'gpu:inventory') }
        'gpu:1' { return (Invoke-GpuDriverAction 'gpu:display-settings') }
        'gpu:2' { return (Invoke-GpuDriverAction 'gpu:inventory') }
        'ai:0' { $file = New-SystemSnapshotReport; return [pscustomobject]@{ ok=$true; message='Apex AI system analysis snapshot saved'; path=$file } }
        'ai:1' { return [pscustomobject]@{ ok=$true; message='Open Optimize and press Select recommended to build a safe plan.' } }
        'ai:2' { return [pscustomobject]@{ ok=$true; message='Select tweaks in Optimize, then use the info buttons for plain-English explanations.' } }
        'intelligence:0' { $file = New-ApexIntelligenceReport; return [pscustomobject]@{ ok=$true; message='Intelligence report saved'; path=$file } }
        'intelligence:1' { $file = New-ApexShaderReport; return [pscustomobject]@{ ok=$true; message='Shader health report saved'; path=$file } }
        'intelligence:2' { return (Invoke-ApexRuntimeSessionStart ([pscustomobject]@{ aggressive=$false })) }
        'intelligence:3' { return (Invoke-ApexRuntimeSessionStop) }
        'activity:0' { Start-Process explorer.exe $script:ReportsDir | Out-Null; return [pscustomobject]@{ ok=$true; message='Reports folder opened'; path=$script:ReportsDir } }
        'activity:1' { Start-Process explorer.exe $script:RollbackDir | Out-Null; return [pscustomobject]@{ ok=$true; message='Rollback folder opened'; path=$script:RollbackDir } }
        'activity:2' { Start-Process explorer.exe $script:DiagDir | Out-Null; return [pscustomobject]@{ ok=$true; message='Diagnostics folder opened'; path=$script:DiagDir } }
        'settings:0' { return (Get-ApexSettings) }
        'settings:1' { return [pscustomobject]@{ ok=$true; message='Updater source is configured from UPDATE-SOURCE.json.' } }
        'settings:2' { return [pscustomobject]@{ ok=$true; message='Advanced mode stays gated; risky tweaks require explicit confirmation.' } }
        'settings:open-appdata' { Start-Process explorer.exe $script:AppDir | Out-Null; return [pscustomobject]@{ ok=$true; message='ApexTune AppData folder opened.'; path=$script:AppDir } }
        'settings:open-diagnostics' { Start-Process explorer.exe $script:DiagDir | Out-Null; return [pscustomobject]@{ ok=$true; message='Diagnostics folder opened.'; path=$script:DiagDir } }
        'settings:open-reports' { Start-Process explorer.exe $script:ReportsDir | Out-Null; return [pscustomobject]@{ ok=$true; message='Reports folder opened.'; path=$script:ReportsDir } }
        'settings:open-windows-startup' { Start-Process 'ms-settings:startupapps' | Out-Null; return [pscustomobject]@{ ok=$true; message='Windows Startup Apps opened.' } }
        'settings:reset' { return (Reset-ApexSettings) }
        'settings:recovery' { return (Get-ApexStartupDiagnostics) }
        'launch:open' { return (Invoke-ApexOpenLastUrl) }
        default { return [pscustomobject]@{ ok=$true; message='Panel action acknowledged' } }
    }
}

function Handle-Request($Context) {
    $path = [uri]::UnescapeDataString($Context.Request.Url.AbsolutePath)
    try {
        if ($path -eq '/' -or $path -eq '/index.html') { Send-File $Context (Join-Path $script:WebRoot 'index.html'); return }
        if ($path -eq '/styles.css') { Send-File $Context (Join-Path $script:WebRoot 'styles.css'); return }
        if ($path -eq '/app.js') { Send-File $Context (Join-Path $script:WebRoot 'app.js'); return }
        if ($path -eq '/apex-bootfix.js') { Send-File $Context (Join-Path $script:WebRoot 'apex-bootfix.js'); return }
        if ($path -eq '/data/tweaks.json') { Send-File $Context (Join-Path $script:DataRoot 'tweaks.json'); return }
        if ($path -eq '/data/games.json') { Send-File $Context (Join-Path $script:DataRoot 'games.json'); return }
        if ($path -eq '/favicon.ico') { Send-File $Context (Join-Path (Join-Path $script:Root 'assets') 'ApexTune-AppIcon.ico'); return }
        if ($path -eq '/apple-touch-icon.png') { Send-File $Context (Join-Path (Join-Path $script:Root 'assets') 'apple-touch-icon.png'); return }
        if ($path -eq '/site.webmanifest') { Send-File $Context (Join-Path $script:Root 'site.webmanifest'); return }
        if ($path -like '/assets/*') {
            $rel = $path.Substring('/assets/'.Length).Replace('/', [IO.Path]::DirectorySeparatorChar)
            if ([string]::IsNullOrWhiteSpace($rel) -or $rel -match '\.\.' -or $rel -match '^[\\/]'  -or $rel -match ':') { Send-Json $Context @{ error='Invalid asset path' } 400; return }
            Send-File $Context (Join-Path (Join-Path $script:Root 'assets') $rel); return
        }
        if ($path -eq '/api/profiles' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexProfileCenter); return }
        if ($path -eq '/api/profiles/apply' -and $Context.Request.HttpMethod -eq 'POST') { $body = Read-BodyJson $Context; Send-Json $Context (Invoke-ApexSafeProfile ([string]$body.profile)); return }
        if ($path -eq '/api/doctor' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexPerformanceDoctorScan); return }
        if ($path -eq '/api/proof/snapshot' -and $Context.Request.HttpMethod -eq 'POST') { $body = Read-BodyJson $Context; $label = if ($body.PSObject.Properties.Name -contains 'label') { [string]$body.label } else { 'manual' }; Send-Json $Context (New-ApexProofSnapshot $label); return }
        if ($path -eq '/api/restore-vault' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexRestoreVaultCenter); return }
        if ($path -eq '/api/restore-vault/restore' -and $Context.Request.HttpMethod -eq 'POST') { $body = Read-BodyJson $Context; Send-Json $Context (Invoke-ApexRestoreVault $body); return }
        if ($path -eq '/api/driver-health' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexDriverHealthCenter); return }
        if ($path -eq '/api/repair' -and $Context.Request.HttpMethod -eq 'POST') { Send-Json $Context (Repair-ApexTuneInstall); return }
        if ($path -eq '/api/updater/verify' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Test-ApexUpdaterIntegrity); return }
        if ($path -eq '/api/jobs/start' -and $Context.Request.HttpMethod -eq 'POST') { $body = Read-BodyJson $Context; Send-Json $Context (New-ApexAsyncJob ([string]$body.type)); return }
        if ($path -eq '/api/jobs/status' -and $Context.Request.HttpMethod -eq 'GET') { $jid = [string]$Context.Request.QueryString['id']; Send-Json $Context (Get-ApexAsyncJob $jid); return }
        if ($path -eq '/api/settings' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexSettings); return }
        if ($path -eq '/api/settings/set' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Set-ApexSetting ([string]$body.key) $body.value); return
        }
        if ($path -eq '/api/settings/reset' -and $Context.Request.HttpMethod -eq 'POST') { Send-Json $Context (Reset-ApexSettings); return }
        if ($path -eq '/api/status') { Send-Json $Context (Get-Status); return }
        if ($path -eq '/api/health') { Send-Json $Context (Get-ApexStartupDiagnostics); return }
        if ($path -eq '/api/diag/startup') { Send-Json $Context (Get-ApexStartupDiagnostics); return }
        if ($path -eq '/api/open' -and $Context.Request.HttpMethod -eq 'POST') { Send-Json $Context (Invoke-ApexOpenLastUrl); return }
        if ($path -eq '/api/intelligence' -and $Context.Request.HttpMethod -eq 'GET') { $refreshIntel = ([string]$Context.Request.QueryString['refresh']) -eq '1'; Send-Json $Context (Get-ApexIntelligenceCenter -Refresh:$refreshIntel); return }
        if ($path -eq '/api/session' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexRuntimeSessionState); return }
        if ($path -eq '/api/session/start' -and $Context.Request.HttpMethod -eq 'POST') { $body = Read-BodyJson $Context; Send-Json $Context (Invoke-ApexRuntimeSessionStart $body); return }
        if ($path -eq '/api/session/stop' -and $Context.Request.HttpMethod -eq 'POST') { Send-Json $Context (Invoke-ApexRuntimeSessionStop); return }
        if ($path -eq '/api/activity' -and $Context.Request.HttpMethod -eq 'GET') {
            $limitRaw = [string]$Context.Request.QueryString['limit']
            $limit = 24
            if (-not [string]::IsNullOrWhiteSpace($limitRaw)) { [int]::TryParse($limitRaw, [ref]$limit) | Out-Null }
            Send-Json $Context (Get-ApexActivityCenter $limit); return
        }
        if ($path -eq '/api/tweaks') { Send-Json $Context (Get-Tweaks); return }
        if ($path -eq '/api/tweak-state' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-TweakState); return }
        if ($path -eq '/api/save' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Save-Plan @($body.ids)); return
        }
        if ($path -eq '/api/apply' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Apply-Tweaks @($body.ids) ([bool]$body.confirmed)); return
        }
        if ($path -eq '/api/disable' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Disable-Tweaks @($body.ids) ([bool]$body.confirmed)); return
        }
        if ($path -eq '/api/startup' -and $Context.Request.HttpMethod -eq 'GET') { $refresh = ([string]$Context.Request.QueryString['refresh']) -eq '1'; Send-Json $Context (Get-StartupItems -Refresh:$refresh); return }
        if ($path -eq '/api/startup/disable' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Disable-StartupItem ([string]$body.id)); return
        }
        if ($path -eq '/api/startup/enable' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Enable-StartupItem ([string]$body.id)); return
        }
        if ($path -eq '/api/games/catalog' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-GameCatalogForUi); return }
        if ($path -eq '/api/games' -and $Context.Request.HttpMethod -eq 'GET') { $refresh = ([string]$Context.Request.QueryString['refresh']) -eq '1'; $fast = ([string]$Context.Request.QueryString['fast']) -eq '1'; Send-Json $Context (Get-GamesCenter -Refresh:$refresh -Fast:$fast); return }
        if ($path -eq '/api/games/optimize' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            $gpuProvider = if ($body.PSObject.Properties.Name -contains 'gpuProvider') { [string]$body.gpuProvider } elseif ([bool]$body.useNvidiaHidden) { 'nvidia' } else { 'auto' }
            Send-Json $Context (Invoke-GameOptimize ([string]$body.id) ([string]$body.profile) $gpuProvider ([bool]$body.useNvidiaHidden)); return
        }
        if ($path -eq '/api/games/locate' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-GameLocate ([string]$body.id) ([string]$body.path)); return
        }
        if ($path -eq '/api/games/action' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-GameAction ([string]$body.action) ([string]$body.id)); return
        }
        if ($path -eq '/api/nvidia-profile/apply' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-NvidiaProfilePreset ([string]$body.preset) ([bool]$body.includeHidden) $null); return
        }
        if ($path -eq '/api/amd-profile/apply' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-AmdPreset ([string]$body.preset)); return
        }
        if ($path -eq '/api/gpu-preset/apply' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-GpuVendorPreset ([string]$body.vendor) ([string]$body.preset) ([bool]$body.includeHidden)); return
        }
        if ($path -eq '/api/gpu-driver' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-GpuDriverCenter); return }
        if ($path -eq '/api/gpu-driver/action' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-GpuDriverAction ([string]$body.action)); return
        }
        if ($path -eq '/api/power' -and $Context.Request.HttpMethod -eq 'GET') { Send-Json $Context (Get-ApexPowerCenter); return }
        if ($path -eq '/api/power/apextune' -and $Context.Request.HttpMethod -eq 'POST') { Send-Json $Context (Invoke-ApexTunePowerPlan); return }
        if ($path -eq '/api/power/custom' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-ApexCustomPowerPlan $body); return
        }
        if ($path -eq '/api/power/restore' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            $target = if ($body.PSObject.Properties.Name -contains 'target') { [string]$body.target } else { '' }
            Send-Json $Context (Restore-ApexPowerPlan $target); return
        }
        if ($path -eq '/api/power/unhide' -and $Context.Request.HttpMethod -eq 'POST') { Send-Json $Context (Invoke-ApexPowerUnhide); return }
        if ($path -eq '/api/power/delete' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Remove-ApexCreatedPowerPlans $body); return
        }
        if ($path -eq '/api/action' -and $Context.Request.HttpMethod -eq 'POST') {
            $body = Read-BodyJson $Context
            Send-Json $Context (Invoke-PanelAction ([string]$body.action)); return
        }
        Send-Json $Context @{ error = 'Not found'; path = $path } 404
    } catch {
        Write-ApexLog $_.Exception.Message 'ERROR'
        Write-ApexCrashLog $_.Exception 'Request'
        Send-Json $Context @{ error = $_.Exception.Message } 500
    }
}

function Get-FreePort {
    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Parse('127.0.0.1'), 0)
    $listener.Start()
    $port = $listener.LocalEndpoint.Port
    $listener.Stop()
    return $port
}

function Open-CommandCenter([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    try { Set-Content -LiteralPath $script:LastUrlPath -Value $Url -Encoding UTF8 } catch {}
    try {
        $shortcut = Join-Path $script:Root 'Open-ApexTune.url'
        Set-Content -LiteralPath $shortcut -Value @('[InternetShortcut]', "URL=$Url") -Encoding ASCII
    } catch {}

    $settings = Read-ApexSettingsFile
    $forceOpen = ([string]$env:APEXTUNE_FORCE_OPEN) -eq '1'
    $forceDesktop = ([string]$env:APEXTUNE_FORCE_DESKTOP) -eq '1'
    $suppressOpen = ([string]$env:APEXTUNE_SUPPRESS_OPEN) -eq '1'
    $autoOpen = if ($suppressOpen) { $false } elseif ($forceOpen -or $forceDesktop) { $true } else { Convert-ApexStrictBool $settings['autoOpenBrowser'] }
    $mode = if ($suppressOpen) { 'none' } elseif ($forceOpen) { 'recovery' } elseif ($forceDesktop) { 'app-window' } else { [string]$settings['launchMode'] }
    if ([string]::IsNullOrWhiteSpace($mode)) { $mode = 'none' }
    $mode = $mode.Trim().ToLowerInvariant()
    if (-not $autoOpen -or $mode -eq 'none' -or $mode -eq 'server-only') {
        Write-ApexLaunchState $Url 'ServerOnly' 'ApexTune is running in background mode. No UI window was launched because auto-open is off.'
        Write-ApexLog "Auto-open disabled by settings. Desktop URL saved to $script:LastUrlPath" 'INFO'
        return $false
    }

    $launched = $false
    if ($mode -eq 'app-window' -and ([string]$env:APEXTUNE_OPEN_DEFAULT) -ne '1') {
        $edgeCandidates = @(
            "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
            "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
        )
        foreach ($edge in $edgeCandidates) {
            if (-not (Test-Path -LiteralPath $edge -PathType Leaf)) { continue }
            try {
                $edgeProfile = Join-Path $script:AppDir 'EdgeAppProfile'
                $p = Start-Process -FilePath $edge -ArgumentList @('--new-window', ('--app=' + $Url), ('--user-data-dir=' + $edgeProfile), '--no-first-run') -PassThru -ErrorAction Stop
                # Edge can hand off app-mode windows to an existing browser process and let the helper process exit.
                # Treat a successful Start-Process as launched so ApexTune never opens a second normal browser tab.
                $launched = $true
                Start-Sleep -Milliseconds 450
                if ($launched) { break }
            } catch { Write-ApexLog "Edge app-window launch failed: $($_.Exception.Message)" 'WARN' }
        }
    }
    if (-not $launched -and $mode -eq 'app-window') {
        Write-ApexLog 'App-window launch did not report success. Normal browser fallback is intentionally blocked; use Launch-ApexTune-Recovery.bat for browser recovery.' 'WARN'
    }
    if (-not $launched -and ($mode -eq 'default-browser' -or $mode -eq 'recovery')) {
        try {
            $cmdArgs = '/c start "" "' + $Url + '"'
            Start-Process -FilePath 'cmd.exe' -ArgumentList $cmdArgs -WindowStyle Hidden -ErrorAction Stop | Out-Null
            $launched = $true
        } catch { Write-ApexLog "Default browser launch failed: $($_.Exception.Message)" 'WARN' }
    }
    if (-not $launched -and $mode -eq 'recovery') {
        try { Start-Process -FilePath 'explorer.exe' -ArgumentList @($Url) -ErrorAction Stop | Out-Null; $launched = $true } catch { Write-ApexLog "Explorer URL launch failed: $($_.Exception.Message)" 'WARN' }
    }
    $launchState = if ($launched) { 'UiLaunchRequested' } else { 'UiLaunchSkippedOrFailed' }
    $launchMessage = if ($launched) { "ApexTune opened the local UI using launch mode: $mode." } else { "ApexTune is running, but no UI window was launched. Use Open-ApexTune.url when needed." }
    Write-ApexLaunchState $Url $launchState $launchMessage
    return $launched
}

function Start-ApexServer {
    $script:Port = Get-FreePort
    $prefixCandidates = @("http://127.0.0.1:$script:Port/", "http://localhost:$script:Port/")
    $listener = $null
    $prefix = $null
    foreach ($candidate in $prefixCandidates) {
        try {
            $tryListener = New-Object Net.HttpListener
            $tryListener.Prefixes.Add($candidate)
            $tryListener.Start()
            $listener = $tryListener
            $prefix = $candidate
            break
        } catch {
            Write-ApexLog "HttpListener failed for $candidate :: $($_.Exception.Message)" 'WARN'
            try { if ($tryListener) { $tryListener.Close() } } catch {}
        }
    }
    if (-not $listener) { throw 'ApexTune could not start the local web server on 127.0.0.1 or localhost. Run Launch-ApexTune-Debug.bat and check AppData\ApexTune\Diagnostics.' }

    Write-Host "ApexTune Command Center running at $prefix" -ForegroundColor Cyan
    Write-Host "ApexTune is running. Normal silent launch uses ApexTune.vbs; debug launch keeps this console visible." -ForegroundColor Yellow
    Write-ApexLog "Started $prefix"
    Write-ApexLaunchState $prefix 'ServerStarted' 'Local web server is listening.'
    Open-CommandCenter $prefix | Out-Null

    while ($listener.IsListening -and -not $script:ServerStop) {
        try {
            $context = $listener.GetContext()
            Handle-Request $context
        } catch {
            Write-ApexLog $_.Exception.Message 'ERROR'
            Start-Sleep -Milliseconds 200
        }
    }
    try { $listener.Stop() } catch {}
}


function New-IntelGpuPresetPackage([string]$Preset, [object]$Game = $null) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $safePreset = ($Preset -replace '[^A-Za-z0-9]+','-')
    $dir = Join-Path $script:DriverPresetDir "Intel-$safePreset-$stamp"
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $settings = switch ($Preset) {
        'Competitive' { @(
            [pscustomobject]@{ setting='Intel Graphics power preference'; value='Maximum Performance when available'; reason='Latency-first Intel Arc/Iris graphics behavior.' },
            [pscustomobject]@{ setting='Windows graphics preference'; value='High performance per game'; reason='Routes games to the best available GPU path.' },
            [pscustomobject]@{ setting='Game Mode'; value='On'; reason='Prioritizes game scheduling and reduces background interference.' }
        ) }
        'Maximum FPS' { @(
            [pscustomobject]@{ setting='Intel Graphics power preference'; value='Maximum Performance'; reason='FPS-first power behavior for Intel graphics.' },
            [pscustomobject]@{ setting='Capture overlays'; value='Off unless needed'; reason='Reduces background capture overhead.' },
            [pscustomobject]@{ setting='Shader/cache behavior'; value='Keep driver cache enabled'; reason='Improves repeat-launch smoothness.' }
        ) }
        'Quality' { @(
            [pscustomobject]@{ setting='Intel Graphics power preference'; value='Balanced/Quality'; reason='Keeps thermals and image quality prioritized.' },
            [pscustomobject]@{ setting='Display settings'; value='Native resolution and highest stable refresh rate'; reason='Quality-first visual path.' }
        ) }
        default { @(
            [pscustomobject]@{ setting='Intel Graphics power preference'; value='Balanced'; reason='Safe Intel graphics default.' },
            [pscustomobject]@{ setting='Windows graphics preference'; value='High performance for optimized games'; reason='Sensible per-game default.' }
        ) }
    }
    $target = if ($Game) { [string]$Game.name } else { 'Global profile' }
    $json = Join-Path $dir 'ApexTune-Intel-GPU-Preset.json'
    [pscustomobject]@{ vendor='Intel'; preset=$Preset; target=$target; generated=(Get-Date).ToString('o'); settings=$settings } | ConvertTo-Json -Depth 10 | Set-Content -Path $json -Encoding UTF8
    $guide = Join-Path $dir "ApexTune-Intel-$safePreset-Profile-Guide.txt"
    $target = if ($Game) { [string]$Game.name } else { 'Global profile' }
    $lines = @('ApexTune Intel GPU Preset Package', "Generated: $(Get-Date -Format o)", "Target: $target", "Preset: $Preset", '', 'Recommended Intel / Windows-side steps:')
    foreach ($s in $settings) { $lines += ("- {0}: {1} - {2}" -f $s.setting,$s.value,$s.reason) }
    $lines += @('', 'ApexTune opens this guide and advanced display settings. Apply matching choices in Intel Graphics Command Center / Arc Control when available.')
    Set-Content -Path $guide -Value $lines -Encoding UTF8
    return [pscustomobject]@{ dir=$dir; json=$json; guide=$guide }
}

function Invoke-IntelGpuPreset([string]$Preset, [object]$Game = $null) {
    $pack = New-IntelGpuPresetPackage $Preset $Game
    $openedGuide = Open-ApexTextFile ([string]$pack.guide)
    $openedFolder = Open-ApexFolder ([string]$pack.dir)
    try { Start-Process 'ms-settings:display-advanced' | Out-Null } catch {}
    return [pscustomobject]@{ ok=$true; message='Intel setup package created. Intel/Windows graphics settings opened with a clear guide.'; vendor='Intel'; preset=$Preset; guidePath=$pack.guide; presetPath=$pack.json; packageDir=$pack.dir; openedGuide=$openedGuide; openedFolder=$openedFolder }
}

function Resolve-GameGpuProvider([string]$Choice) {
    $v = ([string]$Choice).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($v) -or $v -eq 'auto' -or $v -eq 'all') {
        try {
            $detected = (Get-GpuDriverCenter).vendor
            $d = ([string]$detected).Trim().ToLowerInvariant()
            if ($d -match 'nvidia') { return 'nvidia' }
            if ($d -match 'amd') { return 'amd' }
            if ($d -match 'intel') { return 'intel' }
        } catch {}
        return 'windows'
    }
    if ($v -match 'none|off|skip|windows|system') { return 'windows' }
    if ($v -match 'nvidia|geforce|rtx|gtx') { return 'nvidia' }
    if ($v -match 'amd|radeon|adrenalin') { return 'amd' }
    if ($v -match 'intel|arc|iris|uhd') { return 'intel' }
    return 'windows'
}

function Invoke-GpuVendorPreset([string]$Vendor, [string]$Preset, [bool]$IncludeHidden = $true, [object]$Game = $null) {
    $v = Resolve-GameGpuProvider $Vendor
    if ($v -eq 'nvidia') { return (Invoke-NvidiaProfilePreset $Preset $IncludeHidden $Game) }
    if ($v -eq 'amd') { return (Invoke-AmdPreset $Preset $Game) }
    if ($v -eq 'intel') { return (Invoke-IntelGpuPreset $Preset $Game) }
    $gameName = if ($Game) { [string]$Game.name } else { $null }
    return [pscustomobject]@{ ok=$true; message='Windows-side game tuning selected. No vendor profile package was opened.'; vendor='Windows'; preset=$Preset; game=$gameName }
}

try {
    Start-ApexServer
} catch {
    Write-ApexLog $_.Exception.Message 'FATAL'
    Write-ApexCrashLog $_.Exception 'Startup'
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("ApexTune Command Center failed to start.`n$($_.Exception.Message)", 'ApexTune') | Out-Null
    exit 1
}
