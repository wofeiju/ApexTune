Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

$script:DisableHeavyHover = $true
$script:PerformanceMode = $true
$script:TweakPageSize = 72
$script:TweakPage = 1
$script:MaxInitialRenderedCards = 42
$script:MaxStrictApplyCount = 8

$script:ApexCustomUiAvailable = $false
$script:ApexCustomUiTypeError = $null
try {
Add-Type -Language CSharp -ReferencedAssemblies @("System.Windows.Forms.dll", "System.Drawing.dll", "System.dll") -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class ApexRoundedPanel : Panel
{
    public int CornerRadius { get; set; }
    public Color BorderColor { get; set; }
    public int BorderWidth { get; set; }

    public ApexRoundedPanel()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.Padding = new Padding(16);
        this.CornerRadius = 14;
        this.BorderColor = Color.FromArgb(44, 52, 64);
        this.BorderWidth = 1;
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (this.Width <= 1 || this.Height <= 1)
        {
            return;
        }
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
        using (GraphicsPath path = RoundedRect(rect, CornerRadius))
        {
            using (SolidBrush brush = new SolidBrush(this.BackColor))
            {
                e.Graphics.FillPath(brush, path);
            }
            using (Pen pen = new Pen(BorderColor, BorderWidth))
            {
                e.Graphics.DrawPath(pen, path);
            }
        }
    }

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        UpdatePanelRegion();
        this.Invalidate();
    }

    private void UpdatePanelRegion()
    {
        if (this.Width <= 1 || this.Height <= 1)
        {
            return;
        }

        Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
        using (GraphicsPath path = RoundedRect(rect, CornerRadius))
        {
            Region oldRegion = this.Region;
            this.Region = new Region(path);
            if (oldRegion != null)
            {
                oldRegion.Dispose();
            }
        }
    }

    private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        int diameter = radius * 2;
        GraphicsPath path = new GraphicsPath();
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public class ApexBufferedPanel : Panel
{
    public ApexBufferedPanel()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        this.UpdateStyles();
    }
}

public class ApexGradientPanel : Panel
{
    public Color StartColor { get; set; }
    public Color EndColor { get; set; }
    public Color AccentColor { get; set; }
    public Color BorderColor { get; set; }
    public int CornerRadius { get; set; }
    public bool ShowGrid { get; set; }
    public bool ShowAccentOrb { get; set; }

    public ApexGradientPanel()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.StartColor = Color.FromArgb(10, 16, 26);
        this.EndColor = Color.FromArgb(15, 23, 42);
        this.AccentColor = Color.FromArgb(109, 93, 251);
        this.BorderColor = Color.FromArgb(44, 52, 64);
        this.CornerRadius = 18;
        this.ShowGrid = true;
        this.ShowAccentOrb = true;
    }

    protected override void OnPaintBackground(PaintEventArgs e)
    {
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        if (this.Width <= 1 || this.Height <= 1) { return; }
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
        using (GraphicsPath path = RoundedRect(rect, CornerRadius))
        {
            using (LinearGradientBrush brush = new LinearGradientBrush(rect, StartColor, EndColor, LinearGradientMode.ForwardDiagonal))
            {
                e.Graphics.FillPath(brush, path);
            }

            if (ShowAccentOrb)
            {
                Rectangle orb = new Rectangle(this.Width - 260, -150, 360, 320);
                using (GraphicsPath orbPath = new GraphicsPath())
                {
                    orbPath.AddEllipse(orb);
                    using (PathGradientBrush glow = new PathGradientBrush(orbPath))
                    {
                        glow.CenterColor = Color.FromArgb(82, AccentColor);
                        glow.SurroundColors = new Color[] { Color.FromArgb(0, AccentColor) };
                        e.Graphics.FillPath(glow, orbPath);
                    }
                }
            }

            if (ShowGrid)
            {
                using (Pen gridPen = new Pen(Color.FromArgb(16, Color.White), 1))
                {
                    for (int x = 18; x < this.Width; x += 42)
                    {
                        e.Graphics.DrawLine(gridPen, x, 0, x, this.Height);
                    }
                    for (int y = 18; y < this.Height; y += 42)
                    {
                        e.Graphics.DrawLine(gridPen, 0, y, this.Width, y);
                    }
                }
            }

            using (Pen pen = new Pen(BorderColor, 1))
            {
                e.Graphics.DrawPath(pen, path);
            }
        }
    }

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        UpdatePanelRegion();
        this.Invalidate();
    }

    private void UpdatePanelRegion()
    {
        if (this.Width <= 1 || this.Height <= 1) { return; }
        Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
        using (GraphicsPath path = RoundedRect(rect, CornerRadius))
        {
            Region oldRegion = this.Region;
            this.Region = new Region(path);
            if (oldRegion != null) { oldRegion.Dispose(); }
        }
    }

    private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        int diameter = radius * 2;
        GraphicsPath path = new GraphicsPath();
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public class ApexScrollSkin : Control
{
    public Color TrackColor { get; set; }
    public Color ThumbColor { get; set; }
    public Color ThumbHoverColor { get; set; }
    public float ViewRatio { get; set; }
    public float ScrollRatio { get; set; }
    public bool ThumbHot { get; set; }

    public ApexScrollSkin()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.Width = 12;
        this.TrackColor = Color.FromArgb(28, 28, 28);
        this.ThumbColor = Color.FromArgb(115, 115, 115);
        this.ThumbHoverColor = Color.FromArgb(156, 163, 175);
        this.ViewRatio = 1.0f;
        this.ScrollRatio = 0.0f;
        this.Cursor = Cursors.Hand;
    }

    public Rectangle GetThumbBounds()
    {
        int trackHeight = Math.Max(1, this.Height - 8);
        float view = Math.Max(0.05f, Math.Min(1.0f, this.ViewRatio));
        int thumbHeight = Math.Max(38, Math.Min(trackHeight, (int)(trackHeight * view)));
        int range = Math.Max(0, trackHeight - thumbHeight);
        float ratio = Math.Max(0.0f, Math.Min(1.0f, this.ScrollRatio));
        int top = 4 + (int)(range * ratio);
        return new Rectangle(3, top, Math.Max(4, this.Width - 6), thumbHeight);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using (SolidBrush trackBrush = new SolidBrush(this.TrackColor))
        {
            e.Graphics.FillRectangle(trackBrush, this.ClientRectangle);
        }
        if (this.ViewRatio >= 0.995f)
        {
            return;
        }
        Rectangle thumb = GetThumbBounds();
        using (GraphicsPath path = RoundedRect(thumb, Math.Max(2, thumb.Width / 2)))
        using (SolidBrush thumbBrush = new SolidBrush(this.ThumbHot ? this.ThumbHoverColor : this.ThumbColor))
        {
            e.Graphics.FillPath(thumbBrush, path);
        }
    }

    private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        int diameter = radius * 2;
        GraphicsPath path = new GraphicsPath();
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}


public class ApexBrandMark : Control
{
    public Color AccentColor { get; set; }
    public Color AccentTwoColor { get; set; }
    public Color LineColor { get; set; }
    public ContentAlignment TextAlign { get; set; }
    private bool hot;

    public ApexBrandMark()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.Width = 42;
        this.Height = 42;
        this.BackColor = Color.Transparent;
        this.AccentColor = Color.FromArgb(139, 92, 246);
        this.AccentTwoColor = Color.FromArgb(34, 211, 238);
        this.LineColor = Color.FromArgb(248, 250, 252);
        this.TextAlign = ContentAlignment.MiddleCenter;
    }

    protected override void OnMouseEnter(EventArgs e) { hot = true; base.OnMouseEnter(e); this.Invalidate(); }
    protected override void OnMouseLeave(EventArgs e) { hot = false; base.OnMouseLeave(e); this.Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
        e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
        e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
        int size = Math.Max(12, Math.Min(this.Width, this.Height) - 2);
        Rectangle box = new Rectangle((this.Width - size) / 2, (this.Height - size) / 2, size, size);
        using (GraphicsPath shell = RoundedRect(box, Math.Max(8, size / 4)))
        using (LinearGradientBrush fill = new LinearGradientBrush(box, Blend(AccentColor, Color.White, hot ? 0.12f : 0.04f), Color.FromArgb(12, 16, 28), LinearGradientMode.ForwardDiagonal))
        using (Pen border = new Pen(hot ? AccentTwoColor : AccentColor, 2.0f))
        {
            e.Graphics.FillPath(fill, shell);
            e.Graphics.DrawPath(border, shell);
        }

        PointF p1 = new PointF(box.Left + size * 0.24f, box.Bottom - size * 0.25f);
        PointF p2 = new PointF(box.Left + size * 0.50f, box.Top + size * 0.21f);
        PointF p3 = new PointF(box.Right - size * 0.24f, box.Bottom - size * 0.25f);
        using (Pen peak = new Pen(LineColor, Math.Max(2.0f, size / 13.0f)))
        {
            peak.StartCap = LineCap.Round;
            peak.EndCap = LineCap.Round;
            e.Graphics.DrawLine(peak, p1, p2);
            e.Graphics.DrawLine(peak, p2, p3);
        }
        using (Pen pulse = new Pen(AccentTwoColor, Math.Max(1.4f, size / 20.0f)))
        {
            pulse.StartCap = LineCap.Round;
            pulse.EndCap = LineCap.Round;
            float y = box.Top + size * 0.62f;
            e.Graphics.DrawLines(pulse, new PointF[] {
                new PointF(box.Left + size * 0.29f, y),
                new PointF(box.Left + size * 0.42f, y),
                new PointF(box.Left + size * 0.48f, y - size * 0.13f),
                new PointF(box.Left + size * 0.56f, y + size * 0.08f),
                new PointF(box.Left + size * 0.71f, y + size * 0.08f)
            });
        }
    }

    private static Color Blend(Color from, Color to, float amount)
    {
        amount = Math.Max(0f, Math.Min(1f, amount));
        int r = (int)(from.R + ((to.R - from.R) * amount));
        int g = (int)(from.G + ((to.G - from.G) * amount));
        int b = (int)(from.B + ((to.B - from.B) * amount));
        int a = (int)(from.A + ((to.A - from.A) * amount));
        return Color.FromArgb(a, r, g, b);
    }

    private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        int diameter = Math.Max(2, radius * 2);
        GraphicsPath path = new GraphicsPath();
        if (diameter > bounds.Width) { diameter = bounds.Width; }
        if (diameter > bounds.Height) { diameter = bounds.Height; }
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public class ApexPlanSwitch : CheckBox
{
    public Color OnColor { get; set; }
    public Color OffColor { get; set; }
    public Color KnobColor { get; set; }
    public Color TextColor { get; set; }
    public Color BorderColor { get; set; }
    public string OnLabel { get; set; }
    public string OffLabel { get; set; }
    private bool hot;
    private bool down;
    private float knobProgress;
    private Timer animationTimer;

    public ApexPlanSwitch()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint | ControlStyles.Selectable, true);
        this.UpdateStyles();
        this.AutoSize = false;
        this.Width = 72;
        this.Height = 32;
        this.Cursor = Cursors.Hand;
        this.TabStop = true;
        this.OnColor = Color.FromArgb(34, 229, 138);
        this.OffColor = Color.FromArgb(31, 37, 56);
        this.KnobColor = Color.FromArgb(248, 250, 252);
        this.TextColor = Color.White;
        this.BorderColor = Color.FromArgb(71, 85, 120);
        this.OnLabel = "ON";
        this.OffLabel = "OFF";
        this.Text = "";
        this.knobProgress = this.Checked ? 1f : 0f;
        this.animationTimer = new Timer();
        this.animationTimer.Interval = 12;
        this.animationTimer.Tick += delegate { StepAnimation(); };
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && animationTimer != null)
        {
            animationTimer.Stop();
            animationTimer.Dispose();
            animationTimer = null;
        }
        base.Dispose(disposing);
    }

    protected override void OnCheckedChanged(EventArgs e)
    {
        base.OnCheckedChanged(e);
        if (animationTimer != null) { animationTimer.Start(); }
        this.Invalidate();
    }

    private void StepAnimation()
    {
        float target = this.Checked ? 1f : 0f;
        float delta = target - knobProgress;
        if (Math.Abs(delta) < 0.025f)
        {
            knobProgress = target;
            if (animationTimer != null) { animationTimer.Stop(); }
        }
        else
        {
            knobProgress += delta * 0.32f;
        }
        this.Invalidate();
    }

    protected override void OnMouseEnter(EventArgs eventargs) { hot = true; base.OnMouseEnter(eventargs); this.Invalidate(); }
    protected override void OnMouseLeave(EventArgs eventargs) { hot = false; down = false; base.OnMouseLeave(eventargs); this.Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs mevent) { if (mevent.Button == MouseButtons.Left) { down = true; } base.OnMouseDown(mevent); this.Invalidate(); }
    protected override void OnMouseUp(MouseEventArgs mevent) { down = false; base.OnMouseUp(mevent); this.Invalidate(); }
    protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); this.Invalidate(); }
    protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); this.Invalidate(); }
    protected override bool IsInputKey(Keys keyData) { if (keyData == Keys.Space || keyData == Keys.Enter) { return true; } return base.IsInputKey(keyData); }
    protected override void OnKeyDown(KeyEventArgs e) { if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) { this.Checked = !this.Checked; e.Handled = true; } base.OnKeyDown(e); }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle track = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
        int radius = Math.Max(1, track.Height / 2);
        Color targetBack = this.Checked ? this.OnColor : this.OffColor;
        Color back = targetBack;
        if (hot) { back = Blend(back, Color.White, this.Checked ? 0.10f : 0.08f); }
        if (down) { back = Blend(back, Color.Black, 0.08f); }

        using (GraphicsPath path = RoundedRect(track, radius))
        using (LinearGradientBrush brush = new LinearGradientBrush(track, Blend(back, Color.White, 0.08f), Blend(back, Color.Black, 0.08f), LinearGradientMode.Vertical))
        using (Pen border = new Pen(this.Checked ? Blend(this.OnColor, Color.White, 0.25f) : this.BorderColor, this.Focused ? 2f : 1.2f))
        {
            e.Graphics.FillPath(brush, path);
            e.Graphics.DrawPath(border, path);
        }

        if (hot || this.Focused)
        {
            using (GraphicsPath glowPath = RoundedRect(new Rectangle(1, 1, Math.Max(1, this.Width - 3), Math.Max(1, this.Height - 3)), radius))
            using (Pen glowPen = new Pen(Color.FromArgb(this.Focused ? 112 : 54, this.Checked ? this.OnColor : this.BorderColor), 1f))
            {
                e.Graphics.DrawPath(glowPen, glowPath);
            }
        }

        int knobSize = Math.Max(18, this.Height - 8);
        int knobY = (this.Height - knobSize) / 2 + (down ? 1 : 0);
        int startX = 4;
        int endX = this.Width - knobSize - 4;
        int knobX = startX + (int)((endX - startX) * Math.Max(0f, Math.Min(1f, knobProgress)));
        Rectangle knob = new Rectangle(knobX, knobY, knobSize, knobSize);
        using (GraphicsPath shadowPath = RoundedRect(new Rectangle(knob.X, knob.Y + 1, knob.Width, knob.Height), knobSize / 2))
        using (SolidBrush shadow = new SolidBrush(Color.FromArgb(50, 0, 0, 0)))
        {
            e.Graphics.FillPath(shadow, shadowPath);
        }
        using (GraphicsPath knobPath = RoundedRect(knob, knobSize / 2))
        using (LinearGradientBrush knobBrush = new LinearGradientBrush(knob, Color.White, this.KnobColor, LinearGradientMode.Vertical))
        using (Pen knobBorder = new Pen(Color.FromArgb(50, 0, 0, 0), 1))
        {
            e.Graphics.FillPath(knobBrush, knobPath);
            e.Graphics.DrawPath(knobBorder, knobPath);
        }

        string label = this.Checked ? this.OnLabel : this.OffLabel;
        Rectangle textBounds = this.Checked
            ? new Rectangle(7, 0, Math.Max(1, knobX - 8), this.Height)
            : new Rectangle(knobX + knobSize + 3, 0, Math.Max(1, this.Width - knobX - knobSize - 8), this.Height);
        using (Font labelFont = new Font(this.Font.FontFamily, Math.Max(6.0f, this.Font.Size), FontStyle.Bold))
        {
            TextRenderer.DrawText(e.Graphics, label, labelFont, textBounds, this.TextColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
        }
    }

    private static Color Blend(Color from, Color to, float amount)
    {
        amount = Math.Max(0f, Math.Min(1f, amount));
        int r = (int)(from.R + ((to.R - from.R) * amount));
        int g = (int)(from.G + ((to.G - from.G) * amount));
        int b = (int)(from.B + ((to.B - from.B) * amount));
        return Color.FromArgb(from.A, r, g, b);
    }

    private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        int diameter = Math.Max(2, radius * 2);
        GraphicsPath path = new GraphicsPath();
        if (diameter > bounds.Width) { diameter = bounds.Width; }
        if (diameter > bounds.Height) { diameter = bounds.Height; }
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}


public class ApexInfoCircle : Control
{
    public Color FillColor { get; set; }
    public Color BorderColor { get; set; }
    public Color IconColor { get; set; }
    public bool Filled { get; set; }
    private bool hot;

    public ApexInfoCircle()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.Width = 30;
        this.Height = 30;
        this.Cursor = Cursors.Hand;
        this.FillColor = Color.FromArgb(15, 23, 42);
        this.BorderColor = Color.FromArgb(99, 102, 241);
        this.IconColor = Color.White;
        this.Filled = false;
        this.Text = "";
    }

    protected override void OnMouseEnter(EventArgs e) { hot = true; base.OnMouseEnter(e); this.Invalidate(); }
    protected override void OnMouseLeave(EventArgs e) { hot = false; base.OnMouseLeave(e); this.Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs e) { }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        int size = Math.Min(this.Width, this.Height) - 2;
        if (size < 8) { return; }
        Rectangle circle = new Rectangle((this.Width - size) / 2, (this.Height - size) / 2, size, size);
        Color fill = Filled ? FillColor : this.BackColor;
        Color border = hot ? Blend(BorderColor, Color.White, 0.25f) : BorderColor;
        Color icon = hot ? Blend(IconColor, Color.White, 0.18f) : IconColor;
        using (SolidBrush fillBrush = new SolidBrush(fill))
        using (Pen pen = new Pen(border, 2))
        {
            e.Graphics.FillEllipse(fillBrush, circle);
            e.Graphics.DrawEllipse(pen, circle);
        }
        using (SolidBrush iconBrush = new SolidBrush(icon))
        {
            int dot = Math.Max(3, size / 8);
            e.Graphics.FillEllipse(iconBrush, new Rectangle(circle.X + (size - dot) / 2, circle.Y + 7, dot, dot));
            int stemW = Math.Max(4, size / 7);
            int stemH = Math.Max(10, size / 3);
            e.Graphics.FillRectangle(iconBrush, new Rectangle(circle.X + (size - stemW) / 2, circle.Y + size / 2 - 1, stemW, stemH));
        }
    }

    private static Color Blend(Color from, Color to, float amount)
    {
        amount = Math.Max(0f, Math.Min(1f, amount));
        int r = (int)(from.R + ((to.R - from.R) * amount));
        int g = (int)(from.G + ((to.G - from.G) * amount));
        int b = (int)(from.B + ((to.B - from.B) * amount));
        return Color.FromArgb(from.A, r, g, b);
    }
}


public class ApexStatusDot : Control
{
    public Color DotColor { get; set; }
    public Color GlowColor { get; set; }
    public ApexStatusDot()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.Width = 14;
        this.Height = 14;
        this.DotColor = Color.FromArgb(34, 255, 131);
        this.GlowColor = Color.FromArgb(18, 185, 129);
        this.BackColor = Color.Transparent;
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        int size = Math.Min(this.Width, this.Height) - 3;
        if (size < 6) { return; }
        Rectangle outer = new Rectangle((this.Width - size) / 2, (this.Height - size) / 2, size, size);
        using (SolidBrush glow = new SolidBrush(Color.FromArgb(55, GlowColor)))
        using (SolidBrush fill = new SolidBrush(DotColor))
        {
            e.Graphics.FillEllipse(glow, outer);
            Rectangle inner = new Rectangle(outer.X + 3, outer.Y + 3, Math.Max(4, outer.Width - 6), Math.Max(4, outer.Height - 6));
            e.Graphics.FillEllipse(fill, inner);
        }
    }
}

public class ApexGlassButton : Button
{
    public int CornerRadius { get; set; }
    public Color BorderColor { get; set; }
    public Color HoverBackColor { get; set; }
    public Color DownBackColor { get; set; }
    public Color AccentColor { get; set; }
    private bool hot;
    private bool down;

    public ApexGlassButton()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        this.UpdateStyles();
        this.FlatStyle = FlatStyle.Flat;
        this.FlatAppearance.BorderSize = 0;
        this.UseVisualStyleBackColor = false;
        this.Cursor = Cursors.Hand;
        this.CornerRadius = 12;
        this.BorderColor = Color.FromArgb(54, 66, 90);
        this.HoverBackColor = Color.FromArgb(31, 41, 62);
        this.DownBackColor = Color.FromArgb(17, 24, 39);
        this.AccentColor = Color.FromArgb(124, 92, 255);
        this.TextAlign = ContentAlignment.MiddleCenter;
        this.ImageAlign = ContentAlignment.MiddleLeft;
        this.Padding = new Padding(14, 0, 14, 0);
    }

    protected override void OnMouseEnter(EventArgs e) { hot = true; base.OnMouseEnter(e); this.Invalidate(); }
    protected override void OnMouseLeave(EventArgs e) { hot = false; down = false; base.OnMouseLeave(e); this.Invalidate(); }
    protected override void OnMouseDown(MouseEventArgs mevent) { if (mevent.Button == MouseButtons.Left) { down = true; } base.OnMouseDown(mevent); this.Invalidate(); }
    protected override void OnMouseUp(MouseEventArgs mevent) { down = false; base.OnMouseUp(mevent); this.Invalidate(); }
    protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); this.Invalidate(); }
    protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); this.Invalidate(); }
    protected override void OnPaintBackground(PaintEventArgs pevent) { }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
        if (rect.Width < 2 || rect.Height < 2) { return; }

        Color baseColor = this.Enabled ? this.BackColor : Blend(this.BackColor, Color.Gray, 0.45f);
        Color fill = down ? DownBackColor : (hot ? HoverBackColor : baseColor);
        Color top = Blend(fill, Color.White, hot ? 0.09f : 0.045f);
        Color bottom = Blend(fill, Color.Black, 0.045f);

        using (GraphicsPath path = RoundedRect(rect, Math.Max(2, CornerRadius)))
        using (LinearGradientBrush brush = new LinearGradientBrush(rect, top, bottom, LinearGradientMode.Vertical))
        using (Pen border = new Pen(this.Enabled ? BorderColor : Blend(BorderColor, Color.Gray, 0.55f), 1.0f))
        {
            e.Graphics.FillPath(brush, path);
            e.Graphics.DrawPath(border, path);
        }

        if ((hot || this.Focused) && this.Enabled)
        {
            Rectangle glow = new Rectangle(1, 1, Math.Max(1, this.Width - 3), Math.Max(1, this.Height - 3));
            using (GraphicsPath glowPath = RoundedRect(glow, Math.Max(2, CornerRadius - 1)))
            using (Pen glowPen = new Pen(Color.FromArgb(this.Focused ? 118 : 58, AccentColor), this.Focused ? 1.7f : 1.0f))
            {
                e.Graphics.DrawPath(glowPen, glowPath);
            }
        }

        int pressOffset = down ? 1 : 0;
        Rectangle textRect = new Rectangle(this.Padding.Left, pressOffset, Math.Max(1, this.Width - this.Padding.Left - this.Padding.Right), Math.Max(1, this.Height - pressOffset));
        if (this.Image != null)
        {
            int imgSize = Math.Min(24, Math.Min(this.Image.Width, this.Image.Height));
            int imgY = (this.Height - imgSize) / 2;
            int imgX = Math.Max(10, this.Padding.Left - 2);
            e.Graphics.DrawImage(this.Image, new Rectangle(imgX, imgY + pressOffset, imgSize, imgSize));
            textRect = new Rectangle(imgX + imgSize + 10, pressOffset, Math.Max(1, this.Width - imgX - imgSize - 18), Math.Max(1, this.Height - pressOffset));
        }

        TextFormatFlags flags = TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
        if (this.TextAlign == ContentAlignment.MiddleLeft || this.TextAlign == ContentAlignment.TopLeft || this.TextAlign == ContentAlignment.BottomLeft)
        {
            flags |= TextFormatFlags.Left;
        }
        else if (this.TextAlign == ContentAlignment.MiddleRight || this.TextAlign == ContentAlignment.TopRight || this.TextAlign == ContentAlignment.BottomRight)
        {
            flags |= TextFormatFlags.Right;
        }
        else
        {
            flags |= TextFormatFlags.HorizontalCenter;
        }
        TextRenderer.DrawText(e.Graphics, this.Text, this.Font, textRect, this.Enabled ? this.ForeColor : Blend(this.ForeColor, Color.Gray, 0.55f), flags);
    }

    private static Color Blend(Color from, Color to, float amount)
    {
        amount = Math.Max(0f, Math.Min(1f, amount));
        int r = (int)(from.R + ((to.R - from.R) * amount));
        int g = (int)(from.G + ((to.G - from.G) * amount));
        int b = (int)(from.B + ((to.B - from.B) * amount));
        int a = (int)(from.A + ((to.A - from.A) * amount));
        return Color.FromArgb(a, r, g, b);
    }

    private static GraphicsPath RoundedRect(Rectangle bounds, int radius)
    {
        int diameter = Math.Max(2, radius * 2);
        GraphicsPath path = new GraphicsPath();
        if (diameter > bounds.Width) { diameter = bounds.Width; }
        if (diameter > bounds.Height) { diameter = bounds.Height; }
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}


public class ApexSmoothFlowPanel : FlowLayoutPanel
{
    public ApexSmoothFlowPanel()
    {
        this.DoubleBuffered = true;
        this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        this.UpdateStyles();
    }
}

public class ApexComboBox : ComboBox
{
    public Color ItemBackColor { get; set; }
    public Color ItemHoverBackColor { get; set; }
    public Color ItemForeColor { get; set; }

    public ApexComboBox()
    {
        this.DrawMode = DrawMode.OwnerDrawFixed;
        this.DropDownStyle = ComboBoxStyle.DropDownList;
        this.FlatStyle = FlatStyle.Flat;
        this.ItemHeight = 24;
        this.ItemBackColor = Color.FromArgb(17, 23, 34);
        this.ItemHoverBackColor = Color.FromArgb(32, 36, 49);
        this.ItemForeColor = Color.FromArgb(244, 247, 251);
        this.BackColor = this.ItemBackColor;
        this.ForeColor = this.ItemForeColor;
    }

    protected override void OnDrawItem(DrawItemEventArgs e)
    {
        if (e.Index < 0)
        {
            return;
        }

        bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
        Color back = selected ? ItemHoverBackColor : ItemBackColor;
        using (SolidBrush brush = new SolidBrush(back))
        {
            e.Graphics.FillRectangle(brush, e.Bounds);
        }

        Rectangle textBounds = new Rectangle(e.Bounds.X + 8, e.Bounds.Y, Math.Max(0, e.Bounds.Width - 12), e.Bounds.Height);
        TextRenderer.DrawText(
            e.Graphics,
            Convert.ToString(this.Items[e.Index]),
            this.Font,
            textBounds,
            ItemForeColor,
            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis
        );
    }
}

public static class ApexWindowChrome
{
    [DllImport("user32.dll")]
    public static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
}

public static class ApexNativeMetrics
{
    [StructLayout(LayoutKind.Sequential)]
    private struct FILETIME
    {
        public uint dwLowDateTime;
        public uint dwHighDateTime;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private class MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;

        public MEMORYSTATUSEX()
        {
            dwLength = (uint)Marshal.SizeOf(typeof(MEMORYSTATUSEX));
        }
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GetSystemTimes(out FILETIME idleTime, out FILETIME kernelTime, out FILETIME userTime);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX buffer);

    private static bool hasCpuSample = false;
    private static ulong lastIdle = 0;
    private static ulong lastKernel = 0;
    private static ulong lastUser = 0;

    private static ulong ToUInt64(FILETIME value)
    {
        return ((ulong)value.dwHighDateTime << 32) | value.dwLowDateTime;
    }

    public static double GetCpuUsage()
    {
        FILETIME idleTime;
        FILETIME kernelTime;
        FILETIME userTime;
        if (!GetSystemTimes(out idleTime, out kernelTime, out userTime))
        {
            return -1;
        }

        ulong idle = ToUInt64(idleTime);
        ulong kernel = ToUInt64(kernelTime);
        ulong user = ToUInt64(userTime);

        if (!hasCpuSample)
        {
            lastIdle = idle;
            lastKernel = kernel;
            lastUser = user;
            hasCpuSample = true;
            return -1;
        }

        ulong idleDelta = idle - lastIdle;
        ulong kernelDelta = kernel - lastKernel;
        ulong userDelta = user - lastUser;
        ulong totalDelta = kernelDelta + userDelta;

        lastIdle = idle;
        lastKernel = kernel;
        lastUser = user;

        if (totalDelta == 0)
        {
            return 0;
        }

        double busy = ((double)(totalDelta - idleDelta) / totalDelta) * 100.0;
        if (busy < 0) { busy = 0; }
        if (busy > 100) { busy = 100; }
        return busy;
    }

    public static ulong[] GetMemoryStatus()
    {
        MEMORYSTATUSEX status = new MEMORYSTATUSEX();
        if (!GlobalMemoryStatusEx(status))
        {
            return null;
        }

        ulong used = status.ullTotalPhys - status.ullAvailPhys;
        return new ulong[] { (ulong)status.dwMemoryLoad, used, status.ullTotalPhys };
    }
}
"@ -ErrorAction Stop
    $script:ApexCustomUiAvailable = [bool]("ApexRoundedPanel" -as [type])
    if (-not $script:ApexCustomUiAvailable) {
        $script:ApexCustomUiTypeError = "Apex UI Add-Type completed but ApexRoundedPanel was not discoverable."
    }
} catch {
    $script:ApexCustomUiAvailable = $false
    $script:ApexCustomUiTypeError = $_.Exception.Message
}

function Add-ApexFallbackProperties {
    param(
        [Parameter(Mandatory = $true)] $Control,
        [hashtable] $Properties
    )
    if ($null -eq $Control -or $null -eq $Properties) { return $Control }
    foreach ($key in $Properties.Keys) {
        try {
            if ($null -eq $Control.PSObject.Properties[$key]) {
                $Control | Add-Member -NotePropertyName $key -NotePropertyValue $Properties[$key] -Force
            }
        } catch {}
    }
    return $Control
}

function New-ApexUiControl {
    param([Parameter(Mandatory = $true)][string] $TypeName)

    $type = $TypeName -as [type]
    if ($null -ne $type) {
        try { return [Activator]::CreateInstance($type) } catch {}
    }

    $line = [System.Drawing.Color]::FromArgb(44, 52, 64)
    $card = [System.Drawing.Color]::FromArgb(13, 21, 36)
    $panel2 = [System.Drawing.Color]::FromArgb(15, 24, 40)
    $accent = [System.Drawing.Color]::FromArgb(124, 92, 255)
    $green = [System.Drawing.Color]::FromArgb(51, 240, 120)
    $red = [System.Drawing.Color]::FromArgb(255, 77, 94)
    $text = [System.Drawing.Color]::FromArgb(247, 250, 255)

    switch ($TypeName) {
        "ApexBrandMark" {
            $brand = New-Object System.Windows.Forms.Label
            $brand.AutoSize = $false
            $brand.Text = "A"
            $brand.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
            $brand.Font = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
            $brand.ForeColor = $text
            $brand.BackColor = $accent
            return (Add-ApexFallbackProperties $brand @{ AccentColor = $accent; AccentTwoColor = $green; LineColor = $text; CornerRadius = 14 })
        }
        "ApexSmoothFlowPanel" {
            $flow = New-Object System.Windows.Forms.FlowLayoutPanel
            $flow.AutoScroll = $false
            return $flow
        }
        "ApexPlanSwitch" {
            $check = New-Object System.Windows.Forms.CheckBox
            $check.Appearance = [System.Windows.Forms.Appearance]::Button
            $check.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $check.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
            $check.UseVisualStyleBackColor = $false
            $check.BackColor = $red
            $check.ForeColor = [System.Drawing.Color]::White
            $check.Text = "OFF"
            $check.Add_CheckedChanged({
                param($sender, $eventArgs)
                try {
                    $sender.Text = $(if ($sender.Checked) { "ON" } else { "OFF" })
                    $sender.BackColor = $(if ($sender.Checked) { $sender.OnColor } else { $sender.OffColor })
                } catch {}
            })
            return (Add-ApexFallbackProperties $check @{
                OnColor = $green; OffColor = $red; KnobColor = [System.Drawing.Color]::White; TextColor = [System.Drawing.Color]::White;
                BorderColor = $line; OnLabel = "ON"; OffLabel = "OFF"
            })
        }
        "ApexInfoCircle" {
            $button = New-Object System.Windows.Forms.Button
            $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
            $button.Text = "i"
            $button.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
            $button.ForeColor = $text
            $button.BackColor = $panel2
            try { $button.FlatAppearance.BorderSize = 1; $button.FlatAppearance.BorderColor = $accent } catch {}
            return (Add-ApexFallbackProperties $button @{
                FillColor = $panel2; BorderColor = $accent; IconColor = $text; Filled = $false; CornerRadius = 15
            })
        }
        "ApexStatusDot" {
            $label = New-Object System.Windows.Forms.Label
            $label.AutoSize = $false
            $label.Text = [System.Char]::ConvertFromUtf32(0x25CF)
            $label.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
            $label.ForeColor = $green
            $label.BackColor = [System.Drawing.Color]::Transparent
            return (Add-ApexFallbackProperties $label @{ DotColor = $green; GlowColor = $green })
        }
        "ApexGradientPanel" {
            $panel = New-Object System.Windows.Forms.Panel
            $panel.BackColor = $card
            return (Add-ApexFallbackProperties $panel @{
                StartColor = $card; EndColor = $panel2; AccentColor = $accent; BorderColor = $line; CornerRadius = 20;
                ShowGrid = $false; ShowAccentOrb = $false; BorderWidth = 1
            })
        }
        "ApexRoundedPanel" {
            $panel = New-Object System.Windows.Forms.Panel
            $panel.BackColor = $card
            $panel.Padding = New-Object System.Windows.Forms.Padding(16)
            return (Add-ApexFallbackProperties $panel @{ BorderColor = $line; CornerRadius = 18; BorderWidth = 1 })
        }
        default {
            $panel = New-Object System.Windows.Forms.Panel
            return (Add-ApexFallbackProperties $panel @{ BorderColor = $line; CornerRadius = 14; BorderWidth = 1 })
        }
    }
}


function ColorFromHex($Hex) {
    return [System.Drawing.ColorTranslator]::FromHtml($Hex)
}

function Get-ThemeColor($Name, $FallbackHex) {
    $fallback = ColorFromHex $FallbackHex
    if ([string]::IsNullOrWhiteSpace([string]$Name)) { return $fallback }
    try {
        if ($script:Colors -is [hashtable] -and $script:Colors.ContainsKey($Name)) {
            $color = $script:Colors[$Name]
            if ($color -is [System.Drawing.Color]) { return $color }
        }
        $prop = $script:Colors.PSObject.Properties[$Name]
        if ($null -ne $prop -and $prop.Value -is [System.Drawing.Color]) { return $prop.Value }
    } catch {}
    return $fallback
}

function Get-ThemeColors($Theme = "dark") {
    $themeKey = ([string]$Theme).ToLowerInvariant()
    if ($themeKey -eq "light") {
        return @{
            Bg = ColorFromHex "#F4F7FB"
            Panel = ColorFromHex "#FFFFFF"
            Panel2 = ColorFromHex "#EDF3FF"
            Sidebar = ColorFromHex "#FFFFFF"
            Card = ColorFromHex "#FFFFFF"
            Card2 = ColorFromHex "#F8FBFF"
            Field = ColorFromHex "#F1F5FB"
            Line = ColorFromHex "#D3DDEC"
            Hover = ColorFromHex "#E7F0FF"
            ScrollTrack = ColorFromHex "#E2E8F0"
            ScrollThumb = ColorFromHex "#8FA2BF"
            ScrollThumbHover = ColorFromHex "#65758B"
            Text = ColorFromHex "#08111F"
            Muted = ColorFromHex "#5C6980"
            Accent = ColorFromHex "#4F46E5"
            Green = ColorFromHex "#0EA56D"
            Teal = ColorFromHex "#0891B2"
            Blue = ColorFromHex "#2563EB"
            Violet = ColorFromHex "#7C3AED"
            Amber = ColorFromHex "#D97706"
            Red = ColorFromHex "#DC2626"
        }
    }
    return @{
        Bg = ColorFromHex "#050711"
        Panel = ColorFromHex "#080A14"
        Panel2 = ColorFromHex "#101225"
        Sidebar = ColorFromHex "#060712"
        Card = ColorFromHex "#0C0E1A"
        Card2 = ColorFromHex "#111421"
        Field = ColorFromHex "#0A0C15"
        Line = ColorFromHex "#20263A"
        Hover = ColorFromHex "#181C2D"
        ScrollTrack = ColorFromHex "#070914"
        ScrollThumb = ColorFromHex "#414866"
        ScrollThumbHover = ColorFromHex "#A78BFA"
        Text = ColorFromHex "#F8FBFF"
        Muted = ColorFromHex "#A8B0C2"
        Accent = ColorFromHex "#8B5CF6"
        Green = ColorFromHex "#22E58A"
        Teal = ColorFromHex "#00E5FF"
        Blue = ColorFromHex "#5B8CFF"
        Violet = ColorFromHex "#A78BFA"
        Amber = ColorFromHex "#FBBF24"
        Red = ColorFromHex "#FF4D7D"
    }
}

$script:Colors = Get-ThemeColors "dark"

$script:UiTokens = [ordered]@{
    SidebarWidth = 204
    SidebarCompactWidth = 68
    SidebarNavHeight = 42
    SidebarFooterHeight = 112
    HeaderHeight = 72
    SurfaceGap = 10
    CardRadius = 18
    CardGap = 12
    MetricCardHeight = 62
    TweakCardMinWidth = 340
    TweakCardMaxWidth = 462
    TweakCardHeight = 196
    QueueWideWidth = 314
    QueueCompactHeight = 240
    ChipHeight = 26
    ToggleWidth = 72
    ToggleHeight = 32
}
$script:ApexToolTip = New-Object System.Windows.Forms.ToolTip
try {
    $script:ApexToolTip.AutoPopDelay = 9000
    $script:ApexToolTip.InitialDelay = 350
    $script:ApexToolTip.ReshowDelay = 120
    $script:ApexToolTip.ShowAlways = $true
    $script:ApexToolTip.BackColor = (ColorFromHex "#0B1220")
    $script:ApexToolTip.ForeColor = (ColorFromHex "#F8FAFF")
} catch {}


$script:OwnerUsername = "owner"
$script:OwnerPasswordHash = "96ef10a5fe3ac7a74ed10640dddd1cb81276d1ba5ff423f0ded26df644e801cb"
$script:BaseAppData = $(if ($env:APPDATA) { $env:APPDATA } else { [Environment]::GetFolderPath([System.Environment+SpecialFolder]::ApplicationData) })
$script:AppDir = Join-Path $script:BaseAppData "ApexTune"
$script:AppRoot = $script:AppDir
$script:AccountsPath = Join-Path $script:AppDir "accounts.json"
$script:SessionPath = Join-Path $script:AppDir "session.json"
$script:OwnerPath = Join-Path $script:AppDir "owner.json"
$script:BackupsRoot = Join-Path $script:AppDir "Backups"
$script:AppVersion = "40.0 Lovable Command UI + Custom Scroll"
$script:AppVersionNumber = "1.40000"
$script:SupportEmail = "local-only build"


function Repair-TweakCatalog {
    $fixed = 0
    foreach ($tweak in $script:Tweaks) {
        if ($null -eq $tweak.Id -or [string]::IsNullOrWhiteSpace([string]$tweak.Id)) { $tweak | Add-Member -NotePropertyName Id -NotePropertyValue ("tweak-" + [guid]::NewGuid().ToString("N")) -Force; $fixed++ }
        if ($null -eq $tweak.Title -or [string]::IsNullOrWhiteSpace([string]$tweak.Title)) { $tweak | Add-Member -NotePropertyName Title -NotePropertyValue $tweak.Id -Force; $fixed++ }
        if ($null -eq $tweak.Tier) { $tweak | Add-Member -NotePropertyName Tier -NotePropertyValue "Free" -Force; $fixed++ }
        if ($null -eq $tweak.Category) { $tweak | Add-Member -NotePropertyName Category -NotePropertyValue "Maintenance" -Force; $fixed++ }
        if ($null -eq $tweak.Risk) { $tweak | Add-Member -NotePropertyName Risk -NotePropertyValue "Low" -Force; $fixed++ }
        if ($null -eq $tweak.Fps) { $tweak | Add-Member -NotePropertyName Fps -NotePropertyValue 0 -Force; $fixed++ }
        if ($null -eq $tweak.Ping) { $tweak | Add-Member -NotePropertyName Ping -NotePropertyValue 0 -Force; $fixed++ }
        if ($null -eq $tweak.Restart) { $tweak | Add-Member -NotePropertyName Restart -NotePropertyValue $false -Force; $fixed++ }
        if ($null -eq $tweak.Experimental) { $tweak | Add-Member -NotePropertyName Experimental -NotePropertyValue $false -Force; $fixed++ }
        if ($null -eq $tweak.Vendors -or @($tweak.Vendors).Count -eq 0) { $tweak | Add-Member -NotePropertyName Vendors -NotePropertyValue @('nvidia','amd','intel','other') -Force; $fixed++ }
        if ($null -eq $tweak.Systems -or @($tweak.Systems).Count -eq 0) { $tweak | Add-Member -NotePropertyName Systems -NotePropertyValue @('desktop','laptop') -Force; $fixed++ }
        if ($null -eq $tweak.Games -or @($tweak.Games).Count -eq 0) { $tweak | Add-Member -NotePropertyName Games -NotePropertyValue @('esports','aaa','streaming') -Force; $fixed++ }
        if ($null -eq $tweak.Tags) { $tweak | Add-Member -NotePropertyName Tags -NotePropertyValue @() -Force; $fixed++ }
        if ($null -eq $tweak.Summary) { $tweak | Add-Member -NotePropertyName Summary -NotePropertyValue "ApexTune tuning card." -Force; $fixed++ }
        if ($null -eq $tweak.BackupKeys) { $tweak | Add-Member -NotePropertyName BackupKeys -NotePropertyValue @() -Force; $fixed++ }
        if ($null -eq $tweak.Commands -or @($tweak.Commands).Count -eq 0) {
            $tweak | Add-Member -NotePropertyName Commands -NotePropertyValue @('Write-Output "ApexTune guidance card: no automated Windows change was required."') -Force
            $fixed++
        }
        if ($null -eq $tweak.Rollback -or @($tweak.Rollback).Count -eq 0) {
            $tweak | Add-Member -NotePropertyName Rollback -NotePropertyValue @('Write-Output "No rollback command was required for this card."') -Force
            $fixed++
        }
    }
    $script:TweakCatalogFixes = $fixed
}
$script:DefaultSettings = [ordered]@{
    Experimental = $false
    ShowRisky = $false
    RestorePoint = $true
    RegistryBackup = $true
    StrictSafety = $true
    CompactCards = $true
    StartMaximized = $true
    AppMark = "AX"
    Theme = "dark"
}

$script:DefaultProfile = [ordered]@{
    Gpu = "nvidia"
    Network = "ethernet"
    System = "desktop"
    Game = "esports"
}

$script:State = @{
    AuthMode = "login"
    User = $null
    Users = @()
    Selected = @{}
    Filter = "all"
    CategoryFilter = "all"
    RiskFilter = "all"
    Sort = "recommended"
    Search = ""
    Settings = @{}
    Profile = @{}
    Hardware = $null
    AiMessages = @()
}
$script:LiveMetricLabels = @{}
$script:LiveStatsTimer = $null
$script:UpdateCheckTimer = $null
$script:LastUpdateVersionPrompted = ""
$script:LiveStatsWarmupTimer = $null
$script:CpuUsageCounter = $null
$script:HardwareScanJob = $null
$script:HardwareScanTimer = $null
$script:HardwareAutoScanStarted = $false
$script:LivePingCache = @{
    Title = "--"
    Body = "Ping pending"
    LastSample = [datetime]::MinValue
}
$script:ContentHost = $null
$script:PageTransitionTimer = $null
$script:BrandMarkLabels = @()
$script:TweakCardWidth = 360
$script:IsRenderingCards = $false

$script:Tweaks = @(
    [pscustomobject]@{
        Id = "game-mode-hags"; Title = "Game Mode and hardware scheduling"; Tier = "Free"; Category = "Windows"; Risk = "Medium"; Fps = 7; Ping = 1; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "Windows", "GPU")
        Summary = "Enables Windows Game Mode and the hardware GPU scheduling registry value for supported systems."
        BackupKeys = @("HKCU\Software\Microsoft\GameBar", "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers")
        Commands = @(
            'reg add "HKCU\Software\Microsoft\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 1 /f',
            'reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f'
        )
        Rollback = @(
            'reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 0 /f',
            'reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /f'
        )
    }
    [pscustomobject]@{
        Id = "xbox-capture-off"; Title = "Disable Xbox capture overhead"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 5; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "Game DVR", "Background")
        Summary = "Turns off Game DVR capture registry keys that can add overhead while playing."
        BackupKeys = @("HKCU\System\GameConfigStore", "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR")
        Commands = @(
            'reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 1 /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 1 /f'
        )
    }
    [pscustomobject]@{
        Id = "ultimate-performance"; Title = "Ultimate Performance power plan"; Tier = "Free"; Category = "Power"; Risk = "Medium"; Fps = 8; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Power", "CPU", "Desktop")
        Summary = "Creates and activates the Windows Ultimate Performance plan for less aggressive power saving."
        BackupKeys = @()
        Commands = @(
            'powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61',
            'powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61'
        )
        Rollback = @('powercfg -setactive SCHEME_BALANCED')
    }
    [pscustomobject]@{
        Id = "visual-effects-performance"; Title = "Performance visual effects profile"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("Registry", "Explorer", "UI")
        Summary = "Sets Windows visual effects to prioritize performance over animations."
        BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects")
        Commands = @('reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f')
        Rollback = @('reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 0 /f')
    }
    [pscustomobject]@{
        Id = "dns-network-refresh"; Title = "DNS and socket refresh"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 5; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Ping", "DNS", "Winsock")
        Summary = "Flushes DNS and rebuilds the local network stack when connection issues add latency."
        BackupKeys = @()
        Commands = @('ipconfig /flushdns', 'netsh winsock reset', 'netsh int ip reset')
        Rollback = @('# Rollback is a restart. Windows rebuilds the stack from defaults after the reset.')
    }
    [pscustomobject]@{
        Id = "network-throttling-games"; Title = "Gaming multimedia network priority"; Tier = "Free"; Category = "Network"; Risk = "Medium"; Fps = 1; Ping = 6; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "streaming")
        Tags = @("Registry", "Ping", "MMCSS")
        Summary = "Adjusts Windows multimedia scheduling keys used by low-latency gaming profiles."
        BackupKeys = @("HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile", "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games")
        Commands = @(
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 0xffffffff /f',
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v SystemResponsiveness /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f',
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v Priority /t REG_DWORD /d 6 /f',
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d High /f'
        )
        Rollback = @(
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 10 /f',
            'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v SystemResponsiveness /t REG_DWORD /d 20 /f'
        )
    }
    [pscustomobject]@{
        Id = "delivery-optimization-off"; Title = "Reduce update sharing traffic"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 3; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Windows Update", "Bandwidth", "Registry")
        Summary = "Limits Delivery Optimization peer traffic that can compete with games on weaker connections."
        BackupKeys = @("HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config")
        Commands = @('reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config" /v DODownloadMode /t REG_DWORD /d 0 /f')
        Rollback = @('reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config" /v DODownloadMode /f')
    }
    [pscustomobject]@{
        Id = "background-apps-off"; Title = "Background app limiter"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 3; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("Registry", "Background", "CPU")
        Summary = "Disables global background app access for a lean gaming session."
        BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications")
        Commands = @('reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f')
        Rollback = @('reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 0 /f')
    }
    [pscustomobject]@{
        Id = "nvidia-low-latency"; Title = "NVIDIA low latency checklist"; Tier = "Pro"; Category = "GPU"; Risk = "Low"; Fps = 4; Ping = 2; Restart = $false; Experimental = $false
        Vendors = @("nvidia"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("NVIDIA", "Latency", "Profile")
        Summary = "Opens the NVIDIA profile path and lists the per-game settings to test."
        BackupKeys = @()
        Commands = @(
            'Write-Output "NVIDIA: Open NVIDIA Control Panel > Manage 3D settings."',
            'Write-Output "Set Power management mode to Prefer maximum performance for your game."',
            'Write-Output "Set Low Latency Mode to On or Ultra after testing frame pacing."',
            'Start-Process "nvcplui.exe"'
        )
        Rollback = @('Write-Output "NVIDIA rollback: restore the game profile to global defaults."')
    }
    [pscustomobject]@{
        Id = "amd-antilag-profile"; Title = "AMD Anti-Lag profile"; Tier = "Pro"; Category = "GPU"; Risk = "Low"; Fps = 4; Ping = 2; Restart = $false; Experimental = $false
        Vendors = @("amd"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("AMD", "Latency", "Adrenalin")
        Summary = "Creates an AMD Adrenalin checklist for Anti-Lag, Enhanced Sync, and per-game tuning."
        BackupKeys = @()
        Commands = @(
            'Write-Output "AMD: Open AMD Software > Gaming > select your game."',
            'Write-Output "Enable Radeon Anti-Lag for competitive titles."',
            'Write-Output "Test Enhanced Sync per game and disable it if frame pacing gets unstable."'
        )
        Rollback = @('Write-Output "AMD rollback: reset the game profile in AMD Software."')
    }
    [pscustomobject]@{
        Id = "intel-arc-performance"; Title = "Intel graphics performance path"; Tier = "Pro"; Category = "GPU"; Risk = "Low"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("intel"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("Intel", "Arc", "Laptop")
        Summary = "Opens Windows graphics settings for assigning games to High performance."
        BackupKeys = @()
        Commands = @(
            'Write-Output "Intel: set the game to a performance profile in Intel Graphics Command Center."',
            'Start-Process "ms-settings:display-advancedgraphics"'
        )
        Rollback = @('Write-Output "Intel rollback: set the game back to Let Windows decide."')
    }
    [pscustomobject]@{
        Id = "tcp-ack-low-latency"; Title = "TCP ACK low-latency profile"; Tier = "Pro"; Category = "Network"; Risk = "High"; Fps = 0; Ping = 8; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports")
        Tags = @("Registry", "TCP", "Ping")
        Summary = "Applies TCPNoDelay and TcpAckFrequency to active adapters. Test only on stable connections."
        BackupKeys = @("HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces")
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $path = "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($adapter.InterfaceGuid)"',
            '  reg add $path /v TcpAckFrequency /t REG_DWORD /d 1 /f',
            '  reg add $path /v TCPNoDelay /t REG_DWORD /d 1 /f',
            '}'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $path = "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($adapter.InterfaceGuid)"',
            '  reg delete $path /v TcpAckFrequency /f',
            '  reg delete $path /v TCPNoDelay /f',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "dns-performance"; Title = "Fast DNS adapter profile"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 4; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("DNS", "Adapter", "Ping")
        Summary = "Sets active adapters to Cloudflare DNS and flushes the DNS cache."
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ServerAddresses ("1.1.1.1", "1.0.0.1")',
            '}',
            'ipconfig /flushdns'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ResetServerAddresses',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "fullscreen-game-profile"; Title = "Per-game fullscreen profile"; Tier = "Pro"; Category = "Windows"; Risk = "Medium"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("Registry", "Game EXE", "Latency")
        Summary = "Prompts for a game EXE and disables fullscreen optimizations for that game."
        BackupKeys = @("HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers")
        Commands = @(
            '$dialog = New-Object System.Windows.Forms.OpenFileDialog',
            '$dialog.Filter = "Executable (*.exe)|*.exe"',
            '$dialog.Title = "Choose the game executable"',
            'if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {',
            '  $gamePath = $dialog.FileName',
            '  reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v $gamePath /t REG_SZ /d "~ DISABLEDXMAXIMIZEDWINDOWEDMODE HIGHDPIAWARE" /f',
            '} else {',
            '  Write-Output "Skipped per-game fullscreen profile. No executable selected."',
            '}'
        )
        Rollback = @(
            '$dialog = New-Object System.Windows.Forms.OpenFileDialog',
            '$dialog.Filter = "Executable (*.exe)|*.exe"',
            '$dialog.Title = "Choose the game executable to rollback"',
            'if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {',
            '  $gamePath = $dialog.FileName',
            '  reg delete "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" /v $gamePath /f',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "service-trim-experimental"; Title = "Experimental service trim"; Tier = "Pro"; Category = "Windows"; Risk = "High"; Fps = 4; Ping = 1; Restart = $true; Experimental = $true
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop"); Games = @("esports")
        Tags = @("Experimental", "Services", "CPU")
        Summary = "Moves SysMain to Manual for test rigs with disk or CPU spikes. Avoid if caching helps your PC."
        BackupKeys = @()
        Commands = @('Set-Service -Name "SysMain" -StartupType Manual', 'Stop-Service -Name "SysMain" -ErrorAction SilentlyContinue')
        Rollback = @('Set-Service -Name "SysMain" -StartupType Automatic', 'Start-Service -Name "SysMain" -ErrorAction SilentlyContinue')
    }
    [pscustomobject]@{
        Id = "shader-cache-maintenance"; Title = "Shader cache maintenance"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("aaa", "streaming")
        Tags = @("Maintenance", "Stutter", "Storage")
        Summary = "Opens Windows storage settings for DirectX shader cache cleanup after driver changes."
        BackupKeys = @()
        Commands = @('Start-Process "ms-settings:storagesense"', 'Write-Output "Use Temporary files > DirectX Shader Cache after a GPU driver update if games stutter."')
        Rollback = @('Write-Output "No rollback needed. This profile only opens Windows settings."')
    }
    [pscustomobject]@{
        Id = "wifi-power-save-off"; Title = "Wi-Fi power save guard"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 5; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Wi-Fi", "Adapter", "Laptop")
        Summary = "Opens Device Manager so laptop users can disable Wi-Fi adapter power saving."
        BackupKeys = @()
        Commands = @(
            'Write-Output "Open Network adapters > your Wi-Fi adapter > Power Management."',
            'Write-Output "Uncheck Allow the computer to turn off this device to save power, then test battery impact."',
            'Start-Process "devmgmt.msc"'
        )
        Rollback = @('Write-Output "Re-enable the Wi-Fi adapter power saving checkbox if battery life drops too much."')
    }
    [pscustomobject]@{
        Id = "memory-standby-cleanup"; Title = "Standby memory cleanup routine"; Tier = "Pro"; Category = "Maintenance"; Risk = "Medium"; Fps = 4; Ping = 0; Restart = $false; Experimental = $true
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("aaa", "streaming")
        Tags = @("Experimental", "Memory", "Stutter")
        Summary = "Adds a safe reminder workflow for standby memory cleanup tools without downloading binaries."
        BackupKeys = @()
        Commands = @(
            'Write-Output "Standby memory cleanup requires a trusted tool such as Microsoft RAMMap."',
            'Write-Output "Do not run random memory cleaners. Test frame pacing before scheduling anything."'
        )
        Rollback = @('Write-Output "Remove any scheduled memory cleaner task you created during testing."')
    }
    [pscustomobject]@{
        Id = "transparency-effects-off"; Title = "Disable transparency effects"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "UI", "Low overhead")
        Summary = "Turns off Windows transparency effects to reduce small desktop composition overhead."
        BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
        Commands = @('reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f')
        Rollback = @('reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v EnableTransparency /t REG_DWORD /d 1 /f')
    }
    [pscustomobject]@{
        Id = "startup-delay-zero"; Title = "Remove startup app delay"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "Startup", "Responsiveness")
        Summary = "Removes the default Explorer startup delay so login feels snappier after a reboot."
        BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize")
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec /t REG_DWORD /d 0 /f'
        )
        Rollback = @('reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec /f')
    }
    [pscustomobject]@{
        Id = "mouse-accel-off"; Title = "Disable mouse acceleration"; Tier = "Free"; Category = "Input"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports")
        Tags = @("Registry", "Mouse", "Aim")
        Summary = "Disables Windows pointer acceleration for more consistent competitive aiming."
        BackupKeys = @("HKCU\Control Panel\Mouse")
        Commands = @(
            'reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f',
            'reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d 0 /f',
            'reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 1 /f',
            'reg add "HKCU\Control Panel\Mouse" /v MouseThreshold1 /t REG_SZ /d 6 /f',
            'reg add "HKCU\Control Panel\Mouse" /v MouseThreshold2 /t REG_SZ /d 10 /f'
        )
    }
    [pscustomobject]@{
        Id = "power-throttling-off"; Title = "Disable Windows power throttling"; Tier = "Free"; Category = "Power"; Risk = "Medium"; Fps = 5; Ping = 1; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "CPU", "Power")
        Summary = "Disables Windows power throttling policy for systems that need consistent CPU clocks."
        BackupKeys = @("HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling")
        Commands = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v PowerThrottlingOff /t REG_DWORD /d 1 /f'
        )
        Rollback = @('reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v PowerThrottlingOff /f')
    }
    [pscustomobject]@{
        Id = "pcie-link-state-off"; Title = "Disable PCIe link power saving"; Tier = "Free"; Category = "Power"; Risk = "Medium"; Fps = 4; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Power", "PCIe", "GPU")
        Summary = "Turns off PCI Express Link State Power Management for the current power plan."
        BackupKeys = @()
        Commands = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0',
            'powercfg -setdcvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 0',
            'powercfg -setactive SCHEME_CURRENT'
        )
        Rollback = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 1',
            'powercfg -setdcvalueindex SCHEME_CURRENT SUB_PCIEXPRESS ASPM 1',
            'powercfg -setactive SCHEME_CURRENT'
        )
    }
    [pscustomobject]@{
        Id = "usb-selective-suspend-off"; Title = "Disable USB selective suspend"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "streaming")
        Tags = @("USB", "Input", "Power")
        Summary = "Keeps USB devices awake to reduce input device wake delays on the current power plan."
        BackupKeys = @()
        Commands = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVE 0',
            'powercfg -setdcvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVE 0',
            'powercfg -setactive SCHEME_CURRENT'
        )
        Rollback = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVE 1',
            'powercfg -setdcvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVE 1',
            'powercfg -setactive SCHEME_CURRENT'
        )
    }
    [pscustomobject]@{
        Id = "edge-startupboost-off"; Title = "Disable Edge Startup Boost"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "Background", "Browser")
        Summary = "Stops Microsoft Edge from keeping startup boost background processes enabled by policy."
        BackupKeys = @("HKLM\SOFTWARE\Policies\Microsoft\Edge")
        Commands = @(
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @('reg delete "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /f')
    }
    [pscustomobject]@{
        Id = "widgets-news-off"; Title = "Disable Widgets and news feed"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Registry", "Background", "Shell")
        Summary = "Disables the Windows widgets/news surface through policy to reduce background shell noise."
        BackupKeys = @("HKLM\SOFTWARE\Policies\Microsoft\Dsh")
        Commands = @(
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /t REG_DWORD /d 0 /f'
        )
        Rollback = @('reg delete "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /f')
    }
    [pscustomobject]@{
        Id = "foreground-priority"; Title = "Foreground app CPU priority"; Tier = "Free"; Category = "Windows"; Risk = "Medium"; Fps = 3; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("Registry", "CPU", "Scheduler")
        Summary = "Adjusts the Windows priority separation value toward foreground application responsiveness."
        BackupKeys = @("HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl")
        Commands = @('reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 38 /f')
        Rollback = @('reg add "HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl" /v Win32PrioritySeparation /t REG_DWORD /d 2 /f')
    }
    [pscustomobject]@{
        Id = "network-rsc-off"; Title = "Disable receive segment coalescing"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 5; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "streaming")
        Tags = @("Adapter", "Ping", "RSC")
        Summary = "Disables RSC on active adapters when packet coalescing adds latency spikes."
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  Disable-NetAdapterRsc -Name $adapter.Name -ErrorAction SilentlyContinue',
            '}'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  Enable-NetAdapterRsc -Name $adapter.Name -ErrorAction SilentlyContinue',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "large-send-offload-off"; Title = "Disable Large Send Offload"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 5; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "streaming")
        Tags = @("Adapter", "LSO", "Ping")
        Summary = "Disables Large Send Offload on active adapters for users chasing lower latency."
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  Disable-NetAdapterLso -Name $adapter.Name -IPv4 -IPv6 -ErrorAction SilentlyContinue',
            '}'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  Enable-NetAdapterLso -Name $adapter.Name -IPv4 -IPv6 -ErrorAction SilentlyContinue',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "interrupt-moderation-off"; Title = "Disable adapter interrupt moderation"; Tier = "Pro"; Category = "Network"; Risk = "High"; Fps = 0; Ping = 7; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports")
        Tags = @("Adapter", "Interrupts", "Ping")
        Summary = "Attempts to disable Interrupt Moderation on active adapters that expose the setting."
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Interrupt Moderation" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Interrupt Moderation" -DisplayValue "Disabled" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Interrupt Moderation" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Interrupt Moderation" -DisplayValue "Enabled" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "tcp-ecn-timestamps-off"; Title = "TCP ECN and timestamps off"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 4; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports")
        Tags = @("TCP", "Ping", "netsh")
        Summary = "Disables ECN and TCP timestamps for users testing lower-latency TCP behavior."
        BackupKeys = @()
        Commands = @(
            'netsh int tcp set global ecncapability=disabled',
            'netsh int tcp set global timestamps=disabled'
        )
        Rollback = @(
            'netsh int tcp set global ecncapability=default',
            'netsh int tcp set global timestamps=default'
        )
    }
    [pscustomobject]@{
        Id = "xbox-services-manual"; Title = "Xbox service lean mode"; Tier = "Pro"; Category = "Services"; Risk = "Medium"; Fps = 2; Ping = 1; Restart = $true; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa")
        Tags = @("Services", "Xbox", "Background")
        Summary = "Moves Xbox services to Manual for systems that do not use Xbox app, Game Pass, or Xbox networking."
        BackupKeys = @()
        Commands = @(
            '$services = "XblAuthManager", "XblGameSave", "XboxNetApiSvc", "XboxGipSvc"',
            'foreach ($svc in $services) { Set-Service -Name $svc -StartupType Manual -ErrorAction SilentlyContinue }'
        )
        Rollback = @(
            '$services = "XblAuthManager", "XblGameSave", "XboxNetApiSvc", "XboxGipSvc"',
            'foreach ($svc in $services) { Set-Service -Name $svc -StartupType Manual -ErrorAction SilentlyContinue }'
        )
    }
    [pscustomobject]@{
        Id = "search-indexer-manual"; Title = "Windows Search indexer lean mode"; Tier = "Pro"; Category = "Services"; Risk = "Medium"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("aaa", "streaming")
        Tags = @("Services", "Disk", "Background")
        Summary = "Moves Windows Search indexing to Manual for systems where indexing causes disk or CPU spikes."
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "WSearch" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "WSearch" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "WSearch" -StartupType Automatic -ErrorAction SilentlyContinue',
            'Start-Service -Name "WSearch" -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "diagtrack-manual"; Title = "Diagnostics tracking lean mode"; Tier = "Pro"; Category = "Services"; Risk = "Medium"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Services", "Telemetry", "Background")
        Summary = "Moves the Connected User Experiences service to Manual for fewer background telemetry wakeups."
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "DiagTrack" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "DiagTrack" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "DiagTrack" -StartupType Automatic -ErrorAction SilentlyContinue',
            'Start-Service -Name "DiagTrack" -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "core-parking-performance"; Title = "CPU core parking performance mode"; Tier = "Pro"; Category = "Power"; Risk = "High"; Fps = 6; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Power", "CPU", "Advanced")
        Summary = "Sets the current power plan to keep more CPU cores unparked on AC power."
        BackupKeys = @()
        Commands = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 100',
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMAXCORES 100',
            'powercfg -setactive SCHEME_CURRENT'
        )
        Rollback = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 10',
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMAXCORES 100',
            'powercfg -setactive SCHEME_CURRENT'
        )
    }
    [pscustomobject]@{
        Id = "mpo-disable-test"; Title = "Disable MPO stutter test"; Tier = "Pro"; Category = "GPU"; Risk = "High"; Fps = 3; Ping = 0; Restart = $true; Experimental = $true
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("aaa", "streaming")
        Tags = @("Registry", "GPU", "Experimental")
        Summary = "Disables Multiplane Overlay as a test path for users chasing desktop or game stutter."
        BackupKeys = @("HKLM\SOFTWARE\Microsoft\Windows\Dwm")
        Commands = @('reg add "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /t REG_DWORD /d 5 /f')
        Rollback = @('reg delete "HKLM\SOFTWARE\Microsoft\Windows\Dwm" /v OverlayTestMode /f')
    }
    [pscustomobject]@{
        Id = "memory-compression-off"; Title = "Memory compression off test"; Tier = "Pro"; Category = "Memory"; Risk = "High"; Fps = 3; Ping = 0; Restart = $true; Experimental = $true
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop"); Games = @("aaa", "streaming")
        Tags = @("Memory", "Experimental", "Stutter")
        Summary = "Disables Windows memory compression for test rigs with plenty of RAM and compression-related stutter."
        BackupKeys = @()
        Commands = @('Disable-MMAgent -MemoryCompression')
        Rollback = @('Enable-MMAgent -MemoryCompression')
    }
    [pscustomobject]@{
        Id = "dynamic-tick-off"; Title = "Disable dynamic tick test"; Tier = "Pro"; Category = "Boot"; Risk = "High"; Fps = 2; Ping = 1; Restart = $true; Experimental = $true
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports")
        Tags = @("BCD", "Timer", "Experimental")
        Summary = "Uses BCDEdit to disable dynamic tick for users testing input latency and timer behavior."
        BackupKeys = @()
        Commands = @('bcdedit /set disabledynamictick yes')
        Rollback = @('bcdedit /deletevalue disabledynamictick')
    }
    [pscustomobject]@{
        Id = "gamebar-hard-off"; Title = "Full Xbox Game Bar disable"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 3; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Game Bar', 'Background')
        Summary = 'Disables Game Bar launch paths and Game DVR policy for users that do not use the overlay.'
        BackupKeys = @('HKCU\Software\Microsoft\GameBar', 'HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\GameBar" /v UseNexusForGameBarEnabled /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\GameBar" /v ShowStartupPanel /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v AllowGameDVR /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Software\Microsoft\GameBar" /v UseNexusForGameBarEnabled /t REG_DWORD /d 1 /f',
            'reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v AllowGameDVR /f'
        )
    }
    [pscustomobject]@{
        Id = "content-suggestions-off"; Title = "Disable Windows suggestions and ads"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Suggestions', 'Shell')
        Summary = 'Turns off common ContentDeliveryManager suggestion keys that create background shell noise.'
        BackupKeys = @('HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338388Enabled /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338389Enabled /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SystemPaneSuggestionsEnabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338388Enabled /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338389Enabled /f',
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SystemPaneSuggestionsEnabled /f'
        )
    }
    [pscustomobject]@{
        Id = "advertising-id-off"; Title = "Disable advertising ID"; Tier = "Free"; Category = "Privacy"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Privacy', 'Background')
        Summary = 'Disables Windows advertising ID for the current user.'
        BackupKeys = @('HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v Enabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo" /v Enabled /t REG_DWORD /d 1 /f'
        )
    }
    [pscustomobject]@{
        Id = "tailored-experiences-off"; Title = "Disable tailored experiences"; Tier = "Free"; Category = "Privacy"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Privacy', 'Telemetry')
        Summary = 'Turns off Tailored Experiences with diagnostic data for a cleaner local profile.'
        BackupKeys = @('HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy" /v TailoredExperiencesWithDiagnosticDataEnabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy" /v TailoredExperiencesWithDiagnosticDataEnabled /t REG_DWORD /d 1 /f'
        )
    }
    [pscustomobject]@{
        Id = "activity-history-off"; Title = "Disable activity history upload"; Tier = "Free"; Category = "Privacy"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Privacy', 'Background')
        Summary = 'Disables Windows activity feed and activity upload policy.'
        BackupKeys = @('HKLM\SOFTWARE\Policies\Microsoft\Windows\System')
        Commands = @(
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableActivityFeed /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v PublishUserActivities /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v UploadUserActivities /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableActivityFeed /f',
            'reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v PublishUserActivities /f',
            'reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v UploadUserActivities /f'
        )
    }
    [pscustomobject]@{
        Id = "feedback-frequency-off"; Title = "Disable feedback prompts"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Telemetry', 'Shell')
        Summary = 'Stops Windows feedback prompt frequency for fewer interruptions.'
        BackupKeys = @('HKCU\Software\Microsoft\Siuf\Rules')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Siuf\Rules" /v NumberOfSIUFInPeriod /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\Siuf\Rules" /v PeriodInNanoSeconds /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg delete "HKCU\Software\Microsoft\Siuf\Rules" /v NumberOfSIUFInPeriod /f',
            'reg delete "HKCU\Software\Microsoft\Siuf\Rules" /v PeriodInNanoSeconds /f'
        )
    }
    [pscustomobject]@{
        Id = "clipboard-cloud-sync-off"; Title = "Disable clipboard cloud sync"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Clipboard', 'Cloud')
        Summary = 'Disables clipboard history sync across devices while leaving local clipboard behavior intact.'
        BackupKeys = @('HKCU\Software\Microsoft\Clipboard')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Clipboard" /v EnableClipboardHistory /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\Clipboard" /v CloudClipboardAutomaticUpload /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg delete "HKCU\Software\Microsoft\Clipboard" /v EnableClipboardHistory /f',
            'reg delete "HKCU\Software\Microsoft\Clipboard" /v CloudClipboardAutomaticUpload /f'
        )
    }
    [pscustomobject]@{
        Id = "recent-items-off"; Title = "Disable recent files tracking"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Explorer', 'Privacy')
        Summary = 'Turns off recent files and frequent places tracking in Explorer and jump lists.'
        BackupKeys = @('HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v Start_TrackDocs /t REG_DWORD /d 0 /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v Start_TrackProgs /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v Start_TrackDocs /t REG_DWORD /d 1 /f',
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v Start_TrackProgs /t REG_DWORD /d 1 /f'
        )
    }
    [pscustomobject]@{
        Id = "copilot-button-off"; Title = "Disable Copilot shell button"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Shell', 'Copilot')
        Summary = 'Hides/disables the Copilot shell entry points through policy when supported.'
        BackupKeys = @('HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot')
        Commands = @(
            'reg add "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /f',
            'reg add "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f'
        )
        Rollback = @(
            'reg delete "HKCU\Software\Policies\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /f'
        )
    }
    [pscustomobject]@{
        Id = "teams-chat-autoinstall-off"; Title = "Disable consumer Teams auto install"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Startup', 'Teams')
        Summary = 'Prevents the consumer Chat/Teams auto install policy on Windows 11 style systems.'
        BackupKeys = @('HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Communications')
        Commands = @(
            'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Communications" /f',
            'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Communications" /v ConfigureChatAutoInstall /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Communications" /v ConfigureChatAutoInstall /f'
        )
    }
    [pscustomobject]@{
        Id = "taskbar-chat-hide"; Title = "Hide taskbar chat button"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Taskbar', 'Shell')
        Summary = 'Hides the Windows chat button where the TaskbarMn value is supported.'
        BackupKeys = @('HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarMn /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarMn /t REG_DWORD /d 1 /f'
        )
    }
    [pscustomobject]@{
        Id = "notifications-game-session"; Title = "Quiet notification game session"; Tier = "Pro"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Notifications', 'Focus', 'Gaming')
        Summary = 'Opens Focus Assist and notification settings so users can set a no-interruption gaming mode.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:quiethours"',
            'Start-Process "ms-settings:notifications"',
            'Write-Output "Set Focus/Do Not Disturb for gaming sessions and disable app notifications that interrupt competitive games."'
        )
        Rollback = @(
            'Start-Process "ms-settings:quiethours"',
            'Start-Process "ms-settings:notifications"'
        )
    }
    [pscustomobject]@{
        Id = "onedrive-startup-off"; Title = "Disable OneDrive startup"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Startup', 'OneDrive', 'Background')
        Summary = 'Removes the current user''s OneDrive auto-start entry without uninstalling OneDrive.'
        BackupKeys = @('HKCU\Software\Microsoft\Windows\CurrentVersion\Run')
        Commands = @(
            'reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v OneDrive /f'
        )
        Rollback = @(
            'Write-Output "Rollback: open OneDrive Settings > Sync and backup > Start OneDrive when I sign in, or reinstall/repair OneDrive if needed."'
        )
    }
    [pscustomobject]@{
        Id = "edge-background-mode-off"; Title = "Disable Edge background mode"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Edge', 'Background')
        Summary = 'Turns off Edge background mode and startup boost policy.'
        BackupKeys = @('HKLM\SOFTWARE\Policies\Microsoft\Edge')
        Commands = @(
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BackgroundModeEnabled /t REG_DWORD /d 0 /f',
            'reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg delete "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v BackgroundModeEnabled /f',
            'reg delete "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v StartupBoostEnabled /f'
        )
    }
    [pscustomobject]@{
        Id = "chrome-background-mode-note"; Title = "Chrome background mode guard"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Chrome', 'Background', 'Checklist')
        Summary = 'Opens Chrome settings and explains the background apps switch instead of editing profile files blindly.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "chrome.exe" "chrome://settings/system"',
            'Write-Output "Chrome: turn off Continue running background apps when Google Chrome is closed."'
        )
        Rollback = @(
            'Start-Process "chrome.exe" "chrome://settings/system"'
        )
    }
    [pscustomobject]@{
        Id = "discord-startup-off-note"; Title = "Discord startup guard"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Discord', 'Startup', 'Checklist')
        Summary = 'Opens Startup Apps so Discord and other launchers can be disabled without editing app configs.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:startupapps"',
            'Write-Output "Disable Discord, launchers, RGB apps, and overlays you do not need at boot."'
        )
        Rollback = @(
            'Start-Process "ms-settings:startupapps"'
        )
    }
    [pscustomobject]@{
        Id = "startup-folder-open"; Title = "Audit Startup folder"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Startup', 'Explorer', 'Audit')
        Summary = 'Opens both user and common Startup folders for manual cleanup.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "shell:startup"',
            'Start-Process "shell:common startup"'
        )
        Rollback = @(
            'Start-Process "shell:startup"',
            'Start-Process "shell:common startup"'
        )
    }
    [pscustomobject]@{
        Id = "maps-service-manual"; Title = "Downloaded Maps service manual"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'Maps', 'Background')
        Summary = 'Moves the maps broker service to Manual for PCs that do not use offline maps.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "MapsBroker" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "MapsBroker" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "MapsBroker" -StartupType Automatic -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "retail-demo-service-manual"; Title = "Retail demo service manual"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'RetailDemo', 'Background')
        Summary = 'Moves RetailDemo service to Manual when present.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "RetailDemo" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "RetailDemo" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "RetailDemo" -StartupType Manual -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "wer-service-manual"; Title = "Windows Error Reporting lean mode"; Tier = "Pro"; Category = "Services"; Risk = "Medium"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'WER', 'Background')
        Summary = 'Moves Windows Error Reporting service to Manual for users who do not want background error reporting during games.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "WerSvc" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "WerSvc" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "WerSvc" -StartupType Manual -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "insider-service-manual"; Title = "Windows Insider service manual"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'Insider', 'Background')
        Summary = 'Moves Windows Insider service to Manual when present.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "wisvc" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "wisvc" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "wisvc" -StartupType Manual -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "touch-keyboard-desktop-manual"; Title = "Touch keyboard desktop lean mode"; Tier = "Pro"; Category = "Services"; Risk = "Medium"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'Tablet', 'Background')
        Summary = 'Moves touch keyboard handwriting service to Manual on desktops that do not use touch input.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "TabletInputService" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "TabletInputService" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "TabletInputService" -StartupType Manual -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "remote-registry-disabled"; Title = "Disable Remote Registry service"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'Security', 'Background')
        Summary = 'Ensures Remote Registry is disabled on gaming PCs.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "RemoteRegistry" -StartupType Disabled -ErrorAction SilentlyContinue',
            'Stop-Service -Name "RemoteRegistry" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "RemoteRegistry" -StartupType Manual -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "print-spooler-manual-if-no-printer"; Title = "Printer service lean mode"; Tier = "Pro"; Category = "Services"; Risk = "High"; Fps = 1; Ping = 0; Restart = $false; Experimental = $true
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'Printer', 'Experimental')
        Summary = 'Moves Print Spooler to Manual only for PCs that never print. Do not use if you print or use PDF printer workflows.'
        BackupKeys = @()
        Commands = @(
            'Set-Service -Name "Spooler" -StartupType Manual -ErrorAction SilentlyContinue',
            'Stop-Service -Name "Spooler" -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Set-Service -Name "Spooler" -StartupType Automatic -ErrorAction SilentlyContinue',
            'Start-Service -Name "Spooler" -ErrorAction SilentlyContinue'
        )
    }
    [pscustomobject]@{
        Id = "bluetooth-services-audit"; Title = "Bluetooth service audit"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Services', 'Bluetooth', 'Audit')
        Summary = 'Reports Bluetooth service state so users do not accidentally disable Bluetooth mice/headsets.'
        BackupKeys = @()
        Commands = @(
            'Get-Service -Name "bthserv" -ErrorAction SilentlyContinue | Format-List Name,Status,StartType',
            'Write-Output "Do not disable Bluetooth if you use Bluetooth audio, controllers, mouse, or keyboard."'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "balanced-restore-safe"; Title = "Restore Windows Balanced plan"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'Rollback', 'Safety')
        Summary = 'Switches back to the default Balanced scheme for quick rollback testing.'
        BackupKeys = @()
        Commands = @(
            'powercfg -setactive SCHEME_BALANCED'
        )
        Rollback = @(
            'powercfg -setactive SCHEME_BALANCED'
        )
    }
    [pscustomobject]@{
        Id = "high-performance-plan"; Title = "High Performance power plan"; Tier = "Free"; Category = "Power"; Risk = "Medium"; Fps = 5; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'CPU', 'Desktop')
        Summary = 'Activates the standard High Performance plan if available.'
        BackupKeys = @()
        Commands = @(
            'powercfg -setactive SCHEME_MIN'
        )
        Rollback = @(
            'powercfg -setactive SCHEME_BALANCED'
        )
    }
    [pscustomobject]@{
        Id = "disable-fast-startup"; Title = "Disable Fast Startup"; Tier = "Free"; Category = "Power"; Risk = "Medium"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Boot', 'Driver')
        Summary = 'Disables Fast Startup to help driver and device state reset cleanly after shutdown.'
        BackupKeys = @('HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power')
        Commands = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 0 /f'
        )
        Rollback = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power" /v HiberbootEnabled /t REG_DWORD /d 1 /f'
        )
    }
    [pscustomobject]@{
        Id = "disable-hibernation"; Title = "Disable hibernation file"; Tier = "Pro"; Category = "Power"; Risk = "Medium"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'Storage', 'Boot')
        Summary = 'Turns off hibernation to free disk space and disable hiberfile-based startup behavior.'
        BackupKeys = @()
        Commands = @(
            'powercfg /hibernate off'
        )
        Rollback = @(
            'powercfg /hibernate on'
        )
    }
    [pscustomobject]@{
        Id = "active-cooling-ac"; Title = "Active cooling on AC power"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'Cooling', 'Laptop')
        Summary = 'Sets system cooling policy to Active on AC power where supported.'
        BackupKeys = @()
        Commands = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR SYSCOOLPOL 1',
            'powercfg -setactive SCHEME_CURRENT'
        )
        Rollback = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR SYSCOOLPOL 0',
            'powercfg -setactive SCHEME_CURRENT'
        )
    }
    [pscustomobject]@{
        Id = "disk-sleep-never-ac"; Title = "Disable disk sleep on AC"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'Storage', 'Stutter')
        Summary = 'Stops drives from sleeping while plugged in to reduce wake stutter.'
        BackupKeys = @()
        Commands = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_DISK DISKIDLE 0',
            'powercfg -setactive SCHEME_CURRENT'
        )
        Rollback = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_DISK DISKIDLE 1200',
            'powercfg -setactive SCHEME_CURRENT'
        )
    }
    [pscustomobject]@{
        Id = "display-sleep-guard-ac"; Title = "No display sleep while gaming"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'Display', 'Gaming')
        Summary = 'Prevents monitor sleep while plugged in during long gaming sessions.'
        BackupKeys = @()
        Commands = @(
            'powercfg -change -monitor-timeout-ac 0'
        )
        Rollback = @(
            'powercfg -change -monitor-timeout-ac 15'
        )
    }
    [pscustomobject]@{
        Id = "sleep-guard-ac"; Title = "No PC sleep while gaming"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'Sleep', 'Gaming')
        Summary = 'Prevents the PC from sleeping while plugged in during gaming.'
        BackupKeys = @()
        Commands = @(
            'powercfg -change -standby-timeout-ac 0'
        )
        Rollback = @(
            'powercfg -change -standby-timeout-ac 30'
        )
    }
    [pscustomobject]@{
        Id = "processor-boost-mode-open"; Title = "Processor boost mode guide"; Tier = "Pro"; Category = "Power"; Risk = "Medium"; Fps = 4; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'CPU', 'Thermals')
        Summary = 'Shows hidden processor settings and opens power plan controls for boost-mode testing.'
        BackupKeys = @()
        Commands = @(
            'powercfg -attributes SUB_PROCESSOR PERFBOOSTMODE -ATTRIB_HIDE',
            'Start-Process "control.exe" "powercfg.cpl"',
            'Write-Output "Test boost mode carefully: aggressive boost can improve FPS but raise heat on laptops."'
        )
        Rollback = @(
            'powercfg -attributes SUB_PROCESSOR PERFBOOSTMODE +ATTRIB_HIDE'
        )
    }
    [pscustomobject]@{
        Id = "cpu-min-ac-100-desktop"; Title = "Desktop CPU minimum state 100%"; Tier = "Pro"; Category = "Power"; Risk = "High"; Fps = 5; Ping = 1; Restart = $false; Experimental = $true
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Power', 'CPU', 'Experimental')
        Summary = 'Sets processor minimum state to 100% on AC for desktop test rigs chasing consistent clocks.'
        BackupKeys = @()
        Commands = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 100',
            'powercfg -setactive SCHEME_CURRENT'
        )
        Rollback = @(
            'powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 5',
            'powercfg -setactive SCHEME_CURRENT'
        )
    }
    [pscustomobject]@{
        Id = "keyboard-repeat-fast"; Title = "Fast keyboard repeat profile"; Tier = "Free"; Category = "Input"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Keyboard', 'Input')
        Summary = 'Sets a fast repeat delay/rate profile for keyboard-heavy games and desktop use.'
        BackupKeys = @('HKCU\Control Panel\Keyboard')
        Commands = @(
            'reg add "HKCU\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d 0 /f',
            'reg add "HKCU\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d 31 /f'
        )
        Rollback = @(
            'reg add "HKCU\Control Panel\Keyboard" /v KeyboardDelay /t REG_SZ /d 1 /f',
            'reg add "HKCU\Control Panel\Keyboard" /v KeyboardSpeed /t REG_SZ /d 31 /f'
        )
    }
    [pscustomobject]@{
        Id = "mouse-speed-default"; Title = "Mouse speed clean baseline"; Tier = "Free"; Category = "Input"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Mouse', 'Input')
        Summary = 'Sets Windows pointer speed to the clean 6/11 baseline without acceleration.'
        BackupKeys = @('HKCU\Control Panel\Mouse')
        Commands = @(
            'reg add "HKCU\Control Panel\Mouse" /v MouseSensitivity /t REG_SZ /d 10 /f',
            'reg add "HKCU\Control Panel\Mouse" /v MouseSpeed /t REG_SZ /d 0 /f'
        )
        Rollback = @(
            'reg add "HKCU\Control Panel\Mouse" /v MouseSensitivity /t REG_SZ /d 10 /f'
        )
    }
    [pscustomobject]@{
        Id = "game-process-high-priority-prompt"; Title = "Set running game to High priority"; Tier = "Pro"; Category = "Input"; Risk = "Medium"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Process', 'Priority', 'Latency')
        Summary = 'Prompts for a running process name and sets it to High priority for the current session.'
        BackupKeys = @()
        Commands = @(
            '$gameProcess = Read-Host "Enter running process name without .exe"',
            'Get-Process -Name $gameProcess -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "High"; Write-Output "Set $($_.ProcessName) to High priority." }'
        )
        Rollback = @(
            '$gameProcess = Read-Host "Enter running process name without .exe"',
            'Get-Process -Name $gameProcess -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "Normal" }'
        )
    }
    [pscustomobject]@{
        Id = "fortnite-high-priority-session"; Title = "Fortnite High priority session"; Tier = "Pro"; Category = "Input"; Risk = "Medium"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Fortnite', 'Priority', 'Latency')
        Summary = 'Sets Fortnite''s running shipping process to High priority for the current session.'
        BackupKeys = @()
        Commands = @(
            'Get-Process -Name "FortniteClient-Win64-Shipping" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "High"; Write-Output "Fortnite process priority set to High for this session." }'
        )
        Rollback = @(
            'Get-Process -Name "FortniteClient-Win64-Shipping" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "Normal" }'
        )
    }
    [pscustomobject]@{
        Id = "valorant-high-priority-session"; Title = "VALORANT High priority session"; Tier = "Pro"; Category = "Input"; Risk = "Medium"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('VALORANT', 'Priority', 'Latency')
        Summary = 'Sets VALORANT''s running process to High priority for the current session.'
        BackupKeys = @()
        Commands = @(
            'Get-Process -Name "VALORANT-Win64-Shipping" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "High"; Write-Output "VALORANT process priority set to High for this session." }'
        )
        Rollback = @(
            'Get-Process -Name "VALORANT-Win64-Shipping" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "Normal" }'
        )
    }
    [pscustomobject]@{
        Id = "siege-high-priority-session"; Title = "Rainbow Six Siege High priority session"; Tier = "Pro"; Category = "Input"; Risk = "Medium"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Rainbow Six', 'Priority', 'Latency')
        Summary = 'Sets Rainbow Six Siege''s running process to High priority for the current session.'
        BackupKeys = @()
        Commands = @(
            'Get-Process -Name "RainbowSix" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "High"; Write-Output "Rainbow Six process priority set to High for this session." }',
            'Get-Process -Name "RainbowSix_BE" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "High"; Write-Output "Rainbow Six BE process priority set to High for this session." }'
        )
        Rollback = @(
            'Get-Process -Name "RainbowSix","RainbowSix_BE" -ErrorAction SilentlyContinue | ForEach-Object { $_.PriorityClass = "Normal" }'
        )
    }
    [pscustomobject]@{
        Id = "windows-graphics-settings-open"; Title = "Windows graphics preference picker"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('GPU', 'Graphics', 'Settings')
        Summary = 'Opens Windows per-app graphics settings so games can be assigned to the high-performance GPU.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:display-advancedgraphics"',
            'Write-Output "Add each game .exe and choose High performance GPU, especially on hybrid laptops."'
        )
        Rollback = @(
            'Start-Process "ms-settings:display-advancedgraphics"'
        )
    }
    [pscustomobject]@{
        Id = "vrr-settings-open"; Title = "Variable refresh rate settings"; Tier = "Free"; Category = "Display"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('GPU', 'Display', 'VRR')
        Summary = 'Opens Graphics settings to check variable refresh and windowed game optimizations.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:display-advancedgraphics"',
            'Write-Output "Check variable refresh rate and windowed game optimization options. Test per game."'
        )
        Rollback = @(
            'Start-Process "ms-settings:display-advancedgraphics"'
        )
    }
    [pscustomobject]@{
        Id = "advanced-display-open"; Title = "Advanced display refresh-rate check"; Tier = "Free"; Category = "Display"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Display', 'Refresh Rate', 'Monitor')
        Summary = 'Opens advanced display settings so the monitor refresh rate is not stuck at 60 Hz.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:display-advanced"',
            'Write-Output "Confirm your monitor is set to its highest stable refresh rate."'
        )
        Rollback = @(
            'Start-Process "ms-settings:display-advanced"'
        )
    }
    [pscustomobject]@{
        Id = "hdr-game-check"; Title = "HDR gaming check"; Tier = "Free"; Category = "Display"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Display', 'HDR', 'Latency')
        Summary = 'Opens HDR settings so users can disable HDR when it causes weird color, capture, or latency behavior.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:display-advancedgraphics"',
            'Start-Process "ms-settings:display"'
        )
        Rollback = @(
            'Start-Process "ms-settings:display"'
        )
    }
    [pscustomobject]@{
        Id = "nvidia-cache-clean"; Title = "NVIDIA shader cache cleanup"; Tier = "Pro"; Category = "Maintenance"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('NVIDIA', 'Shader', 'Cache')
        Summary = 'Clears common NVIDIA shader cache folders for troubleshooting stutter after driver changes.'
        BackupKeys = @()
        Commands = @(
            '$paths = @("$env:LOCALAPPDATA\NVIDIA\DXCache", "$env:LOCALAPPDATA\NVIDIA\GLCache", "$env:ProgramData\NVIDIA Corporation\NV_Cache")',
            'foreach ($p in $paths) { if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Output "Cleared $p" } }'
        )
        Rollback = @(
            'Write-Output "No rollback needed. Shader caches rebuild automatically."'
        )
    }
    [pscustomobject]@{
        Id = "amd-cache-clean"; Title = "AMD shader cache cleanup"; Tier = "Pro"; Category = "Maintenance"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('amd'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('AMD', 'Shader', 'Cache')
        Summary = 'Clears common AMD shader cache folders for troubleshooting stutter after driver changes.'
        BackupKeys = @()
        Commands = @(
            '$paths = @("$env:LOCALAPPDATA\AMD\DxCache", "$env:LOCALAPPDATA\AMD\DxcCache", "$env:LOCALAPPDATA\AMD\GLCache")',
            'foreach ($p in $paths) { if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Output "Cleared $p" } }'
        )
        Rollback = @(
            'Write-Output "No rollback needed. Shader caches rebuild automatically."'
        )
    }
    [pscustomobject]@{
        Id = "intel-cache-clean"; Title = "Intel graphics cache cleanup"; Tier = "Pro"; Category = "Maintenance"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('intel'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Intel', 'Shader', 'Cache')
        Summary = 'Clears common Intel graphics cache folders for troubleshooting stutter after driver changes.'
        BackupKeys = @()
        Commands = @(
            '$paths = @("$env:LOCALAPPDATA\Intel\ShaderCache", "$env:LOCALAPPDATA\Intel\D3DSCache")',
            'foreach ($p in $paths) { if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Output "Cleared $p" } }'
        )
        Rollback = @(
            'Write-Output "No rollback needed. Shader caches rebuild automatically."'
        )
    }
    [pscustomobject]@{
        Id = "directx-cache-clean"; Title = "DirectX shader cache cleanup"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('DirectX', 'Shader', 'Cache')
        Summary = 'Clears the user DirectX shader cache folder for post-update stutter troubleshooting.'
        BackupKeys = @()
        Commands = @(
            '$p = "$env:LOCALAPPDATA\D3DSCache"',
            'if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Output "Cleared $p" }'
        )
        Rollback = @(
            'Write-Output "No rollback needed. DirectX shader caches rebuild automatically."'
        )
    }
    [pscustomobject]@{
        Id = "gpu-scheduling-settings-open"; Title = "GPU scheduling settings"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('GPU', 'HAGS', 'Settings')
        Summary = 'Opens the Windows graphics defaults page so HAGS and graphics defaults can be checked visually.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:display-advancedgraphics"',
            'Write-Output "Check Hardware-accelerated GPU scheduling and restart after changing it."'
        )
        Rollback = @(
            'Start-Process "ms-settings:display-advancedgraphics"'
        )
    }
    [pscustomobject]@{
        Id = "nvidia-control-panel-open"; Title = "Open NVIDIA Control Panel"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('NVIDIA', 'Control Panel', 'GPU')
        Summary = 'Opens NVIDIA Control Panel when installed for manual low-latency profile review.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "nvcplui.exe" -ErrorAction SilentlyContinue',
            'Write-Output "If NVIDIA Control Panel does not open, install it from Microsoft Store or NVIDIA App."'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "amd-adrenalin-open"; Title = "Open AMD Adrenalin"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('amd'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('AMD', 'Adrenalin', 'GPU')
        Summary = 'Opens AMD Software when installed for Anti-Lag, Chill, and per-game profile review.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "amdsoftware.exe" -ErrorAction SilentlyContinue',
            'Write-Output "If AMD Software does not open, install the official Adrenalin package for your GPU."'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "intel-graphics-open"; Title = "Open Intel Graphics Command Center"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('intel'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Intel', 'Graphics', 'GPU')
        Summary = 'Opens Intel Graphics Command Center when installed for display and performance profile review.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "igcc.exe" -ErrorAction SilentlyContinue',
            'Write-Output "If Intel Graphics Command Center does not open, use Intel Driver & Support Assistant or Microsoft Store."'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "network-rss-enable"; Title = "Enable network Receive Side Scaling"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 3; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'RSS', 'Adapter')
        Summary = 'Enables Receive Side Scaling on active adapters when supported.'
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Enable-NetAdapterRss -Name $adapter.Name -ErrorAction SilentlyContinue }'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Disable-NetAdapterRss -Name $adapter.Name -ErrorAction SilentlyContinue }'
        )
    }
    [pscustomobject]@{
        Id = "tcp-autotuning-normal"; Title = "TCP auto-tuning normal"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 2; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('TCP', 'Network', 'Ping')
        Summary = 'Restores TCP receive window auto-tuning to normal for stable throughput and latency.'
        BackupKeys = @()
        Commands = @(
            'netsh int tcp set global autotuninglevel=normal'
        )
        Rollback = @(
            'netsh int tcp set global autotuninglevel=normal'
        )
    }
    [pscustomobject]@{
        Id = "tcp-global-template-clean"; Title = "TCP global clean baseline"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 3; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('TCP', 'Network', 'Baseline')
        Summary = 'Sets a conservative TCP global baseline before testing game latency.'
        BackupKeys = @()
        Commands = @(
            'netsh int tcp set global autotuninglevel=normal',
            'netsh int tcp set global ecncapability=disabled',
            'netsh int tcp set global timestamps=disabled',
            'netsh int tcp set supplemental template=internet congestionprovider=ctcp'
        )
        Rollback = @(
            'netsh int tcp set global autotuninglevel=normal',
            'netsh int tcp set global ecncapability=default',
            'netsh int tcp set global timestamps=default'
        )
    }
    [pscustomobject]@{
        Id = "arp-cache-flush"; Title = "Flush ARP neighbor cache"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'ARP', 'Ping')
        Summary = 'Flushes the local ARP/neighbor cache for quick network troubleshooting.'
        BackupKeys = @()
        Commands = @(
            'arp -d *'
        )
        Rollback = @(
            'Write-Output "No rollback needed. ARP entries rebuild automatically."'
        )
    }
    [pscustomobject]@{
        Id = "network-release-renew"; Title = "IP release and renew"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 2; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'DHCP', 'Repair')
        Summary = 'Releases and renews IPv4 addresses for troubleshooting bad DHCP/network states. This will briefly disconnect you.'
        BackupKeys = @()
        Commands = @(
            'ipconfig /release',
            'ipconfig /renew',
            'ipconfig /flushdns'
        )
        Rollback = @(
            'ipconfig /renew'
        )
    }
    [pscustomobject]@{
        Id = "dns-google"; Title = "Google DNS adapter profile"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 3; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('DNS', 'Adapter', 'Ping')
        Summary = 'Sets active adapters to Google DNS for users testing DNS response against their ISP.'
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ServerAddresses ("8.8.8.8", "8.8.4.4") }',
            'ipconfig /flushdns'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ResetServerAddresses }'
        )
    }
    [pscustomobject]@{
        Id = "dns-quad9"; Title = "Quad9 DNS adapter profile"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 3; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('DNS', 'Adapter', 'Security')
        Summary = 'Sets active adapters to Quad9 DNS for users testing resolver performance and filtering.'
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ServerAddresses ("9.9.9.9", "149.112.112.112") }',
            'ipconfig /flushdns'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ResetServerAddresses }'
        )
    }
    [pscustomobject]@{
        Id = "dns-auto"; Title = "Reset DNS to automatic"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('DNS', 'Adapter', 'Rollback')
        Summary = 'Resets active adapters to automatic DNS from the router/ISP.'
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) { Set-DnsClientServerAddress -InterfaceIndex $adapter.InterfaceIndex -ResetServerAddresses }',
            'ipconfig /flushdns'
        )
        Rollback = @(
            'Write-Output "DNS is already set to automatic."'
        )
    }
    [pscustomobject]@{
        Id = "energy-efficient-ethernet-off"; Title = "Disable Energy Efficient Ethernet"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 4; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'Ethernet', 'Adapter')
        Summary = 'Disables Energy Efficient Ethernet on adapters that expose the setting.'
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Energy Efficient Ethernet" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Energy Efficient Ethernet" -DisplayValue "Disabled" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Energy Efficient Ethernet" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Energy Efficient Ethernet" -DisplayValue "Enabled" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "green-ethernet-off"; Title = "Disable Green Ethernet"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 4; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'Ethernet', 'Adapter')
        Summary = 'Disables Green Ethernet on adapters that expose the setting.'
        BackupKeys = @()
        Commands = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Green Ethernet" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Green Ethernet" -DisplayValue "Disabled" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
        Rollback = @(
            '$activeAdapters = Get-NetAdapter | Where-Object { $_.Status -eq "Up" }',
            'foreach ($adapter in $activeAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Green Ethernet" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Green Ethernet" -DisplayValue "Enabled" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
    }
    [pscustomobject]@{
        Id = "wifi-5ghz-preferred"; Title = "Prefer 5GHz Wi-Fi band"; Tier = "Pro"; Category = "Network"; Risk = "Medium"; Fps = 0; Ping = 4; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Wi-Fi', 'Adapter', 'Ping')
        Summary = 'Sets Preferred Band to 5GHz on Wi-Fi adapters that expose the option.'
        BackupKeys = @()
        Commands = @(
            '$wifiAdapters = Get-NetAdapter | Where-Object { $_.InterfaceDescription -match "Wi-Fi|Wireless|802.11" }',
            'foreach ($adapter in $wifiAdapters) {',
            '  $prop = Get-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Preferred Band" -ErrorAction SilentlyContinue',
            '  if ($prop) { Set-NetAdapterAdvancedProperty -Name $adapter.Name -DisplayName "Preferred Band" -DisplayValue "Prefer 5GHz band" -NoRestart -ErrorAction SilentlyContinue }',
            '}'
        )
        Rollback = @(
            'Write-Output "Rollback: open Device Manager > Wi-Fi adapter > Advanced > Preferred Band and set the old value."'
        )
    }
    [pscustomobject]@{
        Id = "network-metered-off"; Title = "Disable metered connection flag"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'Windows Update', 'Bandwidth')
        Summary = 'Opens network settings so the current connection can be checked for metered mode.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:network-status"',
            'Write-Output "Make sure your active gaming connection is not incorrectly set as metered unless you need it."'
        )
        Rollback = @(
            'Start-Process "ms-settings:network-status"'
        )
    }
    [pscustomobject]@{
        Id = "adapter-options-open"; Title = "Open adapter options"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'Adapter', 'Settings')
        Summary = 'Opens classic network adapter settings for manual inspection.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ncpa.cpl"'
        )
        Rollback = @(
            'Start-Process "ncpa.cpl"'
        )
    }
    [pscustomobject]@{
        Id = "router-reboot-checklist"; Title = "Router reboot checklist"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Network', 'Router', 'Checklist')
        Summary = 'Adds a clear router/modem reboot checklist for packet loss or routing issues.'
        BackupKeys = @()
        Commands = @(
            'Write-Output "Power-cycle modem and router: unplug 60 seconds, plug modem first, wait online, then router. Retest ping/jitter to the game region."'
        )
        Rollback = @(
            'Write-Output "No PC changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "temp-user-clean"; Title = "Clean user temp folder"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Cleanup', 'Storage', 'Temp')
        Summary = 'Deletes files from the current user''s temp folder when Windows allows it.'
        BackupKeys = @()
        Commands = @(
            'Remove-Item -Path "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue',
            'Write-Output "User temp cleanup complete."'
        )
        Rollback = @(
            'Write-Output "No rollback needed for temporary files."'
        )
    }
    [pscustomobject]@{
        Id = "temp-windows-clean"; Title = "Clean Windows temp folder"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Cleanup', 'Storage', 'Temp')
        Summary = 'Deletes files from C:\Windows\Temp when Windows allows it.'
        BackupKeys = @()
        Commands = @(
            'Remove-Item -Path "$env:WINDIR\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue',
            'Write-Output "Windows temp cleanup complete."'
        )
        Rollback = @(
            'Write-Output "No rollback needed for temporary files."'
        )
    }
    [pscustomobject]@{
        Id = "delivery-cache-clean"; Title = "Clean Delivery Optimization cache"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Cleanup', 'Windows Update', 'Bandwidth')
        Summary = 'Clears Delivery Optimization cache files that can grow large over time.'
        BackupKeys = @()
        Commands = @(
            'Delete-DeliveryOptimizationCache -Force -ErrorAction SilentlyContinue',
            'Write-Output "Delivery Optimization cache cleanup attempted."'
        )
        Rollback = @(
            'Write-Output "No rollback needed for cache cleanup."'
        )
    }
    [pscustomobject]@{
        Id = "windows-error-reports-clean"; Title = "Clean Windows error reports"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Cleanup', 'WER', 'Storage')
        Summary = 'Deletes archived Windows Error Reporting files when present.'
        BackupKeys = @()
        Commands = @(
            '$paths = @("$env:ProgramData\Microsoft\Windows\WER\ReportArchive", "$env:ProgramData\Microsoft\Windows\WER\ReportQueue")',
            'foreach ($p in $paths) { if (Test-Path $p) { Remove-Item "$p\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Output "Cleaned $p" } }'
        )
        Rollback = @(
            'Write-Output "No rollback needed for error-report cleanup."'
        )
    }
    [pscustomobject]@{
        Id = "recycle-bin-empty"; Title = "Empty Recycle Bin"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Cleanup', 'Storage', 'Disk')
        Summary = 'Empties the recycle bin for all drives.'
        BackupKeys = @()
        Commands = @(
            'Clear-RecycleBin -Force -ErrorAction SilentlyContinue'
        )
        Rollback = @(
            'Write-Output "Recycle Bin cleanup cannot be rolled back unless files were restored from backup."'
        )
    }
    [pscustomobject]@{
        Id = "storage-sense-open"; Title = "Open Storage Sense"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Storage', 'Cleanup', 'Windows')
        Summary = 'Opens Windows Storage Sense settings for built-in cleanup.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:storagesense"'
        )
        Rollback = @(
            'Start-Process "ms-settings:storagesense"'
        )
    }
    [pscustomobject]@{
        Id = "trim-ssd-run"; Title = "Run SSD trim/optimize"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Storage', 'SSD', 'TRIM')
        Summary = 'Runs Optimize-Volume TRIM/ReTrim on fixed drives where supported.'
        BackupKeys = @()
        Commands = @(
            'Get-Volume | Where-Object { $_.DriveType -eq "Fixed" -and $_.DriveLetter } | ForEach-Object { Optimize-Volume -DriveLetter $_.DriveLetter -ReTrim -Verbose -ErrorAction SilentlyContinue }'
        )
        Rollback = @(
            'Write-Output "No rollback needed. TRIM is a maintenance operation."'
        )
    }
    [pscustomobject]@{
        Id = "sfc-scan"; Title = "System file checker scan"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Repair', 'Windows')
        Summary = 'Runs SFC to check and repair Windows system files.'
        BackupKeys = @()
        Commands = @(
            'sfc /scannow'
        )
        Rollback = @(
            'Write-Output "SFC makes repairs when needed. Use DISM or System Restore if problems remain."'
        )
    }
    [pscustomobject]@{
        Id = "dism-restorehealth"; Title = "DISM component repair"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Repair', 'Windows')
        Summary = 'Runs DISM RestoreHealth for Windows component store repair.'
        BackupKeys = @()
        Commands = @(
            'DISM /Online /Cleanup-Image /RestoreHealth'
        )
        Rollback = @(
            'Write-Output "DISM repairs Windows components. No direct rollback is normally needed."'
        )
    }
    [pscustomobject]@{
        Id = "chkdsk-online-scan"; Title = "Online disk scan"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Disk', 'Storage')
        Summary = 'Runs a non-offline CHKDSK scan on the system drive.'
        BackupKeys = @()
        Commands = @(
            'chkdsk C: /scan'
        )
        Rollback = @(
            'Write-Output "No changes unless CHKDSK schedules/repairs issues."'
        )
    }
    [pscustomobject]@{
        Id = "battery-report"; Title = "Laptop battery report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Laptop', 'Battery')
        Summary = 'Generates a Windows battery report on the desktop for laptop tuning context.'
        BackupKeys = @()
        Commands = @(
            'powercfg /batteryreport /output "$env:USERPROFILE\Desktop\ApexTune-Battery-Report.html"',
            'Write-Output "Battery report saved to Desktop."'
        )
        Rollback = @(
            'Write-Output "Delete the Desktop battery report file if you no longer need it."'
        )
    }
    [pscustomobject]@{
        Id = "energy-report"; Title = "Power energy report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Power', 'Energy')
        Summary = 'Generates an energy report to find driver, device, and sleep-state problems.'
        BackupKeys = @()
        Commands = @(
            'powercfg /energy /duration 60 /output "$env:USERPROFILE\Desktop\ApexTune-Energy-Report.html"',
            'Write-Output "Energy report saved to Desktop."'
        )
        Rollback = @(
            'Write-Output "Delete the Desktop energy report file if you no longer need it."'
        )
    }
    [pscustomobject]@{
        Id = "sleepstudy-report"; Title = "Sleep study report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Laptop', 'Sleep')
        Summary = 'Generates a SleepStudy report where supported.'
        BackupKeys = @()
        Commands = @(
            'powercfg /sleepstudy /output "$env:USERPROFILE\Desktop\ApexTune-SleepStudy.html"',
            'Write-Output "SleepStudy report saved to Desktop if supported."'
        )
        Rollback = @(
            'Write-Output "Delete the Desktop SleepStudy file if you no longer need it."'
        )
    }
    [pscustomobject]@{
        Id = "driverquery-report"; Title = "Driver inventory report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Drivers', 'Report')
        Summary = 'Exports a driver inventory CSV to the Desktop for troubleshooting.'
        BackupKeys = @()
        Commands = @(
            'driverquery /v /fo csv > "$env:USERPROFILE\Desktop\ApexTune-Driver-Inventory.csv"',
            'Write-Output "Driver inventory saved to Desktop."'
        )
        Rollback = @(
            'Write-Output "Delete the Desktop CSV if you no longer need it."'
        )
    }
    [pscustomobject]@{
        Id = "latency-baseline-ping"; Title = "Latency baseline report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Ping', 'Network')
        Summary = 'Runs a quick ping baseline to Cloudflare and Google DNS.'
        BackupKeys = @()
        Commands = @(
            'ping 1.1.1.1 -n 20',
            'ping 8.8.8.8 -n 20'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "gpu-driver-inventory"; Title = "GPU driver inventory"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'GPU', 'Drivers')
        Summary = 'Lists detected display adapters and driver versions.'
        BackupKeys = @()
        Commands = @(
            'Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,DriverDate,AdapterRAM | Format-Table -AutoSize'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "startup-apps-report"; Title = "Startup apps report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Startup', 'Report')
        Summary = 'Exports visible startup app entries to the Desktop.'
        BackupKeys = @()
        Commands = @(
            'Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-Startup-Apps.csv" -NoTypeInformation',
            'Write-Output "Startup apps report saved to Desktop."'
        )
        Rollback = @(
            'Write-Output "Delete the Desktop CSV if you no longer need it."'
        )
    }
    [pscustomobject]@{
        Id = "process-top-cpu-report"; Title = "Top CPU process snapshot"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'CPU', 'Processes')
        Summary = 'Shows the top CPU-time processes to help find background hogs.'
        BackupKeys = @()
        Commands = @(
            'Get-Process | Sort-Object CPU -Descending | Select-Object -First 20 ProcessName,Id,CPU,WorkingSet | Format-Table -AutoSize'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "process-top-memory-report"; Title = "Top memory process snapshot"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Memory', 'Processes')
        Summary = 'Shows the largest working-set processes to help find RAM hogs.'
        BackupKeys = @()
        Commands = @(
            'Get-Process | Sort-Object WorkingSet -Descending | Select-Object -First 20 ProcessName,Id,CPU,WorkingSet | Format-Table -AutoSize'
        )
        Rollback = @(
            'Write-Output "No changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "windows-update-open"; Title = "Open Windows Update"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Drivers', 'Windows Update', 'Settings')
        Summary = 'Opens Windows Update for optional driver and system update review.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:windowsupdate"'
        )
        Rollback = @(
            'Start-Process "ms-settings:windowsupdate"'
        )
    }
    [pscustomobject]@{
        Id = "optional-updates-open"; Title = "Open optional driver updates"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Drivers', 'Optional Updates', 'Settings')
        Summary = 'Opens Optional Updates where Windows may list driver updates.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "ms-settings:windowsupdate-optionalupdates"'
        )
        Rollback = @(
            'Start-Process "ms-settings:windowsupdate-optionalupdates"'
        )
    }
    [pscustomobject]@{
        Id = "device-manager-open"; Title = "Open Device Manager"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Drivers', 'Device Manager', 'Hardware')
        Summary = 'Opens Device Manager for manual hardware and driver inspection.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "devmgmt.msc"'
        )
        Rollback = @(
            'Start-Process "devmgmt.msc"'
        )
    }
    [pscustomobject]@{
        Id = "event-viewer-open"; Title = "Open Event Viewer"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Crashes', 'Logs')
        Summary = 'Opens Event Viewer to inspect game crashes, driver resets, and system errors.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "eventvwr.msc"'
        )
        Rollback = @(
            'Start-Process "eventvwr.msc"'
        )
    }
    [pscustomobject]@{
        Id = "reliability-monitor-open"; Title = "Open Reliability Monitor"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Crashes', 'Reliability')
        Summary = 'Opens Reliability Monitor for an easy crash timeline.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "perfmon.exe" "/rel"'
        )
        Rollback = @(
            'Start-Process "perfmon.exe" "/rel"'
        )
    }
    [pscustomobject]@{
        Id = "audio-enhancements-open"; Title = "Audio enhancements check"; Tier = "Free"; Category = "Audio"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Audio', 'Latency', 'Settings')
        Summary = 'Opens sound settings so spatial audio/enhancements can be tested when audio latency or crackle happens.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "mmsys.cpl"',
            'Write-Output "Check playback/recording device properties. Disable enhancements/spatial audio if they cause crackle or delay."'
        )
        Rollback = @(
            'Start-Process "mmsys.cpl"'
        )
    }
    [pscustomobject]@{
        Id = "sound-communications-do-nothing"; Title = "Disable Windows communication ducking"; Tier = "Free"; Category = "Audio"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'Audio', 'Voice Chat')
        Summary = 'Prevents Windows from lowering game audio during communications activity.'
        BackupKeys = @('HKCU\Software\Microsoft\Multimedia\Audio')
        Commands = @(
            'reg add "HKCU\Software\Microsoft\Multimedia\Audio" /v UserDuckingPreference /t REG_DWORD /d 3 /f'
        )
        Rollback = @(
            'reg delete "HKCU\Software\Microsoft\Multimedia\Audio" /v UserDuckingPreference /f'
        )
    }
    [pscustomobject]@{
        Id = "steam-overlay-check"; Title = "Steam overlay audit"; Tier = "Free"; Category = "Game"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Steam', 'Overlay', 'Checklist')
        Summary = 'Opens Steam settings and reminds users to test overlay off per game.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "steam://open/settings"',
            'Write-Output "Steam: test disabling overlay per game if you get stutter, capture issues, or input delay."'
        )
        Rollback = @(
            'Start-Process "steam://open/settings"'
        )
    }
    [pscustomobject]@{
        Id = "discord-overlay-check"; Title = "Discord overlay audit"; Tier = "Free"; Category = "Game"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Discord', 'Overlay', 'Checklist')
        Summary = 'Documents the Discord overlay setting path without editing Discord config files.'
        BackupKeys = @()
        Commands = @(
            'Write-Output "Discord: User Settings > Game Overlay > disable in-game overlay for competitive games. Restart Discord after changing it."'
        )
        Rollback = @(
            'Write-Output "Discord: re-enable the overlay from User Settings > Game Overlay if you need it."'
        )
    }
    [pscustomobject]@{
        Id = "nvidia-overlay-check"; Title = "NVIDIA overlay audit"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('NVIDIA', 'Overlay', 'Checklist')
        Summary = 'Opens NVIDIA App/GeForce Experience if installed and reminds users to test overlay off.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "NVIDIA app.exe" -ErrorAction SilentlyContinue',
            'Start-Process "GeForceExperience.exe" -ErrorAction SilentlyContinue',
            'Write-Output "Test NVIDIA overlay off if you get stutter or capture conflicts."'
        )
        Rollback = @(
            'Write-Output "Re-enable NVIDIA overlay if you need ShadowPlay or performance overlay."'
        )
    }
    [pscustomobject]@{
        Id = "amd-overlay-check"; Title = "AMD overlay audit"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('amd'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('AMD', 'Overlay', 'Checklist')
        Summary = 'Opens AMD software if installed and reminds users to test overlay off.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "amdsoftware.exe" -ErrorAction SilentlyContinue',
            'Write-Output "Test AMD overlay off if you get stutter or capture conflicts."'
        )
        Rollback = @(
            'Write-Output "Re-enable AMD overlay if you need recording or metrics overlay."'
        )
    }
    [pscustomobject]@{
        Id = "bcdedit-clean-timer-baseline"; Title = "Clean BCDEdit timer baseline"; Tier = "Pro"; Category = "Boot"; Risk = "High"; Fps = 1; Ping = 1; Restart = $true; Experimental = $true
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('BCD', 'Timer', 'Experimental')
        Summary = 'Deletes common timer override values to return to Windows defaults.'
        BackupKeys = @()
        Commands = @(
            'bcdedit /deletevalue useplatformclock',
            'bcdedit /deletevalue tscsyncpolicy',
            'bcdedit /deletevalue disabledynamictick'
        )
        Rollback = @(
            'Write-Output "Rollback: there is no single universal timer baseline. Reapply only the timer setting you intentionally used before."'
        )
    }
    [pscustomobject]@{
        Id = "hpet-force-on-test"; Title = "Force HPET on test"; Tier = "Pro"; Category = "Boot"; Risk = "High"; Fps = 1; Ping = 1; Restart = $true; Experimental = $true
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('BCD', 'Timer', 'Experimental')
        Summary = 'Forces platform clock as a test only. Many systems perform worse with this enabled.'
        BackupKeys = @()
        Commands = @(
            'bcdedit /set useplatformclock true'
        )
        Rollback = @(
            'bcdedit /deletevalue useplatformclock'
        )
    }
    [pscustomobject]@{
        Id = "gpu-timeout-default"; Title = "Reset GPU timeout values"; Tier = "Pro"; Category = "GPU"; Risk = "Medium"; Fps = 0; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'GPU', 'TDR')
        Summary = 'Deletes custom TDR timeout values to return GPU timeout behavior to Windows defaults.'
        BackupKeys = @('HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers')
        Commands = @(
            'reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDelay /f',
            'reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDdiDelay /f'
        )
        Rollback = @(
            'Write-Output "Rollback: restore exported GraphicsDrivers registry backup if you had custom TDR values."'
        )
    }
    [pscustomobject]@{
        Id = "gpu-timeout-extended-test"; Title = "Extend GPU timeout test"; Tier = "Pro"; Category = "GPU"; Risk = "High"; Fps = 0; Ping = 0; Restart = $true; Experimental = $true
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Registry', 'GPU', 'TDR')
        Summary = 'Extends TDR timeout for creators/games that hit recoverable driver timeouts. Do not use to mask unstable overclocks.'
        BackupKeys = @('HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers')
        Commands = @(
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDelay /t REG_DWORD /d 10 /f',
            'reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDdiDelay /t REG_DWORD /d 10 /f'
        )
        Rollback = @(
            'reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDelay /f',
            'reg delete "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v TdrDdiDelay /f'
        )
    }
    [pscustomobject]@{
        Id = "heat-throttle-check"; Title = "Thermal throttling check"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 3; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Thermals', 'Laptop', 'Diagnostics')
        Summary = 'Adds a thermal checklist for laptops and compact PCs that drop FPS over time.'
        BackupKeys = @()
        Commands = @(
            'Write-Output "Thermal check: compare first 5 minutes vs 30 minutes. If FPS drops hard, clean vents, raise laptop rear, use max fan/OEM performance mode, and check CPU/GPU clocks."'
        )
        Rollback = @(
            'Write-Output "No system changes were made."'
        )
    }
    [pscustomobject]@{
        Id = "oem-control-center-open"; Title = "OEM performance control center"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Laptop', 'OEM', 'Performance')
        Summary = 'Attempts to open common OEM control apps and gives a performance-mode checklist.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "NitroSense.exe" -ErrorAction SilentlyContinue',
            'Start-Process "LenovoVantage.exe" -ErrorAction SilentlyContinue',
            'Start-Process "ArmouryCrate.exe" -ErrorAction SilentlyContinue',
            'Write-Output "Use the OEM app to set Performance/Turbo mode while plugged in. Avoid Silent/Eco when gaming."'
        )
        Rollback = @(
            'Write-Output "Set OEM mode back to Balanced/Silent if heat or fan noise is too high."'
        )
    }
    [pscustomobject]@{
        Id = "clean-boot-msconfig-open"; Title = "Clean boot setup helper"; Tier = "Pro"; Category = "Diagnostics"; Risk = "Medium"; Fps = 2; Ping = 0; Restart = $true; Experimental = $false
        Vendors = @('nvidia', 'amd', 'intel', 'other'); Systems = @('desktop', 'laptop'); Games = @('esports', 'aaa', 'streaming')
        Tags = @('Diagnostics', 'Startup', 'Services')
        Summary = 'Opens System Configuration for a manual clean-boot test without silently disabling services.'
        BackupKeys = @()
        Commands = @(
            'Start-Process "msconfig.exe"',
            'Write-Output "Use Services > Hide all Microsoft services, then test disabling third-party services in small batches."'
        )
        Rollback = @(
            'Start-Process "msconfig.exe"'
        )
    }


    [pscustomobject]@{
        Id = "startup-impact-settings-open"; Title = "Startup impact control panel"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Startup", "Settings", "Impact")
        Summary = "Opens the official Windows Startup Apps page so users can disable high-impact apps safely."
        BackupKeys = @()
        Commands = @('Start-Process "ms-settings:startupapps"', 'Write-Output "Review Startup impact. Disable launchers and updaters you do not need at sign-in."')
        Rollback = @('Start-Process "ms-settings:startupapps"')
    }
    [pscustomobject]@{
        Id = "task-manager-startup-open"; Title = "Task Manager startup audit"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Startup", "Task Manager", "Audit")
        Summary = "Opens Task Manager so startup impact can be reviewed with Windows' built-in startup app list."
        BackupKeys = @()
        Commands = @('Start-Process "taskmgr.exe"', 'Write-Output "Open the Startup apps tab and disable only apps you recognize."')
        Rollback = @('Start-Process "taskmgr.exe"')
    }
    [pscustomobject]@{
        Id = "autoruns-download-open"; Title = "Sysinternals Autoruns deep audit"; Tier = "Pro"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false
        Vendors = @("nvidia", "amd", "intel", "other"); Systems = @("desktop", "laptop"); Games = @("esports", "aaa", "streaming")
        Tags = @("Startup", "Autoruns", "Deep Audit")
        Summary = "Opens Microsoft's Autoruns page for a full autostart audit beyond the normal Startup Apps page."
        BackupKeys = @()
        Commands = @('Start-Process "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns"', 'Write-Output "Use Autoruns carefully: hide Microsoft entries first and research unknown entries before disabling them."')
        Rollback = @('Write-Output "No changes were made by ApexTune. Re-enable entries inside Autoruns if you disabled any."')
    }
    [pscustomobject]@{ Id = "steam-startup-off"; Title = "Disable Steam startup"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Steam","Launcher"); Summary = "Removes common Steam auto-start entries without uninstalling Steam."; BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Run"); Commands = @('reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v Steam /f', 'Write-Output "Steam startup entry removed if it existed."'); Rollback = @('Write-Output "Rollback: open Steam settings and re-enable Run Steam when my computer starts."') }
    [pscustomobject]@{ Id = "epic-startup-off"; Title = "Disable Epic Games Launcher startup"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Epic","Launcher"); Summary = "Removes the Epic Games Launcher auto-start Run key if present."; BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Run"); Commands = @('reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "EpicGamesLauncher" /f', 'Write-Output "Epic launcher startup entry removed if it existed."'); Rollback = @('Write-Output "Rollback: open Epic Games Launcher settings and re-enable start with Windows if desired."') }
    [pscustomobject]@{ Id = "battle-net-startup-off"; Title = "Disable Battle.net startup"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Battle.net","Launcher"); Summary = "Removes common Battle.net launcher auto-start entries when found."; BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Run"); Commands = @('reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "Battle.net" /f', 'Write-Output "Battle.net startup entry removed if it existed."'); Rollback = @('Write-Output "Rollback: open Battle.net app settings and re-enable launch on startup."') }
    [pscustomobject]@{ Id = "riot-client-startup-off"; Title = "Disable Riot Client startup"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Riot","VALORANT"); Summary = "Removes common Riot Client startup entries while leaving Vanguard services untouched."; BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Run"); Commands = @('reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "Riot Client" /f', 'Write-Output "Riot Client startup entry removed if it existed. Vanguard services are not changed."'); Rollback = @('Write-Output "Rollback: open Riot Client settings and re-enable startup behavior if needed."') }
    [pscustomobject]@{ Id = "discord-run-key-off"; Title = "Disable Discord startup Run key"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $true; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Discord","Run Key"); Summary = "Removes common Discord startup entries if Discord launches at sign-in."; BackupKeys = @("HKCU\Software\Microsoft\Windows\CurrentVersion\Run"); Commands = @('reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v Discord /f', 'Write-Output "Discord startup entry removed if it existed."'); Rollback = @('Write-Output "Rollback: open Discord Windows Settings and enable Open Discord."') }
    [pscustomobject]@{ Id = "startup-run-key-export"; Title = "Backup startup Run keys"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Backup","Registry"); Summary = "Exports common startup Run keys to the Desktop before cleanup."; BackupKeys = @(); Commands = @('reg export "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" "%USERPROFILE%\Desktop\ApexTune-HKCU-Run.reg" /y', 'reg export "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" "%USERPROFILE%\Desktop\ApexTune-HKLM-Run.reg" /y'); Rollback = @('Write-Output "Rollback: double-click exported .reg files on Desktop if you need to restore entries."') }
    [pscustomobject]@{ Id = "scheduled-task-startup-audit"; Title = "Scheduled task startup audit"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Scheduled Tasks","Audit"); Summary = "Exports enabled scheduled tasks so users can find update tasks and launchers without disabling blindly."; BackupKeys = @(); Commands = @('Get-ScheduledTask | Where-Object { $_.State -ne "Disabled" } | Select-Object TaskName,TaskPath,State | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-ScheduledTasks.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "high-impact-process-report"; Title = "Background process impact report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Diagnostics","Processes","CPU"); Summary = "Exports top CPU and memory processes to help find what is slowing games down."; BackupKeys = @(); Commands = @('Get-Process | Sort-Object CPU -Descending | Select-Object -First 30 ProcessName,Id,CPU,WorkingSet64 | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-TopProcesses.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "gaming-session-network-test"; Title = "Gaming network baseline test"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 3; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Ping","Network","Report"); Summary = "Runs a short ping baseline to common DNS endpoints and saves it to Desktop."; BackupKeys = @(); Commands = @('ping 1.1.1.1 -n 20 > "$env:USERPROFILE\Desktop\ApexTune-Ping-Cloudflare.txt"', 'ping 8.8.8.8 -n 20 > "$env:USERPROFILE\Desktop\ApexTune-Ping-Google.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "network-adapter-inventory"; Title = "Network adapter inventory"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Adapter","Report"); Summary = "Exports network adapter driver, link speed, and status for troubleshooting ping spikes."; BackupKeys = @(); Commands = @('Get-NetAdapter | Select-Object Name,InterfaceDescription,Status,LinkSpeed,MacAddress,DriverInformation | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-NetworkAdapters.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "gpu-driver-inventory-export"; Title = "GPU driver inventory export"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Driver","Report"); Summary = "Exports detected graphics adapters and driver versions to Desktop."; BackupKeys = @(); Commands = @('Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,DriverDate,AdapterRAM,VideoProcessor | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-GPU-Drivers.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "reliability-monitor-deep-open"; Title = "Open Reliability Monitor timeline"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Crash","Reliability","Diagnostics"); Summary = "Opens Windows Reliability Monitor to diagnose crashes, driver faults, and failed updates."; BackupKeys = @(); Commands = @('Start-Process "perfmon.exe" "/rel"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "event-viewer-gaming-errors"; Title = "Open Event Viewer errors"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Crash","Event Viewer","Diagnostics"); Summary = "Opens Event Viewer so recent application and system errors can be checked after crashes."; BackupKeys = @(); Commands = @('Start-Process "eventvwr.msc"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "repair-system-files"; Title = "System file repair scan"; Tier = "Pro"; Category = "Maintenance"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Repair","SFC","DISM"); Summary = "Runs DISM health restore then System File Checker for Windows corruption that can cause crashes."; BackupKeys = @(); Commands = @('DISM /Online /Cleanup-Image /RestoreHealth', 'sfc /scannow'); Rollback = @('Write-Output "No rollback needed. DISM and SFC repair Windows components."') }
    [pscustomobject]@{ Id = "windows-update-pause-open"; Title = "Open Windows Update controls"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Windows Update","Restart","Settings"); Summary = "Opens Windows Update so users can schedule restart behavior before tournaments or recording sessions."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:windowsupdate"'); Rollback = @('Start-Process "ms-settings:windowsupdate"') }
    [pscustomobject]@{ Id = "notifications-dnd-open"; Title = "Do Not Disturb gaming mode"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Notifications","Focus","Gaming"); Summary = "Opens notification settings so popups do not interrupt games or recordings."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:notifications"'); Rollback = @('Start-Process "ms-settings:notifications"') }
    [pscustomobject]@{ Id = "graphics-defaults-open"; Title = "Open per-app GPU preference"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Windows","Per App"); Summary = "Opens Windows Graphics settings so games can be set to High performance GPU."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:display-advancedgraphics"'); Rollback = @('Start-Process "ms-settings:display-advancedgraphics"') }
    [pscustomobject]@{ Id = "game-mode-settings-open"; Title = "Open Game Mode settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 2; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Game Mode","Windows","Settings"); Summary = "Opens Windows Game Mode settings for a visual check after applying registry Game Mode tweaks."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:gaming-gamemode"'); Rollback = @('Start-Process "ms-settings:gaming-gamemode"') }
    [pscustomobject]@{ Id = "xbox-captures-settings-open"; Title = "Open capture settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Captures","Game DVR","Settings"); Summary = "Opens Capture settings to confirm background recording is off if the user does not need it."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:gaming-gamedvr"'); Rollback = @('Start-Process "ms-settings:gaming-gamedvr"') }
    [pscustomobject]@{ Id = "privacy-diagnostics-basic"; Title = "Open diagnostics privacy controls"; Tier = "Free"; Category = "Privacy"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Privacy","Diagnostics","Windows"); Summary = "Opens diagnostics privacy controls so optional data and tailored experiences can be reviewed."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:privacy-feedback"', 'Start-Process "ms-settings:privacy-diagnostics"'); Rollback = @('Start-Process "ms-settings:privacy-diagnostics"') }


    # v32: extra stable optimizer/startup/diagnostic tweak cards. These are deliberately safe commands:
    # settings shortcuts, reports, reversible registry edits, or guarded service/settings openers.
    [pscustomobject]@{ Id = "v32-startup-task-manager-details"; Title = "Open Task Manager details"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Task Manager","Audit"); Summary = "Opens Task Manager so startup and background process impact can be reviewed safely."; BackupKeys = @(); Commands = @('Start-Process "taskmgr.exe"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-startup-shell-open"; Title = "Open Startup folder"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Folder","Audit"); Summary = "Opens the current user's Startup folder for manual cleanup."; BackupKeys = @(); Commands = @('Start-Process "shell:startup"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-common-startup-shell-open"; Title = "Open common Startup folder"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Folder","Audit"); Summary = "Opens the all-users Startup folder so system-wide startup shortcuts can be reviewed."; BackupKeys = @(); Commands = @('Start-Process "shell:common startup"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-startup-run-current-export"; Title = "Export current-user Run key"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Registry","Backup"); Summary = "Backs up the current-user Run key before startup cleanup."; BackupKeys = @(); Commands = @('reg export "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" "%USERPROFILE%\Desktop\ApexTune-HKCU-Run-v32.reg" /y'); Rollback = @('Write-Output "Import the exported .reg file if you need to restore entries."') }
    [pscustomobject]@{ Id = "v32-startup-run-machine-export"; Title = "Export machine Run key"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Registry","Backup"); Summary = "Backs up the machine-wide Run key before startup cleanup."; BackupKeys = @(); Commands = @('reg export "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" "%USERPROFILE%\Desktop\ApexTune-HKLM-Run-v32.reg" /y'); Rollback = @('Write-Output "Import the exported .reg file if you need to restore entries."') }
    [pscustomobject]@{ Id = "v32-scheduled-tasks-enabled-report"; Title = "Enabled scheduled tasks report"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Tasks","Report"); Summary = "Exports enabled scheduled tasks to Desktop for safe review."; BackupKeys = @(); Commands = @('Get-ScheduledTask | Where-Object { $_.State -ne "Disabled" } | Select-Object TaskName,TaskPath,State | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-EnabledTasks-v32.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-startup-settings-open"; Title = "Open Startup Apps settings"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Settings","Safe"); Summary = "Opens Windows Startup Apps settings, the safest first place to disable startup apps."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:startupapps"'); Rollback = @('Start-Process "ms-settings:startupapps"') }
    [pscustomobject]@{ Id = "v32-apps-advanced-options-open"; Title = "Open Apps advanced options"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Apps","Settings"); Summary = "Opens installed apps so background permissions and startup behavior can be reviewed."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:appsfeatures"'); Rollback = @('Start-Process "ms-settings:appsfeatures"') }
    [pscustomobject]@{ Id = "v32-services-console-open"; Title = "Open Services console"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Services","Audit","Windows"); Summary = "Opens Services for manual review without changing service states."; BackupKeys = @(); Commands = @('Start-Process "services.msc"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-services-auto-report"; Title = "Automatic services report"; Tier = "Free"; Category = "Services"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Services","Report","Audit"); Summary = "Exports automatic services so background load can be reviewed safely."; BackupKeys = @(); Commands = @('Get-Service | Where-Object { $_.StartType -eq "Automatic" } | Select-Object Name,DisplayName,Status,StartType | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-AutomaticServices-v32.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-process-memory-report"; Title = "Top memory process report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Processes","Memory","Report"); Summary = "Exports the top memory-heavy processes to Desktop."; BackupKeys = @(); Commands = @('Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 40 ProcessName,Id,WorkingSet64,CPU | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-TopMemory-v32.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-process-cpu-report"; Title = "Top CPU process report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Processes","CPU","Report"); Summary = "Exports CPU-heavy processes to Desktop for troubleshooting stutters."; BackupKeys = @(); Commands = @('Get-Process | Sort-Object CPU -Descending | Select-Object -First 40 ProcessName,Id,CPU,WorkingSet64 | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-TopCPU-v32.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-network-ipconfig-report"; Title = "Full IP configuration report"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Report","IP"); Summary = "Saves ipconfig /all to Desktop for network troubleshooting."; BackupKeys = @(); Commands = @('ipconfig /all > "%USERPROFILE%\Desktop\ApexTune-IPConfig-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-network-route-report"; Title = "Routing table report"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Route","Report"); Summary = "Exports the Windows route table to help diagnose bad routing/VPN issues."; BackupKeys = @(); Commands = @('route print > "%USERPROFILE%\Desktop\ApexTune-RouteTable-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-network-netstat-report"; Title = "Network connections report"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Connections","Report"); Summary = "Exports active network connections for review."; BackupKeys = @(); Commands = @('netstat -ano > "%USERPROFILE%\Desktop\ApexTune-Netstat-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-network-dns-cache-report"; Title = "DNS cache report"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","DNS","Report"); Summary = "Exports the DNS resolver cache before clearing it."; BackupKeys = @(); Commands = @('ipconfig /displaydns > "%USERPROFILE%\Desktop\ApexTune-DNSCache-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-network-arp-report"; Title = "ARP table report"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","ARP","Report"); Summary = "Exports the ARP table to Desktop for LAN troubleshooting."; BackupKeys = @(); Commands = @('arp -a > "%USERPROFILE%\Desktop\ApexTune-ARP-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-wifi-report-open"; Title = "Generate Wi-Fi report"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 2; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Wi-Fi","Report","Network"); Summary = "Generates Microsoft's wlan report for Wi-Fi disconnect/ping spike troubleshooting."; BackupKeys = @(); Commands = @('netsh wlan show wlanreport'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-proxy-settings-open"; Title = "Open proxy settings"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Proxy","Settings"); Summary = "Opens proxy settings so unwanted proxies can be checked before gaming."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:network-proxy"'); Rollback = @('Start-Process "ms-settings:network-proxy"') }
    [pscustomobject]@{ Id = "v32-network-advanced-open"; Title = "Open advanced network settings"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Adapter","Settings"); Summary = "Opens advanced network settings for adapter review."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:network-advancedsettings"'); Rollback = @('Start-Process "ms-settings:network-advancedsettings"') }
    [pscustomobject]@{ Id = "v32-ethernet-settings-open"; Title = "Open Ethernet settings"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Ethernet","Settings"); Summary = "Opens Ethernet settings for connection review."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:network-ethernet"'); Rollback = @('Start-Process "ms-settings:network-ethernet"') }
    [pscustomobject]@{ Id = "v32-wifi-settings-open"; Title = "Open Wi-Fi settings"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 1; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Network","Wi-Fi","Settings"); Summary = "Opens Wi-Fi settings to review signal and adapter state."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:network-wifi"'); Rollback = @('Start-Process "ms-settings:network-wifi"') }
    [pscustomobject]@{ Id = "v32-gpu-display-settings-open"; Title = "Open display settings"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Display","Settings"); Summary = "Opens Windows display settings for refresh rate and monitor checks."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:display"'); Rollback = @('Start-Process "ms-settings:display"') }
    [pscustomobject]@{ Id = "v32-gpu-graphics-settings-open"; Title = "Open per-app graphics settings"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Graphics","Settings"); Summary = "Opens Windows per-app graphics settings to choose the high-performance GPU."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:display-advancedgraphics"'); Rollback = @('Start-Process "ms-settings:display-advancedgraphics"') }
    [pscustomobject]@{ Id = "v32-gpu-advanced-display-open"; Title = "Open advanced display info"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Refresh Rate","Display"); Summary = "Opens advanced display settings to verify refresh rate."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:display-advanced"'); Rollback = @('Start-Process "ms-settings:display-advanced"') }
    [pscustomobject]@{ Id = "v32-dxdiag-report"; Title = "Save DXDiag report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","DXDiag","Report"); Summary = "Saves a DirectX diagnostic report to Desktop."; BackupKeys = @(); Commands = @('dxdiag /t "%USERPROFILE%\Desktop\ApexTune-DxDiag-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-gpu-device-manager-open"; Title = "Open Device Manager"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Driver","Device Manager"); Summary = "Opens Device Manager for driver and device checks."; BackupKeys = @(); Commands = @('Start-Process "devmgmt.msc"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-maintenance-temp-open"; Title = "Open temporary files"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Storage","Cleanup","Settings"); Summary = "Opens Windows temporary files cleanup page."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:storagesense"'); Rollback = @('Start-Process "ms-settings:storagesense"') }
    [pscustomobject]@{ Id = "v32-storage-settings-open"; Title = "Open storage settings"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Storage","Settings","Cleanup"); Summary = "Opens Windows storage settings for cleanup review."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:storagesense"'); Rollback = @('Start-Process "ms-settings:storagesense"') }
    [pscustomobject]@{ Id = "v32-defrag-open"; Title = "Open drive optimization"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Storage","Optimize","Drive"); Summary = "Opens Windows drive optimization tool for SSD/HDD maintenance review."; BackupKeys = @(); Commands = @('Start-Process "dfrgui.exe"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-disk-health-report"; Title = "Disk health report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Disk","Health","Report"); Summary = "Exports disk model/status information to Desktop."; BackupKeys = @(); Commands = @('Get-CimInstance Win32_DiskDrive | Select-Object Model,Status,Size,MediaType | Export-Csv "$env:USERPROFILE\Desktop\ApexTune-DiskHealth-v32.csv" -NoTypeInformation'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-battery-report"; Title = "Battery report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("laptop"); Games = @("esports","aaa","streaming"); Tags = @("Battery","Laptop","Report"); Summary = "Generates a Windows battery report on laptops."; BackupKeys = @(); Commands = @('powercfg /batteryreport /output "%USERPROFILE%\Desktop\ApexTune-Battery-v32.html"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-energy-report"; Title = "Energy report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Power","Energy","Report"); Summary = "Generates a short Windows energy report for power issues."; BackupKeys = @(); Commands = @('powercfg /energy /duration 15 /output "%USERPROFILE%\Desktop\ApexTune-Energy-v32.html"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-powercfg-report"; Title = "Power configuration report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Power","Report","Settings"); Summary = "Exports active power scheme information."; BackupKeys = @(); Commands = @('powercfg /query > "%USERPROFILE%\Desktop\ApexTune-PowerConfig-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-game-mode-settings-open"; Title = "Open Game Mode settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Game Mode","Windows","Settings"); Summary = "Opens Windows Game Mode settings for verification."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:gaming-gamemode"'); Rollback = @('Start-Process "ms-settings:gaming-gamemode"') }
    [pscustomobject]@{ Id = "v32-captures-settings-open"; Title = "Open Captures settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Captures","Game Bar","Settings"); Summary = "Opens Windows Captures settings to disable background recording if unused."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:gaming-gamedvr"'); Rollback = @('Start-Process "ms-settings:gaming-gamedvr"') }
    [pscustomobject]@{ Id = "v32-gamebar-settings-open"; Title = "Open Game Bar settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Game Bar","Overlay","Settings"); Summary = "Opens Game Bar settings so overlay/capture behavior can be reviewed."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:gaming-gamebar"'); Rollback = @('Start-Process "ms-settings:gaming-gamebar"') }
    [pscustomobject]@{ Id = "v32-focus-settings-open"; Title = "Open Focus settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Focus","Notifications","Gaming"); Summary = "Opens Focus settings to reduce notification interruptions while gaming."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:quiethours"'); Rollback = @('Start-Process "ms-settings:quiethours"') }
    [pscustomobject]@{ Id = "v32-notifications-settings-open"; Title = "Open notification settings"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Notifications","Focus","Settings"); Summary = "Opens notification settings so noisy apps can be turned down."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:notifications"'); Rollback = @('Start-Process "ms-settings:notifications"') }
    [pscustomobject]@{ Id = "v32-sound-settings-open"; Title = "Open sound settings"; Tier = "Free"; Category = "Audio"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Audio","Settings","Input"); Summary = "Opens sound settings for audio device and microphone troubleshooting."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:sound"'); Rollback = @('Start-Process "ms-settings:sound"') }
    [pscustomobject]@{ Id = "v32-controller-panel-open"; Title = "Open controller panel"; Tier = "Free"; Category = "Input"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Controller","Input","Settings"); Summary = "Opens the Windows game controller panel."; BackupKeys = @(); Commands = @('Start-Process "joy.cpl"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-mouse-settings-open"; Title = "Open mouse settings"; Tier = "Free"; Category = "Input"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Mouse","Input","Settings"); Summary = "Opens mouse settings for sensitivity and pointer review."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:mousetouchpad"'); Rollback = @('Start-Process "ms-settings:mousetouchpad"') }
    [pscustomobject]@{ Id = "v32-keyboard-settings-open"; Title = "Open keyboard settings"; Tier = "Free"; Category = "Input"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Keyboard","Input","Settings"); Summary = "Opens keyboard settings for input troubleshooting."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:keyboard"'); Rollback = @('Start-Process "ms-settings:keyboard"') }
    [pscustomobject]@{ Id = "v32-security-core-isolation-open"; Title = "Open Core Isolation"; Tier = "Pro"; Category = "Windows"; Risk = "Medium"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Security","Core Isolation","Settings"); Summary = "Opens Core Isolation settings so security/performance tradeoffs can be reviewed manually."; BackupKeys = @(); Commands = @('Start-Process "windowsdefender://coreisolation"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-security-windows-security-open"; Title = "Open Windows Security"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Security","Windows","Settings"); Summary = "Opens Windows Security dashboard for review."; BackupKeys = @(); Commands = @('Start-Process "windowsdefender:"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-reliability-monitor-open"; Title = "Open Reliability Monitor"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Diagnostics","Crashes","Windows"); Summary = "Opens Reliability Monitor to review app crashes and driver failures."; BackupKeys = @(); Commands = @('Start-Process "perfmon.exe" "/rel"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-event-viewer-open"; Title = "Open Event Viewer"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Diagnostics","Events","Windows"); Summary = "Opens Event Viewer for advanced crash and driver troubleshooting."; BackupKeys = @(); Commands = @('Start-Process "eventvwr.msc"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-update-settings-open"; Title = "Open Windows Update"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Windows Update","Drivers","Settings"); Summary = "Opens Windows Update for pending OS/driver update review."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:windowsupdate"'); Rollback = @('Start-Process "ms-settings:windowsupdate"') }
    [pscustomobject]@{ Id = "v32-optional-updates-open"; Title = "Open optional updates"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Drivers","Optional Updates","Windows"); Summary = "Opens optional updates where some driver updates appear."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:windowsupdate-optionalupdates"'); Rollback = @('Start-Process "ms-settings:windowsupdate-optionalupdates"') }
    [pscustomobject]@{ Id = "v32-sfc-scan"; Title = "Run SFC verification"; Tier = "Pro"; Category = "Diagnostics"; Risk = "Medium"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Repair","SFC","Windows"); Summary = "Runs System File Checker verification for corrupted Windows files."; BackupKeys = @(); Commands = @('sfc /verifyonly'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-dism-health-scan"; Title = "Run DISM health scan"; Tier = "Pro"; Category = "Diagnostics"; Risk = "Medium"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Repair","DISM","Windows"); Summary = "Runs a DISM health scan to check Windows component store health."; BackupKeys = @(); Commands = @('DISM /Online /Cleanup-Image /ScanHealth'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-god-mode-folder"; Title = "Create advanced settings folder"; Tier = "Free"; Category = "Windows"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Settings","Control Panel","Shortcut"); Summary = "Creates a desktop folder shortcut with many advanced Windows settings in one place."; BackupKeys = @(); Commands = @('New-Item -ItemType Directory -Path "$env:USERPROFILE\Desktop\ApexTune Advanced Settings.{ED7BA470-8E54-465E-825C-99712043E01C}" -Force | Out-Null'); Rollback = @('Remove-Item -Path "$env:USERPROFILE\Desktop\ApexTune Advanced Settings.{ED7BA470-8E54-465E-825C-99712043E01C}" -Force -Recurse -ErrorAction SilentlyContinue') }
    [pscustomobject]@{ Id = "v32-apextune-support-folder"; Title = "Open ApexTune support folder"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("ApexTune","Logs","Support"); Summary = "Opens the ApexTune app-data folder containing logs, backups, and error reports."; BackupKeys = @(); Commands = @('Start-Process "$env:APPDATA\ApexTune"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-empty-recycle-bin"; Title = "Empty recycle bin"; Tier = "Pro"; Category = "Maintenance"; Risk = "Medium"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Cleanup","Storage","Recycle Bin"); Summary = "Empties the Recycle Bin to reclaim storage. Review before applying."; BackupKeys = @(); Commands = @('Clear-RecycleBin -Force -ErrorAction SilentlyContinue'); Rollback = @('Write-Output "Recycle Bin contents cannot be automatically restored."') }
    [pscustomobject]@{ Id = "v32-ping-cloudflare-short"; Title = "Short Cloudflare ping test"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 2; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Ping","Test","Network"); Summary = "Runs a quick ping test to 1.1.1.1 and saves the result to Desktop."; BackupKeys = @(); Commands = @('ping 1.1.1.1 -n 20 > "%USERPROFILE%\Desktop\ApexTune-Ping-Cloudflare-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }
    [pscustomobject]@{ Id = "v32-ping-google-short"; Title = "Short Google ping test"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 2; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Ping","Test","Network"); Summary = "Runs a quick ping test to 8.8.8.8 and saves the result to Desktop."; BackupKeys = @(); Commands = @('ping 8.8.8.8 -n 20 > "%USERPROFILE%\Desktop\ApexTune-Ping-Google-v32.txt"'); Rollback = @('Write-Output "No changes were made."') }


    [pscustomobject]@{ Id = "v34-system-snapshot"; Title = "Apex system snapshot report"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Report","Baseline","Safety"); Summary = "Exports a JSON/TXT snapshot with hardware, safety settings, selected tweaks, and live metric context before changes."; BackupKeys = @(); Commands = @('Ensure-AppData; $reports = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reports -Force | Out-Null; $path = Join-Path $reports ("ApexTune-Baseline-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt"); Set-Content -Path $path -Value (Get-HardwareDetailsText $script:State.Hardware) -Encoding UTF8; Write-Output "Saved baseline report to $path"'); Rollback = @('Write-Output "No system changes were made."') }
    [pscustomobject]@{ Id = "v34-latency-probe"; Title = "Apex latency probe"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 3; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Ping","Jitter","Report"); Summary = "Runs a short PowerShell ICMP probe to Cloudflare and Google and saves average/min/max latency notes."; BackupKeys = @(); Commands = @('Invoke-ApexLatencyProbe'); Rollback = @('Write-Output "No system changes were made."') }
    [pscustomobject]@{ Id = "v34-driver-inventory"; Title = "Driver inventory export"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Drivers","Inventory","Report"); Summary = "Exports signed Plug and Play driver inventory for troubleshooting GPU, network, audio, and chipset versions."; BackupKeys = @(); Commands = @('$reports = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reports -Force | Out-Null; $path = Join-Path $reports ("ApexTune-DriverInventory-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".csv"); Get-CimInstance Win32_PnPSignedDriver | Select-Object DeviceName,Manufacturer,DriverVersion,DriverDate,InfName | Sort-Object DeviceName | Export-Csv -NoTypeInformation -Path $path; Write-Output "Saved driver inventory to $path"'); Rollback = @('Write-Output "No system changes were made."') }
    [pscustomobject]@{ Id = "v34-startup-inventory"; Title = "Startup inventory export"; Tier = "Free"; Category = "Startup"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Startup","Inventory","Report"); Summary = "Exports startup command locations from registry and startup folders before disabling anything."; BackupKeys = @(); Commands = @('$reports = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reports -Force | Out-Null; $path = Join-Path $reports ("ApexTune-StartupInventory-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt"); $keys = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run", "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run"; $out = @(); foreach ($k in $keys) { $out += "[$k]"; try { $out += ((Get-ItemProperty -Path $k | Out-String).Trim()) } catch { $out += $_.Exception.Message }; $out += "" }; Set-Content -Path $path -Value ($out -join [Environment]::NewLine) -Encoding UTF8; Write-Output "Saved startup inventory to $path"'); Rollback = @('Write-Output "No system changes were made."') }
    [pscustomobject]@{ Id = "v34-powercfg-energy-report"; Title = "Power efficiency diagnostic report"; Tier = "Free"; Category = "Power"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Power","Battery","Report"); Summary = "Runs Windows powercfg energy diagnostics and saves the HTML report in ApexTune Reports."; BackupKeys = @(); Commands = @('$reports = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reports -Force | Out-Null; $path = Join-Path $reports ("ApexTune-EnergyReport-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".html"); powercfg /energy /duration 20 /output $path; Write-Output "Saved power report to $path"'); Rollback = @('Write-Output "No system changes were made."') }
    [pscustomobject]@{ Id = "v34-directx-shader-cache-clean"; Title = "Clear DirectX shader cache"; Tier = "Free"; Category = "Maintenance"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Shader Cache","DirectX","Stutter"); Summary = "Clears user DirectX shader cache so corrupted shader cache files can rebuild cleanly after driver/game changes."; BackupKeys = @(); Commands = @('$path = Join-Path $env:LOCALAPPDATA "D3DSCache"; if (Test-Path -LiteralPath $path) { Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue; Write-Output "Cleared DirectX shader cache." } else { Write-Output "DirectX shader cache folder not found." }'); Rollback = @('Write-Output "Shader cache rebuilds automatically when games/apps compile shaders again."') }
    [pscustomobject]@{ Id = "v34-network-adapter-inventory"; Title = "Network adapter inventory"; Tier = "Free"; Category = "Network"; Risk = "Low"; Fps = 0; Ping = 2; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Adapter","Network","Report"); Summary = "Exports active adapter names, link speeds, DNS servers, and IP settings before network tuning."; BackupKeys = @(); Commands = @('$reports = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reports -Force | Out-Null; $path = Join-Path $reports ("ApexTune-NetworkInventory-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt"); Get-NetAdapter | Format-List Name,InterfaceDescription,Status,LinkSpeed,MacAddress | Out-File -FilePath $path -Encoding utf8; Get-DnsClientServerAddress | Format-List | Out-File -FilePath $path -Encoding utf8 -Append; ipconfig /all | Out-File -FilePath $path -Encoding utf8 -Append; Write-Output "Saved network inventory to $path"'); Rollback = @('Write-Output "No system changes were made."') }
    [pscustomobject]@{ Id = "v34-open-gpu-preferences"; Title = "Open graphics preference settings"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("GPU","Graphics Settings","Windows"); Summary = "Opens Windows graphics preference settings so individual games can be assigned the high-performance GPU."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:display-advancedgraphics"'); Rollback = @('Start-Process "ms-settings:display-advancedgraphics"') }
    [pscustomobject]@{ Id = "v34-open-refresh-rate"; Title = "Open advanced display settings"; Tier = "Free"; Category = "GPU"; Risk = "Low"; Fps = 1; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Refresh Rate","Display","Monitor"); Summary = "Opens advanced display settings so refresh rate and display mode can be verified before benchmarking."; BackupKeys = @(); Commands = @('Start-Process "ms-settings:display-advanced"'); Rollback = @('Start-Process "ms-settings:display-advanced"') }
    [pscustomobject]@{ Id = "v34-open-reports-folder"; Title = "Open ApexTune reports folder"; Tier = "Free"; Category = "Diagnostics"; Risk = "Low"; Fps = 0; Ping = 0; Restart = $false; Experimental = $false; Vendors = @("nvidia","amd","intel","other"); Systems = @("desktop","laptop"); Games = @("esports","aaa","streaming"); Tags = @("Reports","Logs","Support"); Summary = "Opens the ApexTune Reports folder for snapshots, latency probes, driver inventory, and exported diagnostics."; BackupKeys = @(); Commands = @('$reports = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reports -Force | Out-Null; Start-Process explorer.exe $reports'); Rollback = @('Write-Output "No system changes were made."') }

)

Repair-TweakCatalog

function Ensure-AppData {
    foreach ($path in @($script:AppDir, $script:BackupsRoot)) {
        if (-not (Test-Path $path)) {
            New-Item -ItemType Directory -Path $path -Force | Out-Null
        }
    }
}

function Write-ApexErrorLog($FileName, $ErrorRecord = $null, $Message = "") {
    try {
        Ensure-AppData
        $safeName = $(if ([string]::IsNullOrWhiteSpace([string]$FileName)) { "ApexTune-Error.txt" } else { [string]$FileName })
        $path = Join-Path $script:AppDir $safeName
        $lines = @()
        $lines += "ApexTune diagnostic log"
        $lines += ("Generated: " + (Get-Date).ToString("o"))
        $lines += ("App version: " + $script:AppVersion + " / " + $script:AppVersionNumber)
        $lines += ("User: " + $(if ($script:State -and $script:State.User -and $script:State.User.Username) { [string]$script:State.User.Username } else { "not signed in" }))
        $adminText = "unknown"
        try { $adminText = [string](Test-Admin) } catch {}
        $lines += ("Admin: " + $adminText)
        try {
            $lines += ("Custom UI types loaded: " + [string]$script:ApexCustomUiAvailable)
            if (-not [string]::IsNullOrWhiteSpace([string]$script:ApexCustomUiTypeError)) {
                $lines += ("Custom UI type loader: " + [string]$script:ApexCustomUiTypeError)
            }
        } catch {}
        if (-not [string]::IsNullOrWhiteSpace([string]$Message)) {
            $lines += ""
            $lines += "Message:"
            $lines += [string]$Message
        }
        if ($null -ne $ErrorRecord) {
            $lines += ""
            $lines += "Error record:"
            $lines += ($ErrorRecord | Out-String)
            try {
                if ($ErrorRecord.ScriptStackTrace) {
                    $lines += ""
                    $lines += "Script stack trace:"
                    $lines += [string]$ErrorRecord.ScriptStackTrace
                }
            } catch {}
        }
        $lines += ""
        $lines += "Environment:"
        $lines += ("PowerShell: " + $PSVersionTable.PSVersion.ToString())
        $lines += ("OS: " + [Environment]::OSVersion.VersionString)
        $lines += ("Process: " + [System.Diagnostics.Process]::GetCurrentProcess().ProcessName)
        Set-Content -LiteralPath $path -Value ($lines -join [Environment]::NewLine) -Encoding UTF8
        return $path
    } catch {
        return $null
    }
}

function Copy-Map($Source) {
    $copy = @{}
    foreach ($key in $Source.Keys) {
        $copy[$key] = $Source[$key]
    }
    return $copy
}

function Get-AppTheme {
    # ApexTune v9 uses one consistent pro dark interface so saved light-theme owner/user files
    # cannot accidentally produce washed-out panels or clipped white cards.
    return "dark"
}

function Apply-ColorTheme($Theme = $null) {
    $themeToApply = $(if ($null -ne $Theme) { [string]$Theme } else { Get-AppTheme })
    $script:Colors = Get-ThemeColors $themeToApply
    if ($null -ne $script:Form -and -not $script:Form.IsDisposed) {
        $script:Form.BackColor = $script:Colors.Bg
        $script:Form.ForeColor = $script:Colors.Text
    }
}

function Set-AppTheme($Theme) {
    $themeKey = "dark"
    $script:State.Settings["Theme"] = $themeKey
    Apply-ColorTheme $themeKey
    Save-CurrentUser
    if ($null -ne $script:State.User) {
        Show-App
        Show-View "settings"
    }
}

function Normalize-AppMark($Value) {
    return "APEX"
}

function Get-AppMark {
    return "APEX"
}

function Set-AppMark($Value) {
    Update-AppMarkLabels
    Save-CurrentUser
    return "APEX"
}

function New-AppMarkLabel($FontSize = 11, $BackColor = $null) {
    $mark = New-ApexUiControl "ApexBrandMark"
    $mark.Dock = [System.Windows.Forms.DockStyle]::Fill
    $mark.Margin = New-Object System.Windows.Forms.Padding(0)
    $mark.BackColor = [System.Drawing.Color]::Transparent
    try {
        $mark.AccentColor = $script:Colors.Accent
        $mark.AccentTwoColor = $script:Colors.Teal
        $mark.LineColor = $script:Colors.Text
    } catch {}
    $mark.AccessibleName = "ApexTune logo"
    Set-ApexToolTip $mark "ApexTune - gaming optimizer"
    $script:BrandMarkLabels += $mark
    return $mark
}

function Update-AppMarkLabels {
    foreach ($label in @($script:BrandMarkLabels)) {
        if ($null -ne $label -and -not $label.IsDisposed) { try { $label.Invalidate() } catch {} }
    }
    $script:BrandMarkLabels = @($script:BrandMarkLabels | Where-Object { $null -ne $_ -and -not $_.IsDisposed })
}

function Apply-WindowStartupMode {
    if ($null -eq $script:Form -or $script:Form.IsDisposed) { return }
    $startMaximized = $true
    if ($script:State -and $script:State.Settings -and $script:State.Settings.ContainsKey("StartMaximized")) {
        $startMaximized = [bool]$script:State.Settings.StartMaximized
    }
    if ($startMaximized) {
        $script:Form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
    } elseif ($script:Form.WindowState -eq [System.Windows.Forms.FormWindowState]::Maximized) {
        $script:Form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        $script:Form.Size = New-Object System.Drawing.Size(1440, 900)
        $script:Form.CenterToScreen()
    }
}

function Merge-Map($Defaults, $Existing) {
    $merged = Copy-Map $Defaults
    if ($null -ne $Existing) {
        foreach ($prop in $Existing.PSObject.Properties) {
            $merged[$prop.Name] = $prop.Value
        }
    }
    return $merged
}

function Get-PasswordHash($Password) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Password)
    $hash = $sha.ComputeHash($bytes)
    return (($hash | ForEach-Object { $_.ToString("x2") }) -join "")
}

function Normalize-Username($Username) {
    return (($Username.Trim().ToLowerInvariant()) -replace "[^a-z0-9_-]", "")
}

function Load-Users {
    Ensure-AppData
    if (-not (Test-Path $script:AccountsPath)) { return @() }
    try {
        $raw = Get-Content -Path $script:AccountsPath -Raw
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw | ConvertFrom-Json)
    } catch {
        return @()
    }
}

function Save-Users {
    Ensure-AppData
    @($script:State.Users) | ConvertTo-Json -Depth 10 | Set-Content -Path $script:AccountsPath -Encoding UTF8
}

function Load-OwnerState {
    if (-not (Test-Path $script:OwnerPath)) { return $null }
    try { return (Get-Content -Path $script:OwnerPath -Raw | ConvertFrom-Json) } catch { return $null }
}

function Save-CurrentUser {
    if ($null -eq $script:State.User) { return }
    $script:State.User.Settings = [pscustomobject]$script:State.Settings
    $script:State.User.Profile = [pscustomobject]$script:State.Profile

    if ($script:State.User.Username -eq $script:OwnerUsername) {
        $ownerSave = [pscustomobject]@{
            Settings = $script:State.User.Settings
            Profile = $script:State.User.Profile
            Activity = @($script:State.User.Activity)
        }
        $ownerSave | ConvertTo-Json -Depth 10 | Set-Content -Path $script:OwnerPath -Encoding UTF8
        return
    }

    $next = @()
    foreach ($user in $script:State.Users) {
        if ($user.Username -eq $script:State.User.Username) { $next += $script:State.User } else { $next += $user }
    }
    $script:State["Users"] = $next
    Save-Users
}

function Save-Session($Username, $StayLoggedIn) {
    if (-not $StayLoggedIn) {
        if (Test-Path $script:SessionPath) { Remove-Item -Path $script:SessionPath -Force }
        return
    }
    [pscustomobject]@{ Username = $Username; At = (Get-Date).ToString("o") } |
        ConvertTo-Json | Set-Content -Path $script:SessionPath -Encoding UTF8
}

function Load-Session {
    if (-not (Test-Path $script:SessionPath)) { return $null }
    try { return (Get-Content -Path $script:SessionPath -Raw | ConvertFrom-Json) } catch { return $null }
}

function Clear-Session {
    if (Test-Path $script:SessionPath) { Remove-Item -Path $script:SessionPath -Force }
}

function Test-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Relaunch-AsAdmin {
    if (-not $PSCommandPath) { return }
    $args = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    Start-Process -FilePath "powershell.exe" -ArgumentList $args -Verb RunAs
}

function Add-Activity($Label, $Count) {
    $items = @($script:State.User.Activity)
    $entry = [pscustomobject]@{
        Label = $Label
        Count = $Count
        At = (Get-Date).ToString("o")
    }
    $script:State.User.Activity = @($entry) + $items | Select-Object -First 12
}

function Has-Premium {
    if ($null -eq $script:State.User) { return $false }
    return ($script:State.User.Plan -eq "pro" -or $script:State.User.Plan -eq "founder")
}

function Is-Locked($Tweak) {
    return ($Tweak.Tier -eq "Pro" -and -not (Has-Premium))
}

function Get-ProfileValue($Name, $Fallback) {
    if ($null -eq $script:State.Profile) { return $Fallback }
    if ($script:State.Profile -is [hashtable] -and $script:State.Profile.ContainsKey($Name)) {
        $value = $script:State.Profile[$Name]
    } elseif ($script:State.Profile.PSObject.Properties[$Name]) {
        $value = $script:State.Profile.$Name
    } else {
        $value = $Fallback
    }
    if ([string]::IsNullOrWhiteSpace([string]$value)) { return $Fallback }
    return ([string]$value).ToLowerInvariant()
}

function Is-Recommended($Tweak) {
    $gpu = Get-ProfileValue "Gpu" "nvidia"
    $system = Get-ProfileValue "System" "laptop"
    $game = Get-ProfileValue "Game" "esports"
    $network = Get-ProfileValue "Network" "ethernet"
    if ($Tweak.Vendors -notcontains $gpu) { return $false }
    if ($Tweak.Systems -notcontains $system) { return $false }
    if ($Tweak.Games -notcontains $game) { return $false }
    if ($Tweak.Id -eq "wifi-power-save-off" -and $network -ne "wifi") { return $false }
    return $true
}

function Get-ActiveDashboardSection {
    if ($script:DashboardSection) { return $script:DashboardSection }
    return "dashboard"
}

function Get-DefaultTweakIdsForSection($Section) {
    switch ($Section) {
        "performance" {
            return @(
                "game-mode-hags", "xbox-capture-off", "visual-effects-performance",
                "background-apps-off", "power-throttling-off", "foreground-priority",
                "usb-selective-suspend-off", "startup-delay-zero", "shader-cache-maintenance", "high-performance-plan", "disable-fast-startup", "disk-sleep-never-ac", "active-cooling-ac"
            )
        }
        "network" {
            return @(
                "dns-network-refresh", "network-throttling-games", "delivery-optimization-off",
                "dns-performance", "network-rsc-off", "large-send-offload-off",
                "tcp-ecn-timestamps-off", "wifi-power-save-off", "network-rss-enable", "tcp-autotuning-normal", "energy-efficient-ethernet-off", "dns-auto"
            )
        }
        "startup" {
            return @(
                "startup-apps-report", "startup-impact-settings-open", "startup-folder-open",
                "task-manager-startup-open", "autoruns-download-open", "discord-startup-off-note",
                "onedrive-startup-off", "edge-background-mode-off", "steam-startup-off",
                "epic-startup-off", "battle-net-startup-off", "riot-client-startup-off",
                "teams-chat-autoinstall-off", "chrome-background-mode-note", "maps-service-manual",
                "retail-demo-service-manual", "remote-registry-disabled", "bluetooth-services-audit"
            )
        }
        "gpu" {
            return @(
                "game-mode-hags", "nvidia-low-latency", "fullscreen-game-profile",
                "pcie-link-state-off", "shader-cache-maintenance", "windows-graphics-settings-open", "advanced-display-open", "directx-cache-clean"
            )
        }
        "optimize" {
            return @(
                "game-mode-hags", "xbox-capture-off", "background-apps-off",
                "visual-effects-performance", "power-throttling-off", "foreground-priority",
                "mouse-accel-off", "dns-network-refresh", "network-throttling-games",
                "nvidia-low-latency", "content-suggestions-off", "gamebar-hard-off", "temp-user-clean", "directx-cache-clean"
            )
        }
        default {
            return @(
                "game-mode-hags", "xbox-capture-off", "background-apps-off",
                "power-throttling-off", "foreground-priority", "dns-network-refresh",
                "network-throttling-games", "mouse-accel-off", "nvidia-low-latency",
                "pcie-link-state-off"
            )
        }
    }
}

function Add-TweakId([System.Collections.ArrayList]$List, [string]$Id) {
    if (-not $List.Contains($Id)) { [void]$List.Add($Id) }
}

function Get-RecommendedTweakIdsForSection($Section) {
    $ids = New-Object System.Collections.ArrayList
    foreach ($id in (Get-DefaultTweakIdsForSection $Section)) { Add-TweakId $ids $id }

    $gpu = Get-ProfileValue "Gpu" "nvidia"
    $system = Get-ProfileValue "System" "laptop"
    $game = Get-ProfileValue "Game" "esports"
    $network = Get-ProfileValue "Network" "ethernet"

    if ($gpu -eq "nvidia") {
        foreach ($id in @("nvidia-low-latency", "game-mode-hags", "pcie-link-state-off")) { Add-TweakId $ids $id }
    }
    if ($system -eq "laptop") {
        foreach ($id in @("usb-selective-suspend-off", "power-throttling-off")) { Add-TweakId $ids $id }
    }
    if ($game -eq "esports") {
        foreach ($id in @("mouse-accel-off", "network-throttling-games", "foreground-priority", "fullscreen-game-profile")) { Add-TweakId $ids $id }
    }
    if ((Get-ActiveDashboardSection) -eq "startup") {
        foreach ($id in @("startup-impact-settings-open", "startup-apps-report", "task-manager-startup-open", "startup-folder-open", "high-impact-process-report")) { Add-TweakId $ids $id }
    }

    if ($network -eq "ethernet") {
        foreach ($id in @("network-rsc-off", "large-send-offload-off", "dns-performance")) { Add-TweakId $ids $id }
    } elseif ($network -eq "wifi") {
        foreach ($id in @("wifi-power-save-off", "dns-performance", "dns-network-refresh")) { Add-TweakId $ids $id }
    }

    return @($ids)
}

function Get-TweaksByIds($Ids, [bool]$SkipLocked = $false) {
    $items = @()
    foreach ($id in @($Ids)) {
        $tweak = @($script:Tweaks) | Where-Object { $_.Id -eq $id } | Select-Object -First 1
        if ($null -eq $tweak) { continue }
        if (-not (Test-TweakAllowedBySettings $tweak)) { continue }
        if ($SkipLocked -and (Is-Locked $tweak)) { continue }
        $items += $tweak
    }
    return $items
}

function Get-FallbackTweaksForSection($Filter = $null, [bool]$ForSelection = $false) {
    $section = Get-ActiveDashboardSection
    $ids = $(if ($Filter -eq "recommended" -or $ForSelection) { Get-RecommendedTweakIdsForSection $section } else { Get-DefaultTweakIdsForSection $section })
    $items = @(Get-TweaksByIds $ids $ForSelection)

    if ($Filter -eq "free") { $items = @($items | Where-Object { $_.Tier -eq "Free" }) }
    elseif ($Filter -eq "pro") { $items = @($items | Where-Object { $_.Tier -eq "Pro" }) }
    elseif ($Filter -eq "selected") { $items = @($items | Where-Object { $script:State.Selected.ContainsKey($_.Id) }) }

    if ($items.Count -eq 0 -and -not $ForSelection) {
        $items = @(Get-TweaksByIds (Get-DefaultTweakIdsForSection $section) $false)
    }
    return $items
}

function Get-RecommendedTweaksForSelection {
    $items = @(Get-FallbackTweaksForSection "recommended" $true)
    if ($items.Count -eq 0) {
        $items = @(Get-FallbackTweaksForSection "all" $true)
    }
    return @($items | Select-Object -First 16)
}

function Test-TweakAllowedBySettings($Tweak) {
    if ($Tweak.Experimental -and -not $script:State.Settings.Experimental) { return $false }
    if ($Tweak.Risk -eq "High" -and -not $script:State.Settings.ShowRisky) { return $false }
    return $true
}

function Remove-DisabledSelections {
    foreach ($id in @($script:State.Selected.Keys)) {
        $tweak = @($script:Tweaks) | Where-Object { $_.Id -eq $id } | Select-Object -First 1
        if ($null -eq $tweak -or -not (Test-TweakAllowedBySettings $tweak) -or (Is-Locked $tweak)) {
            $script:State.Selected.Remove($id)
        }
    }
}

function Set-OptimizerSetting($Key, [bool]$Value) {
    $script:State.Settings[$Key] = $Value
    if ($Key -in @("Experimental", "ShowRisky")) {
        Remove-DisabledSelections
    }
    if ($Key -eq "StartMaximized") {
        Apply-WindowStartupMode
    }
    Save-CurrentUser
    if ($script:ActiveView -in @("dashboard", "optimize", "performance", "network", "startup", "gpu")) {
        Render-TweakCards
        Render-Queue
    }
}

function Test-TweakMatchesSection($Tweak) {
    $section = Get-ActiveDashboardSection
    $category = ([string]$Tweak.Category).ToLowerInvariant()
    $tags = ([string](($Tweak.Tags -join " ") + " " + $Tweak.Title + " " + $Tweak.Summary)).ToLowerInvariant()

    if ($section -eq "dashboard") {
        # Dashboard is overview-only in v36; the full library lives in Optimize.
        return (Get-DefaultTweakIdsForSection "dashboard") -contains $Tweak.Id
    }
    if ($section -eq "optimize") {
        $optimizeIds = @(Get-RecommendedTweakIdsForSection "optimize")
        return ($optimizeIds -contains $Tweak.Id)
    }
    if ($section -eq "performance") {
        if ($category -in @("network", "gpu")) { return $false }
        return ($category -in @("windows", "power", "input", "maintenance", "services", "storage", "diagnostics", "startup", "game", "audio", "privacy", "boot") -or $tags -match "\b(cpu|fps|power|scheduler|background|service|memory|startup|visual|timer|stutter|responsiveness|mouse|keyboard|diagnostics|cleanup|game|audio|windows)\b")
    }
    if ($section -eq "startup") {
        return ($category -in @("startup", "services") -or $tags -match "\b(startup|autorun|launcher|boot|login|run key|onedrive|discord|steam|epic|riot|battle.net|teams|edge|chrome|scheduled task|service)\b")
    }
    if ($section -eq "network") {
        return ($category -eq "network" -or $tags -match "\b(network|ping|dns|tcp|winsock|adapter|wi-fi|wifi|bandwidth|ethernet|socket|rsc|lso|ecn|rss|router|packet|jitter|dhcp|arp)\b")
    }
    if ($section -eq "gpu") {
        $gpu = Get-ProfileValue "Gpu" "nvidia"
        if ($category -eq "gpu" -and $Tweak.Vendors -notcontains $gpu) { return $false }
        return ($category -in @("gpu", "display") -or $tags -match "\b(gpu|nvidia|amd|intel|arc|graphics|display|shader|directx|pcie|fullscreen|vrr|hdr|refresh|overlay)\b")
    }
    return $true
}

function Get-VisibleTweaks {
    $items = @()
    $searchText = ([string]$script:State.Search).Trim().ToLowerInvariant()
    $filter = [string]$script:State.Filter
    $categoryFilter = $(if ($script:State.ContainsKey("CategoryFilter")) { [string]$script:State.CategoryFilter } else { "all" })
    $riskFilter = $(if ($script:State.ContainsKey("RiskFilter")) { [string]$script:State.RiskFilter } else { "all" })
    $sort = $(if ($script:State.ContainsKey("Sort")) { [string]$script:State.Sort } else { "recommended" })
    foreach ($tweak in $script:Tweaks) {
        if (-not (Test-TweakAllowedBySettings $tweak)) { continue }
        if (-not (Test-TweakMatchesSection $tweak)) { continue }
        if ($searchText.Length -gt 0) {
            $haystack = (($tweak.Title, $tweak.Summary, $tweak.Category, ($tweak.Tags -join " ")) -join " ").ToLowerInvariant()
            if (-not $haystack.Contains($searchText)) { continue }
        }
        if ($searchText.Length -eq 0 -and $filter -eq "recommended" -and -not (Is-Recommended $tweak)) { continue }
        if ($filter -eq "safe") {
            if ($tweak.Risk -notin @("Low")) { continue }
            if ($tweak.Experimental) { continue }
        }
        if ($filter -eq "aggressive") {
            if ($tweak.Risk -notin @("Medium", "High")) { continue }
        }
        if ($filter -eq "advanced") {
            $tags = ([string](($tweak.Tags -join " ") + " " + $tweak.Summary)).ToLowerInvariant()
            if (-not ($tweak.Experimental -or $tweak.Risk -eq "High" -or $tags -match "\b(bcd|timer|service|registry|driver|adapter|tcp|advanced)\b")) { continue }
        }
        if ($filter -eq "free" -and $tweak.Tier -ne "Free") { continue }
        if ($filter -eq "pro" -and $tweak.Tier -ne "Pro") { continue }
        if ($filter -eq "selected" -and -not $script:State.Selected.ContainsKey($tweak.Id)) { continue }
        if ($categoryFilter -ne "all" -and ([string]$tweak.Category).ToLowerInvariant() -ne $categoryFilter.ToLowerInvariant()) { continue }
        if ($riskFilter -ne "all" -and ([string]$tweak.Risk).ToLowerInvariant() -ne $riskFilter.ToLowerInvariant()) { continue }
        $items += $tweak
    }
    if ($items.Count -eq 0 -and $searchText.Length -eq 0) {
        $items = @(Get-FallbackTweaksForSection $filter $false)
    }
    if ($items.Count -gt 1) {
        if ($sort -eq "fps") { $items = @($items | Sort-Object -Property Fps -Descending) }
        elseif ($sort -eq "ping") { $items = @($items | Sort-Object -Property Ping -Descending) }
        elseif ($sort -eq "risk") { $items = @($items | Sort-Object @{ Expression = { if ($_.Risk -eq "Low") { 0 } elseif ($_.Risk -eq "Medium") { 1 } else { 2 } } }, Title) }
        elseif ($sort -eq "name") { $items = @($items | Sort-Object -Property Title) }
        else { $items = @($items | Sort-Object @{ Expression = { if (Is-Recommended $_) { 0 } else { 1 } } }, @{ Expression = { if ($_.Tier -eq "Free") { 0 } else { 1 } } }, Title) }
    }
    return $items
}


function Get-SelectedTweaks {
    $items = @()
    foreach ($tweak in $script:Tweaks) {
        if ($script:State.Selected.ContainsKey($tweak.Id) -and -not (Is-Locked $tweak) -and (Test-TweakAllowedBySettings $tweak)) {
            $items += $tweak
        }
    }
    return $items
}

function Get-FirstValue($Value, $Fallback = "Unknown") {
    if ($null -eq $Value) { return $Fallback }
    $text = ([string]$Value).Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return $Fallback }
    return $text
}

function Get-SystemHardwareInfo {
    $computer = $null
    $os = $null
    $cpu = $null
    $gpus = @()
    $enclosure = $null
    $battery = $null
    $activeAdapters = @()

    try { $computer = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop } catch {}
    try { $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop } catch {}
    try { $cpu = Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch {}
    try { $gpus = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name }) } catch {}
    if ($gpus.Count -eq 0) {
        try { $gpus = @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Name -match "NVIDIA|GeForce|RTX|GTX|AMD|Radeon|Intel|Arc|Iris|UHD|Graphics" }) } catch {}
    }
    try { $enclosure = Get-CimInstance -ClassName Win32_SystemEnclosure -ErrorAction Stop | Select-Object -First 1 } catch {}
    try { $battery = Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1 } catch {}
    try {
        $activeAdapters = @(Get-NetAdapter -ErrorAction Stop | Where-Object { $_.Status -eq "Up" })
    } catch {
        try {
            $activeAdapters = @(Get-CimInstance -ClassName Win32_NetworkAdapter -ErrorAction Stop | Where-Object { $_.NetConnectionStatus -eq 2 })
        } catch {}
    }

    $gpuNames = @($gpus | ForEach-Object { $_.Name } | Where-Object { $_ })
    $gpuText = if ($gpuNames.Count -gt 0) { ($gpuNames -join " + ") } else { "Unknown GPU" }
    $gpuJoined = $gpuText.ToLowerInvariant()
    $gpuVendor = "other"
    if ($gpuJoined -match "nvidia|geforce|rtx|gtx|quadro|nvlddmkm") { $gpuVendor = "nvidia" }
    elseif ($gpuJoined -match "amd|radeon|rx\s|vega|adrenalin") { $gpuVendor = "amd" }
    elseif ($gpuJoined -match "intel|arc|iris|uhd|hd graphics|xe graphics") { $gpuVendor = "intel" }

    $chassisTypes = @()
    if ($enclosure -and $enclosure.ChassisTypes) { $chassisTypes = @($enclosure.ChassisTypes) }
    $laptopChassis = @(8, 9, 10, 11, 12, 14, 18, 21, 30, 31, 32)
    $isLaptop = $false
    foreach ($type in $chassisTypes) {
        if ($laptopChassis -contains [int]$type) { $isLaptop = $true }
    }
    if ($battery) { $isLaptop = $true }
    $systemType = $(if ($isLaptop) { "laptop" } else { "desktop" })

    if ($activeAdapters.Count -eq 0) {
        try { $activeAdapters = @(Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.InterfaceDescription -notmatch "Virtual|VPN|Bluetooth|Loopback" } | Select-Object -First 3) } catch {}
    }
    $adapterNames = @($activeAdapters | ForEach-Object {
        $name = $_.Name
        $description = $_.InterfaceDescription
        if (-not $description) { $description = $_.Description }
        (($name, $description) -join " ")
    } | Where-Object { $_.Trim().Length -gt 0 })
    $adapterText = if ($adapterNames.Count -gt 0) { ($adapterNames -join " + ") } else { "No active adapter detected - choose Ethernet or Wi-Fi manually" }
    $adapterJoined = $adapterText.ToLowerInvariant()
    $networkType = "ethernet"
    if ($adapterJoined -match "wi-fi|wifi|wireless|wlan|802\.11") { $networkType = "wifi" }

    $ramGb = "Unknown RAM"
    if ($computer -and $computer.TotalPhysicalMemory) {
        $ramGb = ([math]::Round(($computer.TotalPhysicalMemory / 1GB), 0).ToString() + " GB RAM")
    }

    $osText = "Windows"
    if ($os) {
        $build = Get-FirstValue $os.BuildNumber ""
        $caption = Get-FirstValue $os.Caption "Windows"
        $osText = $(if ($build.Length -gt 0) { "$caption build $build" } else { $caption })
    }

    $modelText = "Unknown PC"
    if ($computer) {
        $maker = Get-FirstValue $computer.Manufacturer ""
        $model = Get-FirstValue $computer.Model ""
        $modelText = (($maker, $model) | Where-Object { $_ -and $_.Trim().Length -gt 0 }) -join " "
        if ([string]::IsNullOrWhiteSpace($modelText)) { $modelText = "Unknown PC" }
    }

    return [pscustomobject]@{
        GpuVendor = $gpuVendor
        GpuName = $gpuText
        Network = $networkType
        NetworkName = $adapterText
        System = $systemType
        CpuName = Get-FirstValue $cpu.Name "Unknown CPU"
        Ram = $ramGb
        Os = $osText
        Model = $modelText
        DetectedAt = (Get-Date).ToString("g")
    }
}


function Get-StartupHardwareInfo {
    $profile = $script:State.Profile
    $gpuVendor = $(if ($profile -and $profile.Gpu) { [string]$profile.Gpu } else { "other" })
    $networkType = $(if ($profile -and $profile.Network) { [string]$profile.Network } else { "ethernet" })
    $systemType = $(if ($profile -and $profile.System) { [string]$profile.System } else { "desktop" })
    $gpuName = switch ($gpuVendor) {
        "nvidia" { "Quick start NVIDIA profile - press Rescan for exact GPU"; break }
        "amd" { "Quick start AMD profile - press Rescan for exact GPU"; break }
        "intel" { "Quick start Intel profile - press Rescan for exact GPU"; break }
        default { "Quick start GPU profile - press Rescan for exact adapter"; break }
    }
    return [pscustomobject]@{
        GpuVendor = $gpuVendor
        GpuName = $gpuName
        Network = $networkType
        NetworkName = "Quick start network profile - press Rescan for exact adapter"
        System = $systemType
        CpuName = "Quick start mode - press Rescan for exact CPU"
        Ram = "Quick start mode - press Rescan for exact RAM"
        Os = "Windows"
        Model = "Fast launch profile"
        DetectedAt = "Fast launch - not scanned yet"
    }
}

function Apply-HardwareProfile($Hardware) {
    if ($null -eq $Hardware) { return }
    if ($Hardware.GpuVendor -in @("nvidia", "amd", "intel", "other")) {
        $script:State.Profile["Gpu"] = $Hardware.GpuVendor
    }
    if ($Hardware.Network -in @("ethernet", "wifi")) {
        $script:State.Profile["Network"] = $Hardware.Network
    }
    if ($Hardware.System -in @("desktop", "laptop")) {
        $script:State.Profile["System"] = $Hardware.System
    }
}

function New-Font($Size, $Style = [System.Drawing.FontStyle]::Regular) {
    return New-Object System.Drawing.Font("Segoe UI", $Size, $Style)
}

function New-Label($Text, $X, $Y, $W, $H, $Size = 10, $Style = [System.Drawing.FontStyle]::Regular, $Color = $null) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.Location = New-Object System.Drawing.Point($X, $Y)
    $label.Size = New-Object System.Drawing.Size($W, $H)
    $label.Font = New-Font $Size $Style
    $label.ForeColor = $(if ($Color) { $Color } else { $script:Colors.Text })
    $label.BackColor = [System.Drawing.Color]::Transparent
    $label.AutoEllipsis = $true
    $label.UseCompatibleTextRendering = $false
    return $label
}

function New-AutoLabel($Text, $Size = 10, $Style = [System.Drawing.FontStyle]::Regular, $Color = $null, $MaxWidth = 0) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $true
    $label.Font = New-Font $Size $Style
    $label.ForeColor = $(if ($Color) { $Color } else { $script:Colors.Text })
    $label.BackColor = [System.Drawing.Color]::Transparent
    $label.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
    $label.UseCompatibleTextRendering = $false
    if ($MaxWidth -gt 0) {
        $label.MaximumSize = New-Object System.Drawing.Size($MaxWidth, 0)
    }
    return $label
}

function New-FillLabel($Text, $Size = 10, $Style = [System.Drawing.FontStyle]::Regular, $Color = $null) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $false
    $label.Dock = [System.Windows.Forms.DockStyle]::Fill
    $label.Font = New-Font $Size $Style
    $label.ForeColor = $(if ($Color) { $Color } else { $script:Colors.Text })
    $label.BackColor = [System.Drawing.Color]::Transparent
    $label.AutoEllipsis = $true
    $label.UseCompatibleTextRendering = $false
    $label.Padding = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $label.MinimumSize = New-Object System.Drawing.Size(0, [Math]::Max(20, [int]($label.Font.Height + 6)))
    return $label
}

function New-WrapLabel($Text, $Size = 10, $Style = [System.Drawing.FontStyle]::Regular, $Color = $null) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $false
    $label.Dock = [System.Windows.Forms.DockStyle]::Fill
    $label.Font = New-Font $Size $Style
    $label.ForeColor = $(if ($Color) { $Color } else { $script:Colors.Text })
    $label.BackColor = [System.Drawing.Color]::Transparent
    $label.AutoEllipsis = $false
    $label.UseCompatibleTextRendering = $false
    $label.Padding = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $label.MinimumSize = New-Object System.Drawing.Size(0, [Math]::Max(24, [int]($label.Font.Height + 8)))
    return $label
}

function Get-SolidBackColor($Control, $Fallback = $null) {
    $current = $Control
    while ($null -ne $current) {
        try {
            $color = $current.BackColor
            if ($null -ne $color -and -not $color.IsEmpty -and $color.A -gt 0) {
                return $color
            }
        } catch {}
        $current = $current.Parent
    }
    if ($Fallback) { return $Fallback }
    return $script:Colors.Bg
}

function Normalize-LabelBackColors($Root) {
    if ($null -eq $Root -or $Root.IsDisposed) { return }
    foreach ($control in @($Root.Controls)) {
        if ($null -eq $control -or $control.IsDisposed) { continue }
        if ($control -is [System.Windows.Forms.Label]) {
            try {
                if ($control.BackColor -eq [System.Drawing.Color]::Transparent -or $control.BackColor.A -eq 0) {
                    $control.BackColor = Get-SolidBackColor $control.Parent $script:Colors.Bg
                }
            } catch {}
        }
        if ($control.Controls.Count -gt 0) {
            Normalize-LabelBackColors $control
        }
    }
}


function Apply-ApexTextSafety($Root) {
    if ($null -eq $Root -or $Root.IsDisposed) { return }
    foreach ($control in @($Root.Controls)) {
        if ($null -eq $control -or $control.IsDisposed) { continue }
        try {
            if ($control -is [System.Windows.Forms.Label]) {
                $control.UseCompatibleTextRendering = $false
                if (-not $control.AutoSize) {
                    $minH = [Math]::Max(18, [int]($control.Font.Height + 8))
                    if ($control.MinimumSize.Height -lt $minH) { $control.MinimumSize = New-Object System.Drawing.Size($control.MinimumSize.Width, $minH) }
                    if ($control.Height -gt 0 -and $control.Height -lt $minH -and $control.Dock -eq [System.Windows.Forms.DockStyle]::None) { $control.Height = $minH }
                }
            } elseif ($control -is [System.Windows.Forms.Button]) {
                $control.UseCompatibleTextRendering = $false
                try { $control.AutoEllipsis = $true } catch {}
                $minH = [Math]::Max(34, [int]($control.Font.Height + 14))
                if ($control.MinimumSize.Height -lt $minH) { $control.MinimumSize = New-Object System.Drawing.Size($control.MinimumSize.Width, $minH) }
                if ($control.Height -gt 0 -and $control.Height -lt $minH -and $control.Dock -eq [System.Windows.Forms.DockStyle]::None) { $control.Height = $minH }
                try { if (($control.Padding.Left + $control.Padding.Right) -lt 18) { $control.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0) } } catch {}
            } elseif ($control -is [System.Windows.Forms.ComboBox]) {
                $control.ItemHeight = [Math]::Max(22, [int]($control.Font.Height + 6))
                $control.DropDownHeight = [Math]::Max(220, [int]($control.ItemHeight * 9))
            }
        } catch {}
        if ($control.Controls.Count -gt 0) { Apply-ApexTextSafety $control }
    }
}

function Add-ClickHandlerToTree($Control, [scriptblock]$Handler) {
    if ($null -eq $Control -or $Control.Tag -eq "__noTreeClick") { return }
    $Control.Cursor = [System.Windows.Forms.Cursors]::Hand
    $Control.Add_Click($Handler)
    foreach ($child in $Control.Controls) {
        Add-ClickHandlerToTree $child $Handler
    }
}

function Add-Column($Table, [System.Windows.Forms.SizeType]$Type, [double]$Value) {
    $style = New-Object System.Windows.Forms.ColumnStyle
    $style.SizeType = $Type
    $style.Width = $Value
    [void]$Table.ColumnStyles.Add($style)
}

function Add-Row($Table, [System.Windows.Forms.SizeType]$Type, [double]$Value) {
    $style = New-Object System.Windows.Forms.RowStyle
    $style.SizeType = $Type
    $style.Height = $Value
    [void]$Table.RowStyles.Add($style)
}

function New-Table($Rows, $Columns, $BackColor = $null) {
    $table = New-Object System.Windows.Forms.TableLayoutPanel
    $table.RowCount = $Rows
    $table.ColumnCount = $Columns
    $table.Dock = [System.Windows.Forms.DockStyle]::Fill
    $table.Margin = New-Object System.Windows.Forms.Padding(0)
    $table.Padding = New-Object System.Windows.Forms.Padding(0)
    $table.BackColor = $(if ($BackColor) { $BackColor } else { $script:Colors.Bg })
    $table.GrowStyle = [System.Windows.Forms.TableLayoutPanelGrowStyle]::AddRows  # v22: prevents FixedSize full-table startup crashes
    return $table
}

function Enable-CardHover($Control, $HoverBorder = $null, $HoverBack = $null) {
    # v13: huge tweak libraries create hundreds of controls. Per-card hover events look nice,
    # but they make tab switching and scrolling feel heavy on lower-end laptops. Keep the UI smooth.
    if ($script:DisableHeavyHover) { return }
    if ($null -eq $Control) { return }
    $controlType = $Control.GetType()
    $borderProperty = $controlType.GetProperty("BorderColor")
    $backProperty = $controlType.GetProperty("BackColor")
    $hasBorder = ($null -ne $borderProperty -and $borderProperty.CanWrite)
    $hasBack = ($null -ne $backProperty -and $backProperty.CanWrite)
    if (-not $hasBorder -and -not $hasBack) { return }

    $baseBorder = $(if ($hasBorder) { $Control.BorderColor } else { $null })
    $baseBack = $(if ($hasBack) { $Control.BackColor } else { $null })
    $hoverBorderColor = $(if ($HoverBorder) { $HoverBorder } else { $script:Colors.Accent })
    $hoverBackColor = $(if ($HoverBack) { $HoverBack } else { $baseBack })

    $Control.Add_MouseEnter({
        param($sender, $eventArgs)
        if ($null -eq $sender) { return }
        if ($hasBorder) { $sender.BorderColor = $hoverBorderColor }
        if ($hasBack -and $null -ne $hoverBackColor) { $sender.BackColor = $hoverBackColor }
        $sender.Invalidate()
    }.GetNewClosure())
    $Control.Add_MouseLeave({
        param($sender, $eventArgs)
        if ($null -eq $sender) { return }
        if ($hasBorder -and $null -ne $baseBorder) { $sender.BorderColor = $baseBorder }
        if ($hasBack -and $null -ne $baseBack) { $sender.BackColor = $baseBack }
        $sender.Invalidate()
    }.GetNewClosure())
}

function New-StackPanel($Direction = [System.Windows.Forms.FlowDirection]::TopDown, $Wrap = $false, $BackColor = $null) {
    $panel = New-ApexUiControl "ApexSmoothFlowPanel"
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.AutoScroll = $false
    $panel.AutoSize = $false
    $panel.WrapContents = $Wrap
    $panel.FlowDirection = $Direction
    $panel.Margin = New-Object System.Windows.Forms.Padding(0)
    $panel.Padding = New-Object System.Windows.Forms.Padding(0)
    $panel.BackColor = $(if ($BackColor) { $BackColor } else { $script:Colors.Bg })
    $panel.HorizontalScroll.Enabled = $false
    $panel.HorizontalScroll.Visible = $false
    return $panel
}

function Set-ModernScrollValue($ScrollPanel, $Value, $State = $null) {
    if ($null -eq $ScrollPanel -or $ScrollPanel.IsDisposed) { return }
    $max = $(if ($null -ne $State) { [Math]::Max(0, [int]$State.Max) } else { [Math]::Max(0, $ScrollPanel.Height - $ScrollPanel.Parent.ClientSize.Height) })
    $next = [int][Math]::Max(0, [Math]::Min($max, $Value))
    if ($null -ne $State) { $State.Value = $next }
    try {
        $ScrollPanel.Top = -$next
    } catch {}
}

function Add-ModernScrollWheelHandlers($Control, [scriptblock]$WheelHandler, $FocusTarget, $State) {
    if ($null -eq $Control -or $Control.IsDisposed -or $null -eq $WheelHandler -or $null -eq $State) { return }
    $id = [System.Runtime.CompilerServices.RuntimeHelpers]::GetHashCode($Control)
    if (-not $State.WheelHooked.ContainsKey($id)) {
        $State.WheelHooked[$id] = $true
        $Control.Add_MouseWheel($WheelHandler)
        $focus = $FocusTarget
        $Control.Add_MouseEnter({
            if ($null -ne $focus -and -not $focus.IsDisposed) { $focus.Focus() }
        }.GetNewClosure())
    }
}

function Paint-RoundedFill($Graphics, [System.Drawing.Rectangle]$Rect, [int]$Radius, [System.Drawing.Color]$Color) {
    if ($null -eq $Graphics -or $Rect.Width -le 0 -or $Rect.Height -le 0) { return }
    $radius = [Math]::Max(1, [Math]::Min($Radius, [Math]::Min([int]($Rect.Width / 2), [int]($Rect.Height / 2))))
    $diameter = $radius * 2
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    try {
        $path.AddArc($Rect.X, $Rect.Y, $diameter, $diameter, 180, 90)
        $path.AddArc($Rect.Right - $diameter, $Rect.Y, $diameter, $diameter, 270, 90)
        $path.AddArc($Rect.Right - $diameter, $Rect.Bottom - $diameter, $diameter, $diameter, 0, 90)
        $path.AddArc($Rect.X, $Rect.Bottom - $diameter, $diameter, $diameter, 90, 90)
        $path.CloseFigure()
        $brush = New-Object System.Drawing.SolidBrush($Color)
        try {
            $Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $Graphics.FillPath($brush, $path)
        } finally {
            $brush.Dispose()
        }
    } finally {
        $path.Dispose()
    }
}

function Set-ScrollThumbPaintColor($Thumb, [System.Drawing.Color]$Color) {
    if ($null -eq $Thumb -or $Thumb.IsDisposed) { return }
    $Thumb.Tag = $Color
    $Thumb.Invalidate()
}

function Update-ModernScrollBar($ScrollPanel, $Track, $Thumb, $HostPanel = $null, $State = $null) {
    if ($null -eq $ScrollPanel -or $null -eq $Track -or $null -eq $Thumb) { return }
    if ($ScrollPanel.IsDisposed -or $Track.IsDisposed -or $Thumb.IsDisposed) { return }

    $viewportHeight = $(if ($null -ne $ScrollPanel.Parent) { [Math]::Max(1, $ScrollPanel.Parent.ClientSize.Height) } else { [Math]::Max(1, $ScrollPanel.ClientSize.Height) })
    $preferred = $ScrollPanel.GetPreferredSize((New-Object System.Drawing.Size([Math]::Max(1, $ScrollPanel.Width), 0)))
    $contentHeight = [Math]::Max($viewportHeight, [int]$preferred.Height)
    if ($ScrollPanel.Height -ne $contentHeight) { $ScrollPanel.Height = $contentHeight }

    $max = [Math]::Max(0, $contentHeight - $viewportHeight)
    if ($null -ne $State) {
        $State.Max = $max
        if ($State.Value -gt $max) { $State.Value = $max }
        if ($State.Value -lt 0) { $State.Value = 0 }
        $ScrollPanel.Top = -[int]$State.Value
    }
    $trackHeight = [Math]::Max(1, $Track.ClientSize.Height)
    $scrollable = ($max -gt 0)

    $Track.Visible = $scrollable
    if ($null -ne $HostPanel -and -not $HostPanel.IsDisposed) { $HostPanel.Visible = $scrollable }
    if (-not $scrollable) { return }

    $thumbHeight = 0
    if ($null -ne $State -and $State.ThumbHeight -gt 0) {
        $thumbHeight = [int][Math]::Max(34, [Math]::Min($trackHeight, $State.ThumbHeight))
    } else {
        $visibleRatio = [Math]::Min(1.0, [Math]::Max(0.12, $viewportHeight / [double]$contentHeight))
        $thumbHeight = [int][Math]::Max(34, [Math]::Min($trackHeight, $trackHeight * $visibleRatio))
        if ($null -ne $State) {
            $State.ThumbHeight = $thumbHeight
        }
    }
    $value = $(if ($null -ne $State) { [Math]::Max(0, [int]$State.Value) } else { [Math]::Max(0, -$ScrollPanel.Top) })
    $topRange = [Math]::Max(0, $trackHeight - $thumbHeight)
    $top = $(if ($max -gt 0) { [int](($value / [double]$max) * $topRange) } else { 0 })

    $thumb.Width = [Math]::Max(6, $Track.ClientSize.Width)
    $thumb.Height = $thumbHeight
    $thumb.Left = 0
    $thumb.Top = $top
    $thumb.Visible = $true
    $thumb.BringToFront()
}


function New-ClippedScrollHost($ScrollPanel, $BackColor = $null) {
    # v40: premium custom scroll host. This avoids native WinForms scrollbars while keeping
    # the existing FlowLayoutPanel/card rendering and queue/list logic intact.
    $back = $(if ($BackColor) { $BackColor } else { $script:Colors.Bg })
    $scrollHostPanel = New-ApexUiControl "ApexBufferedPanel"
    $scrollHostPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $scrollHostPanel.Margin = New-Object System.Windows.Forms.Padding(0)
    $scrollHostPanel.Padding = New-Object System.Windows.Forms.Padding(0)
    $scrollHostPanel.BackColor = $back
    $scrollHostPanel.AutoScroll = $false
    $scrollHostPanel.TabStop = $true

    $viewport = New-ApexUiControl "ApexBufferedPanel"
    $viewport.Dock = [System.Windows.Forms.DockStyle]::Fill
    $viewport.Margin = New-Object System.Windows.Forms.Padding(0)
    $viewport.Padding = New-Object System.Windows.Forms.Padding(0)
    $viewport.BackColor = $back
    $viewport.AutoScroll = $false
    $viewport.TabStop = $true

    $track = New-ApexUiControl "ApexBufferedPanel"
    $track.Dock = [System.Windows.Forms.DockStyle]::Right
    $track.Width = 12
    $track.Margin = New-Object System.Windows.Forms.Padding(0)
    $track.Padding = New-Object System.Windows.Forms.Padding(0)
    $track.BackColor = $back
    $track.AutoScroll = $false
    $track.Cursor = [System.Windows.Forms.Cursors]::Hand

    $thumb = New-ApexUiControl "ApexRoundedPanel"
    $thumb.Width = 7
    $thumb.Height = 44
    $thumb.Left = 2
    $thumb.Top = 4
    $thumb.Margin = New-Object System.Windows.Forms.Padding(0)
    $thumb.Padding = New-Object System.Windows.Forms.Padding(0)
    $thumb.BackColor = $(if ($script:Colors.ScrollThumb) { $script:Colors.ScrollThumb } else { ColorFromHex "#414866" })
    $thumb.BorderColor = $thumb.BackColor
    $thumb.BorderWidth = 0
    $thumb.CornerRadius = 5
    $thumb.Cursor = [System.Windows.Forms.Cursors]::Hand
    $track.Controls.Add($thumb)

    $ScrollPanel.Dock = [System.Windows.Forms.DockStyle]::None
    $ScrollPanel.AutoSize = $true
    $ScrollPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $ScrollPanel.Margin = New-Object System.Windows.Forms.Padding(0)
    $ScrollPanel.Padding = New-Object System.Windows.Forms.Padding(0, 6, 12, 18)
    $ScrollPanel.BackColor = $back
    try {
        $ScrollPanel.AutoScroll = $false
        $ScrollPanel.HorizontalScroll.Enabled = $false
        $ScrollPanel.HorizontalScroll.Visible = $false
        $ScrollPanel.VerticalScroll.Enabled = $false
        $ScrollPanel.VerticalScroll.Visible = $false
    } catch {}
    if ($ScrollPanel -is [System.Windows.Forms.FlowLayoutPanel]) {
        $ScrollPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
        $ScrollPanel.WrapContents = $true
    }
    $viewport.Controls.Add($ScrollPanel)
    $scrollHostPanel.Controls.Add($viewport)
    $scrollHostPanel.Controls.Add($track)

    $state = @{
        Value = 0
        Max = 0
        Dragging = $false
        DragStartY = 0
        DragStartValue = 0
        LastWheel = 0
        Track = $track
        Thumb = $thumb
        Viewport = $viewport
        Content = $ScrollPanel
    }

    $setValue = $null
    $update = $null

    $setValue = {
        param([int]$NextValue)
        if ($null -eq $state -or $null -eq $ScrollPanel -or $ScrollPanel.IsDisposed) { return }
        $max = [Math]::Max(0, [int]$state.Max)
        $next = [Math]::Max(0, [Math]::Min($max, $NextValue))
        $state.Value = $next
        try { $ScrollPanel.Top = -[int]$state.Value } catch {}
        if ($null -ne $update) { & $update }
    }

    $update = {
        if ($null -eq $viewport -or $viewport.IsDisposed -or $null -eq $ScrollPanel -or $ScrollPanel.IsDisposed) { return }
        try {
            $viewportWidth = [Math]::Max(1, [int]$viewport.ClientSize.Width)
            $viewportHeight = [Math]::Max(1, [int]$viewport.ClientSize.Height)
            $contentWidth = [Math]::Max(1, $viewportWidth - 14)
            if ($ScrollPanel.Width -ne $contentWidth) { $ScrollPanel.Width = $contentWidth }
            $preferred = $ScrollPanel.GetPreferredSize((New-Object System.Drawing.Size($contentWidth, 0)))
            $contentHeight = [Math]::Max($viewportHeight, [int]$preferred.Height)
            if ($ScrollPanel.Height -ne $contentHeight) { $ScrollPanel.Height = $contentHeight }
            $max = [Math]::Max(0, $contentHeight - $viewportHeight)
            $state.Max = $max
            if ([int]$state.Value -gt $max) { $state.Value = $max }
            if ([int]$state.Value -lt 0) { $state.Value = 0 }
            $ScrollPanel.Left = 0
            $ScrollPanel.Top = -[int]$state.Value

            $scrollable = ($max -gt 0)
            $track.Visible = $scrollable
            if (-not $scrollable) { return }
            $trackHeight = [Math]::Max(1, [int]$track.ClientSize.Height - 10)
            $ratio = [Math]::Min(1.0, [Math]::Max(0.08, $viewportHeight / [double][Math]::Max(1, $contentHeight)))
            $thumbHeight = [int][Math]::Max(42, [Math]::Min($trackHeight, $trackHeight * $ratio))
            $range = [Math]::Max(0, $trackHeight - $thumbHeight)
            $top = 5
            if ($max -gt 0 -and $range -gt 0) { $top = 5 + [int](([int]$state.Value / [double]$max) * $range) }
            $thumb.Width = $(if ([bool]$state.Dragging) { 8 } else { 7 })
            $thumb.Height = $thumbHeight
            $thumb.Left = [Math]::Max(1, [int](($track.ClientSize.Width - $thumb.Width) / 2))
            $thumb.Top = $top
            $thumb.BackColor = $(if ([bool]$state.Dragging) { $script:Colors.Accent } elseif ($thumb.ClientRectangle.Contains($thumb.PointToClient([System.Windows.Forms.Control]::MousePosition))) { $script:Colors.ScrollThumbHover } else { $script:Colors.ScrollThumb })
            $thumb.BorderColor = $thumb.BackColor
            $thumb.BringToFront()
            $track.Invalidate()
            $thumb.Invalidate()
        } catch {}
    }

    $state.Update = $update
    $state.SetValue = $setValue
    try { $ScrollPanel.Tag = $state } catch {}

    $wheelHandler = {
        param($sender, $eventArgs)
        try {
            if ($null -eq $eventArgs) { return }
            $direction = $(if ($eventArgs.Delta -gt 0) { -1 } else { 1 })
            $amount = 96
            if ([System.Windows.Forms.Control]::ModifierKeys -band [System.Windows.Forms.Keys]::Shift) { $amount = 180 }
            & $setValue ([int]$state.Value + ($direction * $amount))
            $eventArgs.Handled = $true
        } catch {}
    }.GetNewClosure()

    foreach ($target in @($scrollHostPanel, $viewport, $ScrollPanel, $track, $thumb)) {
        try { $target.Add_MouseWheel($wheelHandler) } catch {}
        try { $target.Add_MouseEnter({ try { $scrollHostPanel.Focus() } catch {} }.GetNewClosure()) } catch {}
    }

    $scrollHostPanel.Add_KeyDown({
        param($sender, $eventArgs)
        try {
            $vh = [Math]::Max(160, [int]$viewport.ClientSize.Height - 40)
            if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::PageDown) { & $setValue ([int]$state.Value + $vh); $eventArgs.Handled = $true }
            elseif ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::PageUp) { & $setValue ([int]$state.Value - $vh); $eventArgs.Handled = $true }
            elseif ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Home) { & $setValue 0; $eventArgs.Handled = $true }
            elseif ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::End) { & $setValue ([int]$state.Max); $eventArgs.Handled = $true }
            elseif ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Down) { & $setValue ([int]$state.Value + 42); $eventArgs.Handled = $true }
            elseif ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Up) { & $setValue ([int]$state.Value - 42); $eventArgs.Handled = $true }
        } catch {}
    }.GetNewClosure())

    $viewport.Add_SizeChanged({ if ($null -ne $update) { & $update } }.GetNewClosure())
    $scrollHostPanel.Add_SizeChanged({ if ($null -ne $update) { & $update } }.GetNewClosure())
    $ScrollPanel.Add_SizeChanged({ if ($null -ne $update) { & $update } }.GetNewClosure())
    $ScrollPanel.Add_ControlAdded({ if ($null -ne $update) { & $update } }.GetNewClosure())
    $ScrollPanel.Add_ControlRemoved({ if ($null -ne $update) { & $update } }.GetNewClosure())
    $ScrollPanel.Add_Layout({ if ($null -ne $update) { & $update } }.GetNewClosure())

    $thumb.Add_MouseEnter({ try { $thumb.BackColor = $script:Colors.ScrollThumbHover; $thumb.BorderColor = $thumb.BackColor; $thumb.Width = 8; $thumb.Invalidate() } catch {} }.GetNewClosure())
    $thumb.Add_MouseLeave({ try { if (-not [bool]$state.Dragging) { $thumb.BackColor = $script:Colors.ScrollThumb; $thumb.BorderColor = $thumb.BackColor; $thumb.Width = 7; & $update } } catch {} }.GetNewClosure())
    $thumb.Add_MouseDown({
        param($sender, $eventArgs)
        if ($eventArgs.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
        $state.Dragging = $true
        $state.DragStartY = [System.Windows.Forms.Control]::MousePosition.Y
        $state.DragStartValue = [int]$state.Value
        try { $thumb.Capture = $true } catch {}
        try { $thumb.BackColor = $script:Colors.Accent; $thumb.BorderColor = $thumb.BackColor; $thumb.Width = 8; $thumb.Invalidate() } catch {}
    }.GetNewClosure())
    $thumb.Add_MouseMove({
        param($sender, $eventArgs)
        if (-not [bool]$state.Dragging) { return }
        try {
            $trackHeight = [Math]::Max(1, [int]$track.ClientSize.Height - 10)
            $range = [Math]::Max(1, $trackHeight - [int]$thumb.Height)
            $delta = [System.Windows.Forms.Control]::MousePosition.Y - [int]$state.DragStartY
            $next = [int]$state.DragStartValue + [int](($delta / [double]$range) * [Math]::Max(1, [int]$state.Max))
            & $setValue $next
        } catch {}
    }.GetNewClosure())
    $thumb.Add_MouseUp({
        $state.Dragging = $false
        try { $thumb.Capture = $false } catch {}
        try { $thumb.BackColor = $script:Colors.ScrollThumbHover; $thumb.BorderColor = $thumb.BackColor; $thumb.Width = 7; & $update } catch {}
    }.GetNewClosure())
    $track.Add_MouseDown({
        param($sender, $eventArgs)
        try {
            if ($eventArgs.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
            if ($eventArgs.Y -lt $thumb.Top) { & $setValue ([int]$state.Value - [Math]::Max(160, [int]$viewport.ClientSize.Height - 60)) }
            elseif ($eventArgs.Y -gt ($thumb.Top + $thumb.Height)) { & $setValue ([int]$state.Value + [Math]::Max(160, [int]$viewport.ClientSize.Height - 60)) }
        } catch {}
    }.GetNewClosure())

    try { $scrollHostPanel.BeginInvoke([Action]{ if ($null -ne $update) { & $update } }) | Out-Null } catch { try { & $update } catch {} }
    return $scrollHostPanel
}

function New-Card($Padding = 16, $BackColor = $null) {
    $card = New-ApexUiControl "ApexRoundedPanel"
    $card.Dock = [System.Windows.Forms.DockStyle]::Fill
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 16, 16)
    $card.Padding = New-Object System.Windows.Forms.Padding($Padding)
    $card.BackColor = $(if ($BackColor) { $BackColor } else { $script:Colors.Card })
    $card.BorderColor = $script:Colors.Line
    $card.CornerRadius = 18
    return $card
}

function New-GradientCard($Padding = 16, $StartColor = $null, $EndColor = $null, $AccentColor = $null, [bool]$ShowGrid = $true) {
    $card = New-ApexUiControl "ApexGradientPanel"
    $card.Dock = [System.Windows.Forms.DockStyle]::Fill
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 16, 16)
    $card.Padding = New-Object System.Windows.Forms.Padding($Padding)
    $card.StartColor = $(if ($StartColor) { $StartColor } else { $script:Colors.Card })
    $card.EndColor = $(if ($EndColor) { $EndColor } else { $script:Colors.Panel2 })
    $card.BackColor = $card.StartColor
    $card.AccentColor = $(if ($AccentColor) { $AccentColor } else { $script:Colors.Accent })
    $card.BorderColor = $script:Colors.Line
    $card.CornerRadius = 20
    $card.ShowGrid = $(if ($script:PerformanceMode) { $false } else { $ShowGrid })
    $card.ShowAccentOrb = $(if ($script:PerformanceMode) { $false } else { $true })
    return $card
}

function New-PillLabel($Text, $Accent = $null, $BackColor = $null) {
    $accentColor = $(if ($Accent) { $Accent } else { $script:Colors.Accent })
    $back = $(if ($BackColor) { $BackColor } else { $script:Colors.Field })
    $pill = New-ApexUiControl "ApexRoundedPanel"
    $pill.Dock = [System.Windows.Forms.DockStyle]::None
    $pill.Width = 118
    $pill.Height = 28
    $pill.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
    $pill.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 8)
    $pill.BackColor = $back
    $pill.BorderColor = $accentColor
    $pill.CornerRadius = 12
    $label = New-FillLabel $Text 8 ([System.Drawing.FontStyle]::Bold) $accentColor
    $label.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $label.Margin = New-Object System.Windows.Forms.Padding(0)
    $pill.Controls.Add($label)
    return $pill
}

function New-HeaderBlock($Eyebrow, $Title, $Subtitle = "", $BackColor = $null) {
    $blockColor = $(if ($BackColor) { $BackColor } else { $script:Colors.Bg })
    $panel = New-Table 3 1 $blockColor
    $panel.AutoSize = $false
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    Add-Row $panel ([System.Windows.Forms.SizeType]::Absolute) 22
    Add-Row $panel ([System.Windows.Forms.SizeType]::Absolute) 38
    Add-Row $panel ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $panel ([System.Windows.Forms.SizeType]::Percent) 100

    $eyebrowLabel = New-FillLabel $Eyebrow 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent
    $eyebrowLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $eyebrowLabel.AutoEllipsis = $true
    $panel.Controls.Add($eyebrowLabel, 0, 0)

    $titleLabel = New-FillLabel $Title 13.8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $titleLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $titleLabel.AutoEllipsis = $true
    $panel.Controls.Add($titleLabel, 0, 1)

    if ($Subtitle.Length -gt 0) {
        $subLabel = New-WrapLabel $Subtitle 8.4 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
        $subLabel.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
        $subLabel.AutoEllipsis = $true
        $panel.Controls.Add($subLabel, 0, 2)
    }
    return $panel
}

function Style-Field($Control) {
    $Control.Dock = [System.Windows.Forms.DockStyle]::Fill
    $Control.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
    $Control.BackColor = $script:Colors.Field
    $Control.ForeColor = $script:Colors.Text
    $Control.Font = New-Font 10
    return $Control
}

function New-FieldGroup($Label, $Control, $BackColor = $null) {
    $groupBack = $(if ($BackColor) { $BackColor } else { $script:Colors.Card })
    $group = New-Table 3 1 $groupBack
    $group.AutoSize = $false
    $group.Dock = [System.Windows.Forms.DockStyle]::Fill
    $group.MinimumSize = New-Object System.Drawing.Size(0, 62)
    $group.Margin = New-Object System.Windows.Forms.Padding(0, 0, 12, 10)
    $group.Padding = New-Object System.Windows.Forms.Padding(0)
    Add-Row $group ([System.Windows.Forms.SizeType]::Absolute) 18
    Add-Row $group ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $group ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $group ([System.Windows.Forms.SizeType]::Percent) 100
    $fieldLabel = New-FillLabel $Label 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $fieldLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $fieldLabel.AutoEllipsis = $true
    $group.Controls.Add($fieldLabel, 0, 0)
    [void](Style-Field $Control)
    $Control.Margin = New-Object System.Windows.Forms.Padding(0)
    $Control.MinimumSize = New-Object System.Drawing.Size(0, 32)
    try { $Control.AccessibleName = $Label } catch {}
    $fieldShell = New-ApexUiControl "ApexRoundedPanel"
    $fieldShell.Dock = [System.Windows.Forms.DockStyle]::Fill
    $fieldShell.Margin = New-Object System.Windows.Forms.Padding(0)
    $fieldShell.Padding = New-Object System.Windows.Forms.Padding(1)
    $fieldShell.BackColor = $script:Colors.Field
    $fieldShell.BorderColor = $script:Colors.Line
    $fieldShell.CornerRadius = 12
    $Control.Dock = [System.Windows.Forms.DockStyle]::Fill
    $fieldShell.Controls.Add($Control)
    $group.Controls.Add($fieldShell, 0, 1)
    return $group
}


function New-Button($Text, $X, $Y, $W, $H, $Kind = "ghost") {
    $buttonType = "ApexGlassButton" -as [type]
    if ($null -ne $buttonType) { $button = [Activator]::CreateInstance($buttonType) } else { $button = New-Object System.Windows.Forms.Button }
    $isLightTheme = ((Get-AppTheme) -eq "light")
    $button.Text = $Text
    $button.Location = New-Object System.Drawing.Point($X, $Y)
    $button.Size = New-Object System.Drawing.Size($W, $H)
    $button.MinimumSize = New-Object System.Drawing.Size(0, 38)
    $button.Font = New-Font 8.6 ([System.Drawing.FontStyle]::Bold)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    try { $button.FlatAppearance.BorderColor = $script:Colors.Line; $button.FlatAppearance.BorderSize = 0 } catch {}
    $button.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    $button.Padding = New-Object System.Windows.Forms.Padding(12, 0, 12, 0)
    $button.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    try { $button.AutoEllipsis = $true } catch {}
    $button.UseCompatibleTextRendering = $false
    $button.UseVisualStyleBackColor = $false
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    try { $button.CornerRadius = 12; $button.BorderColor = $script:Colors.Line; $button.AccentColor = $script:Colors.Accent } catch {}
    if ($Kind -eq "primary") {
        $button.BackColor = $script:Colors.Accent
        $button.ForeColor = ColorFromHex "#FFFFFF"
        try { $button.FlatAppearance.BorderColor = $script:Colors.Accent } catch {}
        try { $button.BorderColor = $(if ($isLightTheme) { ColorFromHex "#4338CA" } else { ColorFromHex "#A78BFA" }) } catch {}
        try { $button.HoverBackColor = $(if ($isLightTheme) { ColorFromHex "#4338CA" } else { ColorFromHex "#7C6DFF" }); $button.DownBackColor = ColorFromHex "#4F46E5" } catch {}
        try { $button.FlatAppearance.MouseOverBackColor = $(if ($isLightTheme) { ColorFromHex "#4338CA" } else { ColorFromHex "#7C6DFF" }); $button.FlatAppearance.MouseDownBackColor = ColorFromHex "#4F46E5" } catch {}
    } elseif ($Kind -eq "secondary") {
        $button.BackColor = $(if ($isLightTheme) { ColorFromHex "#EEF2FF" } else { ColorFromHex "#172033" })
        $button.ForeColor = $(if ($isLightTheme) { $script:Colors.Accent } else { ColorFromHex "#EDEBFF" })
        try { $button.BorderColor = $(if ($isLightTheme) { ColorFromHex "#C7D2FE" } else { ColorFromHex "#41517A" }) } catch {}
        try { $button.HoverBackColor = $(if ($isLightTheme) { ColorFromHex "#E0E7FF" } else { ColorFromHex "#202B46" }); $button.DownBackColor = $(if ($isLightTheme) { ColorFromHex "#C7D2FE" } else { ColorFromHex "#111827" }) } catch {}
        try { $button.FlatAppearance.BorderColor = $(if ($isLightTheme) { ColorFromHex "#C7D2FE" } else { ColorFromHex "#41517A" }) } catch {}
        try { $button.FlatAppearance.MouseOverBackColor = $(if ($isLightTheme) { ColorFromHex "#E0E7FF" } else { ColorFromHex "#202B46" }); $button.FlatAppearance.MouseDownBackColor = $(if ($isLightTheme) { ColorFromHex "#C7D2FE" } else { ColorFromHex "#111827" }) } catch {}
    } else {
        $button.BackColor = $(if ($isLightTheme) { ColorFromHex "#F8FAFC" } else { ColorFromHex "#101827" })
        $button.ForeColor = $script:Colors.Text
        try { $button.BorderColor = $script:Colors.Line; $button.HoverBackColor = $script:Colors.Hover; $button.DownBackColor = $script:Colors.Panel2 } catch {}
        try { $button.FlatAppearance.MouseOverBackColor = $script:Colors.Hover; $button.FlatAppearance.MouseDownBackColor = $script:Colors.Panel2 } catch {}
    }
    return $button
}


function New-ApexNavIconBitmap($Code, [System.Drawing.Color]$Color, [System.Drawing.Color]$BackColor) {
    $size = 26
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    try {
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.Clear([System.Drawing.Color]::Transparent)
        $rect = New-Object System.Drawing.Rectangle -ArgumentList 2, 2, ($size - 5), ($size - 5)
        $fill = [System.Drawing.Color]::FromArgb(18, $Color.R, $Color.G, $Color.B)
        $brush = New-Object System.Drawing.SolidBrush($fill)
        $pen = New-Object System.Drawing.Pen($Color, 1.45)
        try {
            $g.FillEllipse($brush, $rect)
            $g.DrawEllipse($pen, $rect)
            $label = ([string]$Code).ToUpperInvariant()
            switch ($label) {
                "DB" {
                    $g.DrawRectangle($pen, 8, 8, 4, 4); $g.DrawRectangle($pen, 14, 8, 4, 4)
                    $g.DrawRectangle($pen, 8, 14, 4, 4); $g.DrawRectangle($pen, 14, 14, 4, 4)
                }
                "OP" { $g.DrawLines($pen, @([System.Drawing.Point]::new(14,6),[System.Drawing.Point]::new(9,14),[System.Drawing.Point]::new(14,14),[System.Drawing.Point]::new(11,20),[System.Drawing.Point]::new(18,11),[System.Drawing.Point]::new(13,11))) }
                "PF" { $g.DrawLine($pen,7,18,11,14); $g.DrawLine($pen,11,14,14,16); $g.DrawLine($pen,14,16,19,9) }
                "NT" { $g.DrawEllipse($pen,7,7,12,12); $g.DrawLine($pen,7,13,19,13); $g.DrawLine($pen,13,7,13,19) }
                "SU" { $g.DrawArc($pen,7,8,12,12,35,290); $g.DrawLine($pen,13,6,13,13) }
                "GP" { $g.DrawRectangle($pen,7,8,12,8); $g.DrawLine($pen,13,16,13,19); $g.DrawLine($pen,10,19,16,19) }
                "AI" { $g.DrawEllipse($pen,8,8,4,4); $g.DrawEllipse($pen,15,9,4,4); $g.DrawEllipse($pen,11,16,4,4); $g.DrawLine($pen,12,10,15,11); $g.DrawLine($pen,16,13,14,16); $g.DrawLine($pen,10,12,12,16) }
                "AC" { $g.DrawEllipse($pen,7,7,12,12); $g.DrawLine($pen,13,13,13,9); $g.DrawLine($pen,13,13,17,15) }
                "ST" { $g.DrawEllipse($pen,9,9,8,8); $g.DrawLine($pen,13,5,13,8); $g.DrawLine($pen,13,18,13,21); $g.DrawLine($pen,5,13,8,13); $g.DrawLine($pen,18,13,21,13) }
                default {
                    $font = New-Object System.Drawing.Font("Segoe UI", 6.4, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Point)
                    $textBrush = New-Object System.Drawing.SolidBrush($Color)
                    $format = New-Object System.Drawing.StringFormat
                    try {
                        $format.Alignment = [System.Drawing.StringAlignment]::Center
                        $format.LineAlignment = [System.Drawing.StringAlignment]::Center
                        if ($label.Length -gt 2) { $label = $label.Substring(0, 2) }
                        $rectF = New-Object System.Drawing.RectangleF -ArgumentList ([single]$rect.X), ([single]$rect.Y), ([single]$rect.Width), ([single]$rect.Height)
                        $g.DrawString($label, $font, $textBrush, $rectF, $format)
                    } finally {
                        $format.Dispose(); $textBrush.Dispose(); $font.Dispose()
                    }
                }
            }
        } finally {
            $brush.Dispose(); $pen.Dispose()
        }
    } finally {
        $g.Dispose()
    }
    return $bmp
}

function Set-ApexNavButtonIcon($Button, [bool]$Active) {
    if ($null -eq $Button -or $Button.IsDisposed) { return }
    $code = [string]$Button.AccessibleDescription
    if ([string]::IsNullOrWhiteSpace($code)) { return }
    $color = $(if ($Active) { $script:Colors.Text } else { $script:Colors.Muted })
    $old = $Button.Image
    try { $Button.Image = New-ApexNavIconBitmap $code $color $Button.BackColor } catch {}
    try { if ($null -ne $old) { $old.Dispose() } } catch {}
}

function New-NavButton($Code, $Text, $View) {
    $compact = [bool]$script:SidebarCompact
    $buttonText = $(if ($compact) { "" } else { "  " + $Text })
    $button = New-Button $buttonText 0 0 0 0 "ghost"
    $button.Tag = $View
    $button.AccessibleName = "Open $Text"
    $button.AccessibleDescription = ([string]$Code).ToUpperInvariant()
    $button.Dock = [System.Windows.Forms.DockStyle]::Fill
    $button.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 7)
    $button.TextAlign = $(if ($compact) { [System.Drawing.ContentAlignment]::MiddleCenter } else { [System.Drawing.ContentAlignment]::MiddleLeft })
    $button.ImageAlign = $(if ($compact) { [System.Drawing.ContentAlignment]::MiddleCenter } else { [System.Drawing.ContentAlignment]::MiddleLeft })
    $button.TextImageRelation = [System.Windows.Forms.TextImageRelation]::ImageBeforeText
    $button.Padding = $(if ($compact) { New-Object System.Windows.Forms.Padding(0) } else { New-Object System.Windows.Forms.Padding(12, 0, 10, 0) })
    $button.Font = New-Font 9.8 ([System.Drawing.FontStyle]::Bold)
    $button.FlatAppearance.BorderColor = $script:Colors.Line
    $button.MinimumSize = New-Object System.Drawing.Size(0, [int]$script:UiTokens.SidebarNavHeight)
    try { $button.CornerRadius = 14; $button.BorderColor = $script:Colors.Line; $button.AccentColor = $script:Colors.Accent } catch {}
    Set-ApexNavButtonIcon $button $false
    Set-ApexToolTip $button $Text
    return $button
}


function Invoke-WindowDrag($MouseArgs) {
    if ($null -eq $script:Form -or $MouseArgs.Button -ne [System.Windows.Forms.MouseButtons]::Left) { return }
    [void][ApexWindowChrome]::ReleaseCapture()
    [void][ApexWindowChrome]::SendMessage($script:Form.Handle, 0xA1, 0x2, 0)
}

function New-WindowButton($Text, $HoverColor, $IconKind = "") {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $(if ([string]::IsNullOrWhiteSpace($IconKind)) { $Text } else { "" })
    $button.Dock = [System.Windows.Forms.DockStyle]::Fill
    $button.Margin = New-Object System.Windows.Forms.Padding(0)
    $button.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 2)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderSize = 0
    $button.FlatAppearance.MouseOverBackColor = $HoverColor
    $button.FlatAppearance.MouseDownBackColor = $(if ((Get-AppTheme) -eq "light") { $script:Colors.Panel2 } else { ColorFromHex "#111111" })
    $button.BackColor = $script:Colors.Bg
    $button.ForeColor = $script:Colors.Muted
    $button.Font = New-Font 10 ([System.Drawing.FontStyle]::Bold)
    $button.TabStop = $false
    $button.UseVisualStyleBackColor = $false
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    if (-not [string]::IsNullOrWhiteSpace($IconKind)) {
        $button.Tag = $IconKind
        $button.Add_Paint({
            param($sender, $eventArgs)
            if ($null -eq $sender -or $null -eq $eventArgs) { return }
            $g = $eventArgs.Graphics
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $color = $(if ($sender.Tag -eq "close") { $script:Colors.Text } else { $script:Colors.Muted })
            $pen = New-Object System.Drawing.Pen($color, 1.55)
            try {
                $cx = [int][Math]::Floor($sender.ClientSize.Width / 2)
                $cy = [int][Math]::Floor($sender.ClientSize.Height / 2)
                if ($sender.Tag -eq "min") {
                    $g.DrawLine($pen, $cx - 6, $cy + 5, $cx + 6, $cy + 5)
                } elseif ($sender.Tag -eq "max") {
                    if ($script:Form -and $script:Form.WindowState -eq [System.Windows.Forms.FormWindowState]::Maximized) {
                        $back = New-Object System.Drawing.Rectangle -ArgumentList ([int]($cx - 3)), ([int]($cy - 7)), 10, 8
                        $front = New-Object System.Drawing.Rectangle -ArgumentList ([int]($cx - 7)), ([int]($cy - 3)), 10, 8
                        $g.DrawRectangle($pen, $back)
                        $g.DrawRectangle($pen, $front)
                    } else {
                        $rect = New-Object System.Drawing.Rectangle -ArgumentList ([int]($cx - 6)), ([int]($cy - 5)), 12, 10
                        $g.DrawRectangle($pen, $rect)
                    }
                } elseif ($sender.Tag -eq "close") {
                    $g.DrawLine($pen, $cx - 5, $cy - 5, $cx + 5, $cy + 5)
                    $g.DrawLine($pen, $cx + 5, $cy - 5, $cx - 5, $cy + 5)
                }
            } finally {
                $pen.Dispose()
            }
        })
    }
    return $button
}

function New-AppTitleBar {
    $bar = New-Table 1 3 $script:Colors.Bg
    $bar.Height = 42
    $bar.Margin = New-Object System.Windows.Forms.Padding(0)
    $bar.Padding = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    Add-Column $bar ([System.Windows.Forms.SizeType]::Absolute) 42
    Add-Column $bar ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $bar ([System.Windows.Forms.SizeType]::Absolute) 138
    Add-Row $bar ([System.Windows.Forms.SizeType]::Percent) 100

    $mark = New-AppMarkLabel 8.5
    $mark.Dock = [System.Windows.Forms.DockStyle]::Fill
    $mark.Margin = New-Object System.Windows.Forms.Padding(0, 6, 10, 6)
    $bar.Controls.Add($mark, 0, 0)

    $title = New-FillLabel "ApexTune Command" 9 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $title.Margin = New-Object System.Windows.Forms.Padding(0)
    $bar.Controls.Add($title, 1, 0)

    $buttons = New-Table 1 3 $script:Colors.Bg
    foreach ($i in 1..3) { Add-Column $buttons ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    Add-Row $buttons ([System.Windows.Forms.SizeType]::Percent) 100
    $windowHover = $(if ((Get-AppTheme) -eq "light") { $script:Colors.Panel2 } else { ColorFromHex "#202020" })
    $closeHover = $(if ((Get-AppTheme) -eq "light") { ColorFromHex "#FEE2E2" } else { ColorFromHex "#7F1D1D" })
    $min = New-WindowButton "-" $windowHover "min"
    $max = New-WindowButton "" $windowHover "max"
    $close = New-WindowButton "X" $closeHover "close"
    $min.Add_Click({
        param($sender, $eventArgs)
        try {
            $targetForm = $null
            try { if ($null -ne $sender) { $targetForm = $sender.FindForm() } } catch {}
            if ($null -eq $targetForm -and $script:Form -is [System.Windows.Forms.Form]) { $targetForm = $script:Form }
            if ($null -ne $targetForm) { $targetForm.WindowState = [System.Windows.Forms.FormWindowState]::Minimized }
        } catch {
            try { Show-Toast ("Minimize failed safely: " + $_.Exception.Message) "ApexTune" } catch {}
        }
    })
    $max.Add_Click({
        param($sender, $eventArgs)
        $targetForm = $null
        try { if ($null -ne $sender) { $targetForm = $sender.FindForm() } } catch {}
        if ($null -eq $targetForm -and $script:Form -is [System.Windows.Forms.Form]) { $targetForm = $script:Form }
        if ($null -ne $targetForm -and $targetForm.WindowState -eq [System.Windows.Forms.FormWindowState]::Maximized) {
            $targetForm.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        } elseif ($null -ne $targetForm) {
            $targetForm.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
        }
        if ($null -ne $sender -and -not $sender.IsDisposed) { $sender.Invalidate() }
    }.GetNewClosure())
    $close.Add_Click({ $script:Form.Close() })
    $buttons.Controls.Add($min, 0, 0)
    $buttons.Controls.Add($max, 1, 0)
    $buttons.Controls.Add($close, 2, 0)
    $bar.Controls.Add($buttons, 2, 0)

    $dragHandler = { param($sender, $eventArgs) Invoke-WindowDrag $eventArgs }
    $bar.Add_MouseDown($dragHandler)
    $title.Add_MouseDown($dragHandler)
    $mark.Add_MouseDown($dragHandler)
    $bar.Add_DoubleClick({ $max.PerformClick() })
    $title.Add_DoubleClick({ $max.PerformClick() })
    $script:Form.Add_SizeChanged({
        if ($null -ne $max -and -not $max.IsDisposed) { $max.Invalidate() }
    }.GetNewClosure())
    return $bar
}

function Add-AppSurface($Body) {
    $surface = New-Table 2 1 $script:Colors.Bg
    Add-Row $surface ([System.Windows.Forms.SizeType]::Absolute) 42
    Add-Row $surface ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $surface ([System.Windows.Forms.SizeType]::Percent) 100
    $script:Form.Controls.Add($surface)
    $surface.Controls.Add((New-AppTitleBar), 0, 0)
    $Body.Dock = [System.Windows.Forms.DockStyle]::Fill
    $surface.Controls.Add($Body, 0, 1)
}

function New-TextBox($X, $Y, $W, $H, $Password = $false) {
    $box = New-Object System.Windows.Forms.TextBox
    $box.Location = New-Object System.Drawing.Point($X, $Y)
    $box.Size = New-Object System.Drawing.Size($W, $H)
    $box.Font = New-Font 10
    $box.BackColor = $script:Colors.Field
    $box.ForeColor = $script:Colors.Text
    $box.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $box.UseSystemPasswordChar = $Password
    return $box
}

function New-Combo($Items, $X, $Y, $W, $H, $Selected) {
    $comboType = "ApexComboBox" -as [type]
    if ($null -ne $comboType) { $combo = [Activator]::CreateInstance($comboType) } else { $combo = New-Object System.Windows.Forms.ComboBox }
    $combo.Location = New-Object System.Drawing.Point($X, $Y)
    $combo.Size = New-Object System.Drawing.Size($W, 34)
    $combo.MinimumSize = New-Object System.Drawing.Size(0, 32)
    $combo.Font = New-Font 8.6 ([System.Drawing.FontStyle]::Bold)
    $combo.BackColor = $script:Colors.Field
    $combo.ForeColor = $script:Colors.Text
    $combo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $combo.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $combo.IntegralHeight = $false
    $combo.DropDownHeight = 252
    $combo.ItemHeight = 24
    try {
        $combo.ItemBackColor = $script:Colors.Field
        $combo.ItemHoverBackColor = $script:Colors.Hover
        $combo.ItemForeColor = $script:Colors.Text
    } catch {}
    [void]$combo.Items.AddRange($Items)
    $selectedText = [string]$Selected
    $selectedIndex = $combo.Items.IndexOf($selectedText)
    if ($selectedIndex -lt 0 -and $combo.Items.Count -gt 0) { $selectedIndex = 0 }
    if ($selectedIndex -ge 0) { $combo.SelectedIndex = $selectedIndex }
    try {
        $combo.AccessibleName = "ApexTune profile dropdown"
        if ($script:ApexToolTip) { $script:ApexToolTip.SetToolTip($combo, "Choose the detected profile for safer recommended tweaks.") }
    } catch {}
    return $combo
}


function Set-ApexToolTip($Control, [string]$Text) {
    if ($null -eq $Control -or [string]::IsNullOrWhiteSpace($Text)) { return }
    try {
        if ($script:ApexToolTip) { $script:ApexToolTip.SetToolTip($Control, $Text) }
        if ([string]::IsNullOrWhiteSpace([string]$Control.AccessibleDescription)) { $Control.AccessibleDescription = $Text }
    } catch {}
}


function Get-ApexShortChipText($Text) {
    $value = ([string]$Text).Trim()
    $upper = $value.ToUpperInvariant()
    $map = @{
        "MAINTENANCE" = "MAINT"; "MAINTENANCE / STORAGE" = "MAINT"; "DIRECTX" = "DX"; "REGISTRY" = "REG";
        "WINDOWS" = "WIN"; "POWER" = "PWR"; "NETWORK" = "NET"; "INPUT" = "INPUT"; "AUDIO" = "AUDIO";
        "NO RESTART" = "NO RST"; "NO RST" = "NO RST"; "RESTART" = "RST"; "MEDIUM" = "MED"; "HIGH" = "HIGH"; "LOW" = "LOW";
        "GPU / DISPLAY" = "GPU"; "PERFORMANCE / POWER" = "PWR"; "INPUT / LATENCY" = "INPUT"; "SERVICES / STARTUP" = "START";
        "DIAGNOSTICS" = "DIAG"; "CLEANUP" = "CLEAN"; "MAINTENANC" = "MAINT"; "DIREC" = "DX"; "REGIST" = "REG"
    }
    if ($map.ContainsKey($upper)) { return $map[$upper] }
    if ($upper.Length -gt 10) { return $upper.Substring(0, [Math]::Min(6, $upper.Length)) }
    return $upper
}

function New-ApexChip($Text, $Accent = $null, $BackColor = $null, [int]$MinWidth = 58, [int]$MaxWidth = 110) {
    $accentColor = $(if ($Accent) { $Accent } else { $script:Colors.Accent })
    $back = $(if ($BackColor) { $BackColor } else { $script:Colors.Field })
    $full = [string]$Text
    $short = Get-ApexShortChipText $full
    $font = New-Font 7.8 ([System.Drawing.FontStyle]::Bold)
    $measure = [System.Windows.Forms.TextRenderer]::MeasureText($short, $font)
    $height = $(if ($script:UiTokens.Contains("ChipHeight")) { [int]$script:UiTokens.ChipHeight } else { 26 })
    $desired = [Math]::Max($MinWidth, [int]($measure.Width + 24))
    if ($MaxWidth -gt 0) { $desired = [Math]::Min($MaxWidth, $desired) }
    if ($desired -lt ($measure.Width + 18)) { $desired = [int]($measure.Width + 18) }

    $chip = New-ApexUiControl "ApexRoundedPanel"
    $chip.Dock = [System.Windows.Forms.DockStyle]::None
    $chip.Width = $desired
    $chip.Height = $height
    $chip.MinimumSize = New-Object System.Drawing.Size($desired, $height)
    $chip.MaximumSize = New-Object System.Drawing.Size($desired, $height)
    $chip.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 6)
    $chip.Padding = New-Object System.Windows.Forms.Padding(7, 0, 7, 0)
    $chip.BackColor = $back
    try { $chip.BorderColor = $accentColor; $chip.BorderWidth = 1; $chip.CornerRadius = [Math]::Max(8, [int]($height / 2)) } catch {}
    $chip.TabStop = $false
    $chip.Cursor = [System.Windows.Forms.Cursors]::Default
    $chip.AccessibleName = "Chip " + $full

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $short
    $label.Dock = [System.Windows.Forms.DockStyle]::Fill
    $label.AutoSize = $false
    $label.AutoEllipsis = $true
    $label.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $label.Font = $font
    $label.ForeColor = $accentColor
    $label.BackColor = $back
    $label.Margin = New-Object System.Windows.Forms.Padding(0)
    $label.Padding = New-Object System.Windows.Forms.Padding(0)
    $label.UseCompatibleTextRendering = $false
    $label.AccessibleName = "Chip " + $full
    $chip.Controls.Add($label)
    Set-ApexToolTip $chip $full
    Set-ApexToolTip $label $full
    return $chip
}

function New-Badge($Text, $Accent = $null, $BackColor = $null, [int]$Width = 76) {
    $accentColor = $(if ($Accent) { $Accent } else { $script:Colors.Accent })
    $back = $(if ($BackColor) { $BackColor } else { $script:Colors.Field })
    $badge = New-ApexUiControl "ApexRoundedPanel"
    $badge.Dock = [System.Windows.Forms.DockStyle]::Fill
    $badge.MinimumSize = New-Object System.Drawing.Size($Width, 28)
    $badge.Padding = New-Object System.Windows.Forms.Padding(8, 0, 8, 0)
    $badge.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 0)
    $badge.BackColor = $back
    $badge.BorderColor = $accentColor
    $badge.CornerRadius = 11
    $label = New-FillLabel ([string]$Text) 7.2 ([System.Drawing.FontStyle]::Bold) $accentColor
    $label.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $label.Margin = New-Object System.Windows.Forms.Padding(0)
    $badge.Controls.Add($label)
    return $badge
}

function New-SectionTitle($Eyebrow, $Title, $Subtitle, $BackColor = $null) {
    $panel = New-Table 3 1 $(if ($BackColor) { $BackColor } else { $script:Colors.Card })
    Add-Row $panel ([System.Windows.Forms.SizeType]::Absolute) 22
    Add-Row $panel ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $panel ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $panel ([System.Windows.Forms.SizeType]::Percent) 100
    $eye = New-FillLabel ([string]$Eyebrow).ToUpperInvariant() 8.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent
    $eye.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $head = New-FillLabel ([string]$Title) 13.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $head.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $sub = New-FillLabel ([string]$Subtitle) 8.8 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $sub.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $panel.Controls.Add($eye, 0, 0)
    $panel.Controls.Add($head, 0, 1)
    $panel.Controls.Add($sub, 0, 2)
    return $panel
}

function Show-Toast($Text, $Title = "ApexTune") {
    try {
        $host = $(if ($null -ne $script:ContentHost -and -not $script:ContentHost.IsDisposed) { $script:ContentHost } else { $script:Form })
        if ($null -eq $host -or $host.IsDisposed) { return }
        if ($null -ne $script:ToastPanel -and -not $script:ToastPanel.IsDisposed) {
            try { $script:ToastPanel.Parent.Controls.Remove($script:ToastPanel) } catch {}
            try { $script:ToastPanel.Dispose() } catch {}
        }
        $toast = New-ApexUiControl "ApexRoundedPanel"
        $toast.Width = [Math]::Min(460, [Math]::Max(320, $host.ClientSize.Width - 52))
        $toast.Height = 82
        $toast.Left = [Math]::Max(18, $host.ClientSize.Width - $toast.Width - 26)
        $toast.Top = 22
        $toast.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Right
        $toast.Padding = New-Object System.Windows.Forms.Padding(16, 12, 16, 12)
        $toast.BackColor = $script:Colors.Panel2
        $toast.BorderColor = $script:Colors.Accent
        $toast.CornerRadius = 18
        $grid = New-Table 2 1 $toast.BackColor
        Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 26
        Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
        Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
        $titleLabel = New-FillLabel ([string]$Title) 9.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Teal
        $titleLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $msgLabel = New-FillLabel ([string]$Text) 8.8 ([System.Drawing.FontStyle]::Regular) $script:Colors.Text
        $msgLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
        $grid.Controls.Add($titleLabel, 0, 0)
        $grid.Controls.Add($msgLabel, 0, 1)
        $toast.Controls.Add($grid)
        $host.Controls.Add($toast)
        $toast.BringToFront()
        $script:ToastPanel = $toast
        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 2800
        $timer.Add_Tick({
            try { $timer.Stop(); $timer.Dispose() } catch {}
            try {
                if ($null -ne $toast -and -not $toast.IsDisposed) {
                    if ($toast.Parent) { $toast.Parent.Controls.Remove($toast) }
                    $toast.Dispose()
                }
            } catch {}
        }.GetNewClosure())
        $timer.Start()
    } catch {
        try { [System.Windows.Forms.MessageBox]::Show($script:Form, $Text, $Title, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null } catch {}
    }
}


function Invoke-ManualRestorePoint {
    if (-not (Test-Admin)) {
        $choice = [System.Windows.Forms.MessageBox]::Show(
            $script:Form,
            "Creating a Windows restore point requires administrator rights. Relaunch ApexTune as administrator?",
            "Administrator required",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) {
            Save-CurrentUser
            if ($script:State.User -and $script:State.User.Username) {
                Save-Session $script:State.User.Username $true
            }
            Relaunch-AsAdmin
            if ($script:Form) { $script:Form.Close() }
        }
        return
    }

    Append-Log "Creating manual restore point"
    if ($script:Form) { $script:Form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor }
    try {
        $output = Checkpoint-Computer -Description "ApexTune manual restore point" -RestorePointType "MODIFY_SETTINGS" 2>&1
        foreach ($line in $output) { Append-Log ($line.ToString()) }
        Show-Toast "Windows restore point request completed." "Restore point"
    } catch {
        $message = "Windows could not create the restore point: " + $_.Exception.Message
        Append-Log $message
        Show-Toast $message "Restore point warning"
    } finally {
        if ($script:Form) { $script:Form.Cursor = [System.Windows.Forms.Cursors]::Default }
    }
}

function Refresh-CurrentView {
    $view = $(if ($script:ActiveView) { [string]$script:ActiveView } else { "dashboard" })
    $script:ActiveView = $null
    Show-View $view
}

function Invoke-HardwareRescan {
    if ($script:Form) { $script:Form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor }
    try {
        $script:State["Hardware"] = Get-SystemHardwareInfo
        Apply-HardwareProfile $script:State.Hardware
        Save-CurrentUser
        Refresh-CurrentView
        Show-Toast "Hardware profile refreshed. ApexTune updated the GPU, network, and system filters from the newest scan." "Hardware rescan"
    } catch {
        Show-Toast ("Hardware rescan failed: " + $_.Exception.Message) "Hardware rescan"
    } finally {
        if ($script:Form) { $script:Form.Cursor = [System.Windows.Forms.Cursors]::Default }
    }
}

function Start-HardwareAutoScan {
    if ($script:HardwareAutoScanStarted) { return }
    $script:HardwareAutoScanStarted = $true
    if ($null -eq $script:Form -or $script:Form.IsDisposed) { return }

    $delayTimer = New-Object System.Windows.Forms.Timer
    $delayTimer.Interval = 1400
    $delayTimer.Add_Tick({
        try { $delayTimer.Stop() } catch {}
        try { $delayTimer.Dispose() } catch {}
        try {
            if ($null -ne $script:HardwareScanJob) { return }
            $script:HardwareScanJob = Start-Job -Name "ApexTuneHardwareScan" -ScriptBlock {
                function FirstText($Value, $Fallback) {
                    if ($null -eq $Value) { return $Fallback }
                    $text = ([string]$Value).Trim()
                    if ([string]::IsNullOrWhiteSpace($text)) { return $Fallback }
                    return $text
                }

                $computer = $null; $os = $null; $cpu = $null; $gpus = @(); $enclosure = $null; $battery = $null; $activeAdapters = @()
                try { $computer = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop } catch {}
                try { $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop } catch {}
                try { $cpu = Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch {}
                try { $gpus = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name }) } catch {}
                if ($gpus.Count -eq 0) {
                    try { $gpus = @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Name -match "NVIDIA|GeForce|RTX|GTX|AMD|Radeon|Intel|Arc|Iris|UHD|Graphics" }) } catch {}
                }
                try { $enclosure = Get-CimInstance -ClassName Win32_SystemEnclosure -ErrorAction Stop | Select-Object -First 1 } catch {}
                try { $battery = Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue | Select-Object -First 1 } catch {}
                try { $activeAdapters = @(Get-NetAdapter -ErrorAction Stop | Where-Object { $_.Status -eq "Up" }) } catch {
                    try { $activeAdapters = @(Get-CimInstance -ClassName Win32_NetworkAdapter -ErrorAction Stop | Where-Object { $_.NetConnectionStatus -eq 2 }) } catch {}
                }

                $gpuNames = @($gpus | ForEach-Object { $_.Name } | Where-Object { $_ })
                $gpuText = if ($gpuNames.Count -gt 0) { ($gpuNames -join " + ") } else { "Unknown GPU" }
                $gpuJoined = $gpuText.ToLowerInvariant()
                $gpuVendor = "other"
                if ($gpuJoined -match "nvidia|geforce|rtx|gtx|quadro|nvlddmkm") { $gpuVendor = "nvidia" }
                elseif ($gpuJoined -match "amd|radeon|rx\s|vega|adrenalin") { $gpuVendor = "amd" }
                elseif ($gpuJoined -match "intel|arc|iris|uhd|hd graphics|xe graphics") { $gpuVendor = "intel" }

                $isLaptop = $false
                if ($enclosure -and $enclosure.ChassisTypes) { foreach ($type in @($enclosure.ChassisTypes)) { if (@(8,9,10,11,12,14,18,21,30,31,32) -contains [int]$type) { $isLaptop = $true } } }
                if ($battery) { $isLaptop = $true }
                $systemType = if ($isLaptop) { "laptop" } else { "desktop" }

                $adapterNames = @($activeAdapters | ForEach-Object {
                    $name = $_.Name
                    $description = $_.InterfaceDescription
                    if (-not $description) { $description = $_.Description }
                    (($name, $description) -join " ").Trim()
                } | Where-Object { $_.Length -gt 0 })
                $adapterText = if ($adapterNames.Count -gt 0) { ($adapterNames -join " + ") } else { "No active adapter detected - choose Ethernet or Wi-Fi manually" }
                $networkType = if ($adapterText.ToLowerInvariant() -match "wi-fi|wifi|wireless|wlan|802\.11") { "wifi" } else { "ethernet" }

                $ramGb = "Unknown RAM"
                if ($computer -and $computer.TotalPhysicalMemory) { $ramGb = ([math]::Round(($computer.TotalPhysicalMemory / 1GB), 0).ToString() + " GB RAM") }
                $osText = "Windows"
                if ($os) {
                    $build = FirstText $os.BuildNumber ""
                    $caption = FirstText $os.Caption "Windows"
                    $osText = if ($build.Length -gt 0) { "$caption build $build" } else { $caption }
                }
                $modelText = "Unknown PC"
                if ($computer) {
                    $maker = FirstText $computer.Manufacturer ""
                    $model = FirstText $computer.Model ""
                    $modelText = (($maker, $model) | Where-Object { $_ -and $_.Trim().Length -gt 0 }) -join " "
                    if ([string]::IsNullOrWhiteSpace($modelText)) { $modelText = "Unknown PC" }
                }

                [pscustomobject]@{
                    GpuVendor = $gpuVendor
                    GpuName = $gpuText
                    Network = $networkType
                    NetworkName = $adapterText
                    System = $systemType
                    CpuName = FirstText $cpu.Name "Unknown CPU"
                    Ram = $ramGb
                    Os = $osText
                    Model = $modelText
                    DetectedAt = (Get-Date).ToString("g")
                }
            }

            $pollTimer = New-Object System.Windows.Forms.Timer
            $pollTimer.Interval = 900
            $pollTimer.Add_Tick({
                try {
                    if ($null -eq $script:HardwareScanJob) { return }
                    if ($script:HardwareScanJob.State -notin @("Completed", "Failed", "Stopped")) { return }
                    try { $pollTimer.Stop() } catch {}
                    try { $pollTimer.Dispose() } catch {}
                    $result = $null
                    if ($script:HardwareScanJob.State -eq "Completed") {
                        try { $result = Receive-Job -Job $script:HardwareScanJob -ErrorAction Stop | Select-Object -First 1 } catch {}
                    }
                    try { Remove-Job -Job $script:HardwareScanJob -Force -ErrorAction SilentlyContinue } catch {}
                    $script:HardwareScanJob = $null
                    $script:HardwareScanTimer = $null
                    if ($null -ne $result) {
                        $script:State["Hardware"] = $result
                        Apply-HardwareProfile $script:State.Hardware
                        Save-CurrentUser
                        if ($script:ActiveView -in @("dashboard", "optimize", "performance", "network", "startup", "gpu")) { Refresh-CurrentView }
                    }
                } catch {
                    try { $pollTimer.Stop() } catch {}
                    try { $pollTimer.Dispose() } catch {}
                    $script:HardwareScanJob = $null
                    $script:HardwareScanTimer = $null
                }
            }.GetNewClosure())
            $script:HardwareScanTimer = $pollTimer
            $pollTimer.Start()
        } catch {
            $script:HardwareScanJob = $null
        }
    }.GetNewClosure())
    $delayTimer.Start()
}


function Open-ExternalLink($Url) {
    try {
        Start-Process ([string]$Url)
    } catch {
        Show-Toast ("Could not open link: " + $_.Exception.Message) "Open link"
    }
}


function Get-GpuDriverInfo {
    $hardware = $script:State.Hardware
    $video = @()
    try { $video = @(Get-CimInstance -ClassName Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name }) } catch {}
    $signedDrivers = @()
    try { $signedDrivers = @(Get-CimInstance -ClassName Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceClass -eq "DISPLAY" -and $_.DeviceName }) } catch {}
    if ($video.Count -eq 0 -and $signedDrivers.Count -gt 0) { $video = $signedDrivers }

    function Get-DisplayRank($adapter) {
        $adapterName = ""
        if ($adapter -and $adapter.Name) { $adapterName = [string]$adapter.Name }
        elseif ($adapter -and $adapter.DeviceName) { $adapterName = [string]$adapter.DeviceName }
        $n = $adapterName.ToLowerInvariant()
        if ($n -match "nvidia|geforce|rtx|gtx|quadro") { return 100 }
        if ($n -match "amd|radeon|rx\s|vega|firepro|w\d{4}") { return 95 }
        if ($n -match "intel.*arc|arc.*graphics") { return 90 }
        if ($n -match "intel|iris|uhd|hd graphics|xe graphics") { return 60 }
        if ($n -match "microsoft basic display|basic render") { return 10 }
        return 40
    }

    $primary = $null
    if ($video.Count -gt 0) {
        $ranked = @($video | Sort-Object @{Expression = { Get-DisplayRank $_ }; Descending = $true }, @{Expression = { if ($_.AdapterRAM) { [int64]$_.AdapterRAM } else { 0 } }; Descending = $true })
        if ($ranked.Count -gt 0) { $primary = $ranked[0] }
    }

    $name = $(if ($primary -and $primary.Name) { [string]$primary.Name } elseif ($primary -and $primary.DeviceName) { [string]$primary.DeviceName } elseif ($hardware) { [string]$hardware.GpuName } else { "Unknown GPU" })
    $allNames = @()
    if ($video.Count -gt 0) {
        $allNames = @($video | ForEach-Object { if ($_.Name) { [string]$_.Name } elseif ($_.DeviceName) { [string]$_.DeviceName } } | Where-Object { $_ })
    }
    if ($allNames.Count -eq 0 -and $hardware -and $hardware.GpuName) { $allNames = @([string]$hardware.GpuName) }

    $vendorText = (($name + " " + ($allNames -join " ")).ToLowerInvariant())
    $vendor = "other"
    if ($vendorText -match "nvidia|geforce|rtx|gtx|quadro") { $vendor = "nvidia" }
    elseif ($vendorText -match "amd|radeon|rx\s|vega|firepro|w\d{4}") { $vendor = "amd" }
    elseif ($vendorText -match "intel|arc|iris|uhd|hd graphics|xe graphics") { $vendor = "intel" }
    if ($hardware -and $hardware.GpuVendor -and $hardware.GpuVendor -ne "other") {
        # If a discrete GPU is present, prefer it over an integrated fallback detected earlier.
        if (-not (($vendor -in @("nvidia", "amd")) -and $hardware.GpuVendor -eq "intel")) { $vendor = [string]$hardware.GpuVendor }
    }

    $version = "Unknown"
    if ($primary) {
        if ($primary.DriverVersion) { $version = [string]$primary.DriverVersion }
        elseif ($primary.DriverProviderName) { $version = [string]$primary.DriverProviderName }
    }

    $date = $null
    if ($primary) {
        try {
            if ($primary.DriverDate) {
                if ($primary.DriverDate -is [datetime]) { $date = [datetime]$primary.DriverDate }
                else { $date = [System.Management.ManagementDateTimeConverter]::ToDateTime([string]$primary.DriverDate) }
            }
        } catch {
            try { $date = [datetime]::Parse([string]$primary.DriverDate) } catch {}
        }
    }
    if ($null -eq $date -and $signedDrivers.Count -gt 0) {
        try {
            $key = (($name -split "\+")[0].Trim())
            $signed = $signedDrivers | Where-Object { $_.DeviceName -and $_.DeviceName -match [regex]::Escape($key) } | Select-Object -First 1
            if (-not $signed) { $signed = $signedDrivers | Sort-Object @{Expression = { Get-DisplayRank $_ }; Descending = $true } | Select-Object -First 1 }
            if ($signed -and $signed.DriverDate) { $date = [datetime]$signed.DriverDate }
            if ($signed -and $signed.DriverVersion -and $version -eq "Unknown") { $version = [string]$signed.DriverVersion }
        } catch {}
    }

    $ageDays = $null
    if ($date) { $ageDays = [int]([Math]::Max(0, ((Get-Date) - $date).TotalDays)) }
    return [pscustomobject]@{
        Vendor = $vendor
        Name = $name
        Version = $version
        Date = $date
        AgeDays = $ageDays
        AllNames = $allNames
        IsHybrid = ($allNames.Count -gt 1)
        IsLaptop = ($hardware -and $hardware.System -eq "laptop")
    }
}

function Get-DriverVendorProfile($Vendor) {
    switch ([string]$Vendor) {
        "nvidia" {
            return [pscustomobject]@{
                Name = "NVIDIA"
                AutoName = "NVIDIA App / official driver page"
                AutoUrl = "https://www.nvidia.com/en-us/drivers/"
                ManualUrl = "https://www.nvidia.com/en-us/drivers/"
                VendorAppUrl = "https://www.nvidia.com/en-us/software/nvidia-app/"
                CleanToolName = "NVCleanstall"
                CleanToolUrl = "https://www.techpowerup.com/download/techpowerup-nvcleanstall/"
                CleanToolNote = "Advanced NVIDIA-only clean/custom install. Good for a minimal driver package, but regular NVIDIA install is safer for most people."
            }
        }
        "amd" {
            return [pscustomobject]@{
                Name = "AMD Radeon"
                AutoName = "AMD Auto-Detect / Adrenalin"
                AutoUrl = "https://www.amd.com/en/support/download/drivers.html"
                ManualUrl = "https://www.amd.com/en/support/download/drivers.html"
                VendorAppUrl = "https://www.amd.com/en/support/download/drivers.html"
                CleanToolName = "AMD Cleanup Utility"
                CleanToolUrl = "https://www.amd.com/en/resources/support-articles/faqs/GPU-601.html"
                CleanToolNote = "AMD's clean-install alternative. Use it when Adrenalin is corrupted, updates fail, or you swapped GPU vendors."
            }
        }
        "intel" {
            return [pscustomobject]@{
                Name = "Intel Graphics"
                AutoName = "Intel Driver & Support Assistant"
                AutoUrl = "https://www.intel.com/content/www/us/en/support/detect.html"
                ManualUrl = "https://www.intel.com/content/www/us/en/download-center/home.html"
                VendorAppUrl = "https://www.intel.com/content/www/us/en/support/detect.html"
                CleanToolName = "Intel DSA + DDU if corrupted"
                CleanToolUrl = "https://www.intel.com/content/www/us/en/support/detect.html"
                CleanToolNote = "Use Intel DSA first. Use DDU only for broken driver leftovers or vendor-swap cleanup."
            }
        }
        default {
            return [pscustomobject]@{
                Name = "Unknown / OEM GPU"
                AutoName = "Windows Update + OEM support"
                AutoUrl = "ms-settings:windowsupdate-optionalupdates"
                ManualUrl = "ms-settings:windowsupdate-optionalupdates"
                VendorAppUrl = "devmgmt.msc"
                CleanToolName = "DDU universal cleanup"
                CleanToolUrl = "https://www.wagnardsoft.com/"
                CleanToolNote = "Use OEM/laptop support first. Use DDU only if the driver is badly broken."
            }
        }
    }
}

function Get-DriverAssessment($DriverInfo = $null) {
    if ($null -eq $DriverInfo) { $DriverInfo = Get-GpuDriverInfo }
    $profile = Get-DriverVendorProfile $DriverInfo.Vendor
    $dateText = $(if ($DriverInfo.Date) { $DriverInfo.Date.ToString("yyyy-MM-dd") } else { "unknown date" })
    $ageText = $(if ($null -ne $DriverInfo.AgeDays) { "$($DriverInfo.AgeDays) days old" } else { "age unknown" })
    $action = "Check manually"
    $severity = "Info"
    $reason = "ApexTune cannot prove the newest release from inside an offline local app, so it opens the best official vendor update path."

    if ($null -ne $DriverInfo.AgeDays) {
        if ($DriverInfo.AgeDays -ge 180) {
            $severity = "Update strongly recommended"
            $action = "Update before tuning"
            $reason = "Your display driver looks very old. For FPS, stability, anti-cheat compatibility, and new-game fixes, check the GPU driver before stacking tweaks."
        } elseif ($DriverInfo.AgeDays -ge 90) {
            $severity = "Update recommended"
            $action = "Check now"
            $reason = "This driver is old enough that a newer Game Ready, Studio, Adrenalin, or Intel graphics release is likely worth checking."
        } elseif ($DriverInfo.AgeDays -ge 45) {
            $severity = "Check for update"
            $action = "Optional check"
            $reason = "This driver is not ancient, but checking the vendor app is smart if a game is stuttering, crashing, or newly released."
        } elseif ($DriverInfo.AgeDays -le 21) {
            $severity = "Looks current"
            $action = "Benchmark first"
            $reason = "The driver date looks recent. Do not reinstall drivers just to chase placebo FPS unless a game is broken."
        } else {
            $severity = "Probably okay"
            $action = "Update only if needed"
            $reason = "This driver is fairly recent. Benchmark first, then update only for game fixes, crashes, or bad stutter."
        }
    }

    $installMode = "Regular vendor install through $($profile.AutoName)."
    if ($DriverInfo.Vendor -eq "nvidia") {
        $installMode = "NVIDIA App/official drivers. Pick Game Ready for competitive gaming, Studio for creator stability, or NVCleanstall only for an advanced minimal NVIDIA package."
    } elseif ($DriverInfo.Vendor -eq "amd") {
        $installMode = "AMD Auto-Detect/Adrenalin. Use AMD Cleanup Utility as the AMD clean-install alternative; use DDU only for deeper corruption or vendor swaps."
    } elseif ($DriverInfo.Vendor -eq "intel") {
        $installMode = "Intel Driver & Support Assistant first, Intel Download Center manually if DSA misses something, DDU only for broken leftovers."
    } else {
        $installMode = "Windows Optional Updates, Device Manager, and your PC/laptop OEM support page. Use universal DDU only as a repair tool."
    }

    if ($DriverInfo.IsLaptop) {
        $reason += " Since this looks like a laptop, the OEM support page can matter for hybrid graphics and power profiles."
    }
    if ($DriverInfo.IsHybrid) {
        $reason += " Hybrid graphics detected: update the gaming/discrete GPU first, then Intel/AMD integrated graphics if the OEM or vendor tool recommends it."
    }

    return [pscustomobject]@{
        Severity = $severity
        Action = $action
        Reason = $reason
        DateText = $dateText
        AgeText = $ageText
        InstallMode = $installMode
        VendorProfile = $profile
        Summary = ("{0}: {1}. Installed driver {2}, {3}." -f $severity, $action, $dateText, $ageText)
    }
}

function Get-DriverBestUrl($Vendor) {
    return (Get-DriverVendorProfile $Vendor).AutoUrl
}

function Get-DriverManualUrl($Vendor) {
    return (Get-DriverVendorProfile $Vendor).ManualUrl
}

function Open-DriverPath($Url) {
    if ([string]::IsNullOrWhiteSpace([string]$Url)) { return }
    try {
        if ([string]$Url -like "ms-settings:*") { Start-Process ([string]$Url); return }
        if ([string]$Url -eq "devmgmt.msc") { Start-Process "devmgmt.msc"; return }
        Open-ExternalLink $Url
    } catch {
        Show-Toast ("Could not open driver path: " + $_.Exception.Message) "Driver utility"
    }
}

function Invoke-DriverAutoPick {
    $info = Get-GpuDriverInfo
    $assessment = Get-DriverAssessment $info
    $profile = $assessment.VendorProfile
    Append-Log ("Driver AI: " + $assessment.Summary)
    $message = @(
        "ApexTune detected: $($info.Name)",
        "Driver: $($info.Version) / $($assessment.DateText) / $($assessment.AgeText)",
        "Vendor path: $($profile.AutoName)",
        "AI pick: $($assessment.InstallMode)",
        "",
        "Open the recommended update path now?"
    ) -join [Environment]::NewLine
    $choice = [System.Windows.Forms.MessageBox]::Show(
        $script:Form,
        $message,
        "AI driver pick",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) { Open-DriverPath $profile.AutoUrl }
}

function Invoke-ManualDriverSearch {
    $info = Get-GpuDriverInfo
    $profile = Get-DriverVendorProfile $info.Vendor
    Append-Log ("Opening manual driver search for " + $profile.Name)
    Open-DriverPath $profile.ManualUrl
}

function Invoke-VendorDriverApp {
    $info = Get-GpuDriverInfo
    $profile = Get-DriverVendorProfile $info.Vendor
    Append-Log ("Opening vendor driver app/path for " + $profile.Name)
    Open-DriverPath $profile.VendorAppUrl
}

function Invoke-VendorCleanTool {
    $info = Get-GpuDriverInfo
    $assessment = Get-DriverAssessment $info
    $profile = $assessment.VendorProfile
    $choice = [System.Windows.Forms.MessageBox]::Show(
        $script:Form,
        "$($profile.CleanToolName)`n`n$($profile.CleanToolNote)`n`nDetected GPU: $($info.Name)`nDriver: $($info.Version) / $($assessment.DateText)`n`nOpen this clean-install tool/path now?",
        "Vendor clean install tool",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) {
        Append-Log ("Opening clean install tool: " + $profile.CleanToolName)
        Open-DriverPath $profile.CleanToolUrl
    }
}

function Invoke-UniversalDduFlow {
    $info = Get-GpuDriverInfo
    $choice = [System.Windows.Forms.MessageBox]::Show(
        $script:Form,
        "DDU is a universal NVIDIA/AMD/Intel driver cleanup tool. Use it only for real driver problems: black screens, broken control panels, failed updates, vendor swaps, or bad stutter after driver installs.`n`nRegular vendor install is safer for normal updates.`n`nOpen the DDU source page now?",
        "Universal DDU cleanup",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) {
        Append-Log ("Opening DDU page for detected GPU: " + $info.Name)
        Open-ExternalLink "https://www.wagnardsoft.com/"
    }
}

function Invoke-NVCleanstallFlow {
    # Backwards-compatible handler name. In v6 this opens the right clean tool for the detected GPU.
    Invoke-VendorCleanTool
}

function Show-CleanDriverNotes {
    $info = Get-GpuDriverInfo
    $assessment = Get-DriverAssessment $info
    $profile = $assessment.VendorProfile
    $all = if ($info.AllNames -and $info.AllNames.Count -gt 0) { ($info.AllNames -join " + ") } else { $info.Name }
    $text = @(
        "Detected display adapters: $all",
        "Primary gaming path: $($profile.Name)",
        "Installed driver: $($info.Version)",
        "Driver date: $($assessment.DateText) ($($assessment.AgeText))",
        "",
        "Regular install: safest first choice. Use it for normal updates.",
        "Auto-pick best: opens the official updater/search path for NVIDIA, AMD, Intel, or Windows/OEM fallback.",
        "Vendor clean tool: NVIDIA uses NVCleanstall, AMD uses AMD Cleanup Utility, Intel uses Intel DSA first, unknown GPUs use OEM/Windows fallback.",
        "Universal DDU: NVIDIA/AMD/Intel cleanup repair path. Use only for broken/corrupted drivers, black screens, vendor swaps, or failed updates.",
        "",
        "AI recommendation: $($assessment.Summary)",
        $assessment.Reason
    ) -join [Environment]::NewLine
    [System.Windows.Forms.MessageBox]::Show($script:Form, $text, "GPU driver install notes", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}


function Get-TopRecommendationText([int]$Limit = 7) {
    $items = @(Get-RecommendedTweaksForSelection | Select-Object -First $Limit)
    if ($items.Count -eq 0) { return "- No recommendations found with the current filters." }
    return (($items | ForEach-Object { "- " + $_.Title + " [" + $_.Risk + "] FPS +" + $_.Fps + " / Ping +" + $_.Ping }) -join [Environment]::NewLine)
}


function Get-FocusedAiTweaks([string]$Focus, [int]$Limit = 7, [bool]$SkipLocked = $false) {
    $focusText = ([string]$Focus).ToLowerInvariant()
    $items = @($script:Tweaks | Where-Object { Test-TweakAllowedBySettings $_ })

    if ($focusText -eq "network") {
        $items = @($items | Where-Object { ($_.Category -eq "Network") -or ($_.Ping -ge 3) } | Sort-Object Ping -Descending)
    } elseif ($focusText -eq "driver") {
        $items = @($items | Where-Object { ($_.Category -eq "GPU") -or ([string]($_.Tags -join " ") -match "GPU|NVIDIA|AMD|Intel|Shader|DirectX|Fullscreen") } | Sort-Object Fps -Descending)
    } elseif ($focusText -eq "cpu") {
        $items = @($items | Where-Object { ($_.Category -in @("Windows", "Power", "Services", "Memory")) -or ([string]($_.Tags -join " ") -match "CPU|Memory|Service|Background|Power") } | Sort-Object Fps -Descending)
    } elseif ($focusText -eq "thermal") {
        $items = @($items | Where-Object { ($_.Category -eq "Power") -or ([string]($_.Tags -join " ") -match "Laptop|Power|PCIe|USB") } | Sort-Object Fps -Descending)
    } else {
        $items = @($items | Where-Object { ($_.Fps -ge 3) -and ($_.Category -ne "Network") } | Sort-Object Fps -Descending)
    }

    if ($SkipLocked) { $items = @($items | Where-Object { -not (Is-Locked $_) }) }
    if ($items.Count -eq 0) { $items = @(Get-RecommendedTweaksForSelection) }
    return @($items | Select-Object -First $Limit)
}

function Get-FocusedRecommendationText([string]$Focus, [int]$Limit = 7) {
    $items = @(Get-FocusedAiTweaks $Focus $Limit $false)
    if ($items.Count -eq 0) { return "- No matching tweaks found with the current profile/settings." }
    $lines = @()
    foreach ($tweak in $items) {
        $lockText = if (Is-Locked $tweak) { " (locked on this plan)" } else { "" }
        $lines += ("- {0} [{1}] FPS +{2} / Ping +{3}{4}" -f $tweak.Title, $tweak.Risk, $tweak.Fps, $tweak.Ping, $lockText)
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-AiPcSnapshotText {
    $hardware = $script:State.Hardware
    if ($null -eq $hardware) { $hardware = Get-SystemHardwareInfo; $script:State["Hardware"] = $hardware }
    $driver = Get-GpuDriverInfo
    $assessment = Get-DriverAssessment $driver
    $profile = $assessment.VendorProfile
    $recNames = Get-TopRecommendationText 6
    $hybrid = if ($driver.IsHybrid) { "Yes - " + ($driver.AllNames -join " + ") } else { "No" }
    $lines = @(
        "Here is my live PC read:",
        "GPU: $($hardware.GpuName)",
        "Display adapters: $hybrid",
        "CPU/RAM: $($hardware.CpuName) / $($hardware.Ram)",
        "Network: $($hardware.Network.ToUpperInvariant()) - $($hardware.NetworkName)",
        "System: $($hardware.System.ToUpperInvariant()) - $($hardware.Model)",
        "Windows: $($hardware.Os)",
        "",
        "Driver opinion: $($assessment.Summary)",
        "Best driver path: $($profile.AutoName)",
        $assessment.Reason,
        "",
        "What I would test first:",
        $recNames,
        "",
        "My honest order: drivers/status check first, then 3-5 safe tweaks, restart, benchmark one game, then go deeper only if the numbers prove it helped."
    )
    return ($lines -join [Environment]::NewLine)
}

function Get-AiReply($UserText) {
    $raw = [string]$UserText
    $text = $raw.ToLowerInvariant()
    $hardware = $script:State.Hardware
    if ($null -eq $hardware) { $hardware = Get-SystemHardwareInfo; $script:State["Hardware"] = $hardware }
    $driver = Get-GpuDriverInfo
    $assessment = Get-DriverAssessment $driver
    $profile = $assessment.VendorProfile
    if ([string]::IsNullOrWhiteSpace($text)) { return Get-AiPcSnapshotText }

    # Intent priority matters. Network/ping questions must be answered before broad game/FPS words like "Fortnite".
    if ($text -match "ping|network|ethernet|wifi|wi-fi|packet|jitter|dns|lag spike|latency|router|modem|isp|server region|matchmaking region|rubberband|disconnect") {
        $script:LastAiIntent = "network"
        $wifiNote = if ($hardware.Network -eq "wifi") { "You are on Wi-Fi, so signal strength, interference, 2.4/5 GHz band choice, and adapter power saving matter a lot. Ethernet is still the cleanest competitive fix." } else { "Ethernet detected. That is good; if ping is still high, I would suspect router/modem, ISP routing, local congestion, or the game server path before random FPS tweaks." }
        $gameLine = if ($text -match "fortnite") { "For Fortnite specifically, high ping is not an FPS problem. It is usually server region, packet loss/jitter, Wi-Fi/router issues, ISP routing, or the path to Epic servers." } else { "Separate network latency from FPS stutter: ping/packet loss is network, frame drops are PC performance." }
        $networkPicks = Get-FocusedRecommendationText "network" 7
        return @(
            "High ping / network plan:",
            $gameLine,
            "Detected connection: $($hardware.Network.ToUpperInvariant()) - $($hardware.NetworkName)",
            $wifiNote,
            "",
            "Do this first:",
            "1. Set the game region to Auto or the closest region.",
            "2. Restart modem/router and test while nobody is downloading or streaming.",
            "3. Turn on in-game network stats and watch ping, packet loss, and jitter.",
            "4. Run a baseline ping test, then test again after each tweak so you know what actually helped.",
            "5. Try DNS/socket refresh and update-sharing reduction before advanced TCP adapter edits.",
            "",
            "ApexTune network picks I would test:",
            $networkPicks,
            "",
            "Do not apply the whole FPS list for a ping problem. If packet loss stays high after Ethernet/router testing, it may be ISP routing or the game server path, not your PC."
        ) -join [Environment]::NewLine
    }

    if ($text -match "driver|gpu|graphics|nvidia|geforce|rtx|gtx|amd|radeon|intel|arc|adrenalin|nvclean|cleanup|ddu|clean install|clean-install|update") {
        $script:LastAiIntent = "driver"
        $cleanAdvice = switch ($driver.Vendor) {
            "nvidia" { "For NVIDIA, use regular NVIDIA App/Game Ready first. Use NVCleanstall only if you want a smaller custom package and understand what components you are removing. DDU is the repair option, not the normal update path." }
            "amd" { "For AMD, the closest NVCleanstall-style clean path is AMD Cleanup Utility, then reinstall Adrenalin from AMD Auto-Detect or manual support. DDU is the deeper universal repair path." }
            "intel" { "For Intel, use Intel Driver & Support Assistant first. If drivers are corrupted, use DDU carefully, then reinstall through Intel DSA or the Download Center." }
            default { "For unknown/OEM graphics, use Windows Optional Updates, Device Manager, and your laptop/PC support page first. Use DDU only if normal driver repair fails." }
        }
        return @(
            "Driver plan for this machine:",
            "Detected GPU: $($driver.Name)",
            "Installed driver: $($driver.Version) / $($assessment.DateText) / $($assessment.AgeText)",
            "Status: $($assessment.Summary)",
            "Auto path: $($profile.AutoName)",
            "Manual path: $($profile.Name) support/download page",
            "Clean path: $($profile.CleanToolName)",
            "",
            $cleanAdvice,
            "",
            "My recommendation: $($assessment.Action). $($assessment.Reason)"
        ) -join [Environment]::NewLine
    }

    if ($text -match "crash|crashing|freeze|freezing|black screen|blue screen|bsod|error|won't open|wont open") {
        $script:LastAiIntent = "crash"
        return @(
            "Crash/freezing plan:",
            "Do not apply more tweaks yet. Stability comes first.",
            "1. Update or roll back the GPU driver depending on when the crashes started.",
            "2. Verify game files and remove unstable launch options/overlays.",
            "3. Check Windows Event Viewer for the exact crash module.",
            "4. If the driver/control panel is broken, use the GPU tab clean-install path for your vendor.",
            "5. Only tune FPS after the game is stable."
        ) -join [Environment]::NewLine
    }

    if ($text -match "input lag|input delay|mouse|keyboard|controller|raw input|acceleration|sensitivity") {
        $script:LastAiIntent = "input"
        return @(
            "Input delay plan:",
            "Separate input lag from low FPS and high ping. Input delay usually comes from frame queue, V-Sync, overlays, bad USB/power saving, mouse acceleration, or overloaded CPU/GPU.",
            "Use raw input in-game when available, disable mouse acceleration, test Reflex/Anti-Lag per game, and keep FPS stable instead of only chasing max FPS.",
            "",
            "ApexTune picks I would test:",
            (Get-FocusedRecommendationText "fps" 5)
        ) -join [Environment]::NewLine
    }


    if ($text -match "fortnite|rainbow six|r6|siege|valorant|roblox") {
        $script:LastAiIntent = "fps"
        if ($text -match "fortnite") {
            return @(
                "Fortnite performance guide:",
                "1. First identify the problem: high ping is network; stutter/FPS drops are PC performance.",
                "2. Test Performance Mode, DX11, and DX12 separately. Do not swap every match; let shaders settle.",
                "3. Use a realistic FPS cap your laptop can hold. Smooth 120/144 is better than unstable peaks.",
                "4. Keep fullscreen on, close overlays/recorders, update GPU drivers after major Fortnite engine updates.",
                "5. For ping, set the correct region, prefer Ethernet, restart modem/router, and watch packet loss/jitter.",
                "",
                "ApexTune picks I would test for Fortnite:",
                (Get-FocusedRecommendationText "fps" 7)
            ) -join [Environment]::NewLine
        } elseif ($text -match "rainbow six|r6|siege") {
            return @(
                "Rainbow Six Siege performance guide:",
                "1. Use a stable FPS cap and focus on 1% lows/frametime, not only max FPS.",
                "2. Test Vulkan/DX path if both are available for your install, then keep the smoother one.",
                "3. Use Ethernet, disable unnecessary overlays, keep drivers clean, and avoid risky service disabling.",
                "4. For competitive play, prioritize stable render latency, clean background apps, and consistent GPU clocks.",
                "",
                "ApexTune picks I would test for R6:",
                (Get-FocusedRecommendationText "fps" 7)
            ) -join [Environment]::NewLine
        } elseif ($text -match "valorant") {
            return @(
                "VALORANT performance guide:",
                "1. Keep Vanguard/Windows security stable. Do not use sketchy timer/service hacks.",
                "2. Use fullscreen, test Reflex/low-latency setting, and cap FPS to something your PC can hold.",
                "3. Clean GPU drivers if crashes/stutter started after an update.",
                "4. Close browsers, Discord overlays, capture tools, launchers, and RGB software before playing.",
                "",
                "ApexTune picks I would test for VALORANT:",
                (Get-FocusedRecommendationText "fps" 7)
            ) -join [Environment]::NewLine
        } elseif ($text -match "roblox") {
            return @(
                "Roblox performance guide:",
                "1. Lower graphics quality first and close browser tabs/recorders because Roblox can be CPU-heavy.",
                "2. Keep drivers current and use Windows Graphics settings to force High performance for Roblox Player.",
                "3. Be careful with FPS unlockers: only use trusted tools and follow platform/community rules.",
                "4. If ping is the issue, treat it as network: region/server, Wi-Fi, router, packet loss, ISP routing.",
                "",
                "ApexTune picks I would test for Roblox:",
                (Get-FocusedRecommendationText "fps" 6)
            ) -join [Environment]::NewLine
        }
    }

    if ($text -match "settings|best settings|dx11|dx12|performance mode|fullscreen|reflex|anti-lag|control panel") {
        $script:LastAiIntent = "driver"
        $gpuLine = switch ($driver.Vendor) {
            "nvidia" { "NVIDIA: use per-game profile, Prefer maximum performance for the game only, Reflex/Low Latency when supported, and avoid forcing global settings until tested." }
            "amd" { "AMD: use Adrenalin per-game tuning, test Anti-Lag per game, and avoid global overrides that hurt frame pacing." }
            "intel" { "Intel: set the game to High performance in Windows Graphics settings and use Intel DSA for driver sanity." }
            default { "Unknown GPU: use Windows Graphics settings first and avoid vendor-specific tweaks until the adapter is identified." }
        }
        return @(
            "Settings answer:",
            $gpuLine,
            "If the problem is ping, use the network plan. If the problem is stutter, focus on drivers, shader cache, power, and background apps.",
            "",
            "ApexTune picks I would test:",
            (Get-FocusedRecommendationText "driver" 6)
        ) -join [Environment]::NewLine
    }

    if ($text -match "fps|optimize|recommend|stutter|low fps|frames|frame|1% lows|low performance|lag") {
        $script:LastAiIntent = "fps"
        $items = Get-FocusedRecommendationText "fps" 8
        $gameNote = ""
        if ($text -match "fortnite") { $gameNote = "Fortnite FPS plan: benchmark DX11, DX12, and Performance Mode; keep shader cache stable; use fullscreen; keep GPU drivers current after major Epic updates; do not stack random timer tweaks." }
        elseif ($text -match "siege|rainbow|r6") { $gameNote = "Rainbow Six Siege plan: stable frametime matters more than huge tweak stacks. Use Reflex/low-latency options if available, Ethernet, clean background apps, and avoid aggressive service disabling." }
        elseif ($text -match "rust") { $gameNote = "Rust plan: CPU, RAM, SSD, and server/entity load matter a lot. Close launchers and browsers, watch RAM pressure, use an SSD, and do not expect registry tweaks to fix weak hardware." }
        elseif ($text -match "valorant") { $gameNote = "Valorant plan: keep Vanguard/Windows security stable, avoid aggressive service disabling, use clean drivers, and prioritize consistent frametime over risky tweaks." }
        else { $gameNote = "For most games: stable drivers, low background usage, correct power plan, and sane GPU control-panel settings beat giant tweak packs." }
        return @(
            "FPS/stutter plan:",
            $gameNote,
            "",
            "ApexTune picks I would test first:",
            $items,
            "",
            "Apply in small batches: pick 3-5 safe/medium tweaks, save the plan, apply, restart, then compare FPS, 1% lows, frametime, temps, and stutter."
        ) -join [Environment]::NewLine
    }

    if ($text -match "ram|memory|cpu|processor|bottleneck|usage|background|startup") {
        $script:LastAiIntent = "cpu"
        return @(
            "CPU/RAM/bottleneck read:",
            "CPU/RAM detected: $($hardware.CpuName) / $($hardware.Ram)",
            "If CPU usage is high, close browsers, launchers, overlays, recording software, RGB tools, and updaters before touching risky registry changes.",
            "If RAM usage is high, find the actual process in Task Manager/Resource Monitor instead of using random memory cleaners.",
            "",
            "ApexTune CPU/background picks:",
            (Get-FocusedRecommendationText "cpu" 7)
        ) -join [Environment]::NewLine
    }

    if ($text -match "laptop|battery|power|thermal|heat|temperature|temp|fan|throttle|plugged") {
        $script:LastAiIntent = "thermal"
        return @(
            "Laptop/thermal/power plan:",
            "Detected system: $($hardware.System.ToUpperInvariant()) - $($hardware.Model)",
            "Run plugged in, use the correct Windows/OEM performance mode, keep vents clear, and watch CPU/GPU temps while gaming.",
            "A cooler stable laptop often beats a hotter laptop with more tweaks. If clocks drop during matches, it is throttling, not a registry problem.",
            "",
            "Power-related ApexTune picks:",
            (Get-FocusedRecommendationText "thermal" 6)
        ) -join [Environment]::NewLine
    }

    if ($text -match "ssd|hdd|drive|disk|storage|shader cache|cache|loading|texture") {
        $script:LastAiIntent = "storage"
        return @(
            "Storage/cache answer:",
            "If the game is on an HDD, move it to an SSD before expecting miracle FPS tweaks.",
            "Shader-cache stutter can happen after driver updates or major game patches. Clean cache only when there is a real stutter problem, then let the game rebuild it by playing a few matches."
        ) -join [Environment]::NewLine
    }

    if ($text -match "safe|danger|risky|restore|backup|rollback|undo") {
        $script:LastAiIntent = "safety"
        return @(
            "Safety answer:",
            "Keep restore point and registry backups ON.",
            "Low-risk tweaks are fine to test first. Medium-risk tweaks should be done in small batches. High-risk/experimental tweaks are for measurable problems only.",
            "Export the plan before applying. If something feels worse, use rollback notes or a restore point instead of stacking more tweaks."
        ) -join [Environment]::NewLine
    }

    if ($text -match "hello|hi|yo|hey") {
        return @(
            "Yo - I can help like a PC tuning coach.",
            "Ask me about high ping, low FPS, stutter, driver updates, clean installs, crashes, CPU/RAM bottlenecks, laptop heat, input delay, or what ApexTune should apply first.",
            "Current quick read: $($driver.Name), driver status: $($assessment.Summary), network: $($hardware.Network.ToUpperInvariant())."
        ) -join [Environment]::NewLine
    }

    return @(
        "General PC coach answer:",
        "I did not catch one exact category, so I would diagnose it in this order: network, FPS/stutter, drivers, CPU/RAM, heat, storage, then risky tweaks last.",
        "Current PC read:",
        "GPU: $($driver.Name)",
        "Driver: $($assessment.Summary)",
        "Network: $($hardware.Network.ToUpperInvariant()) - $($hardware.NetworkName)",
        "CPU/RAM: $($hardware.CpuName) / $($hardware.Ram)",
        "",
        "Ask me with the symptom and game, like: 'Fortnite ping spikes', 'R6 low FPS', 'AMD driver clean install', 'input delay', 'CPU bottleneck', or 'what should I apply first'."
    ) -join [Environment]::NewLine
}

function Add-AiMessage($Speaker, $Text) {
    if ($null -eq $script:State.AiMessages) { $script:State["AiMessages"] = @() }
    $script:State["AiMessages"] += [pscustomobject]@{ Speaker = [string]$Speaker; Text = [string]$Text; At = Get-Date }
    if ($script:State.AiMessages.Count -gt 50) { $script:State["AiMessages"] = @($script:State.AiMessages | Select-Object -Last 50) }
}

function Get-AiTranscript {
    if ($null -eq $script:State.AiMessages -or @($script:State.AiMessages).Count -eq 0) {
        Add-AiMessage "Apex AI" (Get-AiPcSnapshotText)
    }
    $blocks = @()
    foreach ($msg in @($script:State.AiMessages)) {
        $blocks += ("[{0}] {1}:`r`n{2}" -f ([datetime]$msg.At).ToString("h:mm tt"), $msg.Speaker, $msg.Text)
    }
    return ($blocks -join "`r`n`r`n")
}

function Render-AiTranscript {
    if ($null -eq $script:AiChatBox -or $script:AiChatBox.IsDisposed) { return }
    $script:AiChatBox.Text = Get-AiTranscript
    $script:AiChatBox.SelectionStart = $script:AiChatBox.TextLength
    $script:AiChatBox.ScrollToCaret()
}

function Send-AiChatMessage($Box) {
    if ($null -eq $Box -or $Box.IsDisposed) { return }
    $msg = ([string]$Box.Text).Trim()
    if ([string]::IsNullOrWhiteSpace($msg)) { return }
    Add-AiMessage "You" $msg
    Add-AiMessage "Apex AI" (Get-AiReply $msg)
    $Box.Text = ""
    Render-AiTranscript
}

function Select-AiRecommendedTweaks {
    $focus = if ([string]::IsNullOrWhiteSpace([string]$script:LastAiIntent)) { "fps" } else { [string]$script:LastAiIntent }
    if ($focus -in @("crash", "safety", "storage")) { $focus = "fps" }
    $candidates = @(Get-FocusedAiTweaks $focus 8 $true)
    if ($candidates.Count -eq 0) {
        $candidates = @(Get-RecommendedTweaksForSelection | Where-Object { -not (Is-Locked $_) } | Select-Object -First 8)
    }
    foreach ($tweak in $candidates) {
        $script:State.Selected[$tweak.Id] = $true
    }
    Add-AiMessage "Apex AI" ("I added {0}-focused picks based on the last question. Review the queue before applying anything." -f $focus)
    Render-AiTranscript
    Show-Toast "AI focused picks were added to the queue." "Apex AI"
}

function Build-AIAssistant {
    $layout = New-Table 2 1 $script:Colors.Bg
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) 126
    Add-Row $layout ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $layout ([System.Windows.Forms.SizeType]::Percent) 100
    $script:Content.Controls.Add($layout)

    $top = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Accent $true
    $top.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 16)
    Enable-CardHover $top $script:Colors.Accent $script:Colors.Hover
    $topGrid = New-Table 1 2 $top.BackColor
    Add-Column $topGrid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $topGrid ([System.Windows.Forms.SizeType]::Absolute) 410
    Add-Row $topGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $header = New-HeaderBlock "APEX AI" "PC tuning chat" "Ask any PC tuning question. Apex AI now separates ping, FPS, drivers, crashes, input delay, CPU/RAM, thermals, storage, and safety instead of repeating the same response." $top.BackColor
    $topGrid.Controls.Add($header, 0, 0)
    $buttons = New-Table 1 3 $top.BackColor
    Add-Column $buttons ([System.Windows.Forms.SizeType]::Percent) 33.333
    Add-Column $buttons ([System.Windows.Forms.SizeType]::Percent) 33.333
    Add-Column $buttons ([System.Windows.Forms.SizeType]::Percent) 33.333
    Add-Row $buttons ([System.Windows.Forms.SizeType]::Absolute) 44
    $analyze = New-Button "Analyze PC" 0 0 0 0 "primary"
    $drivers = New-Button "Driver check" 0 0 0 0 "secondary"
    $pick = New-Button "Select AI picks" 0 0 0 0 "ghost"
    foreach ($button in @($analyze, $drivers, $pick)) {
        $button.Dock = [System.Windows.Forms.DockStyle]::Fill
        $button.Margin = New-Object System.Windows.Forms.Padding(8, 22, 0, 0)
    }
    $buttons.Controls.Add($analyze, 0, 0)
    $buttons.Controls.Add($drivers, 1, 0)
    $buttons.Controls.Add($pick, 2, 0)
    $topGrid.Controls.Add($buttons, 1, 0)
    $top.Controls.Add($topGrid)
    $layout.Controls.Add($top, 0, 0)

    $chatCard = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Teal $false
    Enable-CardHover $chatCard $script:Colors.Accent $script:Colors.Hover
    $chatGrid = New-Table 2 1 $chatCard.BackColor
    Add-Row $chatGrid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $chatGrid ([System.Windows.Forms.SizeType]::Absolute) 58
    Add-Column $chatGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $script:AiChatBox = New-Object System.Windows.Forms.TextBox
    $script:AiChatBox.Multiline = $true
    $script:AiChatBox.ReadOnly = $true
    $script:AiChatBox.ScrollBars = [System.Windows.Forms.ScrollBars]::None
    $script:AiChatBox.Dock = [System.Windows.Forms.DockStyle]::Fill
    $script:AiChatBox.BackColor = $script:Colors.Field
    $script:AiChatBox.ForeColor = $script:Colors.Text
    $script:AiChatBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:AiChatBox.Font = New-Font 9.4
    $script:AiChatBox.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $chatGrid.Controls.Add($script:AiChatBox, 0, 0)

    $inputRow = New-Table 1 2 $chatCard.BackColor
    Add-Column $inputRow ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $inputRow ([System.Windows.Forms.SizeType]::Absolute) 132
    Add-Row $inputRow ([System.Windows.Forms.SizeType]::Percent) 100
    $input = New-TextBox 0 0 0 0
    $input.Dock = [System.Windows.Forms.DockStyle]::Fill
    $input.Margin = New-Object System.Windows.Forms.Padding(0, 4, 12, 4)
    try { $input.PlaceholderText = "Ask: should I update drivers, clean install AMD/NVIDIA/Intel, boost FPS, fix ping..." } catch {}
    $send = New-Button "Send" 0 0 0 0 "primary"
    $send.Dock = [System.Windows.Forms.DockStyle]::Fill
    $send.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 4)
    $inputRow.Controls.Add($input, 0, 0)
    $inputRow.Controls.Add($send, 1, 0)
    $chatGrid.Controls.Add($inputRow, 0, 1)
    $chatCard.Controls.Add($chatGrid)
    $layout.Controls.Add($chatCard, 0, 1)

    $analyze.Add_Click({ Add-AiMessage "Apex AI" (Get-AiPcSnapshotText); Render-AiTranscript })
    $drivers.Add_Click({ Add-AiMessage "Apex AI" (Get-AiReply "driver check"); Render-AiTranscript })
    $pick.Add_Click({ Select-AiRecommendedTweaks })
    $send.Add_Click({ Send-AiChatMessage $input })
    $input.Add_KeyDown({ param($sender, $eventArgs) if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Enter) { Send-AiChatMessage $sender; $eventArgs.SuppressKeyPress = $true } })
    Render-AiTranscript
}


function New-GpuDriverUtilityCard($Hardware) {
    if ($null -eq $Hardware) { $Hardware = $script:State.Hardware }
    $info = Get-GpuDriverInfo
    $assessment = Get-DriverAssessment $info
    $profile = $assessment.VendorProfile
    $card = New-GradientCard 12 $script:Colors.Field $script:Colors.Card2 $script:Colors.Blue $false
    $card.Margin = New-Object System.Windows.Forms.Padding(0)
    $card.BorderColor = $script:Colors.Line
    Enable-CardHover $card $script:Colors.Accent $script:Colors.Hover

    $grid = New-Table 5 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 54
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 42
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 42
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 62
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $header = New-HeaderBlock "UNIVERSAL GPU DRIVER UTILITY" "Any GPU driver check + install paths" "Apex AI detects NVIDIA, AMD, Intel, hybrid laptops, or OEM/unknown GPUs and opens the safest driver route." $card.BackColor
    $grid.Controls.Add($header, 0, 0)

    $row1 = New-Table 1 2 $card.BackColor
    Add-Column $row1 ([System.Windows.Forms.SizeType]::Absolute) 110
    Add-Column $row1 ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $row1 ([System.Windows.Forms.SizeType]::Percent) 100
    $row1.Controls.Add((New-FillLabel "GPU" 8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted), 0, 0)
    $gpuLine = ($profile.Name.ToUpperInvariant() + " - " + $info.Name)
    if ($info.IsHybrid) { $gpuLine += "  | Hybrid: " + ($info.AllNames -join " + ") }
    $row1.Controls.Add((New-FillLabel $gpuLine 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Green), 1, 0)
    $grid.Controls.Add($row1, 0, 1)

    $row2 = New-Table 1 2 $card.BackColor
    Add-Column $row2 ([System.Windows.Forms.SizeType]::Absolute) 110
    Add-Column $row2 ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $row2 ([System.Windows.Forms.SizeType]::Percent) 100
    $row2.Controls.Add((New-FillLabel "DRIVER" 8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted), 0, 0)
    $row2.Controls.Add((New-FillLabel ($info.Version + " / " + $assessment.DateText + " / " + $assessment.AgeText) 8.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Teal), 1, 0)
    $grid.Controls.Add($row2, 0, 2)

    $status = New-WrapLabel ("AI: " + $assessment.Summary + " Best path: " + $profile.AutoName + ". Clean path: " + $profile.CleanToolName + ".") 8.4 ([System.Drawing.FontStyle]::Bold) $(if ($assessment.Severity -match "Update|Check") { $script:Colors.Amber } else { $script:Colors.Green })
    $status.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
    $grid.Controls.Add($status, 0, 3)

    $buttons = New-Table 2 4 $card.BackColor
    foreach ($i in 1..4) { Add-Column $buttons ([System.Windows.Forms.SizeType]::Percent) 25 }
    Add-Row $buttons ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $buttons ([System.Windows.Forms.SizeType]::Percent) 50
    $best = New-Button "Auto-pick best" 0 0 0 0 "primary"
    $manual = New-Button "Manual search" 0 0 0 0 "secondary"
    $vendorApp = New-Button "Vendor app" 0 0 0 0 "secondary"
    $clean = New-Button "Vendor clean" 0 0 0 0 "secondary"
    $ddu = New-Button "DDU universal" 0 0 0 0 "ghost"
    $notes = New-Button "Install notes" 0 0 0 0 "ghost"
    $device = New-Button "Device Manager" 0 0 0 0 "ghost"
    $rescan = New-Button "Rescan" 0 0 0 0 "ghost"
    foreach ($button in @($best, $manual, $vendorApp, $clean, $ddu, $notes, $device, $rescan)) {
        $button.Dock = [System.Windows.Forms.DockStyle]::Fill
        $button.Margin = New-Object System.Windows.Forms.Padding(0, 4, 8, 4)
        $button.Font = New-Font 7.8 ([System.Drawing.FontStyle]::Bold)
    }
    $buttons.Controls.Add($best, 0, 0)
    $buttons.Controls.Add($manual, 1, 0)
    $buttons.Controls.Add($vendorApp, 2, 0)
    $buttons.Controls.Add($clean, 3, 0)
    $buttons.Controls.Add($ddu, 0, 1)
    $buttons.Controls.Add($notes, 1, 1)
    $buttons.Controls.Add($device, 2, 1)
    $buttons.Controls.Add($rescan, 3, 1)
    $grid.Controls.Add($buttons, 0, 4)
    $card.Controls.Add($grid)

    $best.Add_Click({ Invoke-DriverAutoPick })
    $manual.Add_Click({ Invoke-ManualDriverSearch })
    $vendorApp.Add_Click({ Invoke-VendorDriverApp })
    $clean.Add_Click({ Invoke-VendorCleanTool })
    $ddu.Add_Click({ Invoke-UniversalDduFlow })
    $notes.Add_Click({ Show-CleanDriverNotes })
    $device.Add_Click({ try { Start-Process "devmgmt.msc" } catch { Show-Toast $_.Exception.Message "Device Manager" } })
    $rescan.Add_Click({ Invoke-HardwareRescan })
    return $card
}

function Export-SelectedPlan {
    $selected = @(Get-SelectedTweaks)
    if ($selected.Count -eq 0) {
        Show-Toast "Select at least one tweak before exporting a plan." "ApexTune"
        return
    }
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = "Save ApexTune PowerShell plan"
    $dialog.Filter = "PowerShell script (*.ps1)|*.ps1|Text file (*.txt)|*.txt"
    $dialog.FileName = "ApexTune-Optimization-Plan.ps1"
    if ($dialog.ShowDialog($script:Form) -eq [System.Windows.Forms.DialogResult]::OK) {
        Set-Content -Path $dialog.FileName -Value (Build-PlanScript $selected) -Encoding UTF8
        Add-Activity "Exported optimization plan" $selected.Count
        Save-CurrentUser
        Show-Toast "Plan exported. Review the file before running it as administrator." "Plan exported"
    }
}

function Build-AuthView {
    Stop-PageSlideTransition
    Stop-LiveStatsTimer
    $script:Form.Controls.Clear()
    $script:BrandMarkLabels = @()
    $script:Form.Text = "ApexTune Eclipse - Sign in"
    $root = New-Table 1 2 $script:Colors.Bg
    Add-Column $root ([System.Windows.Forms.SizeType]::Absolute) 500
    Add-Column $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-AppSurface $root

    $leftShell = New-Table 1 1 $script:Colors.Sidebar
    $leftShell.Padding = New-Object System.Windows.Forms.Padding(28)
    Add-Column $leftShell ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $leftShell ([System.Windows.Forms.SizeType]::Percent) 100
    $root.Controls.Add($leftShell, 0, 0)

    $left = New-Table 10 1 $script:Colors.Sidebar
    Add-Column $left ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 96
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 54
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 66
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 66
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 66
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 52
    Add-Row $left ([System.Windows.Forms.SizeType]::Absolute) 120
    Add-Row $left ([System.Windows.Forms.SizeType]::Percent) 100
    $leftShell.Controls.Add($left, 0, 0)

    $brand = New-Table 1 2 $script:Colors.Sidebar
    Add-Column $brand ([System.Windows.Forms.SizeType]::Absolute) 58
    Add-Column $brand ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $brand ([System.Windows.Forms.SizeType]::Percent) 100
    $mark = New-AppMarkLabel 12
    $mark.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $mark.BackColor = $script:Colors.Accent
    $mark.Margin = New-Object System.Windows.Forms.Padding(0, 0, 14, 34)
    $brand.Controls.Add($mark, 0, 0)
    $brandCopy = New-Table 2 1 $script:Colors.Sidebar
    Add-Row $brandCopy ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $brandCopy ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Column $brandCopy ([System.Windows.Forms.SizeType]::Percent) 100
    $brandCopy.Controls.Add((New-FillLabel "ApexTune" 20 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text), 0, 0)
    $brandCopy.Controls.Add((New-FillLabel "Windows Gaming Optimizer" 8.8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted), 0, 1)
    $brand.Controls.Add($brandCopy, 1, 0)
    $left.Controls.Add($brand, 0, 0)

    $tabs = New-Table 1 2 $script:Colors.Sidebar
    Add-Column $tabs ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Column $tabs ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $tabs ([System.Windows.Forms.SizeType]::Percent) 100
    $loginButton = New-Button "Sign in" 0 0 0 0 "primary"
    $signupButton = New-Button "Create account" 0 0 0 0 "ghost"
    $loginButton.Dock = [System.Windows.Forms.DockStyle]::Fill
    $signupButton.Dock = [System.Windows.Forms.DockStyle]::Fill
    $loginButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 10)
    $signupButton.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    $tabs.Controls.Add($loginButton, 0, 0)
    $tabs.Controls.Add($signupButton, 1, 0)
    $left.Controls.Add($tabs, 0, 1)

    $script:UsernameBox = New-TextBox 0 0 0 0
    $script:PasswordBox = New-TextBox 0 0 0 0 $true
    $script:ConfirmBox = New-TextBox 0 0 0 0 $true
    $left.Controls.Add((New-FieldGroup "Username" $script:UsernameBox $script:Colors.Sidebar), 0, 2)
    $left.Controls.Add((New-FieldGroup "Password" $script:PasswordBox $script:Colors.Sidebar), 0, 3)
    $script:ConfirmLabel = New-FieldGroup "Confirm password" $script:ConfirmBox $script:Colors.Sidebar
    $script:ConfirmLabel.Visible = $false
    $script:ConfirmBox.Visible = $false
    $left.Controls.Add($script:ConfirmLabel, 0, 4)

    $script:StayLogged = New-Object System.Windows.Forms.CheckBox
    $script:StayLogged.Text = "Stay logged in"
    $script:StayLogged.Dock = [System.Windows.Forms.DockStyle]::Fill
    $script:StayLogged.Checked = $true
    $script:StayLogged.ForeColor = $script:Colors.Text
    $script:StayLogged.BackColor = [System.Drawing.Color]::Transparent
    $script:StayLogged.Font = New-Font 9.5 ([System.Drawing.FontStyle]::Bold)
    $left.Controls.Add($script:StayLogged, 0, 5)

    $script:AuthMessage = New-FillLabel "" 9 ([System.Drawing.FontStyle]::Regular) $script:Colors.Amber
    $script:AuthMessage.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $left.Controls.Add($script:AuthMessage, 0, 6)

    $submit = New-Button "Sign in" 0 0 0 0 "primary"
    $submit.Dock = [System.Windows.Forms.DockStyle]::Fill
    $submit.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
    $left.Controls.Add($submit, 0, 7)

    $owner = New-Card 16 $script:Colors.Card
    $owner.Margin = New-Object System.Windows.Forms.Padding(0, 18, 0, 0)
    $owner.BorderColor = $script:Colors.Line
    $ownerGrid = New-Table 3 1 $owner.BackColor
    Add-Row $ownerGrid ([System.Windows.Forms.SizeType]::Absolute) 22
    Add-Row $ownerGrid ([System.Windows.Forms.SizeType]::Absolute) 28
    Add-Row $ownerGrid ([System.Windows.Forms.SizeType]::Absolute) 28
    Add-Column $ownerGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $ownerGrid.Controls.Add((New-FillLabel "OWNER ACCESS" 8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent), 0, 0)
    $ownerGrid.Controls.Add((New-FillLabel "Username: owner" 9 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text), 0, 1)
    $ownerGrid.Controls.Add((New-FillLabel "Password check: hash-protected demo owner" 8.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Green), 0, 2)
    $owner.Controls.Add($ownerGrid)
    $left.Controls.Add($owner, 0, 8)

    $rightShell = New-Table 3 1 $script:Colors.Bg
    $rightShell.Padding = New-Object System.Windows.Forms.Padding(42)
    Add-Column $rightShell ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $rightShell ([System.Windows.Forms.SizeType]::Absolute) 150
    Add-Row $rightShell ([System.Windows.Forms.SizeType]::Absolute) 126
    Add-Row $rightShell ([System.Windows.Forms.SizeType]::Percent) 100
    $root.Controls.Add($rightShell, 1, 0)

    $rightShell.Controls.Add((New-HeaderBlock "PREMIUM DESKTOP TUNING" "Mega FPS + latency tuning suite" "A Hone/EXM-inspired command center with a much bigger local tweak library, safer backups, driver tools, diagnostics, and AI coaching."), 0, 0)

    $metrics = New-Table 1 3 $script:Colors.Bg
    foreach ($i in 1..3) { Add-Column $metrics ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    Add-Row $metrics ([System.Windows.Forms.SizeType]::Percent) 100
    $metrics.Controls.Add((New-SystemStatusCard "Tweaks" ("{0}+" -f $script:Tweaks.Count) "Mega library cards" $script:Colors.Accent), 0, 0)
    $metrics.Controls.Add((New-SystemStatusCard "Profiles" "Hardware aware" "GPU, network, system" $script:Colors.Green), 1, 0)
    $metrics.Controls.Add((New-SystemStatusCard "Apply mode" "Admin" "Required for real changes" $script:Colors.Amber), 2, 0)
    $rightShell.Controls.Add($metrics, 0, 1)

    $previews = New-Table 1 3 $script:Colors.Bg
    foreach ($i in 1..3) { Add-Column $previews ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    Add-Row $previews ([System.Windows.Forms.SizeType]::Percent) 100
    $previews.Controls.Add((New-InfoPanel 0 0 0 0 "Safety" "Registry backups" "Exports targeted registry keys before selected groups run."), 0, 0)
    $previews.Controls.Add((New-InfoPanel 0 0 0 0 "Premium" "Pro unlocks" "GPU, network, service, and experimental cards unlock after upgrade."), 1, 0)
    $previews.Controls.Add((New-InfoPanel 0 0 0 0 "Detection" "Hardware profile" "ApexTune matches recommendations to the detected PC profile."), 2, 0)
    $rightShell.Controls.Add($previews, 0, 2)

    $setAuth = {
        param($mode)
        $script:State["AuthMode"] = $mode
        $script:ConfirmLabel.Visible = ($mode -eq "signup")
        $script:ConfirmBox.Visible = ($mode -eq "signup")
        $submit.Text = $(if ($mode -eq "signup") { "Create account" } else { "Sign in" })
        if ($mode -eq "signup") {
            $signupButton.BackColor = $script:Colors.Accent
            $signupButton.ForeColor = $script:Colors.Text
            $loginButton.BackColor = $script:Colors.Panel2
            $loginButton.ForeColor = $script:Colors.Text
        } else {
            $loginButton.BackColor = $script:Colors.Accent
            $loginButton.ForeColor = $script:Colors.Text
            $signupButton.BackColor = $script:Colors.Panel2
            $signupButton.ForeColor = $script:Colors.Text
        }
        $script:AuthMessage.Text = ""
    }

    $loginButton.Add_Click({ & $setAuth "login" }.GetNewClosure())
    $signupButton.Add_Click({ & $setAuth "signup" }.GetNewClosure())
    $submit.Add_Click({ Submit-Auth })
    & $setAuth $script:State.AuthMode
}

function New-MetricCard($Value, $Label, $X, $Y) {
    $panel = New-Card 14 $script:Colors.Card
    $grid = New-Table 2 1 $script:Colors.Card
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 60
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 40
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $valueLabel = New-FillLabel $Value 18 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $valueLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $labelControl = New-FillLabel $Label 9 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $labelControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $grid.Controls.Add($valueLabel, 0, 0)
    $grid.Controls.Add($labelControl, 0, 1)
    $panel.Controls.Add($grid)
    return $panel
}

function New-PreviewCard($Title, $Body, $X, $Y, $Accent) {
    $panel = New-Card 14 $script:Colors.Card
    $panel.BorderColor = $(if ($Accent) { $Accent } else { $script:Colors.Line })
    $grid = New-Table 2 1 $script:Colors.Card
    Add-Row $grid ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $titleLabel = New-AutoLabel $Title 11 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $bodyLabel = New-WrapLabel $Body 9 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $bodyLabel.Margin = New-Object System.Windows.Forms.Padding(0, 10, 0, 0)
    $grid.Controls.Add($titleLabel, 0, 0)
    $grid.Controls.Add($bodyLabel, 0, 1)
    $panel.Controls.Add($grid)
    return $panel
}

function Submit-Auth {
    $username = Normalize-Username $script:UsernameBox.Text
    $password = $script:PasswordBox.Text
    if ($username.Length -lt 3 -or $password.Length -lt 8) {
        $script:AuthMessage.Text = "Use at least 3 username characters and 8 password characters."
        return
    }

    if ($script:State.AuthMode -eq "signup") {
        if ($password -ne $script:ConfirmBox.Text) {
            $script:AuthMessage.Text = "Passwords do not match."
            return
        }
        if ($username -eq $script:OwnerUsername -or (@($script:State.Users) | Where-Object { $_.Username -eq $username })) {
            $script:AuthMessage.Text = "That username is already taken."
            return
        }
        $user = [pscustomobject]@{
            Username = $username
            PasswordHash = Get-PasswordHash $password
            Plan = "free"
            CreatedAt = (Get-Date).ToString("o")
            Settings = [pscustomobject](Copy-Map $script:DefaultSettings)
            Profile = [pscustomobject](Copy-Map $script:DefaultProfile)
            Activity = @()
        }
        $script:State["Users"] += $user
        Save-Users
        $script:State["User"] = $user
        Save-Session $username $script:StayLogged.Checked
        Show-App
        return
    }

    if ($username -eq $script:OwnerUsername -and (Get-PasswordHash $password) -eq $script:OwnerPasswordHash) {
        Sign-In $username
        Save-Session $username $script:StayLogged.Checked
        Show-App
        return
    }

    $user = @($script:State.Users) | Where-Object { $_.Username -eq $username } | Select-Object -First 1
    if ($null -eq $user -or $user.PasswordHash -ne (Get-PasswordHash $password)) {
        $script:AuthMessage.Text = "Username or password is incorrect."
        return
    }
    $script:State["User"] = $user
    Save-Session $username $script:StayLogged.Checked
    Show-App
}

function Sign-In($Username) {
    if ($Username -eq $script:OwnerUsername) {
        $ownerState = Load-OwnerState
        $script:State["User"] = [pscustomobject]@{
            Username = "owner"
            Plan = "founder"
            CreatedAt = "2026-04-25T00:00:00.000Z"
            Settings = $(if ($ownerState) { $ownerState.Settings } else { [pscustomobject]@{ Experimental = $true; ShowRisky = $true; RestorePoint = $true; RegistryBackup = $true; CompactCards = $false } })
            Profile = $(if ($ownerState) { $ownerState.Profile } else { [pscustomobject](Copy-Map $script:DefaultProfile) })
            Activity = $(if ($ownerState) { @($ownerState.Activity) } else { @() })
        }
        return
    }
    $script:State["User"] = @($script:State.Users) | Where-Object { $_.Username -eq $Username } | Select-Object -First 1
}

function Set-NavButtonState($ActiveView) {
    if ($null -eq $script:NavButtons) { return }
    foreach ($key in $script:NavButtons.Keys) {
        $button = $script:NavButtons[$key]
        if ($null -eq $button -or $button.IsDisposed) { continue }
        if ($key -eq $ActiveView) {
            $button.BackColor = $script:Colors.Hover
            $button.ForeColor = $script:Colors.Text
            try {
                $button.BorderColor = $script:Colors.Accent
                $button.AccentColor = $script:Colors.Accent
                $button.HoverBackColor = $script:Colors.Hover
                $button.DownBackColor = $script:Colors.Panel2
            } catch {}
            $button.FlatAppearance.BorderColor = $script:Colors.Accent
            $button.FlatAppearance.MouseOverBackColor = $script:Colors.Hover
            $button.FlatAppearance.MouseDownBackColor = $script:Colors.Panel2
            Set-ApexNavButtonIcon $button $true
        } else {
            $button.BackColor = $script:Colors.Sidebar
            $button.ForeColor = $script:Colors.Muted
            try {
                $button.BorderColor = $script:Colors.Line
                $button.AccentColor = $script:Colors.Accent
                $button.HoverBackColor = $script:Colors.Hover
                $button.DownBackColor = $script:Colors.Panel2
            } catch {}
            $button.FlatAppearance.BorderColor = $script:Colors.Line
            $button.FlatAppearance.MouseOverBackColor = $script:Colors.Hover
            $button.FlatAppearance.MouseDownBackColor = $script:Colors.Panel2
            Set-ApexNavButtonIcon $button $false
        }
        try { $button.Invalidate() } catch {}
    }
}


function Show-App {
    $script:State["Settings"] = Merge-Map $script:DefaultSettings $script:State.User.Settings
    if ($script:PerformanceMode) { $script:State.Settings["CompactCards"] = $true }
    $script:State["Profile"] = Merge-Map $script:DefaultProfile $script:State.User.Profile
    Apply-ColorTheme
    Apply-WindowStartupMode
    $script:State["Hardware"] = Get-StartupHardwareInfo
    Apply-HardwareProfile $script:State.Hardware
    $script:State["Selected"] = @{}
    $script:Form.Controls.Clear()
    $script:BrandMarkLabels = @()
    $script:Form.Text = "ApexTune Eclipse - Command UI v62.10"
    $script:SidebarCompact = ($script:Form.ClientSize.Width -lt 1320)
    $sidebarWidth = $(if ($script:SidebarCompact) { [int]$script:UiTokens.SidebarCompactWidth } else { [int]$script:UiTokens.SidebarWidth })

    $root = New-Table 1 2 $script:Colors.Bg
    Add-Column $root ([System.Windows.Forms.SizeType]::Absolute) $sidebarWidth
    Add-Column $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-AppSurface $root

    $side = New-Table 3 1 $script:Colors.Sidebar
    $side.Padding = $(if ($script:SidebarCompact) { New-Object System.Windows.Forms.Padding(9, 10, 9, 10) } else { New-Object System.Windows.Forms.Padding(12, 12, 12, 12) })
    Add-Row $side ([System.Windows.Forms.SizeType]::Absolute) $(if ($script:SidebarCompact) { 66 } else { 78 })
    Add-Row $side ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $side ([System.Windows.Forms.SizeType]::Absolute) $(if ($script:SidebarCompact) { 104 } else { [int]$script:UiTokens.SidebarFooterHeight })
    Add-Column $side ([System.Windows.Forms.SizeType]::Percent) 100
    $root.Controls.Add($side, 0, 0)

    $brand = New-Card 10 $script:Colors.Sidebar
    $brand.Dock = [System.Windows.Forms.DockStyle]::Fill
    $brand.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    $brand.Padding = $(if ($script:SidebarCompact) { New-Object System.Windows.Forms.Padding(8) } else { New-Object System.Windows.Forms.Padding(10, 9, 10, 9) })
    $brand.BorderColor = $script:Colors.Line
    if ($script:SidebarCompact) {
        $markOnly = New-AppMarkLabel 11
        $markOnly.Dock = [System.Windows.Forms.DockStyle]::Fill
        $markOnly.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
        $brand.Controls.Add($markOnly)
        Set-ApexToolTip $brand "ApexTune Eclipse"
    } else {
        $brandGrid = New-Table 1 2 $brand.BackColor
        Add-Column $brandGrid ([System.Windows.Forms.SizeType]::Absolute) 54
        Add-Column $brandGrid ([System.Windows.Forms.SizeType]::Percent) 100
        Add-Row $brandGrid ([System.Windows.Forms.SizeType]::Percent) 100
        $mark = New-AppMarkLabel 11
        $mark.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
        $mark.BackColor = $script:Colors.Accent
        $mark.Margin = New-Object System.Windows.Forms.Padding(0, 0, 12, 0)
        $brandGrid.Controls.Add($mark, 0, 0)
        $brandCopy = New-Table 2 1 $brand.BackColor
        Add-Row $brandCopy ([System.Windows.Forms.SizeType]::Percent) 56
        Add-Row $brandCopy ([System.Windows.Forms.SizeType]::Percent) 44
        Add-Column $brandCopy ([System.Windows.Forms.SizeType]::Percent) 100
        $brandName = New-FillLabel "ApexTune" 13.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
        $brandName.TextAlign = [System.Drawing.ContentAlignment]::BottomLeft
        $brandSub = New-FillLabel "Gaming optimizer" 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
        $brandSub.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
        $brandCopy.Controls.Add($brandName, 0, 0)
        $brandCopy.Controls.Add($brandSub, 0, 1)
        $brandGrid.Controls.Add($brandCopy, 1, 0)
        $brand.Controls.Add($brandGrid)
    }
    $side.Controls.Add($brand, 0, 0)

    $navHost = New-Object System.Windows.Forms.Panel
    $navHost.Dock = [System.Windows.Forms.DockStyle]::Fill
    $navHost.BackColor = $script:Colors.Sidebar
    $navHost.AutoScroll = $false
    $navHost.HorizontalScroll.Enabled = $false
    $navHost.HorizontalScroll.Visible = $false
    $nav = New-Table 9 1 $script:Colors.Sidebar
    $nav.Dock = [System.Windows.Forms.DockStyle]::Top
    $nav.Height = 9 * ([int]$script:UiTokens.SidebarNavHeight + 7)
    Add-Column $nav ([System.Windows.Forms.SizeType]::Percent) 100
    foreach ($i in 1..9) { Add-Row $nav ([System.Windows.Forms.SizeType]::Absolute) ([int]$script:UiTokens.SidebarNavHeight + 7) }
    $dash = New-NavButton "DB" "Dashboard" "dashboard"
    $opt = New-NavButton "OP" "Optimize" "optimize"
    $perf = New-NavButton "PF" "Performance" "performance"
    $net = New-NavButton "NT" "Network" "network"
    $startupNav = New-NavButton "SU" "Startup" "startup"
    $gpuNav = New-NavButton "GP" "GPU" "gpu"
    $ai = New-NavButton "AI" "Apex AI" "ai"
    $act = New-NavButton "AC" "Activity" "activity"
    $set = New-NavButton "ST" "Settings" "settings"
    $nav.Controls.Add($dash, 0, 0); $nav.Controls.Add($opt, 0, 1); $nav.Controls.Add($perf, 0, 2); $nav.Controls.Add($net, 0, 3); $nav.Controls.Add($startupNav, 0, 4); $nav.Controls.Add($gpuNav, 0, 5); $nav.Controls.Add($ai, 0, 6); $nav.Controls.Add($act, 0, 7); $nav.Controls.Add($set, 0, 8)
    $navHost.Controls.Add($nav)
    $side.Controls.Add($navHost, 0, 1)
    $script:NavButtons = @{ dashboard = $dash; optimize = $opt; performance = $perf; network = $net; startup = $startupNav; gpu = $gpuNav; ai = $ai; activity = $act; settings = $set }

    $footer = New-Table 3 1 $script:Colors.Sidebar
    Add-Column $footer ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $footer ([System.Windows.Forms.SizeType]::Absolute) 24
    Add-Row $footer ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $footer ([System.Windows.Forms.SizeType]::Percent) 50
    $script:PlanLabel = New-FillLabel "" 8.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent
    $script:PlanLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $footer.Controls.Add($script:PlanLabel, 0, 0)
    $account = New-Button $(if ($script:SidebarCompact) { "Me" } else { "Account" }) 0 0 0 0 "ghost"
    $account.Dock = [System.Windows.Forms.DockStyle]::Fill
    $account.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 7)
    $footer.Controls.Add($account, 0, 1)
    $script:NavButtons.account = $account
    $logout = New-Button $(if ($script:SidebarCompact) { "Out" } else { "Log out" }) 0 0 0 0 "ghost"
    $logout.Dock = [System.Windows.Forms.DockStyle]::Fill
    $logout.Margin = New-Object System.Windows.Forms.Padding(0)
    $footer.Controls.Add($logout, 0, 2)
    Set-ApexToolTip $account "Account"
    Set-ApexToolTip $logout "Log out"
    $side.Controls.Add($footer, 0, 2)

    $shell = New-Table 2 1 $script:Colors.Bg
    $shell.Padding = New-Object System.Windows.Forms.Padding(0, 4, 8, 8)
    Add-Row $shell ([System.Windows.Forms.SizeType]::Absolute) ([int]$script:UiTokens.HeaderHeight)
    Add-Row $shell ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $shell ([System.Windows.Forms.SizeType]::Percent) 100
    $root.Controls.Add($shell, 1, 0)

    $topShell = New-GradientCard 14 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Accent $false
    $topShell.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    $topShell.Padding = New-Object System.Windows.Forms.Padding(14, 6, 12, 6)
    $topShell.CornerRadius = 18
    $topShell.BorderColor = $script:Colors.Line
    $topbar = New-Table 1 5 $script:Colors.Card
    Add-Column $topbar ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $topbar ([System.Windows.Forms.SizeType]::Absolute) 104
    Add-Column $topbar ([System.Windows.Forms.SizeType]::Absolute) 106
    Add-Column $topbar ([System.Windows.Forms.SizeType]::Absolute) 116
    Add-Column $topbar ([System.Windows.Forms.SizeType]::Absolute) 116
    Add-Row $topbar ([System.Windows.Forms.SizeType]::Percent) 100
    $titleBlock = New-Table 3 1 $script:Colors.Card
    Add-Row $titleBlock ([System.Windows.Forms.SizeType]::Absolute) 20
    Add-Row $titleBlock ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $titleBlock ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $titleBlock ([System.Windows.Forms.SizeType]::Percent) 100
    $script:WelcomeLabel = New-FillLabel "" 8.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Teal
    $script:WelcomeLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $titleBlock.Controls.Add($script:WelcomeLabel, 0, 0)
    $script:MainTitleLabel = New-FillLabel "Eclipse command center" 14.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $script:MainTitleLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $titleBlock.Controls.Add($script:MainTitleLabel, 0, 1)
    $script:MainSubtitleLabel = New-FillLabel "Safe plans, live telemetry, rollback trails, and driver guidance." 7.8 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $script:MainSubtitleLabel.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $titleBlock.Controls.Add($script:MainSubtitleLabel, 0, 2)
    $topbar.Controls.Add($titleBlock, 0, 0)
    $ownerPill = New-Badge $(if ($script:State.User.Username -eq "owner") { "OWNER" } else { "USER" }) $script:Colors.Accent $script:Colors.Field 96
    $onlinePill = New-Badge "ONLINE" $script:Colors.Green $script:Colors.Field 98
    $topbar.Controls.Add($ownerPill, 1, 0)
    $topbar.Controls.Add($onlinePill, 2, 0)
    $accountTop = New-Button "Account" 0 0 0 0 "ghost"
    $script:UpgradeButton = New-Button "Upgrade" 0 0 0 0 "secondary"
    foreach ($button in @($accountTop, $script:UpgradeButton)) {
        $button.Dock = [System.Windows.Forms.DockStyle]::Fill
        $button.Margin = New-Object System.Windows.Forms.Padding(10, 12, 0, 12)
        $button.MinimumSize = New-Object System.Drawing.Size(0, 44)
    }
    $topbar.Controls.Add($accountTop, 3, 0)
    $topbar.Controls.Add($script:UpgradeButton, 4, 0)
    $topShell.Controls.Add($topbar)
    $shell.Controls.Add($topShell, 0, 0)

    $script:ContentHost = New-ApexUiControl "ApexBufferedPanel"
    $script:ContentHost.Dock = [System.Windows.Forms.DockStyle]::Fill
    $script:ContentHost.BackColor = $script:Colors.Bg
    $script:ContentHost.Margin = New-Object System.Windows.Forms.Padding(0)
    $script:ContentHost.Padding = New-Object System.Windows.Forms.Padding(0)
    $shell.Controls.Add($script:ContentHost, 0, 1)
    $script:Content = $null

    $dash.Add_Click({ Show-View "dashboard" }); $opt.Add_Click({ Show-View "optimize" }); $perf.Add_Click({ Show-View "performance" }); $net.Add_Click({ Show-View "network" }); $startupNav.Add_Click({ Show-View "startup" }); $gpuNav.Add_Click({ Show-View "gpu" }); $ai.Add_Click({ Show-View "ai" }); $act.Add_Click({ Show-View "activity" }); $set.Add_Click({ Show-View "settings" })
    $account.Add_Click({ Show-View "account" }); $accountTop.Add_Click({ Show-View "account" }); $script:UpgradeButton.Add_Click({ Show-PayDialog })
    $logout.Add_Click({ Clear-Session; $script:State["User"] = $null; Build-AuthView })
    $script:Form.Add_SizeChanged({
        try {
            if ($null -ne $script:CardsFlow -and -not $script:CardsFlow.IsDisposed) {
                $newWidth = Get-ResponsiveTweakCardWidth
                if ([Math]::Abs($newWidth - [int]$script:TweakCardWidth) -ge 28) { Render-TweakCards }
            }
        } catch {}
    }.GetNewClosure())

    Update-Header
    Show-View "dashboard"
    Start-ApexUpdatePolling
    Start-HardwareAutoScan
    Normalize-LabelBackColors $script:Form
    Apply-ApexTextSafety $script:Form
}


function Update-Header {
    $premium = Has-Premium
    $script:WelcomeLabel.Text = "WELCOME, " + $script:State.User.Username.ToUpperInvariant()
    $script:PlanLabel.Text = $(if ($script:State.User.Plan -eq "founder") { "Owner plan" } elseif ($premium) { "Pro plan" } else { "Free plan" })
    $script:UpgradeButton.Visible = -not $premium
}

function Set-TopHeader($View) {
    if ($null -eq $script:MainTitleLabel -or $null -eq $script:MainSubtitleLabel) { return }

    $title = "Dashboard"
    $subtitle = "A complete hardware-aware overview for FPS, latency, and system tuning."
    if ($View -eq "optimize") {
        $title = "Optimize"
        $subtitle = "Review recommended and general tuning cards for this hardware profile."
    } elseif ($View -eq "performance") {
        $title = "Performance"
        $subtitle = "Review FPS-focused CPU, Windows, power, and background tuning cards."
    } elseif ($View -eq "network") {
        $title = "Network"
        $subtitle = "Review ping-focused adapter, DNS, TCP, and bandwidth tuning cards."
    } elseif ($View -eq "startup") {
        $title = "Startup Optimizer"
        $subtitle = "Audit startup apps, launchers, scheduled tasks, and background services before your gaming session."
    } elseif ($View -eq "gpu") {
        $title = "GPU"
        $subtitle = "Review graphics-card related tuning paths, driver status, and vendor driver utilities."
    } elseif ($View -eq "ai") {
        $title = "Apex AI Assistant"
        $subtitle = "Chat with the local tuning advisor for driver checks, FPS picks, ping guidance, and PC recommendations."
    }
    if ($View -eq "account") {
        $title = "Account and billing"
        $subtitle = "Manage your local account, unlock state, and saved profile."
    } elseif ($View -eq "activity") {
        $title = "Recent plans"
        $subtitle = "Review applied plans, premium unlocks, and optimization history."
    } elseif ($View -eq "settings") {
        $title = "Optimizer preferences"
        $subtitle = "Control which tweak groups appear and how cautious the apply plan should be."
    }

    $script:MainTitleLabel.Text = $title
    $script:MainSubtitleLabel.Text = $subtitle
    Normalize-LabelBackColors $script:MainTitleLabel.Parent
}

function Stop-PageSlideTransition {
    if ($null -ne $script:PageTransitionTimer) {
        try { $script:PageTransitionTimer.Stop() } catch {}
        try { $script:PageTransitionTimer.Dispose() } catch {}
        $script:PageTransitionTimer = $null
    }
    if ($null -ne $script:ContentHost -and -not $script:ContentHost.IsDisposed -and $null -ne $script:Content -and -not $script:Content.IsDisposed) {
        try {
            $script:Content.Dock = [System.Windows.Forms.DockStyle]::Fill
            $script:Content.Bounds = $script:ContentHost.ClientRectangle
            $script:Content.Visible = $true
            $script:Content.BringToFront()
        } catch {}
        foreach ($control in @($script:ContentHost.Controls)) {
            if ([string]$control.Tag -like "transition*") {
                try { $script:ContentHost.Controls.Remove($control) } catch {}
                try { $control.Dispose() } catch {}
            } elseif (-not [object]::ReferenceEquals($control, $script:Content)) {
                try { $script:ContentHost.Controls.Remove($control) } catch {}
                try { $control.Dispose() } catch {}
            }
        }
    }
}

function Start-PageSlideTransition($OldContent, $NewContent, [bool]$ShouldAnimate) {
    if ($null -eq $script:ContentHost -or $script:ContentHost.IsDisposed -or $null -eq $NewContent -or $NewContent.IsDisposed) { return }

    if (-not $ShouldAnimate -or $null -eq $OldContent -or $OldContent.IsDisposed) {
        $NewContent.Dock = [System.Windows.Forms.DockStyle]::Fill
        $NewContent.Bounds = $script:ContentHost.ClientRectangle
        $NewContent.Visible = $true
        $NewContent.BringToFront()
        if ($null -ne $OldContent -and -not $OldContent.IsDisposed) {
            try { $script:ContentHost.Controls.Remove($OldContent) } catch {}
            try { $OldContent.Dispose() } catch {}
        }
        return
    }

    $hostBounds = $script:ContentHost.ClientRectangle
    $NewContent.Dock = [System.Windows.Forms.DockStyle]::None
    $NewContent.Bounds = $hostBounds
    $NewContent.Visible = $true
    $NewContent.Enabled = $true
    $NewContent.BringToFront()

    $accent = New-Object System.Windows.Forms.Panel
    $accent.BackColor = $script:Colors.Accent
    $accent.Height = 2
    $accent.Width = 0
    $accent.Left = 0
    $accent.Top = 0
    $accent.Tag = "transitionAccent"
    $script:ContentHost.Controls.Add($accent)
    $accent.BringToFront()

    try { $NewContent.PerformLayout() } catch {}
    if ($null -ne $OldContent -and -not $OldContent.IsDisposed) {
        try { $script:ContentHost.Controls.Remove($OldContent) } catch {}
        try { $OldContent.Dispose() } catch {}
    }

    try {
        $totalFrames = 5
        foreach ($frame in 1..$totalFrames) {
            if ($null -eq $NewContent -or $NewContent.IsDisposed -or $null -eq $script:ContentHost -or $script:ContentHost.IsDisposed) { break }
            $progress = [Math]::Min(1.0, $frame / [double]$totalFrames)
            $ease = $progress * $progress * (3.0 - (2.0 * $progress))
            $bounds = $script:ContentHost.ClientRectangle
            $revealWidth = [int]($bounds.Width * $ease)
            if ($null -ne $accent -and -not $accent.IsDisposed) {
                $accent.Width = [Math]::Max(1, $revealWidth)
                $accent.Top = 0
                $accent.Left = 0
                $accent.BringToFront()
            }
            try { $script:ContentHost.Refresh(); [System.Windows.Forms.Application]::DoEvents() } catch {}
            Start-Sleep -Milliseconds 4
        }
    } finally {
        try {
            if ($null -ne $accent -and -not $accent.IsDisposed) {
                if ($accent.Parent) { $accent.Parent.Controls.Remove($accent) }
                $accent.Dispose()
            }
        } catch {}
        try {
            $NewContent.Dock = [System.Windows.Forms.DockStyle]::Fill
            $NewContent.Bounds = $script:ContentHost.ClientRectangle
            $NewContent.Enabled = $true
            $NewContent.BringToFront()
        } catch {}
        $script:PageTransitionTimer = $null
    }
}

function Show-View($View) {
    if ($null -eq $script:ContentHost -or $script:ContentHost.IsDisposed) { return }
    if ($script:ActiveView -in @("optimize", "performance", "network", "startup", "gpu") -and $View -in @("optimize", "performance", "network", "startup", "gpu") -and $null -ne $script:Content -and -not $script:Content.IsDisposed) {
        try {
            $script:DashboardSection = $View
            $script:ActiveView = $View
            Set-TopHeader $View
            Set-NavButtonState $View
            Update-DashboardLibraryChrome
            $script:TweakPage = 1
            Render-TweakCards
            Render-Queue
            return
        } catch {}
    }

    if ($script:ActiveView -eq $View -and $null -ne $script:Content -and -not $script:Content.IsDisposed) { return }

    Stop-PageSlideTransition
    $oldContent = $script:Content
    $shouldAnimate = $false # v13: instant tab switches; no frame-by-frame transition lag
    $newContent = New-ApexUiControl "ApexBufferedPanel"
    $newContent.Dock = [System.Windows.Forms.DockStyle]::None
    $newContent.Bounds = $script:ContentHost.ClientRectangle
    $newContent.BackColor = $script:Colors.Bg
    $newContent.Margin = New-Object System.Windows.Forms.Padding(0)
    $newContent.Padding = New-Object System.Windows.Forms.Padding(0)
    $newContent.Visible = $false
    $script:ContentHost.Controls.Add($newContent)
    $script:Content = $newContent

    $script:TweakPage = 1
    $script:ActiveView = $View
    Set-TopHeader $View
    Set-NavButtonState $View
    $isLiveDashboardView = ($View -in @("dashboard", "optimize", "performance", "network", "startup", "gpu"))
    if (-not $isLiveDashboardView) { Stop-LiveStatsTimer }

    try {
        if ($isLiveDashboardView) {
            $script:DashboardSection = $View
            Build-Dashboard
        } elseif ($View -eq "ai") {
            Build-AIAssistant
        } elseif ($View -eq "account") {
            Build-Account
        } elseif ($View -eq "activity") {
            Build-Activity
        } elseif ($View -eq "settings") {
            Build-Settings
        }
    } catch {
        $message = $_.Exception.Message
        $logPath = Write-ApexErrorLog "ApexTune-LastError.txt" $_ $message
        try { if ($newContent.Parent) { $newContent.Parent.Controls.Remove($newContent) } } catch {}
        try { $newContent.Dispose() } catch {}
        $script:Content = $oldContent
        if ($null -ne $oldContent -and -not $oldContent.IsDisposed) { $oldContent.Visible = $true; $oldContent.BringToFront() }
        [System.Windows.Forms.MessageBox]::Show($script:Form, "ApexTune caught a UI error instead of crashing.`n`n$message`n`nSaved to: %APPDATA%\ApexTune\ApexTune-LastError.txt", "ApexTune stability guard", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
        return
    }

    Normalize-LabelBackColors $newContent
    Apply-ApexTextSafety $newContent
    Start-PageSlideTransition $oldContent $newContent $shouldAnimate
    $script:Content = $newContent
}

function Get-DashboardEyebrow {
    $section = $(if ($script:DashboardSection) { $script:DashboardSection } else { "dashboard" })
    if ($section -eq "performance") { return "PERFORMANCE LIBRARY" }
    if ($section -eq "network") { return "NETWORK LIBRARY" }
    if ($section -eq "startup") { return "STARTUP OPTIMIZER" }
    if ($section -eq "gpu") { return "GPU LIBRARY" }
    if ($section -eq "optimize") { return "OPTIMIZATION LIBRARY" }
    return "UNIFIED TWEAK LIBRARY"
}

function Get-DashboardLibraryTitle {
    $section = $(if ($script:DashboardSection) { $script:DashboardSection } else { "dashboard" })
    if ($section -eq "performance") { return "Performance tweaks" }
    if ($section -eq "network") { return "Network tweaks" }
    if ($section -eq "startup") { return "Startup optimizer" }
    if ($section -eq "gpu") { return "GPU tweaks" }
    if ($section -eq "optimize") { return "Optimization workspace" }
    return "Unified tweak library"
}

function Get-DashboardLibrarySubtitle {
    $section = $(if ($script:DashboardSection) { $script:DashboardSection } else { "dashboard" })
    if ($section -eq "performance") { return "FPS, power, Windows, CPU, and background tuning cards." }
    if ($section -eq "network") { return "Ping, DNS, adapter, and bandwidth related tuning cards." }
    if ($section -eq "startup") { return "Startup apps, launchers, scheduled tasks, and background services you can audit or disable safely." }
    if ($section -eq "gpu") { return "Graphics-card related cards matched to the detected hardware." }
    if ($section -eq "optimize") { return "All real tweak cards. Game guides live in Apex AI." }
    return "Search, filter, pick, and inspect every real tweak card."
}



function Update-DashboardLibraryChrome {
    try {
        if ($null -ne $script:LibraryEyebrowLabel -and -not $script:LibraryEyebrowLabel.IsDisposed) { $script:LibraryEyebrowLabel.Text = Get-DashboardEyebrow }
        if ($null -ne $script:LibraryTitleLabel -and -not $script:LibraryTitleLabel.IsDisposed) { $script:LibraryTitleLabel.Text = Get-DashboardLibraryTitle }
        if ($null -ne $script:LibrarySubtitleLabel -and -not $script:LibrarySubtitleLabel.IsDisposed) { $script:LibrarySubtitleLabel.Text = Get-DashboardLibrarySubtitle }
    } catch {}
}

function Get-TweakLibraryGroup($Tweak) {
    $category = ([string]$Tweak.Category).ToLowerInvariant()
    $tags = ([string](($Tweak.Tags -join " ") + " " + $Tweak.Title + " " + $Tweak.Summary)).ToLowerInvariant()
    if ($category -eq "network" -or $tags -match "\b(network|ping|dns|tcp|winsock|adapter|ethernet|wifi|wi-fi|packet|latency|router|dhcp|arp)\b") { return "Network" }
    if ($category -in @("gpu", "display") -or $tags -match "\b(gpu|nvidia|amd|intel|graphics|shader|directx|pcie|fullscreen|display|refresh|vrr|hdr|overlay)\b") { return "GPU / Display" }
    if ($category -eq "power" -or $tags -match "\b(power|battery|throttle|performance plan|processor|cooling|sleep|hibernate|oem)\b") { return "Performance / Power" }
    if ($category -eq "input" -or $tags -match "\b(mouse|keyboard|input|foreground|process|priority)\b") { return "Input / Latency" }
    if ($category -in @("maintenance", "memory", "storage") -or $tags -match "\b(cache|storage|cleanup|standby|memory|stutter|temp|trim|ssd|recycle)\b") { return "Maintenance / Storage" }
    if ($category -eq "diagnostics" -or $tags -match "\b(diagnostics|report|scan|repair|driver inventory|reliability|event viewer|crash|thermal|baseline)\b") { return "Diagnostics" }
    if ($category -in @("services", "startup") -or $tags -match "\b(service|sysmain|startup|onedrive|edge|teams|background)\b") { return "Services / Startup" }
    if ($category -in @("audio", "game", "privacy", "boot") -or $tags -match "\b(audio|game|fortnite|valorant|roblox|rainbow six|privacy|telemetry|bcd|timer)\b") { return "Optimize / Windows" }
    return "Optimize / Windows"
}

function Get-TweakLibraryGroupSubtitle($Group) {
    switch ([string]$Group) {
        "Network" { return "Ping, DNS, Winsock, TCP, adapter, and bandwidth tuning." }
        "GPU / Display" { return "Driver, graphics, shader cache, fullscreen, and display-related cards." }
        "Performance / Power" { return "Power plans, CPU scheduling, throttling, and FPS stability cards." }
        "Input / Latency" { return "Mouse, foreground priority, and input-delay focused cards." }
        "Maintenance / Storage" { return "Cache, shader, temp, disk, memory, storage, and stutter-maintenance routines." }
        "Services / Startup" { return "Startup apps, Windows services, launchers, and background-process cards." }
        "Diagnostics" { return "Reports, repair scans, crash tools, driver inventory, and baseline checks." }
        default { return "General Windows and safe first-pass optimization cards." }
    }
}

function Get-TweakLibraryGroupAccent($Group) {
    switch ([string]$Group) {
        "Network" { return $script:Colors.Teal }
        "GPU / Display" { return $script:Colors.Violet }
        "Performance / Power" { return $script:Colors.Green }
        "Input / Latency" { return $script:Colors.Accent }
        "Maintenance / Storage" { return $script:Colors.Amber }
        "Services / Startup" { return $script:Colors.Red }
        "Diagnostics" { return $script:Colors.Teal }
        default { return $script:Colors.Accent }
    }
}

function New-LibraryStatTile($Label, $Value, $Accent) {
    $tile = New-Card 6 $script:Colors.Field
    $tile.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
    $tile.Padding = New-Object System.Windows.Forms.Padding(10, 4, 10, 4)
    $tile.BorderColor = $script:Colors.Line
    $grid = New-Table 1 2 $tile.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 55
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 45
    $name = New-FillLabel ([string]$Label) 7.1 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $name.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $value = New-FillLabel ([string]$Value) 9.2 ([System.Drawing.FontStyle]::Bold) $Accent
    $value.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $grid.Controls.Add($name, 0, 0)
    $grid.Controls.Add($value, 1, 0)
    $tile.Controls.Add($grid)
    return $tile
}


function New-LibraryStatsStrip {
    $allowed = @($script:Tweaks | Where-Object { Test-TweakAllowedBySettings $_ })
    $visible = @(Get-VisibleTweaks)
    $freeCount = @($allowed | Where-Object { $_.Tier -eq "Free" }).Count
    $proCount = @($allowed | Where-Object { $_.Tier -eq "Pro" }).Count
    $selectedCount = @($script:State.Selected.Keys).Count
    $strip = New-Table 1 5 $script:Colors.Card
    $strip.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 4)
    foreach ($i in 1..5) { Add-Column $strip ([System.Windows.Forms.SizeType]::Percent) 20 }
    Add-Row $strip ([System.Windows.Forms.SizeType]::Percent) 100
    $strip.Controls.Add((New-LibraryStatTile "Catalog" $allowed.Count $script:Colors.Accent), 0, 0)
    $strip.Controls.Add((New-LibraryStatTile "Showing" $visible.Count $script:Colors.Green), 1, 0)
    $strip.Controls.Add((New-LibraryStatTile "Free" $freeCount $script:Colors.Teal), 2, 0)
    $strip.Controls.Add((New-LibraryStatTile "Pro" $proCount $script:Colors.Amber), 3, 0)
    $strip.Controls.Add((New-LibraryStatTile "Queued" $selectedCount $script:Colors.Violet), 4, 0)
    return $strip
}


function New-TweakCategoryHeader($Group, $Count) {
    $accent = Get-TweakLibraryGroupAccent $Group
    $width = 680
    if ($null -ne $script:CardsFlow -and -not $script:CardsFlow.IsDisposed -and $script:CardsFlow.ClientSize.Width -gt 0) {
        $width = [Math]::Max(340, [int]($script:CardsFlow.ClientSize.Width - 34))
    }
    $card = New-Card 12 $script:Colors.Panel2
    $card.Dock = [System.Windows.Forms.DockStyle]::None
    $card.Width = $width
    $card.Height = 62
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 16, 12)
    $card.BorderColor = $accent

    $grid = New-Table 1 3 $card.BackColor
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 8
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 86
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $bar = New-Object System.Windows.Forms.Panel
    $bar.Dock = [System.Windows.Forms.DockStyle]::Fill
    $bar.BackColor = $accent
    $bar.Margin = New-Object System.Windows.Forms.Padding(0)
    $grid.Controls.Add($bar, 0, 0)

    $copy = New-Table 2 1 $card.BackColor
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 28
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $title = New-FillLabel ([string]$Group) 12.5 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $subtitle = New-FillLabel (Get-TweakLibraryGroupSubtitle $Group) 8.5 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $subtitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $copy.Controls.Add($title, 0, 0)
    $copy.Controls.Add($subtitle, 0, 1)
    $grid.Controls.Add($copy, 1, 0)

    $badge = New-FillLabel ("{0} cards" -f [int]$Count) 8.2 ([System.Drawing.FontStyle]::Bold) $accent
    $badge.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $badge.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
    $grid.Controls.Add($badge, 2, 0)
    $card.Controls.Add($grid)
    return $card
}

function New-SystemStatusCard($Label, $Title, $Body, $Accent) {
    $card = New-Card 10 $script:Colors.Card
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 16, 12)
    $card.BorderColor = $script:Colors.Line
    Enable-CardHover $card $Accent $script:Colors.Hover

    $grid = New-Table 3 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 18
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 22
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $labelControl = New-FillLabel $Label.ToUpperInvariant() 8 ([System.Drawing.FontStyle]::Bold) $Accent
    $labelControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $titleControl = New-FillLabel ([string]$Title) 11.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $titleControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $bodyControl = New-FillLabel ([string]$Body) 8.4 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $bodyControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft

    $grid.Controls.Add($labelControl, 0, 0)
    $grid.Controls.Add($titleControl, 0, 1)
    $grid.Controls.Add($bodyControl, 0, 2)
    $card.Controls.Add($grid)
    return $card
}

function New-LiveMetricCard($Key, $Label, $Title, $Body, $Accent) {
    $card = New-Card 8 $script:Colors.Card2
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 6)
    $card.Padding = New-Object System.Windows.Forms.Padding(10, 5, 10, 5)
    $card.BorderColor = $script:Colors.Line
    $card.MinimumSize = New-Object System.Drawing.Size(0, [int]$script:UiTokens.MetricCardHeight)
    Enable-CardHover $card $Accent $script:Colors.Hover
    $grid = New-Table 3 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 17
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 27
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $labelControl = New-FillLabel $Label.ToUpperInvariant() 6.9 ([System.Drawing.FontStyle]::Bold) $Accent
    $labelControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $titleControl = New-FillLabel ([string]$Title) 11.6 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $titleControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $titleControl.Margin = New-Object System.Windows.Forms.Padding(0)
    $titleControl.AutoEllipsis = $true
    $bodyControl = New-FillLabel ([string]$Body) 7.1 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $bodyControl.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $bodyControl.Margin = New-Object System.Windows.Forms.Padding(0)
    $bodyControl.AutoEllipsis = $true
    $grid.Controls.Add($labelControl, 0, 0)
    $grid.Controls.Add($titleControl, 0, 1)
    $grid.Controls.Add($bodyControl, 0, 2)
    $card.Controls.Add($grid)
    if ($null -eq $script:LiveMetricLabels) { $script:LiveMetricLabels = @{} }
    $script:LiveMetricLabels[$Key] = @{ Title = $titleControl; Body = $bodyControl }
    return $card
}


function Set-LiveMetric($Key, $Title, $Body) {
    if ($null -eq $script:LiveMetricLabels -or -not $script:LiveMetricLabels.ContainsKey($Key)) { return }
    $entry = $script:LiveMetricLabels[$Key]
    if ($null -eq $entry -or $null -eq $entry.Title -or $entry.Title.IsDisposed) { return }
    $entry.Title.Text = [string]$Title
    if ($null -ne $entry.Body -and -not $entry.Body.IsDisposed) {
        $entry.Body.Text = [string]$Body
    }
}

function Get-LiveCpuUsage {
    try {
        if ($null -ne $script:CpuUsageCounter) {
            $value = [math]::Round([double]$script:CpuUsageCounter.NextValue())
            if ($value -lt 0) { $value = 0 }
            if ($value -gt 100) { $value = 100 }
            return @{ Title = "$value%"; Body = "Processor load" }
        }
    } catch {}
    try {
        $nativeValue = [ApexNativeMetrics]::GetCpuUsage()
        if ($nativeValue -ge 0) {
            $value = [math]::Round([double]$nativeValue)
            return @{ Title = "$value%"; Body = "Processor load" }
        }
    } catch {}
    try {
        $cpu = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -ErrorAction Stop
        if ($null -ne $cpu) {
            $value = [math]::Round([double]$cpu.PercentProcessorTime)
            return @{ Title = "$value%"; Body = "Processor load" }
        }
    } catch {}
    return @{ Title = "--"; Body = "CPU usage unavailable" }
}

function Get-LiveRamUsage {
    try {
        $memory = [ApexNativeMetrics]::GetMemoryStatus()
        if ($null -ne $memory -and $memory.Count -ge 3 -and [double]$memory[2] -gt 0) {
            $usedPct = [math]::Round([double]$memory[0])
            $usedGb = [math]::Round(([double]$memory[1]) / 1GB, 1)
            $totalGb = [math]::Round(([double]$memory[2]) / 1GB, 1)
            return @{ Title = "$usedPct%"; Body = "$usedGb GB / $totalGb GB" }
        }
    } catch {}
    try {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $totalKb = [double]$os.TotalVisibleMemorySize
        $freeKb = [double]$os.FreePhysicalMemory
        if ($totalKb -le 0) { throw "Missing memory total" }
        $usedKb = $totalKb - $freeKb
        $usedPct = [math]::Round(($usedKb / $totalKb) * 100)
        $usedGb = [math]::Round(($usedKb * 1KB) / 1GB, 1)
        $totalGb = [math]::Round(($totalKb * 1KB) / 1GB, 1)
        return @{ Title = "$usedPct%"; Body = "$usedGb GB / $totalGb GB" }
    } catch {
        $hardwareRam = ""
        if ($script:State -and $script:State.Hardware -and $script:State.Hardware.Ram) { $hardwareRam = [string]$script:State.Hardware.Ram }
        return @{ Title = "--"; Body = $(if ($hardwareRam) { $hardwareRam } else { "RAM usage unavailable" }) }
    }
}

function Get-LiveNetworkPing {
    $now = Get-Date
    if ($null -ne $script:LivePingCache -and $script:LivePingCache.ContainsKey("LastSample")) {
        $age = $now - [datetime]$script:LivePingCache.LastSample
        if ($script:LivePingCache.LastSample -ne [datetime]::MinValue -and $age.TotalSeconds -lt 15) {
            return @{ Title = $script:LivePingCache.Title; Body = $script:LivePingCache.Body }
        }
    }

    $targets = @("1.1.1.1", "8.8.8.8")
    foreach ($target in $targets) {
        $ping = $null
        try {
            $ping = New-Object System.Net.NetworkInformation.Ping
            $reply = $ping.Send($target, 55)
            if ($null -ne $reply -and $reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
                $script:LivePingCache = @{
                    Title = "$($reply.RoundtripTime) ms"
                    Body = "Ping to $target"
                    LastSample = $now
                }
                return @{ Title = $script:LivePingCache.Title; Body = $script:LivePingCache.Body }
            }
        } catch {
        } finally {
            if ($null -ne $ping) { $ping.Dispose() }
        }
    }
    $script:LivePingCache = @{
        Title = "--"
        Body = "Ping unavailable"
        LastSample = $now
    }
    return @{ Title = $script:LivePingCache.Title; Body = $script:LivePingCache.Body }
}

function Get-LiveFpsEstimate {
    $items = @(Get-SelectedTweaks)
    $source = "Selected plan estimate"
    if ($items.Count -eq 0) {
        $items = @(Get-RecommendedTweaksForSelection | Where-Object { -not (Is-Locked $_) })
        $source = "Recommended estimate"
    }
    $fps = ($items | Measure-Object -Property Fps -Sum).Sum
    if ($null -eq $fps) { $fps = 0 }
    if ($fps -gt 0) { return @{ Title = "+$fps FPS"; Body = $source } }
    return @{ Title = "0 FPS"; Body = $source }
}

function Update-LiveDashboardMetrics {
    if ($script:IsRenderingCards) { return }
    if ($null -eq $script:LiveMetricLabels -or $script:LiveMetricLabels.Count -eq 0) { return }

    $cpu = Get-LiveCpuUsage
    Set-LiveMetric "cpu" $cpu.Title $cpu.Body

    $ram = Get-LiveRamUsage
    Set-LiveMetric "ram" $ram.Title $ram.Body

    $ping = Get-LiveNetworkPing
    Set-LiveMetric "ping" $ping.Title $ping.Body

    $fps = Get-LiveFpsEstimate
    Set-LiveMetric "fps" $fps.Title $fps.Body

    try {
        $score = Get-ApexOptimizationScore $script:State.Hardware
        $grade = Get-ApexScoreGrade $score
        Set-LiveMetric "score" ("{0} / 100" -f $score) ("Grade $grade")
        Set-LiveMetric "profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ((Get-ProfileValue "Network" "ethernet") + " / " + (Get-ProfileValue "Game" "esports"))
    } catch {}
}


function Stop-LiveStatsTimer {
    if ($null -ne $script:LiveStatsWarmupTimer) {
        try { $script:LiveStatsWarmupTimer.Stop() } catch {}
        try { $script:LiveStatsWarmupTimer.Dispose() } catch {}
        $script:LiveStatsWarmupTimer = $null
    }
    if ($null -ne $script:LiveStatsTimer) {
        try { $script:LiveStatsTimer.Stop() } catch {}
        try { $script:LiveStatsTimer.Dispose() } catch {}
        $script:LiveStatsTimer = $null
$script:UpdateCheckTimer = $null
$script:LastUpdateVersionPrompted = ""
    }
    if ($null -ne $script:CpuUsageCounter) {
        try { $script:CpuUsageCounter.Dispose() } catch {}
        $script:CpuUsageCounter = $null
    }
}

function Start-LiveStatsTimer {
    Stop-LiveStatsTimer
    $script:CpuUsageCounter = $null
    try { [void][ApexNativeMetrics]::GetCpuUsage() } catch {}

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 12000
    $timer.Add_Tick({ Update-LiveDashboardMetrics }.GetNewClosure())
    $script:LiveStatsTimer = $timer
    $timer.Start()

    $warmup = New-Object System.Windows.Forms.Timer
    $warmup.Interval = 5200
    $warmup.Add_Tick({
        try { $warmup.Stop() } catch {}
        try { $warmup.Dispose() } catch {}
        if ($script:LiveStatsWarmupTimer -eq $warmup) { $script:LiveStatsWarmupTimer = $null }
        Update-LiveDashboardMetrics
    }.GetNewClosure())
    $script:LiveStatsWarmupTimer = $warmup
    $warmup.Start()
}


function New-HomeActionCard($Eyebrow, $Title, $Body, $ButtonText, [scriptblock]$Click, $Accent = $null) {
    $accentColor = $(if ($Accent) { $Accent } else { $script:Colors.Accent })
    $card = New-Card 14 $script:Colors.Card2
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 12, 12)
    $card.Padding = New-Object System.Windows.Forms.Padding(14, 12, 14, 12)
    $card.BorderColor = $script:Colors.Line
    Enable-CardHover $card $accentColor $script:Colors.Hover

    $grid = New-Table 4 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 22
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 32
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 46
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $eye = New-FillLabel ([string]$Eyebrow).ToUpperInvariant() 7.8 ([System.Drawing.FontStyle]::Bold) $accentColor
    $eye.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $title = New-FillLabel ([string]$Title) 11.6 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $bodyLabel = New-WrapLabel ([string]$Body) 8.5 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $bodyLabel.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $button = New-Button $ButtonText 0 0 0 0 "secondary"
    $button.Dock = [System.Windows.Forms.DockStyle]::Fill
    $button.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 0)
    $button.MinimumSize = New-Object System.Drawing.Size(0, 38)
    $button.AccessibleName = $ButtonText
    if ($Click) { $button.Add_Click($Click) }

    $grid.Controls.Add($eye, 0, 0)
    $grid.Controls.Add($title, 0, 1)
    $grid.Controls.Add($bodyLabel, 0, 2)
    $grid.Controls.Add($button, 0, 3)
    $card.Controls.Add($grid)
    return $card
}

function New-SafetyStrip($BackColor = $null) {
    $back = $(if ($BackColor) { $BackColor } else { $script:Colors.Card })
    $strip = New-Table 1 3 $back
    foreach ($i in 1..3) { Add-Column $strip ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    Add-Row $strip ([System.Windows.Forms.SizeType]::Percent) 100
    $restore = $(if ([bool]$script:State.Settings.RestorePoint) { "Restore ON" } else { "Restore OFF" })
    $backup = $(if ([bool]$script:State.Settings.RegistryBackup) { "Backup ON" } else { "Backup OFF" })
    $strict = $(if ([bool]$script:State.Settings.StrictSafety) { "Strict ON" } else { "Strict OFF" })
    $strip.Controls.Add((New-Badge $restore $(if ([bool]$script:State.Settings.RestorePoint) { $script:Colors.Green } else { $script:Colors.Amber }) $back 92), 0, 0)
    $strip.Controls.Add((New-Badge $backup $(if ([bool]$script:State.Settings.RegistryBackup) { $script:Colors.Teal } else { $script:Colors.Amber }) $back 92), 1, 0)
    $strip.Controls.Add((New-Badge $strict $(if ([bool]$script:State.Settings.StrictSafety) { $script:Colors.Accent } else { $script:Colors.Amber }) $back 92), 2, 0)
    return $strip
}

function Build-HomeDashboard {
    try {
        $script:Content.AutoScroll = $false
        $script:Content.HorizontalScroll.Enabled = $false
        $script:Content.HorizontalScroll.Visible = $false
    } catch {}

    $hardware = $script:State.Hardware
    if ($null -eq $hardware) { $hardware = [pscustomobject]@{ GpuVendor="other"; GpuName="Unknown GPU"; Network="ethernet"; NetworkName="Unknown network"; System="desktop"; CpuName="Unknown CPU"; Ram="Unknown RAM"; Os="Windows"; Model="Unknown PC"; DetectedAt="" } }

    $layout = New-Table 4 1 $script:Colors.Bg
    $layout.Dock = [System.Windows.Forms.DockStyle]::Fill
    $layout.AutoSize = $false
    $layout.MinimumSize = New-Object System.Drawing.Size(0, 0)
    $layout.Height = [Math]::Max(620, [int]$script:ContentHost.ClientSize.Height)
    $layout.Padding = New-Object System.Windows.Forms.Padding(0)
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) 236
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) 150
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) 228
    Add-Row $layout ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $layout ([System.Windows.Forms.SizeType]::Percent) 100
    $script:Content.Controls.Add($layout)

    $score = Get-ApexOptimizationScore $hardware
    $grade = Get-ApexScoreGrade $score
    $hero = New-GradientCard 18 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Accent $false
    $hero.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $hero.Padding = New-Object System.Windows.Forms.Padding(18, 16, 18, 16)
    $hero.BorderColor = $script:Colors.Line
    $heroGrid = New-Table 1 2 $script:Colors.Card
    Add-Column $heroGrid ([System.Windows.Forms.SizeType]::Percent) 34
    Add-Column $heroGrid ([System.Windows.Forms.SizeType]::Percent) 66
    Add-Row $heroGrid ([System.Windows.Forms.SizeType]::Percent) 100

    $copy = New-Table 5 1 $script:Colors.Card
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 24
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 46
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 44
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 44
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $eye = New-FillLabel "ECLIPSE COMMAND CENTER" 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent
    $eye.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $title = New-FillLabel "Ready for safe FPS tuning" 18.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $body = New-WrapLabel "Overview only: live metrics, safety state, hardware profile, and quick actions. Use Optimize for the full tweak library." 9.0 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $body.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $scoreLine = New-FillLabel ("Apex score {0} / 100 - {1}" -f $score, $grade) 10.0 ([System.Drawing.FontStyle]::Bold) $(if ($score -ge 82) { $script:Colors.Green } elseif ($score -ge 68) { $script:Colors.Amber } else { $script:Colors.Red })
    $scoreLine.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $copy.Controls.Add($eye, 0, 0)
    $copy.Controls.Add($title, 0, 1)
    $copy.Controls.Add($body, 0, 2)
    $copy.Controls.Add($scoreLine, 0, 3)
    $copy.Controls.Add((New-SafetyStrip $script:Colors.Card), 0, 4)
    $heroGrid.Controls.Add($copy, 0, 0)

    $metricsGrid = New-Table 2 3 $script:Colors.Card
    foreach ($i in 1..3) { Add-Column $metricsGrid ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    foreach ($i in 1..2) { Add-Row $metricsGrid ([System.Windows.Forms.SizeType]::Percent) 50 }
    $script:LiveMetricLabels = @{}
    $metricsGrid.Controls.Add((New-LiveMetricCard "cpu" "CPU usage" "--" "Loading" $script:Colors.Accent), 0, 0)
    $metricsGrid.Controls.Add((New-LiveMetricCard "ram" "RAM usage" "--" "Memory" $script:Colors.Teal), 1, 0)
    $metricsGrid.Controls.Add((New-LiveMetricCard "ping" "Network ping" "--" "Latency" $script:Colors.Green), 2, 0)
    $metricsGrid.Controls.Add((New-LiveMetricCard "fps" "FPS estimate" "--" "Recommended" $script:Colors.Amber), 0, 1)
    $metricsGrid.Controls.Add((New-LiveMetricCard "score" "Apex score" ("{0} / 100" -f $score) ("Grade $grade") $script:Colors.Violet), 1, 1)
    $metricsGrid.Controls.Add((New-LiveMetricCard "profile" "Active profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ((Get-ProfileValue "Network" "ethernet") + " / " + (Get-ProfileValue "Game" "esports")) $script:Colors.Blue), 2, 1)
    $heroGrid.Controls.Add($metricsGrid, 1, 0)
    $hero.Controls.Add($heroGrid)
    $layout.Controls.Add($hero, 0, 0)

    $statusGrid = New-Table 1 3 $script:Colors.Bg
    foreach ($i in 1..3) { Add-Column $statusGrid ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    Add-Row $statusGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $statusGrid.Controls.Add((New-SystemStatusCard "Safety rails" "Protected apply flow" "Restore point, registry backup, strict confirmations." $script:Colors.Green), 0, 0)
    $statusGrid.Controls.Add((New-SystemStatusCard "Profile" ($hardware.GpuVendor.ToUpperInvariant() + " / " + $hardware.Network.ToUpperInvariant()) "Hardware-aware recommendations after rescan." $script:Colors.Teal), 1, 0)
    $statusGrid.Controls.Add((New-SystemStatusCard "Next step" "Open Optimize" "Browse compact tweak cards and build a small reversible plan." $script:Colors.Accent), 2, 0)
    $layout.Controls.Add($statusGrid, 0, 1)

    $profileCard = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Teal $false
    $profileCard.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $profileCard.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 10)
    $profileGrid = New-Table 1 2 $script:Colors.Card
    Add-Column $profileGrid ([System.Windows.Forms.SizeType]::Percent) 43
    Add-Column $profileGrid ([System.Windows.Forms.SizeType]::Percent) 57
    Add-Row $profileGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $profileLeft = New-Table 2 1 $script:Colors.Card
    Add-Row $profileLeft ([System.Windows.Forms.SizeType]::Absolute) 62
    Add-Row $profileLeft ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $profileLeft ([System.Windows.Forms.SizeType]::Percent) 100
    $profileLeft.Controls.Add((New-SectionTitle "HARDWARE PROFILE" "Detected hardware" "Use Rescan for exact GPU, adapter, RAM, and model detection." $script:Colors.Card), 0, 0)
    $profileControls = New-Table 2 2 $script:Colors.Card
    foreach ($i in 1..2) { Add-Column $profileControls ([System.Windows.Forms.SizeType]::Percent) 50 }
    foreach ($i in 1..2) { Add-Row $profileControls ([System.Windows.Forms.SizeType]::Percent) 50 }
    $gpu = New-Combo @("nvidia", "amd", "intel", "other") 0 0 0 0 $script:State.Profile.Gpu
    $network = New-Combo @("ethernet", "wifi") 0 0 0 0 $script:State.Profile.Network
    $system = New-Combo @("desktop", "laptop") 0 0 0 0 $script:State.Profile.System
    $game = New-Combo @("esports", "aaa", "streaming") 0 0 0 0 $script:State.Profile.Game
    $profileControls.Controls.Add((New-FieldGroup "GPU" $gpu), 0, 0)
    $profileControls.Controls.Add((New-FieldGroup "Connection" $network), 1, 0)
    $profileControls.Controls.Add((New-FieldGroup "System" $system), 0, 1)
    $profileControls.Controls.Add((New-FieldGroup "Game type" $game), 1, 1)
    $profileLeft.Controls.Add($profileControls, 0, 1)
    $profileGrid.Controls.Add($profileLeft, 0, 0)
    $profileGrid.Controls.Add((New-HardwareSummaryCard $hardware), 1, 0)
    $profileCard.Controls.Add($profileGrid)
    $layout.Controls.Add($profileCard, 0, 2)

    $gpu.Add_SelectedIndexChanged({ $script:State.Profile["Gpu"] = $gpu.SelectedItem; Save-CurrentUser; Set-LiveMetric "profile" ([string]$gpu.SelectedItem).ToUpperInvariant() ((Get-ProfileValue "Network" "ethernet") + " / " + (Get-ProfileValue "Game" "esports")) })
    $network.Add_SelectedIndexChanged({ $script:State.Profile["Network"] = $network.SelectedItem; Save-CurrentUser; Set-LiveMetric "profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ([string]$network.SelectedItem + " / " + (Get-ProfileValue "Game" "esports")) })
    $system.Add_SelectedIndexChanged({ $script:State.Profile["System"] = $system.SelectedItem; Save-CurrentUser })
    $game.Add_SelectedIndexChanged({ $script:State.Profile["Game"] = $game.SelectedItem; Save-CurrentUser; Set-LiveMetric "profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ((Get-ProfileValue "Network" "ethernet") + " / " + [string]$game.SelectedItem) })

    $actionsGrid = New-Table 1 4 $script:Colors.Bg
    foreach ($i in 1..4) { Add-Column $actionsGrid ([System.Windows.Forms.SizeType]::Percent) 25 }
    Add-Row $actionsGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $actionsGrid.Controls.Add((New-HomeActionCard "Optimize" "Build a safe plan" "Open the full compact tweak library with filters, selected queue, and apply summary." "Open Optimize" { Show-View "optimize" } $script:Colors.Accent), 0, 0)
    $actionsGrid.Controls.Add((New-HomeActionCard "Report" "Export snapshot" "Save hardware, live metrics, profile, safety settings, and selected-plan metadata." "Snapshot" { Export-ApexSystemSnapshot } $script:Colors.Teal), 1, 0)
    $actionsGrid.Controls.Add((New-HomeActionCard "Latency" "Probe ping" "Run a quick Cloudflare/Google latency sample and save the report to ApexTune Reports." "Latency probe" { Invoke-ApexLatencyProbe } $script:Colors.Green), 2, 0)
    $actionsGrid.Controls.Add((New-HomeActionCard "Safety" "Create restore point" "Request a Windows restore point before bigger optimization sessions." "Restore point" { Invoke-ManualRestorePoint } $script:Colors.Amber), 3, 0)
    $layout.Controls.Add($actionsGrid, 0, 3)

    Update-LiveDashboardMetrics
    Start-LiveStatsTimer
}

function Build-Dashboard {
    if ((Get-ActiveDashboardSection) -eq "dashboard") { Build-HomeDashboard; return }
    if ((Get-ActiveDashboardSection) -eq "dashboard" -and [string]$script:State.Filter -eq "recommended") {
        $script:State["Filter"] = "all"
    }
    try {
        $script:Content.AutoScroll = $false
        $script:Content.HorizontalScroll.Enabled = $false
        $script:Content.HorizontalScroll.Visible = $false
    } catch {}
    $contentWidth = $(if ($null -ne $script:ContentHost -and $script:ContentHost.ClientSize.Width -gt 0) { [int]$script:ContentHost.ClientSize.Width } else { 1200 })
    $profileRowHeight = $(if ((Get-ActiveDashboardSection) -eq "gpu") { 214 } else { 188 })
    $layout = New-Table 3 1 $script:Colors.Bg
    $layout.Dock = [System.Windows.Forms.DockStyle]::Fill
    $layout.AutoSize = $false
    $layout.MinimumSize = New-Object System.Drawing.Size(0, 0)
    $layout.Height = [Math]::Max(520, [int]$script:ContentHost.ClientSize.Height)
    $layout.Padding = New-Object System.Windows.Forms.Padding(0)
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) 116
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) ([Math]::Min($profileRowHeight, 164))
    Add-Row $layout ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $layout ([System.Windows.Forms.SizeType]::Percent) 100
    $script:Content.Controls.Add($layout)

    $hardware = $script:State.Hardware
    if ($null -eq $hardware) { $hardware = [pscustomobject]@{ GpuVendor="other"; GpuName="Unknown GPU"; Network="ethernet"; NetworkName="Unknown network"; System="desktop"; CpuName="Unknown CPU"; Ram="Unknown RAM"; Os="Windows"; Model="Unknown PC"; DetectedAt="" } }

    $hero = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Accent $false
    $hero.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $hero.Padding = New-Object System.Windows.Forms.Padding(14, 8, 14, 8)
    $hero.CornerRadius = 18
    $hero.BorderColor = $script:Colors.Line
    $heroGrid = New-Table 1 2 $script:Colors.Card
    Add-Column $heroGrid ([System.Windows.Forms.SizeType]::Percent) 24
    Add-Column $heroGrid ([System.Windows.Forms.SizeType]::Percent) 76
    Add-Row $heroGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $score = Get-ApexOptimizationScore $hardware
    $grade = Get-ApexScoreGrade $score
    $heroCopy = New-Table 4 1 $script:Colors.Card
    Add-Row $heroCopy ([System.Windows.Forms.SizeType]::Absolute) 16
    Add-Row $heroCopy ([System.Windows.Forms.SizeType]::Absolute) 28
    Add-Row $heroCopy ([System.Windows.Forms.SizeType]::Absolute) 22
    Add-Row $heroCopy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $heroCopy ([System.Windows.Forms.SizeType]::Percent) 100
    $eyebrow = New-FillLabel "ECLIPSE COMMAND CENTER" 8.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent
    $title = New-FillLabel "Live system pulse" 15.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $subtitle = New-FillLabel "Metrics, safety, profile, and queued-plan impact." 7.6 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $safetyLine = New-FillLabel ("Restore {0} / Backup {1} / Strict {2}" -f $(if ($script:State.Settings.RestorePoint) { "ON" } else { "OFF" }), $(if ($script:State.Settings.RegistryBackup) { "ON" } else { "OFF" }), $(if ($script:State.Settings.StrictSafety) { "ON" } else { "OFF" })) 7.8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Green
    foreach ($control in @($eyebrow,$title,$subtitle,$safetyLine)) { $control.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft }
    $heroCopy.Controls.Add($eyebrow, 0, 0); $heroCopy.Controls.Add($title, 0, 1); $heroCopy.Controls.Add($subtitle, 0, 2); $heroCopy.Controls.Add($safetyLine, 0, 3)
    $heroGrid.Controls.Add($heroCopy, 0, 0)

    $metricsGrid = New-Table 2 3 $script:Colors.Card
    foreach ($i in 1..3) { Add-Column $metricsGrid ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    foreach ($i in 1..2) { Add-Row $metricsGrid ([System.Windows.Forms.SizeType]::Percent) 50 }
    $script:LiveMetricLabels = @{}
    $metricsGrid.Controls.Add((New-LiveMetricCard "cpu" "CPU usage" "--" "Loading sample" $script:Colors.Accent), 0, 0)
    $metricsGrid.Controls.Add((New-LiveMetricCard "ram" "RAM usage" "--" "Memory in use" $script:Colors.Teal), 1, 0)
    $metricsGrid.Controls.Add((New-LiveMetricCard "ping" "Network ping" "--" "Latency probe" $script:Colors.Green), 2, 0)
    $metricsGrid.Controls.Add((New-LiveMetricCard "fps" "FPS estimate" "--" "Selected plan" $script:Colors.Amber), 0, 1)
    $metricsGrid.Controls.Add((New-LiveMetricCard "score" "Apex score" ("{0} / 100" -f $score) ("Grade $grade") $script:Colors.Violet), 1, 1)
    $metricsGrid.Controls.Add((New-LiveMetricCard "profile" "Active profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ((Get-ProfileValue "Network" "ethernet") + " / " + (Get-ProfileValue "Game" "esports")) $script:Colors.Blue), 2, 1)
    $heroGrid.Controls.Add($metricsGrid, 1, 0)
    $hero.Controls.Add($heroGrid)
    $layout.Controls.Add($hero, 0, 0)

    $profileCard = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Teal $false
    $profileCard.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $profileCard.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 10)
    $profileCard.CornerRadius = 18
    $profileCard.BorderColor = $script:Colors.Line
    $profileGrid = New-Table 1 2 $script:Colors.Card
    Add-Column $profileGrid ([System.Windows.Forms.SizeType]::Percent) 43
    Add-Column $profileGrid ([System.Windows.Forms.SizeType]::Percent) 57
    Add-Row $profileGrid ([System.Windows.Forms.SizeType]::Percent) 100

    $profileLeft = New-Table 2 1 $script:Colors.Card
    Add-Row $profileLeft ([System.Windows.Forms.SizeType]::Absolute) 74
    Add-Row $profileLeft ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $profileLeft ([System.Windows.Forms.SizeType]::Percent) 100
    $detectedTarget = "Detected target: {0} GPU, {1}, {2}" -f $hardware.GpuVendor.ToUpperInvariant(), $hardware.Network.ToUpperInvariant(), $hardware.System.ToUpperInvariant()
    $profileLeft.Controls.Add((New-SectionTitle "AUTO-DETECTED HARDWARE PROFILE" "Hardware detected" ($detectedTarget + " - tuned for small reversible batches") $script:Colors.Card), 0, 0)
    $profileControls = New-Table 2 2 $script:Colors.Card
    foreach ($i in 1..2) { Add-Column $profileControls ([System.Windows.Forms.SizeType]::Percent) 50 }
    foreach ($i in 1..2) { Add-Row $profileControls ([System.Windows.Forms.SizeType]::Percent) 50 }
    $gpu = New-Combo @("nvidia", "amd", "intel", "other") 0 0 0 0 $script:State.Profile.Gpu
    $network = New-Combo @("ethernet", "wifi") 0 0 0 0 $script:State.Profile.Network
    $system = New-Combo @("desktop", "laptop") 0 0 0 0 $script:State.Profile.System
    $game = New-Combo @("esports", "aaa", "streaming") 0 0 0 0 $script:State.Profile.Game
    $profileControls.Controls.Add((New-FieldGroup "GPU" $gpu), 0, 0)
    $profileControls.Controls.Add((New-FieldGroup "Connection" $network), 1, 0)
    $profileControls.Controls.Add((New-FieldGroup "System" $system), 0, 1)
    $profileControls.Controls.Add((New-FieldGroup "Game type" $game), 1, 1)
    $profileLeft.Controls.Add($profileControls, 0, 1)
    $profileGrid.Controls.Add($profileLeft, 0, 0)
    if ((Get-ActiveDashboardSection) -eq "gpu") { $profileGrid.Controls.Add((New-GpuDriverUtilityCard $hardware), 1, 0) } else { $profileGrid.Controls.Add((New-HardwareSummaryCard $hardware), 1, 0) }
    $profileCard.Controls.Add($profileGrid)
    $layout.Controls.Add($profileCard, 0, 1)

    $gpu.Add_SelectedIndexChanged({ $script:State.Profile["Gpu"] = $gpu.SelectedItem; Save-CurrentUser; Set-LiveMetric "profile" ([string]$gpu.SelectedItem).ToUpperInvariant() ((Get-ProfileValue "Network" "ethernet") + " / " + (Get-ProfileValue "Game" "esports")); Render-TweakCards; Render-Queue })
    $network.Add_SelectedIndexChanged({ $script:State.Profile["Network"] = $network.SelectedItem; Save-CurrentUser; Set-LiveMetric "profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ([string]$network.SelectedItem + " / " + (Get-ProfileValue "Game" "esports")); Render-TweakCards; Render-Queue })
    $system.Add_SelectedIndexChanged({ $script:State.Profile["System"] = $system.SelectedItem; Save-CurrentUser; Render-TweakCards; Render-Queue })
    $game.Add_SelectedIndexChanged({ $script:State.Profile["Game"] = $game.SelectedItem; Save-CurrentUser; Set-LiveMetric "profile" ((Get-ProfileValue "Gpu" "nvidia").ToUpperInvariant()) ((Get-ProfileValue "Network" "ethernet") + " / " + [string]$game.SelectedItem); Render-TweakCards; Render-Queue })

    $main = New-Table 1 2 $script:Colors.Bg
    $queueWidth = $(if ($contentWidth -lt 1240) { 300 } else { [int]$script:UiTokens.QueueWideWidth })
    Add-Column $main ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $main ([System.Windows.Forms.SizeType]::Absolute) $queueWidth
    Add-Row $main ([System.Windows.Forms.SizeType]::Percent) 100
    $layout.Controls.Add($main, 0, 2)

    $library = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Accent $false
    $library.Margin = New-Object System.Windows.Forms.Padding(0, 0, 12, 0)
    $library.CornerRadius = 18
    $library.BorderColor = $script:Colors.Line
    $libraryGrid = New-Table 2 1 $script:Colors.Card
    Add-Row $libraryGrid ([System.Windows.Forms.SizeType]::Absolute) 172
    Add-Row $libraryGrid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $libraryGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $libraryTop = New-Table 4 1 $script:Colors.Card
    $libraryTop.Padding = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    Add-Column $libraryTop ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $libraryTop ([System.Windows.Forms.SizeType]::Absolute) 58
    Add-Row $libraryTop ([System.Windows.Forms.SizeType]::Absolute) 30
    Add-Row $libraryTop ([System.Windows.Forms.SizeType]::Absolute) 38
    Add-Row $libraryTop ([System.Windows.Forms.SizeType]::Absolute) 42
    $libraryCopy = New-SectionTitle (Get-DashboardEyebrow) (Get-DashboardLibraryTitle) (Get-DashboardLibrarySubtitle) $script:Colors.Card
    try { $script:LibraryEyebrowLabel = $libraryCopy.GetControlFromPosition(0, 0); $script:LibraryTitleLabel = $libraryCopy.GetControlFromPosition(0, 1); $script:LibrarySubtitleLabel = $libraryCopy.GetControlFromPosition(0, 2) } catch {}
    $libraryTop.Controls.Add($libraryCopy, 0, 0)
    $libraryTop.Controls.Add((New-LibraryStatsStrip), 0, 1)

    $chipRow = New-Table 1 8 $script:Colors.Card
    foreach ($i in 1..8) { Add-Column $chipRow ([System.Windows.Forms.SizeType]::Percent) 12.5 }
    Add-Row $chipRow ([System.Windows.Forms.SizeType]::Percent) 100
    $chipSpecs = @(
        @{ Text="Recommended"; Value="recommended"; Color=$script:Colors.Accent },
        @{ Text="Safe"; Value="safe"; Color=$script:Colors.Green },
        @{ Text="Aggressive"; Value="aggressive"; Color=$script:Colors.Amber },
        @{ Text="Advanced"; Value="advanced"; Color=$script:Colors.Red },
        @{ Text="All"; Value="all"; Color=$script:Colors.Blue },
        @{ Text="Free"; Value="free"; Color=$script:Colors.Teal },
        @{ Text="Pro"; Value="pro"; Color=$script:Colors.Amber },
        @{ Text="Selected"; Value="selected"; Color=$script:Colors.Violet }
    )
    $c = 0
    foreach ($spec in $chipSpecs) {
        $chip = New-Button $spec.Text 0 0 0 0 $(if ([string]$script:State.Filter -eq [string]$spec.Value) { "primary" } else { "ghost" })
        $chip.Dock = [System.Windows.Forms.DockStyle]::Fill
        $chip.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 4)
        $chip.MinimumSize = New-Object System.Drawing.Size(0, 34)
        $chip.Font = New-Font 8.2 ([System.Drawing.FontStyle]::Bold)
        try { $chip.BorderColor = $(if ([string]$script:State.Filter -eq [string]$spec.Value) { $spec.Color } else { $script:Colors.Line }); $chip.AccentColor = $spec.Color } catch {}
        $value = [string]$spec.Value
        $chip.Add_Click({ $script:State["Filter"] = $value; $script:TweakPage = 1; Render-TweakCards; Render-Queue; Show-Toast ("Filter: " + $value) "ApexTune" }.GetNewClosure())
        $chipRow.Controls.Add($chip, $c, 0)
        $c++
    }
    $libraryTop.Controls.Add($chipRow, 0, 2)

    $toolbar = New-Table 1 5 $script:Colors.Card
    $toolbar.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
    Add-Column $toolbar ([System.Windows.Forms.SizeType]::Percent) 38
    Add-Column $toolbar ([System.Windows.Forms.SizeType]::Percent) 18
    Add-Column $toolbar ([System.Windows.Forms.SizeType]::Percent) 16
    Add-Column $toolbar ([System.Windows.Forms.SizeType]::Percent) 16
    Add-Column $toolbar ([System.Windows.Forms.SizeType]::Absolute) 124
    Add-Row $toolbar ([System.Windows.Forms.SizeType]::Absolute) 42
    $search = New-TextBox 0 0 0 0
    $search.Text = $script:State.Search
    $categories = @("all") + @($script:Tweaks | ForEach-Object { [string]$_.Category } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Sort-Object -Unique)
    $category = New-Combo $categories 0 0 0 0 $(if ($script:State.ContainsKey("CategoryFilter")) { $script:State.CategoryFilter } else { "all" })
    $risk = New-Combo @("all", "Low", "Medium", "High") 0 0 0 0 $(if ($script:State.ContainsKey("RiskFilter")) { $script:State.RiskFilter } else { "all" })
    $sort = New-Combo @("recommended", "fps", "ping", "risk", "name") 0 0 0 0 $(if ($script:State.ContainsKey("Sort")) { $script:State.Sort } else { "recommended" })
    $selectAllVisible = New-Button "Select visible" 0 0 0 0 "secondary"
    $selectAllVisible.Dock = [System.Windows.Forms.DockStyle]::Fill
    $selectAllVisible.Margin = New-Object System.Windows.Forms.Padding(8, 8, 0, 0)
    $selectAllVisible.Font = New-Font 8.0 ([System.Drawing.FontStyle]::Bold)
    $toolbar.Controls.Add((New-FieldGroup "Search" $search), 0, 0)
    $toolbar.Controls.Add((New-FieldGroup "Category" $category), 1, 0)
    $toolbar.Controls.Add((New-FieldGroup "Risk" $risk), 2, 0)
    $toolbar.Controls.Add((New-FieldGroup "Sort" $sort), 3, 0)
    $toolbar.Controls.Add($selectAllVisible, 4, 0)
    $libraryTop.Controls.Add($toolbar, 0, 3)
    $libraryGrid.Controls.Add($libraryTop, 0, 0)

    $script:CardsFlow = New-StackPanel ([System.Windows.Forms.FlowDirection]::LeftToRight) $true $script:Colors.Card
    $script:CardsFlow.Padding = New-Object System.Windows.Forms.Padding(0, 12, 0, 20)
    $script:LastCardsFlowWidth = 0
    $script:CardsFlow.Add_SizeChanged({ if ($null -ne $script:CardsFlow -and -not $script:CardsFlow.IsDisposed) { $width = [int]$script:CardsFlow.ClientSize.Width; if ($width -gt 0) { $script:LastCardsFlowWidth = $width } } })
    $libraryGrid.Controls.Add((New-ClippedScrollHost $script:CardsFlow $script:Colors.Card), 0, 1)
    $library.Controls.Add($libraryGrid)
    $main.Controls.Add($library, 0, 0)

    $script:QueuePanel = New-GradientCard 16 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Green $false
    $script:QueuePanel.Margin = New-Object System.Windows.Forms.Padding(0)
    $script:QueuePanel.CornerRadius = 18
    $script:QueuePanel.BorderColor = $script:Colors.Line
    $main.Controls.Add($script:QueuePanel, 1, 0)

    $search.Add_TextChanged({ param($sender, $eventArgs) if ($null -eq $sender -or $sender.IsDisposed) { return }; $script:State["Search"] = ([string]$sender.Text).Trim(); $script:TweakPage = 1; Render-TweakCards })
    $category.Add_SelectedIndexChanged({ param($sender, $eventArgs) if ($null -eq $sender -or $sender.IsDisposed -or $null -eq $sender.SelectedItem) { return }; $script:State["CategoryFilter"] = [string]$sender.SelectedItem; $script:TweakPage = 1; Render-TweakCards })
    $risk.Add_SelectedIndexChanged({ param($sender, $eventArgs) if ($null -eq $sender -or $sender.IsDisposed -or $null -eq $sender.SelectedItem) { return }; $script:State["RiskFilter"] = [string]$sender.SelectedItem; $script:TweakPage = 1; Render-TweakCards })
    $sort.Add_SelectedIndexChanged({ param($sender, $eventArgs) if ($null -eq $sender -or $sender.IsDisposed -or $null -eq $sender.SelectedItem) { return }; $script:State["Sort"] = [string]$sender.SelectedItem; $script:TweakPage = 1; Render-TweakCards })
    $selectAllVisible.Add_Click({
        $visible = @(Get-VisibleTweaks | Where-Object { -not (Is-Locked $_) })
        if ($visible.Count -eq 0) { Show-Toast "No unlocked visible tweaks to select." "ApexTune"; return }
        $warning = "Select all visible unlocked tweaks in this tab/filter?`n`nApexTune recommends small reversible batches. Restore points, registry backups, and strict safety checks stay enabled when configured."
        $result = [System.Windows.Forms.MessageBox]::Show($script:Form, $warning, "Select visible tweaks", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($result -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        foreach ($tweak in $visible) { $script:State.Selected[$tweak.Id] = $true }
        Render-TweakCards; Render-Queue; Show-Toast ("Selected " + $visible.Count + " visible unlocked tweaks.") "ApexTune"
    })

    Render-TweakCards
    Render-Queue
    Update-LiveDashboardMetrics
    Start-LiveStatsTimer
}


function Show-TweakInfo($Tweak) {
    if ($null -eq $Tweak) { return }
    $tags = $(if ($Tweak.Tags) { ($Tweak.Tags -join ", ") } else { "None" })
    $cmdCount = @($Tweak.Commands).Count
    $rollbackCount = @($Tweak.Rollback).Count
    $backupText = $(if ($Tweak.BackupKeys -and @($Tweak.BackupKeys).Count -gt 0) { ($Tweak.BackupKeys -join [Environment]::NewLine) } else { "No registry backup keys needed for this card." })
    $restartText = $(if ($Tweak.Restart) { "Yes - restart after applying." } else { "No restart usually required." })
    $lockText = $(if (Is-Locked $Tweak) { "Locked on this account until Pro/Owner." } else { "Available on this account." })
    $message = @(
        "$($Tweak.Title)",
        "",
        "Category: $($Tweak.Category)",
        "Tier: $($Tweak.Tier) / Status: $lockText",
        "Risk: $($Tweak.Risk)",
        "FPS focus: +$($Tweak.Fps)",
        "Ping focus: +$($Tweak.Ping)",
        "Restart: $restartText",
        "Tags: $tags",
        "",
        "What it does:",
        "$($Tweak.Summary)",
        "",
        "Before applying:",
        "- ApexTune saves a readable plan.",
        "- Restore point and registry backup options should stay ON.",
        "- Apply small batches and benchmark one game before stacking more.",
        "",
        "Automation:",
        "$cmdCount apply command(s), $rollbackCount rollback note/command(s).",
        "",
        "Backup targets:",
        $backupText
    ) -join [Environment]::NewLine
    [System.Windows.Forms.MessageBox]::Show($script:Form, $message, "Tweak info", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}

function New-TweakCard($Tweak) {
    $selected = $script:State.Selected.ContainsKey($Tweak.Id)
    $locked = Is-Locked $Tweak
    $isLightTheme = ((Get-AppTheme) -eq "light")
    $selectedBack = $(if ($isLightTheme) { ColorFromHex "#EEF2FF" } else { ColorFromHex "#111A2D" })
    $lockedBack = $(if ($isLightTheme) { ColorFromHex "#FFF7ED" } else { ColorFromHex "#17131F" })
    $baseBack = $(if ($selected) { $selectedBack } elseif ($locked) { $lockedBack } else { $script:Colors.Card2 })
    $card = New-Card 12 $baseBack
    $card.Dock = [System.Windows.Forms.DockStyle]::None
    $card.Width = $(if ($script:TweakCardWidth -gt 0) { $script:TweakCardWidth } else { [int]$script:UiTokens.TweakCardMaxWidth })
    $card.Height = [int]$script:UiTokens.TweakCardHeight
    $card.MinimumSize = New-Object System.Drawing.Size([int]$script:UiTokens.TweakCardMinWidth, [int]$script:UiTokens.TweakCardHeight)
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 12, 12)
    $card.Padding = New-Object System.Windows.Forms.Padding(12, 10, 12, 10)
    $card.CornerRadius = 16
    $riskColor = $(if ($Tweak.Risk -eq "High") { $script:Colors.Red } elseif ($Tweak.Risk -eq "Medium") { $script:Colors.Amber } else { $script:Colors.Teal })
    $tierColor = $(if ($Tweak.Tier -eq "Pro") { $script:Colors.Amber } else { $script:Colors.Accent })
    $card.BorderColor = $(if ($selected) { $script:Colors.Accent } elseif ($locked) { $script:Colors.Amber } else { $script:Colors.Line })
    Enable-CardHover $card $(if ($selected) { $script:Colors.Accent } else { $riskColor }) $script:Colors.Hover

    $grid = New-Table 4 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 50
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 38
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $top = New-Table 1 3 $card.BackColor
    Add-Column $top ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $top ([System.Windows.Forms.SizeType]::Absolute) 74
    Add-Column $top ([System.Windows.Forms.SizeType]::Absolute) 74
    Add-Row $top ([System.Windows.Forms.SizeType]::Percent) 100
    $title = New-FillLabel $Tweak.Title 9.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $title.AutoEllipsis = $true
    Set-ApexToolTip $title ([string]$Tweak.Title)
    $top.Controls.Add($title, 0, 0)
    $top.Controls.Add((New-ApexChip $Tweak.Tier.ToUpperInvariant() $tierColor $card.BackColor 60 70), 1, 0)
    $top.Controls.Add((New-ApexChip $Tweak.Risk.ToUpperInvariant() $riskColor $card.BackColor 62 72), 2, 0)
    $grid.Controls.Add($top, 0, 0)

    $summary = New-WrapLabel $Tweak.Summary 8.1 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $summary.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $summary.AutoEllipsis = $true
    $summary.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    Set-ApexToolTip $summary ([string]$Tweak.Summary)
    $grid.Controls.Add($summary, 0, 1)

    $chips = New-StackPanel ([System.Windows.Forms.FlowDirection]::LeftToRight) $true $card.BackColor
    $chips.AutoScroll = $false
    $chips.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $chips.Padding = New-Object System.Windows.Forms.Padding(0)
    $categoryText = $(if ([string]::IsNullOrWhiteSpace([string]$Tweak.Category)) { "SYSTEM" } else { ([string]$Tweak.Category).ToUpperInvariant() })
    $areaText = $(if ($Tweak.Tags -and @($Tweak.Tags).Count -gt 0) { ([string]$Tweak.Tags[0]).ToUpperInvariant() } else { "SYSTEM" })
    [void]$chips.Controls.Add((New-ApexChip $categoryText $script:Colors.Blue $card.BackColor 58 76))
    [void]$chips.Controls.Add((New-ApexChip ("FPS +{0}" -f $Tweak.Fps) $script:Colors.Green $card.BackColor 60 78))
    [void]$chips.Controls.Add((New-ApexChip ("PING +{0}" -f $Tweak.Ping) $script:Colors.Teal $card.BackColor 66 86))
    [void]$chips.Controls.Add((New-ApexChip $(if ($Tweak.Restart) { "RESTART" } else { "NO RESTART" }) $(if ($Tweak.Restart) { $script:Colors.Amber } else { $script:Colors.Green }) $card.BackColor 66 86))
    [void]$chips.Controls.Add((New-ApexChip $areaText $script:Colors.Violet $card.BackColor 54 76))
    $grid.Controls.Add($chips, 0, 2)

    $bottom = New-Table 1 3 $card.BackColor
    Add-Column $bottom ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $bottom ([System.Windows.Forms.SizeType]::Absolute) 90
    Add-Column $bottom ([System.Windows.Forms.SizeType]::Absolute) 38
    Add-Row $bottom ([System.Windows.Forms.SizeType]::Percent) 100
    $trustText = $(if ($locked) { "Locked Pro card" } elseif ($selected) { "Selected - queued safely" } else { "Safety checked before apply" })
    $trust = New-FillLabel $trustText 7.8 ([System.Drawing.FontStyle]::Bold) $(if ($selected) { $script:Colors.Green } elseif ($locked) { $script:Colors.Amber } else { $script:Colors.Muted })
    $trust.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $trust.AutoEllipsis = $true
    Set-ApexToolTip $trust "Restore point and registry backup checks run before eligible tweaks apply."
    $bottom.Controls.Add($trust, 0, 0)

    if ($locked) {
        $unlock = New-Button "Unlock" 0 0 0 0 "secondary"
        $unlock.Dock = [System.Windows.Forms.DockStyle]::Fill
        $unlock.Margin = New-Object System.Windows.Forms.Padding(6, 3, 6, 3)
        $unlock.Padding = New-Object System.Windows.Forms.Padding(0)
        $unlock.Font = New-Font 7.4 ([System.Drawing.FontStyle]::Bold)
        $unlock.Tag = "__noTreeClick"
        $unlock.AccessibleName = "Unlock $($Tweak.Title)"
        $unlock.Add_Click({ Show-PayDialog })
        $bottom.Controls.Add($unlock, 1, 0)
    } else {
        $check = New-ApexUiControl "ApexPlanSwitch"
        $check.Tag = $Tweak.Id
        $check.Checked = $selected
        $check.Width = [int]$script:UiTokens.ToggleWidth
        $check.Height = [int]$script:UiTokens.ToggleHeight
        $check.Font = New-Font 7.0 ([System.Drawing.FontStyle]::Bold)
        $check.OnColor = $script:Colors.Green
        $check.OffColor = (ColorFromHex "#252B3E")
        $check.BorderColor = $(if ($selected) { $script:Colors.Green } else { $script:Colors.Line })
        $check.KnobColor = $(if ((Get-AppTheme) -eq "light") { [System.Drawing.Color]::White } else { ColorFromHex "#F8FAFC" })
        $check.TextColor = [System.Drawing.Color]::White
        $check.OnLabel = "ON"
        $check.OffLabel = "OFF"
        $check.Anchor = [System.Windows.Forms.AnchorStyles]::None
        $check.Margin = New-Object System.Windows.Forms.Padding(0)
        $check.AccessibleName = "Toggle $($Tweak.Title)"
        Set-ApexToolTip $check "Add or remove this tweak from the optimization queue."
        $check.Add_CheckedChanged({
            param($sender, $eventArgs)
            if ($null -eq $sender -or [string]::IsNullOrWhiteSpace([string]$sender.Tag)) { return }
            $tweakId = [string]$sender.Tag
            if ($sender.Checked) { $script:State.Selected[$tweakId] = $true } else { $script:State.Selected.Remove($tweakId) }
            Render-Queue
            $sender.Invalidate()
        })
        $switchSlot = New-Object System.Windows.Forms.Panel
        $switchSlot.Dock = [System.Windows.Forms.DockStyle]::Fill
        $switchSlot.Margin = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
        $switchSlot.BackColor = $card.BackColor
        $switchSlot.Tag = "__noTreeClick"
        $switchSlot.Controls.Add($check)
        $switchSlot.Add_SizeChanged({
            param($sender, $eventArgs)
            if ($null -ne $sender -and $sender.Controls.Count -gt 0) {
                $toggle = $sender.Controls[0]
                $toggle.Left = [Math]::Max(0, [int](($sender.ClientSize.Width - $toggle.Width) / 2))
                $toggle.Top = [Math]::Max(0, [int](($sender.ClientSize.Height - $toggle.Height) / 2))
            }
        })
        $bottom.Controls.Add($switchSlot, 1, 0)
    }

    $infoButton = New-ApexUiControl "ApexInfoCircle"
    $infoButton.Dock = [System.Windows.Forms.DockStyle]::None
    $infoButton.Width = 30
    $infoButton.Height = 30
    $infoButton.Margin = New-Object System.Windows.Forms.Padding(0)
    $infoButton.BackColor = $card.BackColor
    $infoButton.FillColor = $script:Colors.Panel2
    $infoButton.BorderColor = $script:Colors.Accent
    $infoButton.IconColor = $script:Colors.Text
    $infoButton.Filled = $false
    $infoButton.Tag = "__noTreeClick"
    $infoButton.AccessibleName = "Show details for $($Tweak.Title)"
    Set-ApexToolTip $infoButton "View what this tweak changes, risk, backup keys, and rollback notes."
    $tweakForInfo = $Tweak
    $infoButton.Add_Click({ Show-TweakInfo $tweakForInfo }.GetNewClosure())
    $infoSlot = New-Object System.Windows.Forms.Panel
    $infoSlot.Dock = [System.Windows.Forms.DockStyle]::Fill
    $infoSlot.Margin = New-Object System.Windows.Forms.Padding(0)
    $infoSlot.BackColor = $card.BackColor
    $infoSlot.Tag = "__noTreeClick"
    $infoSlot.Controls.Add($infoButton)
    $infoSlot.Add_SizeChanged({
        param($sender, $eventArgs)
        if ($null -ne $sender -and $sender.Controls.Count -gt 0) {
            $b = $sender.Controls[0]
            $b.Left = [Math]::Max(0, [int](($sender.ClientSize.Width - $b.Width) / 2))
            $b.Top = [Math]::Max(0, [int](($sender.ClientSize.Height - $b.Height) / 2))
        }
    })
    $bottom.Controls.Add($infoSlot, 2, 0)
    $grid.Controls.Add($bottom, 0, 3)
    $card.Controls.Add($grid)
    $tweakForCard = $Tweak
    Add-ClickHandlerToTree $card ({ Show-TweakInfo $tweakForCard }.GetNewClosure())
    return $card
}


function New-EmptyTweakResultCard {
    $card = New-Card 18 $script:Colors.Card2
    $card.Dock = [System.Windows.Forms.DockStyle]::None
    $card.Width = $(if ($script:TweakCardWidth -gt 0) { $script:TweakCardWidth } else { 430 })
    $card.Height = 138
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 16, 16)
    $card.BorderColor = $script:Colors.Line

    $grid = New-Table 3 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $grid ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $title = New-AutoLabel "No tweaks found" 13 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    $body = New-AutoLabel "Try another search term or switch the filter to All." 9.2 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted 520
    $body.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
    $grid.Controls.Add($title, 0, 0)
    $grid.Controls.Add($body, 0, 1)
    $card.Controls.Add($grid)
    return $card
}

function Get-ResponsiveTweakCardWidth {
    $available = 900
    if ($null -ne $script:CardsFlow -and -not $script:CardsFlow.IsDisposed -and $script:CardsFlow.ClientSize.Width -gt 0) {
        $available = [Math]::Max(340, $script:CardsFlow.ClientSize.Width - 24)
    }
    $columns = 1
    if ($available -ge 1320) { $columns = 3 }
    elseif ($available -ge 760) { $columns = 2 }
    else { $columns = 1 }
    $gap = 12 * ($columns - 1)
    $raw = [int][Math]::Floor(($available - $gap) / $columns)
    $min = [int]$script:UiTokens.TweakCardMinWidth
    $max = [int]$script:UiTokens.TweakCardMaxWidth
    if ($columns -eq 1) { return [Math]::Max($min, [Math]::Min($max + 90, $raw)) }
    return [Math]::Max($min, [Math]::Min($max, $raw))
}


function New-LoadMoreTweaksCard($Shown, $Total) {
    $card = New-Card 16 $script:Colors.Panel2
    $card.Dock = [System.Windows.Forms.DockStyle]::None
    $card.Width = $(if ($script:TweakCardWidth -gt 0) { $script:TweakCardWidth } else { 430 })
     $card.Height = 96
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 14, 14)
    $card.BorderColor = $script:Colors.Accent

    $grid = New-Table 3 1 $card.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 30
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 36
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $title = New-FillLabel ("Showing {0} of {1}" -f [int]$Shown, [int]$Total) 11.5 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $body = New-WrapLabel "More cards are available. Search/filter to jump directly, or load the next page." 8 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $button = New-Button "Load more tweaks" 0 0 0 0 "secondary"
    $button.Dock = [System.Windows.Forms.DockStyle]::Left
    $button.Width = 148
    $button.Height = 28
    $button.Add_Click({
        $script:TweakPage = [Math]::Max(1, [int]$script:TweakPage + 1)
        Render-TweakCards
    })

    $grid.Controls.Add($title, 0, 0)
    $grid.Controls.Add($body, 0, 1)
    $grid.Controls.Add($button, 0, 2)
    $card.Controls.Add($grid)
    return $card
}

function Render-TweakCards {
    if ($null -eq $script:CardsFlow) { return }
    if ($script:IsRenderingCards) { return }
    $script:IsRenderingCards = $true
    try {
        $script:CardsFlow.SuspendLayout()
        $script:CardsFlow.Controls.Clear()
        if ($script:CardsFlow.ClientSize.Width -gt 0) { $script:LastCardsFlowWidth = [int]$script:CardsFlow.ClientSize.Width }
        $script:TweakCardWidth = Get-ResponsiveTweakCardWidth
        $items = @(Get-VisibleTweaks)
        $searchText = ([string]$script:State.Search).Trim()
        if ($items.Count -eq 0 -and $searchText.Length -eq 0) { $items = @(Get-FallbackTweaksForSection "recommended" $false) }
        if ($items.Count -eq 0 -and $searchText.Length -eq 0) { $items = @(Get-FallbackTweaksForSection "all" $false) }
        if ($items.Count -eq 0 -and $searchText.Length -eq 0) { $items = @(Get-TweaksByIds @("game-mode-hags", "dns-network-refresh", "nvidia-low-latency") $false) }

        if ($items.Count -eq 0) {
            $script:CardsFlow.Controls.Add((New-EmptyTweakResultCard))
        } else {
            $page = [Math]::Max(1, [int]$script:TweakPage)
            $pageSize = [Math]::Max(12, [int]$script:TweakPageSize)
            $limit = [Math]::Min($items.Count, $page * $pageSize)
            $displayItems = @($items | Select-Object -First $limit)
            foreach ($tweak in $displayItems) {
                $script:CardsFlow.Controls.Add((New-TweakCard $tweak))
            }
            if ($limit -lt $items.Count) {
                $script:CardsFlow.Controls.Add((New-LoadMoreTweaksCard $limit $items.Count))
            }
        }
        # v14: skip deep normalization on every card; explicit colors are already set.
    } finally {
        try { $script:CardsFlow.ResumeLayout($true) } catch { try { $script:CardsFlow.ResumeLayout() } catch {} }
        try { $script:CardsFlow.PerformLayout() } catch {}
        try {
            if ($null -ne $script:CardsFlow.Tag -and $script:CardsFlow.Tag -is [hashtable] -and $script:CardsFlow.Tag.ContainsKey("Update")) { & $script:CardsFlow.Tag.Update }
        } catch {}
        $script:IsRenderingCards = $false
    }
}

function Render-Queue {
    if ($null -eq $script:QueuePanel) { return }
    $script:QueuePanel.Controls.Clear()
    $selected = @(Get-SelectedTweaks)
    $fps = ($selected | Measure-Object -Property Fps -Sum).Sum
    if ($null -eq $fps) { $fps = 0 }
    $ping = ($selected | Measure-Object -Property Ping -Sum).Sum
    if ($null -eq $ping) { $ping = 0 }
    $risk = "Low"
    if ($selected | Where-Object { $_.Risk -eq "High" }) { $risk = "High" }
    elseif ($selected | Where-Object { $_.Risk -eq "Medium" }) { $risk = "Medium" }
    $needsRestart = [bool]($selected | Where-Object { $_.Restart } | Select-Object -First 1)
    $riskColor = $(if ($risk -eq "High") { $script:Colors.Red } elseif ($risk -eq "Medium") { $script:Colors.Amber } else { $script:Colors.Green })

    $grid = New-Table 6 1 $script:Colors.Card
    $grid.Padding = New-Object System.Windows.Forms.Padding(0)
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 56
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 82
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 54
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 100
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 62
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $queueHeader = New-Table 2 2 $script:Colors.Card
    Add-Row $queueHeader ([System.Windows.Forms.SizeType]::Absolute) 26
    Add-Row $queueHeader ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $queueHeader ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $queueHeader ([System.Windows.Forms.SizeType]::Absolute) 78
    $queueEyebrow = New-FillLabel "OPTIMIZATION QUEUE" 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Teal
    $queueEyebrow.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $queueTitle = New-FillLabel ("{0} selected" -f $selected.Count) 12.8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $queueTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $readyBadge = New-Badge $(if ($selected.Count -gt 0) { "READY" } else { "IDLE" }) $(if ($selected.Count -gt 0) { $script:Colors.Green } else { $script:Colors.Muted }) $script:Colors.Card 72
    $queueHeader.Controls.Add($queueEyebrow, 0, 0)
    $queueHeader.Controls.Add($readyBadge, 1, 0)
    $queueHeader.Controls.Add($queueTitle, 0, 1)
    $grid.Controls.Add($queueHeader, 0, 0)

    $metrics = New-Table 2 2 $script:Colors.Card
    foreach ($i in 1..2) { Add-Column $metrics ([System.Windows.Forms.SizeType]::Percent) 50 }
    foreach ($i in 1..2) { Add-Row $metrics ([System.Windows.Forms.SizeType]::Percent) 50 }
    $metrics.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    $metrics.Controls.Add((New-QueueMetric "FPS" ("+{0}" -f $fps) $script:Colors.Green), 0, 0)
    $metrics.Controls.Add((New-QueueMetric "PING" ("+{0}" -f $ping) $script:Colors.Teal), 1, 0)
    $metrics.Controls.Add((New-QueueMetric "RISK" $risk $riskColor), 0, 1)
    $metrics.Controls.Add((New-QueueMetric "RESTART" $(if ($needsRestart) { "Needed" } else { "No" }) $(if ($needsRestart) { $script:Colors.Amber } else { $script:Colors.Green })), 1, 1)
    $grid.Controls.Add($metrics, 0, 1)

    $selectedCard = New-Card 12 $script:Colors.Field
    $selectedCard.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 8)
    $selectedCard.Padding = New-Object System.Windows.Forms.Padding(12)
    $selectedCard.BorderColor = $script:Colors.Line
    if ($selected.Count -eq 0) {
        $empty = New-Table 4 1 $selectedCard.BackColor
        Add-Row $empty ([System.Windows.Forms.SizeType]::Absolute) 38
        Add-Row $empty ([System.Windows.Forms.SizeType]::Absolute) 34
        Add-Row $empty ([System.Windows.Forms.SizeType]::Absolute) 48
        Add-Row $empty ([System.Windows.Forms.SizeType]::Percent) 100
        Add-Column $empty ([System.Windows.Forms.SizeType]::Percent) 100
        $emptyTitle = New-FillLabel "Build a safe plan" 12.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
        $emptyTitle.TextAlign = [System.Drawing.ContentAlignment]::BottomCenter
        $emptyBody = New-WrapLabel "Pick Recommended or toggle cards. ApexTune writes a plan, restore point, registry backup, and rollback notes before applying." 8.4 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
        $emptyBody.TextAlign = [System.Drawing.ContentAlignment]::TopCenter
        $emptyBadgeRow = New-Table 1 3 $selectedCard.BackColor
        foreach ($i in 1..3) { Add-Column $emptyBadgeRow ([System.Windows.Forms.SizeType]::Percent) 33.333 }
        Add-Row $emptyBadgeRow ([System.Windows.Forms.SizeType]::Percent) 100
        $emptyBadgeRow.Controls.Add((New-Badge "RESTORE" $script:Colors.Green $selectedCard.BackColor 80), 0, 0)
        $emptyBadgeRow.Controls.Add((New-Badge "BACKUP" $script:Colors.Teal $selectedCard.BackColor 80), 1, 0)
        $emptyBadgeRow.Controls.Add((New-Badge "STRICT" $script:Colors.Accent $selectedCard.BackColor 80), 2, 0)
        $empty.Controls.Add($emptyTitle, 0, 0)
        $empty.Controls.Add($emptyBody, 0, 1)
        $empty.Controls.Add($emptyBadgeRow, 0, 2)
        $selectedCard.Controls.Add($empty)
    } else {
        $selectedGrid = New-Table 2 1 $selectedCard.BackColor
        Add-Row $selectedGrid ([System.Windows.Forms.SizeType]::Absolute) 28
        Add-Row $selectedGrid ([System.Windows.Forms.SizeType]::Percent) 100
        Add-Column $selectedGrid ([System.Windows.Forms.SizeType]::Percent) 100
        $selectedGrid.Controls.Add((New-FillLabel "Selected tweak stack" 8.6 ([System.Drawing.FontStyle]::Bold) $script:Colors.Teal), 0, 0)
        $listFlow = New-StackPanel ([System.Windows.Forms.FlowDirection]::TopDown) $false $selectedCard.BackColor
        $listFlow.Padding = New-Object System.Windows.Forms.Padding(0, 2, 4, 8)
        foreach ($tweak in $selected | Select-Object -First 12) {
            $itemRow = New-Table 1 2 $selectedCard.BackColor
            $itemRow.Height = 34
            $itemRow.Width = 250
            $itemRow.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
            Add-Column $itemRow ([System.Windows.Forms.SizeType]::Percent) 100
            Add-Column $itemRow ([System.Windows.Forms.SizeType]::Absolute) 34
            Add-Row $itemRow ([System.Windows.Forms.SizeType]::Percent) 100
            $item = New-FillLabel $tweak.Title 8.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
            $item.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
            $item.AutoEllipsis = $true
            $remove = New-Button "X" 0 0 0 0 "ghost"
            $remove.Dock = [System.Windows.Forms.DockStyle]::Fill
            $remove.Margin = New-Object System.Windows.Forms.Padding(6, 1, 0, 1)
            $remove.Padding = New-Object System.Windows.Forms.Padding(0)
            $remove.MinimumSize = New-Object System.Drawing.Size(0, 30)
            $remove.Font = New-Font 8.5 ([System.Drawing.FontStyle]::Bold)
            $remove.Tag = $tweak.Id
            $remove.AccessibleName = "Remove $($tweak.Title)"
            $remove.Add_Click({ param($sender, $eventArgs) if ($sender.Tag) { $script:State.Selected.Remove([string]$sender.Tag); Render-TweakCards; Render-Queue } })
            $itemRow.Controls.Add($item, 0, 0)
            $itemRow.Controls.Add($remove, 1, 0)
            [void]$listFlow.Controls.Add($itemRow)
        }
        if ($selected.Count -gt 12) {
            [void]$listFlow.Controls.Add((New-AutoLabel ("+ {0} more selected" -f ($selected.Count - 12)) 8.2 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted 240))
        }
        $selectedGrid.Controls.Add((New-ClippedScrollHost $listFlow $selectedCard.BackColor), 0, 1)
        $selectedCard.Controls.Add($selectedGrid)
    }
    $grid.Controls.Add($selectedCard, 0, 2)

    $safety = New-Card 8 $script:Colors.Panel2
    $safety.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    $safety.Padding = New-Object System.Windows.Forms.Padding(10, 8, 10, 8)
    $safety.BorderColor = $(if ($risk -eq "High") { $script:Colors.Red } elseif ($risk -eq "Medium") { $script:Colors.Amber } else { $script:Colors.Green })
    $safetyFlow = New-StackPanel ([System.Windows.Forms.FlowDirection]::LeftToRight) $true $safety.BackColor
    $safetyFlow.Padding = New-Object System.Windows.Forms.Padding(0)
    [void]$safetyFlow.Controls.Add((New-ApexChip $(if ($script:State.Settings.RestorePoint) { "RESTORE ON" } else { "RESTORE OFF" }) $(if ($script:State.Settings.RestorePoint) { $script:Colors.Green } else { $script:Colors.Amber }) $safety.BackColor 88 112))
    [void]$safetyFlow.Controls.Add((New-ApexChip $(if ($script:State.Settings.RegistryBackup) { "BACKUP ON" } else { "BACKUP OFF" }) $(if ($script:State.Settings.RegistryBackup) { $script:Colors.Teal } else { $script:Colors.Amber }) $safety.BackColor 88 112))
    [void]$safetyFlow.Controls.Add((New-ApexChip $(if ($script:State.Settings.StrictSafety) { "STRICT ON" } else { "STRICT OFF" }) $(if ($script:State.Settings.StrictSafety) { $script:Colors.Accent } else { $script:Colors.Amber }) $safety.BackColor 82 108))
    $safety.Controls.Add($safetyFlow)
    $grid.Controls.Add($safety, 0, 3)

    $actionGrid = New-Table 2 1 $script:Colors.Card
    Add-Row $actionGrid ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $actionGrid ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Column $actionGrid ([System.Windows.Forms.SizeType]::Percent) 100
    $select = New-Button "Select recommended" 0 0 0 0 "secondary"
    $select.Dock = [System.Windows.Forms.DockStyle]::Fill
    $select.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    $actionGrid.Controls.Add($select, 0, 0)
    $actions = New-Table 1 3 $script:Colors.Card
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 30
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 30
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 40
    Add-Row $actions ([System.Windows.Forms.SizeType]::Percent) 100
    $clear = New-Button "Clear" 0 0 0 0 "ghost"
    $export = New-Button "Save" 0 0 0 0 "secondary"
    $apply = New-Button "Apply" 0 0 0 0 "primary"
    foreach ($button in @($clear, $export, $apply)) {
        $button.Dock = [System.Windows.Forms.DockStyle]::Fill
        $button.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
        $button.MinimumSize = New-Object System.Drawing.Size(0, 44)
    }
    $apply.Margin = New-Object System.Windows.Forms.Padding(0)
    if ($selected.Count -eq 0) {
        $apply.Enabled = $false
        $apply.BackColor = $script:Colors.Panel2
        $apply.ForeColor = $script:Colors.Muted
        try { $apply.BorderColor = $script:Colors.Line; $apply.HoverBackColor = $script:Colors.Panel2; $apply.DownBackColor = $script:Colors.Panel2 } catch {}
    }
    $actions.Controls.Add($clear, 0, 0)
    $actions.Controls.Add($export, 1, 0)
    $actions.Controls.Add($apply, 2, 0)
    $actionGrid.Controls.Add($actions, 0, 1)
    $grid.Controls.Add($actionGrid, 0, 4)

    $script:LogBox = New-Object System.Windows.Forms.TextBox
    $script:LogBox.Dock = [System.Windows.Forms.DockStyle]::Fill
    $script:LogBox.Multiline = $true
    $script:LogBox.ScrollBars = [System.Windows.Forms.ScrollBars]::None
    $script:LogBox.ReadOnly = $true
    $script:LogBox.BackColor = $script:Colors.Field
    $script:LogBox.ForeColor = $script:Colors.Muted
    $script:LogBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $script:LogBox.Font = New-Font 8.4
    $script:LogBox.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
    $script:LogBox.Text = $(if ($selected.Count -eq 0) { "Queue idle. Select tweaks to preview apply logs here." } else { "Ready to apply $($selected.Count) tweak(s). Medium/high risk plans require confirmation." })
    $grid.Controls.Add($script:LogBox, 0, 5)

    $script:QueuePanel.Controls.Add($grid)
    Normalize-LabelBackColors $script:QueuePanel
    $liveFps = Get-LiveFpsEstimate
    Set-LiveMetric "fps" $liveFps.Title $liveFps.Body

    $select.Add_Click({
        foreach ($tweak in Get-RecommendedTweaksForSelection) {
            if (-not (Is-Locked $tweak)) { $script:State.Selected[$tweak.Id] = $true }
        }
        Render-TweakCards
        Render-Queue
        Show-Toast "Recommended safe tweaks were added to your queue." "ApexTune"
    })
    $clear.Add_Click({
        $script:State["Selected"] = @{}
        Render-TweakCards
        Render-Queue
        Show-Toast "Optimization queue cleared." "ApexTune"
    })
    $export.Add_Click({ Export-SelectedPlan })
    $apply.Add_Click({ if ($selected.Count -gt 0) { Apply-SelectedTweaks } })
}


function New-QueueMetric($Label, $Value, $Accent) {
    $card = New-Card 6 $script:Colors.Field
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 8)
    $card.Padding = New-Object System.Windows.Forms.Padding(10, 6, 10, 6)
    $card.BorderColor = $script:Colors.Line
    $table = New-Table 2 1 $card.BackColor
    Add-Row $table ([System.Windows.Forms.SizeType]::Absolute) 18
    Add-Row $table ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $table ([System.Windows.Forms.SizeType]::Percent) 100
    $labelControl = New-FillLabel $Label 7.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $labelControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $valueControl = New-FillLabel ([string]$Value) 10.6 ([System.Drawing.FontStyle]::Bold) $Accent
    $valueControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $table.Controls.Add($labelControl, 0, 0)
    $table.Controls.Add($valueControl, 0, 1)
    $card.Controls.Add($table)
    return $card
}


function New-HardwareChip($Label, $Value, $Accent = $null) {
    $chip = New-Card 10 $script:Colors.Field
    $chip.Dock = [System.Windows.Forms.DockStyle]::Fill
    $chip.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $chip.BorderColor = $(if ($Accent) { $Accent } else { $script:Colors.Line })
    $grid = New-Table 2 1 $chip.BackColor
    Add-Row $grid ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $grid.Controls.Add((New-AutoLabel $Label.ToUpperInvariant() 7.5 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted), 0, 0)
    $valueLabel = New-FillLabel $Value 8.8 ([System.Drawing.FontStyle]::Bold) $(if ($Accent) { $Accent } else { $script:Colors.Text })
    $valueLabel.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 0)
    $grid.Controls.Add($valueLabel, 0, 1)
    $chip.Controls.Add($grid)
    return $chip
}


function Get-ApexOptimizationScore($Hardware) {
    $score = 72
    try {
        if ($script:State -and $script:State.Settings) {
            if ([bool]$script:State.Settings.RestorePoint) { $score += 5 } else { $score -= 8 }
            if ([bool]$script:State.Settings.RegistryBackup) { $score += 5 } else { $score -= 8 }
            if ([bool]$script:State.Settings.StrictSafety) { $score += 4 } else { $score -= 4 }
            if ([bool]$script:State.Settings.ShowRisky) { $score -= 5 }
            if ([bool]$script:State.Settings.Experimental) { $score -= 5 }
        }
        $selected = @(Get-SelectedTweaks)
        $score += [Math]::Min(8, $selected.Count)
        if ($selected | Where-Object { $_.Risk -eq "High" }) { $score -= 10 }
        if ($Hardware -and $Hardware.GpuVendor -in @('nvidia','amd','intel')) { $score += 4 }
        if ($Hardware -and $Hardware.Network -eq 'ethernet') { $score += 3 }
    } catch {}
    return [Math]::Max(0, [Math]::Min(100, [int]$score))
}

function Get-ApexScoreGrade([int]$Score) {
    if ($Score -ge 92) { return 'Elite' }
    if ($Score -ge 82) { return 'Ready' }
    if ($Score -ge 68) { return 'Good' }
    if ($Score -ge 52) { return 'Needs review' }
    return 'Risky'
}

function Export-ApexSystemSnapshot {
    Ensure-AppData
    $reports = Join-Path $script:AppDir "Reports"
    if (-not (Test-Path -LiteralPath $reports)) { New-Item -ItemType Directory -Path $reports -Force | Out-Null }
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $hardware = $script:State.Hardware
    $cpu = $null; $ram = $null; $ping = $null
    try { $cpu = Get-LiveCpuUsage } catch {}
    try { $ram = Get-LiveRamUsage } catch {}
    try { $ping = Get-LiveNetworkPing } catch {}
    $selected = @(Get-SelectedTweaks | Select-Object Id,Title,Tier,Category,Risk,Fps,Ping,Restart,Experimental)
    $snapshot = [pscustomobject]@{
        AppVersion = $script:AppVersion
        AppVersionNumber = $script:AppVersionNumber
        GeneratedAt = (Get-Date).ToString('o')
        User = $(if ($script:State.User) { $script:State.User.Username } else { 'not signed in' })
        Admin = (Test-Admin)
        ApexScore = (Get-ApexOptimizationScore $hardware)
        Grade = (Get-ApexScoreGrade (Get-ApexOptimizationScore $hardware))
        Hardware = $hardware
        Live = [pscustomobject]@{ Cpu = $cpu; Ram = $ram; Ping = $ping }
        Profile = $script:State.Profile
        Settings = $script:State.Settings
        SelectedTweaks = $selected
        Safety = (Get-TweakSafetySummary @(Get-SelectedTweaks))
    }
    $jsonPath = Join-Path $reports ("ApexTune-SystemSnapshot-{0}.json" -f $stamp)
    $txtPath = Join-Path $reports ("ApexTune-SystemSnapshot-{0}.txt" -f $stamp)
    $snapshot | ConvertTo-Json -Depth 12 | Set-Content -Path $jsonPath -Encoding UTF8
    $summary = @(
        "ApexTune System Snapshot",
        "Generated: " + (Get-Date).ToString('u'),
        "Version: $script:AppVersion / $script:AppVersionNumber",
        "Score: " + $snapshot.ApexScore + " (" + $snapshot.Grade + ")",
        "",
        (Get-HardwareDetailsText $hardware),
        "",
        "Selected tweaks: " + @($selected).Count,
        "Reports folder: " + $reports
    ) -join [Environment]::NewLine
    Set-Content -Path $txtPath -Value $summary -Encoding UTF8
    try { Start-Process explorer.exe ("/select,`"$txtPath`"") } catch {}
    Show-Toast ("Saved system snapshot:`n" + $txtPath) "ApexTune report"
}

function Invoke-ApexLatencyProbe {
    Ensure-AppData
    $reports = Join-Path $script:AppDir "Reports"
    if (-not (Test-Path -LiteralPath $reports)) { New-Item -ItemType Directory -Path $reports -Force | Out-Null }
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $path = Join-Path $reports ("ApexTune-LatencyProbe-{0}.txt" -f $stamp)
    $targets = @('1.1.1.1','8.8.8.8')
    $lines = @("ApexTune latency probe", "Generated: " + (Get-Date).ToString('u'), "")
    foreach ($target in $targets) {
        $lines += "Target: $target"
        try {
            $samples = @()
            for ($i = 0; $i -lt 8; $i++) {
                $p = New-Object System.Net.NetworkInformation.Ping
                try {
                    $r = $p.Send($target, 650)
                    if ($r -and $r.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) { $samples += [int64]$r.RoundtripTime }
                } finally { $p.Dispose() }
            }
            if ($samples.Count -gt 0) {
                $avg = [Math]::Round((($samples | Measure-Object -Average).Average), 1)
                $min = ($samples | Measure-Object -Minimum).Minimum
                $max = ($samples | Measure-Object -Maximum).Maximum
                $jitter = [Math]::Round(($max - $min), 1)
                $lines += "Average: $avg ms"
                $lines += "Min/Max: $min ms / $max ms"
                $lines += "Jitter range: $jitter ms"
            } else {
                $lines += "No successful samples. Firewall, DNS, or network may be blocking ICMP."
            }
        } catch { $lines += ("Probe failed: " + $_.Exception.Message) }
        $lines += ""
    }
    Set-Content -Path $path -Value ($lines -join [Environment]::NewLine) -Encoding UTF8
    try { Start-Process notepad.exe $path } catch {}
    Show-Toast ("Latency probe saved:`n" + $path) "Latency probe"
}

function Show-ApexCoachTips {
    $hardware = $script:State.Hardware
    $score = Get-ApexOptimizationScore $hardware
    $grade = Get-ApexScoreGrade $score
    $selected = @(Get-SelectedTweaks)
    $tips = New-Object 'System.Collections.Generic.List[string]'
    $tips.Add("Apex Score: $score / 100 ($grade)")
    $tips.Add("")
    if ($selected.Count -eq 0) { $tips.Add("Start with Select recommended, then remove anything you do not understand. Benchmark before and after.") }
    elseif ($selected.Count -gt $script:MaxStrictApplyCount) { $tips.Add("Your queue is large. Split it into smaller runs so you can isolate wins or regressions.") }
    else { $tips.Add("Your queue size is reasonable. Save the plan, apply, restart if prompted, then benchmark one game.") }
    if (-not [bool]$script:State.Settings.RestorePoint) { $tips.Add("Turn restore points back on before real apply runs.") }
    if (-not [bool]$script:State.Settings.RegistryBackup) { $tips.Add("Turn registry backups back on before registry tweaks.") }
    if ($hardware -and $hardware.Network -eq 'wifi') { $tips.Add("Wi-Fi detected: prefer Ethernet for competitive play, or use the Network tab for DNS/adapter checks.") }
    if ($hardware -and $hardware.GpuVendor -eq 'other') { $tips.Add("GPU vendor is unknown: use Rescan and the GPU tab before applying graphics-specific tweaks.") }
    $tips.Add("Use Snapshot before changes and Latency Probe after network changes so results are measurable.")
    [System.Windows.Forms.MessageBox]::Show($script:Form, ($tips -join [Environment]::NewLine), "Apex Coach", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
}

function New-ApexMiniButton($Text, [scriptblock]$Click, $Kind = "ghost") {
    $button = New-Button $Text 0 0 0 0 $Kind
    $button.Dock = [System.Windows.Forms.DockStyle]::Fill
    $button.Margin = New-Object System.Windows.Forms.Padding(0, 3, 8, 3)
    $button.MinimumSize = New-Object System.Drawing.Size(0, 36)
    $button.Font = New-Font 8.0 ([System.Drawing.FontStyle]::Bold)
    $button.Tag = "__noTreeClick"
    if ($null -ne $Click) { $button.Add_Click($Click) }
    return $button
}

function New-HardwareSummaryCard($Hardware) {
    $card = New-Card 12 $script:Colors.Field
    $card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
    $card.BorderColor = $script:Colors.Line
    Enable-CardHover $card $script:Colors.Accent $script:Colors.Hover

    $score = Get-ApexOptimizationScore $Hardware
    $grade = Get-ApexScoreGrade $score
    $scoreColor = $(if ($score -ge 82) { $script:Colors.Green } elseif ($score -ge 68) { $script:Colors.Amber } else { $script:Colors.Red })

    $grid = New-Table 6 2 $card.BackColor
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 118
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 44
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 38
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 36
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 36
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 36
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $titleRow = New-Table 1 5 $card.BackColor
    Add-Column $titleRow ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $titleRow ([System.Windows.Forms.SizeType]::Absolute) 98
    Add-Column $titleRow ([System.Windows.Forms.SizeType]::Absolute) 118
    Add-Column $titleRow ([System.Windows.Forms.SizeType]::Absolute) 132
    Add-Column $titleRow ([System.Windows.Forms.SizeType]::Absolute) 100
    Add-Row $titleRow ([System.Windows.Forms.SizeType]::Percent) 100
    $title = New-FillLabel "Eclipse safety profile" 9.0 ([System.Drawing.FontStyle]::Bold) $script:Colors.Teal
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $title.Margin = New-Object System.Windows.Forms.Padding(0)
    $scoreBadge = New-FillLabel ("Score " + $score) 8.2 ([System.Drawing.FontStyle]::Bold) $scoreColor
    $scoreBadge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $rescanButton = New-ApexMiniButton "Rescan" { Invoke-HardwareRescan } "ghost"
    $restoreButton = New-ApexMiniButton "Restore point" { Invoke-ManualRestorePoint } "secondary"
    $hint = New-FillLabel $grade 8.2 ([System.Drawing.FontStyle]::Bold) $scoreColor
    $hint.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
    $titleRow.Controls.Add($title, 0, 0)
    $titleRow.Controls.Add($scoreBadge, 1, 0)
    $titleRow.Controls.Add($rescanButton, 2, 0)
    $titleRow.Controls.Add($restoreButton, 3, 0)
    $titleRow.Controls.Add($hint, 4, 0)
    $grid.Controls.Add($titleRow, 0, 0)
    $grid.SetColumnSpan($titleRow, 2)

    Add-HardwareInfoRow $grid 1 "GPU" (($Hardware.GpuVendor.ToUpperInvariant()) + " - " + $Hardware.GpuName) $script:Colors.Green
    Add-HardwareInfoRow $grid 2 "Connection" (($Hardware.Network.ToUpperInvariant()) + " - " + $Hardware.NetworkName) $script:Colors.Teal
    Add-HardwareInfoRow $grid 3 "System" (($Hardware.System.ToUpperInvariant()) + " - " + $Hardware.Model) $script:Colors.Blue
    Add-HardwareInfoRow $grid 4 "Safety" ("Restore " + $(if ([bool]$script:State.Settings.RestorePoint) { "ON" } else { "OFF" }) + " / Registry backup " + $(if ([bool]$script:State.Settings.RegistryBackup) { "ON" } else { "OFF" }) + " / Strict " + $(if ([bool]$script:State.Settings.StrictSafety) { "ON" } else { "OFF" })) $script:Colors.Amber

    $actions = New-Table 1 4 $card.BackColor
    foreach ($i in 1..4) { Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 25 }
    Add-Row $actions ([System.Windows.Forms.SizeType]::Percent) 100
    $snapshot = New-ApexMiniButton "Snapshot" { Export-ApexSystemSnapshot } "primary"
    $latency = New-ApexMiniButton "Latency probe" { Invoke-ApexLatencyProbe } "secondary"
    $coach = New-ApexMiniButton "Coach" { Show-ApexCoachTips } "secondary"
    $details = New-ApexMiniButton "Details" { Show-HardwareDetails $script:State.Hardware } "ghost"
    $actions.Controls.Add($snapshot, 0, 0)
    $actions.Controls.Add($latency, 1, 0)
    $actions.Controls.Add($coach, 2, 0)
    $actions.Controls.Add($details, 3, 0)
    $grid.Controls.Add($actions, 0, 5)
    $grid.SetColumnSpan($actions, 2)

    $card.Controls.Add($grid)
    $openDetails = { Show-HardwareDetails $script:State.Hardware }
    Add-ClickHandlerToTree $card $openDetails
    return $card
}

function Add-HardwareInfoRow($Grid, $Row, $Label, $Value, $Accent) {
    $labelControl = New-FillLabel ($Label.ToUpperInvariant()) 7.7 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $labelControl.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $labelControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft

    $valueControl = New-FillLabel ([string]$Value) 7.8 ([System.Drawing.FontStyle]::Bold) $Accent
    $valueControl.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
    $valueControl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $valueControl.AutoEllipsis = $true
    $valueControl.UseCompatibleTextRendering = $false

    $Grid.Controls.Add($labelControl, 0, $Row)
    $Grid.Controls.Add($valueControl, 1, $Row)
}

function Get-HardwareDetailsText($Hardware) {
    if ($null -eq $Hardware) {
        return "No hardware information has been detected yet."
    }

    $lines = @(
        "GPU profile: " + $Hardware.GpuVendor.ToUpperInvariant()
        "GPU devices: " + $Hardware.GpuName
        ""
        "Connection profile: " + $Hardware.Network.ToUpperInvariant()
        "Active network adapters: " + $Hardware.NetworkName
        ""
        "System profile: " + $Hardware.System.ToUpperInvariant()
        "Computer model: " + $Hardware.Model
        ""
        "CPU: " + $Hardware.CpuName
        "Memory: " + $Hardware.Ram
        "Windows: " + $Hardware.Os
        ""
        "Detected at: " + $Hardware.DetectedAt
    )
    return ($lines -join [Environment]::NewLine)
}

function Show-HardwareDetails($Hardware) {
    if ($null -eq $Hardware) { $Hardware = $script:State.Hardware }

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "Detected hardware info"
    $dialog.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $dialog.Size = New-Object System.Drawing.Size(720, 520)
    $dialog.MinimumSize = New-Object System.Drawing.Size(560, 420)
    $dialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
    $dialog.BackColor = $script:Colors.Bg
    $dialog.ForeColor = $script:Colors.Text
    $dialog.Font = New-Font 9

    $root = New-Table 3 1 $script:Colors.Bg
    $root.Padding = New-Object System.Windows.Forms.Padding(22)
    Add-Column $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $root ([System.Windows.Forms.SizeType]::Absolute) 78
    Add-Row $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $root ([System.Windows.Forms.SizeType]::Absolute) 50
    $dialog.Controls.Add($root)

    $root.Controls.Add((New-HeaderBlock "FULL HARDWARE PROFILE" "Detected hardware info" "These are the complete values ApexTune used to choose the hardware-based filters."), 0, 0)

    $detailsBox = New-Object System.Windows.Forms.TextBox
    $detailsBox.Multiline = $true
    $detailsBox.ReadOnly = $true
    $detailsBox.WordWrap = $true
    $detailsBox.ScrollBars = [System.Windows.Forms.ScrollBars]::None
    $detailsBox.Dock = [System.Windows.Forms.DockStyle]::Fill
    $detailsBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $detailsBox.BackColor = $script:Colors.Field
    $detailsBox.ForeColor = $script:Colors.Text
    $detailsBox.Font = New-Font 10
    $detailsBox.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 14)
    $detailsBox.Text = Get-HardwareDetailsText $Hardware
    $root.Controls.Add($detailsBox, 0, 1)

    $actions = New-Table 1 2 $script:Colors.Bg
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $actions ([System.Windows.Forms.SizeType]::Absolute) 130
    Add-Row $actions ([System.Windows.Forms.SizeType]::Percent) 100
    $close = New-Button "Close" 0 0 0 0 "primary"
    $close.Dock = [System.Windows.Forms.DockStyle]::Fill
    $close.Margin = New-Object System.Windows.Forms.Padding(0)
    $close.Add_Click({ $dialog.Close() })
    $actions.Controls.Add($close, 1, 0)
    $root.Controls.Add($actions, 0, 2)

    [void]$dialog.ShowDialog($script:Form)
}

function Append-Log($Text) {
    if ($script:LogBox) {
        $script:LogBox.AppendText(("[" + (Get-Date -Format "HH:mm:ss") + "] " + $Text + [Environment]::NewLine))
    }
}

function Build-Account {
    $layout = New-Table 2 1 $script:Colors.Bg
    Add-Row $layout ([System.Windows.Forms.SizeType]::Absolute) 214
    Add-Row $layout ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $layout ([System.Windows.Forms.SizeType]::Percent) 100
    $script:Content.Controls.Add($layout)

    $cards = New-Table 1 3 $script:Colors.Bg
    foreach ($i in 1..3) { Add-Column $cards ([System.Windows.Forms.SizeType]::Percent) 33.333 }
    Add-Row $cards ([System.Windows.Forms.SizeType]::Percent) 100
    $card1 = New-InfoPanel 0 0 0 0 "Signed in as" $script:State.User.Username $(if (Has-Premium) { "All tweak packs are unlocked on this account." } else { "Free plan. Paid tweak cards are locked." })
    $card2 = New-InfoPanel 0 0 0 0 "Premium tweaks" $(if (Has-Premium) { "Unlocked" } else { "Locked" }) "Use checkout or the owner account to unlock paid tools."
    $card3 = New-InfoPanel 0 0 0 0 "Security" "Password hashes" "Local demo accounts are stored in AppData with SHA-256 password hashes."
    $cards.Controls.Add($card1, 0, 0)
    $cards.Controls.Add($card2, 1, 0)
    $cards.Controls.Add($card3, 2, 0)
    $layout.Controls.Add($cards, 0, 0)

    if (-not (Has-Premium)) {
        $upgrade = New-Button "View upgrade" 0 0 170 40 "primary"
        $upgrade.Dock = [System.Windows.Forms.DockStyle]::Left
        $upgrade.Width = 170
        $upgrade.Margin = New-Object System.Windows.Forms.Padding(0, 18, 0, 0)
        $upgrade.Add_Click({ Show-PayDialog })
        $actionRow = New-StackPanel ([System.Windows.Forms.FlowDirection]::LeftToRight) $false $script:Colors.Bg
        $actionRow.AutoScroll = $false
        $actionRow.Controls.Add($upgrade)
        $layout.Controls.Add($actionRow, 0, 1)
    } else {
        $premiumCard = New-InfoPanel 0 0 0 0 "Plan status" "Premium active" "All paid tweak cards are available on this account."
        $premiumCard.Margin = New-Object System.Windows.Forms.Padding(0)
        $layout.Controls.Add($premiumCard, 0, 1)
    }
}

function New-InfoPanel($X, $Y, $W, $H, $Label, $Title, $Body) {
    $panel = New-Card 18 $script:Colors.Card
    Enable-CardHover $panel $script:Colors.Accent $script:Colors.Hover
    $grid = New-Table 3 1 $script:Colors.Card
    Add-Row $grid ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $grid ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $grid.Controls.Add((New-AutoLabel $Label.ToUpperInvariant() 8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent), 0, 0)
    $titleLabel = New-AutoLabel $Title 15 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $titleLabel.Margin = New-Object System.Windows.Forms.Padding(0, 14, 0, 0)
    $grid.Controls.Add($titleLabel, 0, 1)
    $bodyLabel = New-AutoLabel $Body 9.2 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted 280
    $bodyLabel.Margin = New-Object System.Windows.Forms.Padding(0, 14, 0, 0)
    $grid.Controls.Add($bodyLabel, 0, 2)
    $panel.Controls.Add($grid)
    return $panel
}

function Build-Activity {
    $layout = New-Table 1 1 $script:Colors.Bg
    Add-Row $layout ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $layout ([System.Windows.Forms.SizeType]::Percent) 100
    $script:Content.Controls.Add($layout)

    $card = New-Card 18 $script:Colors.Card
    Enable-CardHover $card $script:Colors.Accent $script:Colors.Hover
    $grid = New-Table 2 1 $script:Colors.Card
    Add-Row $grid ([System.Windows.Forms.SizeType]::Absolute) 104
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $grid.Controls.Add((New-HeaderBlock "ACTIVITY" "Recent plans" "A readable history of applied or unlocked optimization actions." $script:Colors.Card), 0, 0)

    if (@($script:State.User.Activity).Count -eq 0) {
        $empty = New-Card 18 $script:Colors.Field
        $empty.Margin = New-Object System.Windows.Forms.Padding(0)
        $empty.BorderColor = $script:Colors.Line
        Enable-CardHover $empty $script:Colors.Accent $script:Colors.Hover
        $emptyGrid = New-Table 5 1 $empty.BackColor
        Add-Row $emptyGrid ([System.Windows.Forms.SizeType]::Percent) 42
        Add-Row $emptyGrid ([System.Windows.Forms.SizeType]::Absolute) 30
        Add-Row $emptyGrid ([System.Windows.Forms.SizeType]::Absolute) 26
        Add-Row $emptyGrid ([System.Windows.Forms.SizeType]::Absolute) 34
        Add-Row $emptyGrid ([System.Windows.Forms.SizeType]::Percent) 58
        Add-Column $emptyGrid ([System.Windows.Forms.SizeType]::Percent) 100
        $emptyTitle = New-FillLabel "No optimization plans yet" 14 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
        $emptyTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
        $emptyGrid.Controls.Add($emptyTitle, 0, 1)
        $emptyBody = New-FillLabel "Applied plans, restore point notes, and unlock history will appear here." 9.5 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
        $emptyBody.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
        $emptyGrid.Controls.Add($emptyBody, 0, 2)
        $emptyHint = New-FillLabel "Run a recommended plan to start building your history." 9 ([System.Drawing.FontStyle]::Bold) $script:Colors.Accent
        $emptyHint.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
        $emptyGrid.Controls.Add($emptyHint, 0, 3)
        $empty.Controls.Add($emptyGrid)
        $grid.Controls.Add($empty, 0, 1)
    } else {
        $activityFlow = New-StackPanel ([System.Windows.Forms.FlowDirection]::TopDown) $false $script:Colors.Field
        $activityFlow.Padding = New-Object System.Windows.Forms.Padding(0, 4, 0, 10)
        foreach ($item in @($script:State.User.Activity)) {
            $row = New-Card 12 $script:Colors.Card2
            $row.Dock = [System.Windows.Forms.DockStyle]::None
            $row.Width = 820
            $row.Height = 58
            $row.Margin = New-Object System.Windows.Forms.Padding(0, 0, 14, 10)
            $row.BorderColor = $script:Colors.Line
            $rowGrid = New-Table 1 2 $row.BackColor
            Add-Column $rowGrid ([System.Windows.Forms.SizeType]::Percent) 100
            Add-Column $rowGrid ([System.Windows.Forms.SizeType]::Absolute) 170
            Add-Row $rowGrid ([System.Windows.Forms.SizeType]::Percent) 100
            $label = New-FillLabel ("{0} - {1} tweaks" -f $item.Label, $item.Count) 9.8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
            $label.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
            $time = New-FillLabel ([datetime]$item.At).ToString("g") 8.8 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
            $time.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
            $rowGrid.Controls.Add($label, 0, 0)
            $rowGrid.Controls.Add($time, 1, 0)
            $row.Controls.Add($rowGrid)
            [void]$activityFlow.Controls.Add($row)
        }
        $grid.Controls.Add((New-ClippedScrollHost $activityFlow $script:Colors.Field), 0, 1)
    }
    $card.Controls.Add($grid)
    $layout.Controls.Add($card, 0, 0)
}

function Resize-SettingsRows($Panel) {
    if ($null -eq $Panel) { return }
    $hiddenScrollbarWidth = 0
    if ($null -ne $Panel.Parent -and [string]$Panel.Parent.Tag -eq "scrollClip") {
        $hiddenScrollbarWidth = 18
    }
    $width = [Math]::Max(420, $Panel.ClientSize.Width - $Panel.Padding.Left - $Panel.Padding.Right - $hiddenScrollbarWidth - 24)
    foreach ($control in $Panel.Controls) {
        if ($null -ne $control -and [string]$control.Tag -eq "settingsRow") {
            $control.Width = $width
        }
    }
}

function Add-SettingsRow($Panel, $Row, $Height) {
    if ($null -eq $Panel -or $null -eq $Row) { return }
    $Row.Tag = "settingsRow"
    $Row.Dock = [System.Windows.Forms.DockStyle]::None
    $Row.Height = $Height
    $Row.Width = [Math]::Max(420, $Panel.ClientSize.Width - $Panel.Padding.Left - $Panel.Padding.Right - 48)
    $Row.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    [void]$Panel.Controls.Add($Row)
}


function New-SettingsHeroRow {
    $panel = New-GradientCard 18 $script:Colors.Card $script:Colors.Panel2 $script:Colors.Accent $false
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $panel.BorderColor = $script:Colors.Accent
    $grid = New-Table 1 3 $panel.BackColor
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 160
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 160
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $copy = New-Table 2 1 $panel.BackColor
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $title = New-FillLabel "Safety rails stay on by default" 15 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $body = New-WrapLabel "ApexTune is designed around small batches, restore points, targeted registry backups, readable plans, rollback scripts, and update validation." 9.0 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $body.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $copy.Controls.Add($title,0,0); $copy.Controls.Add($body,0,1)
    $grid.Controls.Add($copy,0,0)
    $snapshot = New-ApexMiniButton "Snapshot" { Export-ApexSystemSnapshot } "primary"
    $reports = New-ApexMiniButton "Reports" { $reportsPath = Join-Path $script:AppDir "Reports"; New-Item -ItemType Directory -Path $reportsPath -Force | Out-Null; Start-Process explorer.exe $reportsPath } "secondary"
    $grid.Controls.Add($snapshot,1,0); $grid.Controls.Add($reports,2,0)
    $panel.Controls.Add($grid)
    return $panel
}

function Build-Settings {
    $settingsList = New-StackPanel ([System.Windows.Forms.FlowDirection]::TopDown) $false $script:Colors.Bg
    $settingsList.Padding = New-Object System.Windows.Forms.Padding(0, 0, 8, 18)
    $settingsList.AutoScroll = $false
    $settingsList.WrapContents = $false
    $settingsList.HorizontalScroll.Enabled = $false
    $settingsList.HorizontalScroll.Visible = $false
    $settingsList.Tag = "settingsStack"
    $script:Content.Controls.Add((New-ClippedScrollHost $settingsList $script:Colors.Bg))

    Add-SettingsRow $settingsList (New-SettingsHeroRow) 118
    Add-SettingsRow $settingsList (New-ThemeSettingRow) 96
    Add-SettingsRow $settingsList (New-AppMarkSettingRow) 102
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Open maximized" "Starts ApexTune in a full-size desktop layout." "StartMaximized") 90
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Turn experimental features on" "Shows aggressive or early-stage tweaks with extra warnings." "Experimental") 90
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Show high risk tweaks" "Includes registry changes that need careful review." "ShowRisky") 90
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Create restore point step" "Adds a Windows restore point before edits when supported." "RestorePoint") 90
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Back up registry keys" "Exports targeted registry keys before tweak groups run." "RegistryBackup") 90
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Strict safety confirmations" "Adds extra confirmations for large batches, destructive cleanup, BCDEdit, and restore/backup-disabled runs." "StrictSafety") 96
    Add-SettingsRow $settingsList (New-SettingRow 0 0 "Compact tweak cards" "Fits more controls on smaller displays." "CompactCards") 90
    Add-SettingsRow $settingsList (New-UpdateStatusSettingRow) 128

    $settingsList.Add_SizeChanged({ param($sender, $eventArgs) Resize-SettingsRows $sender }.GetNewClosure())
    Resize-SettingsRows $settingsList
}

function Get-ApexUpdateStatusResult {
    try {
        $source = Get-ApexUpdateSourceObject
        if ($null -eq $source -or (Test-ApexPlaceholderUpdateUrl ([string]$source.manifestUrl))) {
            return [pscustomobject]@{ State = "notconnected"; Light = "*"; Color = $script:Colors.Amber; Title = "Updater not connected"; Body = "Add your hosted latest.json URL in UPDATE-SOURCE.json, then check again."; Current = (Get-AppLocalVersionNumber); Latest = "-"; Result = $null }
        }
        $result = Test-ApexUpdateAvailable -Silent
        if ($null -eq $result) {
            return [pscustomobject]@{ State = "error"; Light = "*"; Color = $script:Colors.Red; Title = "Update check failed"; Body = "Could not read the update manifest. Check the URL or internet connection."; Current = (Get-AppLocalVersionNumber); Latest = "-"; Result = $null }
        }
        if ($result.Available) {
            return [pscustomobject]@{ State = "outdated"; Light = "*"; Color = $script:Colors.Red; Title = "Update available"; Body = ("{0}  ---->  {1}" -f $result.CurrentText, $result.LatestText); Current = $result.CurrentText; Latest = $result.LatestText; Result = $result }
        }
        return [pscustomobject]@{ State = "current"; Light = "*"; Color = $script:Colors.Green; Title = "ApexTune is up to date"; Body = ("Current version: " + $result.CurrentText); Current = $result.CurrentText; Latest = $result.LatestText; Result = $result }
    } catch {
        return [pscustomobject]@{ State = "error"; Light = "*"; Color = $script:Colors.Red; Title = "Update check error"; Body = $_.Exception.Message; Current = (Get-AppLocalVersionNumber); Latest = "-"; Result = $null }
    }
}

function Set-UpdateStatusRowView($Status, $DotLabel, $TitleLabel, $BodyLabel, $UpdateButton) {
    if ($null -eq $Status) { return }
    if ($null -ne $DotLabel -and -not $DotLabel.IsDisposed) { $DotLabel.Text = $Status.Light; $DotLabel.ForeColor = $Status.Color }
    if ($null -ne $TitleLabel -and -not $TitleLabel.IsDisposed) { $TitleLabel.Text = $Status.Title }
    if ($null -ne $BodyLabel -and -not $BodyLabel.IsDisposed) { $BodyLabel.Text = $Status.Body }
    if ($null -ne $UpdateButton -and -not $UpdateButton.IsDisposed) { $UpdateButton.Enabled = ($Status.State -eq "outdated" -and $null -ne $Status.Result); $UpdateButton.Tag = $Status.Result }
}

function New-UpdateStatusSettingRow {
    $panel = New-Card 14 $script:Colors.Card
    Enable-CardHover $panel $script:Colors.Accent $script:Colors.Hover
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)

    $grid = New-Table 1 3 $script:Colors.Card
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 54
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 286
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $dot = New-FillLabel "*" 24 ([System.Drawing.FontStyle]::Bold) $script:Colors.Amber
    $dot.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $grid.Controls.Add($dot, 0, 0)

    $copy = New-Table 2 1 $script:Colors.Card
    Add-Row $copy ([System.Windows.Forms.SizeType]::Absolute) 34
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $title = New-FillLabel "Checking update status..." 11.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $body = New-WrapLabel "ApexTune shows green when current and red when an update is available." 8.8 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $body.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
    $copy.Controls.Add($title, 0, 0)
    $copy.Controls.Add($body, 0, 1)
    $grid.Controls.Add($copy, 1, 0)

    $actions = New-Table 2 2 $script:Colors.Card
    Add-Row $actions ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $actions ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 50
    $check = New-Button "Check now" 0 0 0 0 "secondary"
    $manual = New-Button "Open updater" 0 0 0 0 "ghost"
    $update = New-Button "Update" 0 0 0 0 "primary"
    $sourceBtn = New-Button "Source" 0 0 0 0 "ghost"
    foreach ($button in @($check,$manual,$update,$sourceBtn)) { $button.Dock = [System.Windows.Forms.DockStyle]::Fill; $button.Margin = New-Object System.Windows.Forms.Padding(6, 4, 0, 4); $button.Font = New-Font 8.2 ([System.Drawing.FontStyle]::Bold) }
    $update.Enabled = $false

    $check.Add_Click({
        $status = Get-ApexUpdateStatusResult
        Set-UpdateStatusRowView $status $dot $title $body $update
        if ($status.State -eq "outdated" -and $status.Result) { Show-ApexUpdatePrompt $status.Result }
    }.GetNewClosure())
    $manual.Add_Click({
        try { Start-Process -FilePath (Join-Path $PSScriptRoot "Launch-ApexTune-Updater.bat") -WorkingDirectory $PSScriptRoot } catch { Show-Toast ("Could not open updater: " + $_.Exception.Message) "Updater" }
    })
    $update.Add_Click({
        $result = $update.Tag
        if ($null -ne $result) { Start-ApexTuneUpdaterProcess $result.Manifest }
    }.GetNewClosure())
    $sourceBtn.Add_Click({
        try { Start-Process "notepad.exe" (Join-Path $PSScriptRoot "UPDATE-SOURCE.json") } catch { Show-Toast ("Could not open UPDATE-SOURCE.json: " + $_.Exception.Message) "Updater source" }
    })
    $actions.Controls.Add($check,0,0); $actions.Controls.Add($manual,1,0); $actions.Controls.Add($update,0,1); $actions.Controls.Add($sourceBtn,1,1)
    $grid.Controls.Add($actions, 2, 0)
    $panel.Controls.Add($grid)

    $panel.Add_HandleCreated({
        $status = Get-ApexUpdateStatusResult
        Set-UpdateStatusRowView $status $dot $title $body $update
    }.GetNewClosure())
    return $panel
}

function Update-SettingToggleStyle($Toggle) {
    if ($null -eq $Toggle) { return }
    $Toggle.Text = $(if ($Toggle.Checked) { "ON" } else { "OFF" })
    $Toggle.BackColor = $(if ($Toggle.Checked) { $script:Colors.Accent } else { $script:Colors.Panel2 })
    $Toggle.ForeColor = $(if ($Toggle.Checked) { ColorFromHex "#F8FAFC" } else { $script:Colors.Text })
    $Toggle.FlatAppearance.BorderColor = $(if ($Toggle.Checked) { $script:Colors.Accent } else { $script:Colors.Line })
    $Toggle.FlatAppearance.MouseOverBackColor = $(if ($Toggle.Checked) { ColorFromHex "#4F8FF8" } else { $script:Colors.Hover })
    $Toggle.FlatAppearance.MouseDownBackColor = $(if ($Toggle.Checked) { ColorFromHex "#2563EB" } else { $script:Colors.Panel2 })
}

function New-SettingRow($X, $Y, $Title, $Body, $Key) {
    $panel = New-Card 14 $script:Colors.Card
    Enable-CardHover $panel $script:Colors.Accent $script:Colors.Hover
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)
    $grid = New-Table 1 2 $script:Colors.Card
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 126
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100
    $copy = New-Table 2 1 $script:Colors.Card
    Add-Row $copy ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $titleLabel = New-AutoLabel $Title 10.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $titleLabel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 0)
    $copy.Controls.Add($titleLabel, 0, 0)
    $bodyLabel = New-AutoLabel $Body 9.0 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted 760
    $bodyLabel.Margin = New-Object System.Windows.Forms.Padding(0, 7, 0, 0)
    $copy.Controls.Add($bodyLabel, 0, 1)
    $toggleHost = New-Table 3 1 $script:Colors.Card
    Add-Row $toggleHost ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $toggleHost ([System.Windows.Forms.SizeType]::Absolute) 38
    Add-Row $toggleHost ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Column $toggleHost ([System.Windows.Forms.SizeType]::Percent) 100
    $check = New-Object System.Windows.Forms.CheckBox
    $check.Dock = [System.Windows.Forms.DockStyle]::Fill
    $check.AutoSize = $false
    $check.Appearance = [System.Windows.Forms.Appearance]::Button
    $check.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $check.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $check.Font = New-Font 8.8 ([System.Drawing.FontStyle]::Bold)
    $check.Margin = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
    $check.MinimumSize = New-Object System.Drawing.Size(86, 34)
    $check.UseVisualStyleBackColor = $false
    $check.Tag = $Key
    $check.Checked = [bool]$script:State.Settings[$Key]
    Update-SettingToggleStyle $check
    $check.Add_CheckedChanged({
        param($sender, $eventArgs)
        Update-SettingToggleStyle $sender
        Set-OptimizerSetting ([string]$sender.Tag) ([bool]$sender.Checked)
    })
    $grid.Controls.Add($copy, 0, 0)
    $toggleHost.Controls.Add($check, 0, 1)
    $grid.Controls.Add($toggleHost, 1, 0)
    $panel.Controls.Add($grid)
    return $panel
}

function New-ThemeSettingRow {
    $panel = New-Card 16 $script:Colors.Card
    Enable-CardHover $panel $script:Colors.Accent $script:Colors.Hover
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)

    $grid = New-Table 1 2 $script:Colors.Card
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 270
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $copy = New-Table 2 1 $script:Colors.Card
    Add-Row $copy ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $copy.Controls.Add((New-AutoLabel "Appearance" 10.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text), 0, 0)
    $bodyLabel = New-AutoLabel "Pro dark mode is locked in for this build so old saved light settings cannot wash out or clip the UI." 9.0 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted 760
    $bodyLabel.Margin = New-Object System.Windows.Forms.Padding(0, 7, 0, 0)
    $copy.Controls.Add($bodyLabel, 0, 1)

    $theme = Get-AppTheme
    $choices = New-Table 1 2 $script:Colors.Card
    Add-Column $choices ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Column $choices ([System.Windows.Forms.SizeType]::Percent) 50
    Add-Row $choices ([System.Windows.Forms.SizeType]::Absolute) 42
    $dark = New-Button "Pro Dark" 0 0 0 0 $(if ($theme -eq "dark") { "primary" } else { "ghost" })
    $light = New-Button "Locked" 0 0 0 0 $(if ($theme -eq "light") { "primary" } else { "ghost" })
    $dark.Dock = [System.Windows.Forms.DockStyle]::Fill
    $light.Dock = [System.Windows.Forms.DockStyle]::Fill
    $dark.Margin = New-Object System.Windows.Forms.Padding(0, 2, 10, 2)
    $light.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $dark.Add_Click({ Set-AppTheme "dark" })
    $light.Add_Click({ Set-AppTheme "light" })
    $choices.Controls.Add($dark, 0, 0)
    $choices.Controls.Add($light, 1, 0)

    $grid.Controls.Add($copy, 0, 0)
    $grid.Controls.Add($choices, 1, 0)
    $panel.Controls.Add($grid)
    return $panel
}

function New-AppMarkSettingRow {
    $panel = New-Card 16 $script:Colors.Card
    Enable-CardHover $panel $script:Colors.Accent $script:Colors.Hover
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 12)

    $grid = New-Table 1 2 $script:Colors.Card
    Add-Column $grid ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $grid ([System.Windows.Forms.SizeType]::Absolute) 300
    Add-Row $grid ([System.Windows.Forms.SizeType]::Percent) 100

    $copy = New-Table 2 1 $script:Colors.Card
    Add-Row $copy ([System.Windows.Forms.SizeType]::AutoSize) 0
    Add-Row $copy ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $copy ([System.Windows.Forms.SizeType]::Percent) 100
    $copy.Controls.Add((New-AutoLabel "App mark" 10.4 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text), 0, 0)
    $bodyLabel = New-AutoLabel "Customize the small title bar and sidebar logo text." 9.0 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted 760
    $bodyLabel.Margin = New-Object System.Windows.Forms.Padding(0, 7, 0, 0)
    $copy.Controls.Add($bodyLabel, 0, 1)

    $editor = New-Table 1 2 $script:Colors.Card
    Add-Column $editor ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $editor ([System.Windows.Forms.SizeType]::Absolute) 112
    Add-Row $editor ([System.Windows.Forms.SizeType]::Absolute) 42
    $box = New-TextBox 0 0 0 0
    $box.Dock = [System.Windows.Forms.DockStyle]::Fill
    $box.Margin = New-Object System.Windows.Forms.Padding(0, 2, 0, 2)
    $box.Text = Get-AppMark
    $box.MaxLength = 3
    $box.CharacterCasing = [System.Windows.Forms.CharacterCasing]::Upper
    $save = New-Button "Save" 0 0 0 0 "secondary"
    $save.Dock = [System.Windows.Forms.DockStyle]::Fill
    $save.Margin = New-Object System.Windows.Forms.Padding(10, 2, 0, 2)
    $save.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 1)
    $save.Tag = $box
    $save.Add_Click({
        param($sender, $eventArgs)
        $targetBox = $sender.Tag
        if ($null -ne $targetBox -and $targetBox -is [System.Windows.Forms.TextBox]) {
            $targetBox.Text = (Set-AppMark ([string]$targetBox.Text))
        }
    })
    $box.Add_KeyDown({
        param($sender, $eventArgs)
        if ($eventArgs.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
            if ($null -ne $sender -and $sender -is [System.Windows.Forms.TextBox]) {
                $sender.Text = (Set-AppMark ([string]$sender.Text))
            }
            $eventArgs.SuppressKeyPress = $true
        }
    })
    $editor.Controls.Add($box, 0, 0)
    $editor.Controls.Add($save, 1, 0)

    $grid.Controls.Add($copy, 0, 0)
    $grid.Controls.Add($editor, 1, 0)
    $panel.Controls.Add($grid)
    return $panel
}

function Show-PayDialog {
    if (Has-Premium) {
        Show-Toast "This account already has all paid tweaks unlocked."
        return
    }
    $result = [System.Windows.Forms.MessageBox]::Show(
        $script:Form,
        "ApexTune Pro demo checkout unlocks GPU, network, MSI-mode guard, and experimental tweak packs for this local account. Continue?",
        "ApexTune Pro",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
        $script:State.User.Plan = "pro"
        Add-Activity "Demo checkout completed" 0
        Save-CurrentUser
        Update-Header
        Show-Toast "Pro tweaks unlocked."
        Show-View "dashboard"
    }
}

function Safe-FileName($Value) {
    return (($Value -replace "[^a-zA-Z0-9_-]", "_").Trim("_"))
}

function Build-PlanScript($Tweaks) {
    $lines = @()
    $lines += "# ApexTune Optimization Plan"
    $lines += "# Generated: " + (Get-Date)
    $lines += "# App version: $script:AppVersion"
    $lines += "# Run PowerShell as Administrator and review every line first."
    $lines += "# Tip: benchmark one game before and after. If something feels worse, run the rollback notes or use System Restore."
    $summary = Get-TweakSafetySummary $Tweaks
    $lines += ("# Safety summary: {0} tweak(s), Medium={1}, High={2}, Experimental={3}, Restart={4}, Cleanup/repair={5}, Boot/timer={6}" -f $summary.Count, $summary.Medium, $summary.High, $summary.Experimental, $summary.Restart, $summary.Destructive, $summary.Boot)
    $lines += '$ErrorActionPreference = "Continue"'
    $lines += '$backupRoot = Join-Path $env:USERPROFILE "Desktop\ApexTune-Backups"'
    $lines += 'New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null'
    if ($script:State.Settings.RestorePoint) {
        $lines += ""
        $lines += 'Checkpoint-Computer -Description "ApexTune before tweaks" -RestorePointType "MODIFY_SETTINGS"'
    }
    $i = 1
    foreach ($tweak in $Tweaks) {
        $lines += ""
        $lines += "# $i. $($tweak.Title)"
        $lines += "# Risk: $($tweak.Risk). $($tweak.Summary)"
        if ($script:State.Settings.RegistryBackup) {
            $b = 1
            foreach ($key in $tweak.BackupKeys) {
                $lines += ('reg export "{0}" "$backupRoot\{1}-{2}.reg" /y' -f $key, $tweak.Id, $b)
                $b++
            }
        }
        $lines += $tweak.Commands
        $i++
    }
    return ($lines -join [Environment]::NewLine)
}

function Build-RollbackScript($Tweaks) {
    $lines = @("# ApexTune Rollback Notes", "# Prefer System Restore if a tweak causes instability.")
    $i = 1
    foreach ($tweak in $Tweaks) {
        $lines += ""
        $lines += "# $i. $($tweak.Title)"
        $lines += $tweak.Rollback
        $i++
    }
    return ($lines -join [Environment]::NewLine)
}

function Backup-RegistryKeys($Tweak, $BackupDir) {
    if (-not $script:State.Settings.RegistryBackup) { return }
    $index = 1
    foreach ($key in $Tweak.BackupKeys) {
        $file = Join-Path $BackupDir ((Safe-FileName $Tweak.Id) + "-$index.reg")
        Append-Log "Backing up $key"
        $output = & reg.exe export $key $file /y 2>&1
        foreach ($line in $output) { Append-Log ($line.ToString()) }
        $index++
    }
}

function Invoke-Tweak($Tweak) {
    Append-Log "Applying: $($Tweak.Title)"
    try {
        if (-not (Test-TweakAllowedBySettings $Tweak)) { Append-Log "Skipped by current safety settings."; return }
        $scriptText = ('$ErrorActionPreference = "Continue"' + [Environment]::NewLine + ($Tweak.Commands -join [Environment]::NewLine))
        $block = [scriptblock]::Create($scriptText)
        $output = & $block 2>&1
        foreach ($line in $output) { Append-Log ($line.ToString()) }
        Append-Log "Finished: $($Tweak.Title)"
    } catch {
        Append-Log ("Error: " + $_.Exception.Message)
    }
}

function Get-AppLocalVersionNumber {
    if ($script:AppVersionNumber) { return [string]$script:AppVersionNumber }
    $versionFile = Join-Path $PSScriptRoot "VERSION.txt"
    if (Test-Path -LiteralPath $versionFile) {
        $raw = (Get-Content -Raw -LiteralPath $versionFile).Trim()
        if ($raw -match '(\d+(\.\d+)+)') { return $matches[1] }
    }
    return "0.0.0"
}

function Convert-ToApexVersion([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return [version]"0.0.0" }
    $clean = ([string]$Value).Trim()
    if ($clean -match '(\d+(\.\d+)+)') { $clean = $matches[1] }
    elseif ($clean -match '^(\d+)$') { $clean = "$($matches[1]).0.0" }
    $parts = @($clean.Split('.') | Where-Object { $_ -match '^\d+$' })
    while ($parts.Count -lt 2) { $parts += '0' }
    if ($parts.Count -gt 4) { $parts = $parts[0..3] }
    try { return [version]($parts -join '.') } catch { return [version]"0.0.0" }
}

function Test-ApexPlaceholderUpdateUrl([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return $true }
    $bad = @('PUT_REAL_HTTPS', 'PUT_DOWNLOAD', 'example.com', 'your-domain.com', 'localhost/replace', 'ApexTune_Latest.zip')
    foreach ($item in $bad) {
        if ($Url.IndexOf($item, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) { return $true }
    }
    return $false
}

function Get-ApexUpdateSourceObject {
    $sourcePath = Join-Path $PSScriptRoot "UPDATE-SOURCE.json"
    if (Test-Path -LiteralPath $sourcePath) {
        try { return (Get-Content -Raw -LiteralPath $sourcePath | ConvertFrom-Json) } catch { }
    }
    $manifestPath = Join-Path $PSScriptRoot "UPDATE-MANIFEST.json"
    if (Test-Path -LiteralPath $manifestPath) {
        try {
            $m = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
            if ($m.manifestUrl) { return [pscustomobject]@{ manifestUrl = [string]$m.manifestUrl; checkOnStartup = $true; checkIntervalMinutes = 3 } }
        } catch { }
    }
    return [pscustomobject]@{ manifestUrl = ""; checkOnStartup = $true; checkIntervalMinutes = 3 }
}

function Get-ApexLatestManifest([switch]$Silent) {
    $source = Get-ApexUpdateSourceObject
    $manifestUrl = [string]$source.manifestUrl
    if (Test-ApexPlaceholderUpdateUrl $manifestUrl) {
        if (-not $Silent) { Show-Toast "Updater is not connected to a hosted manifest yet." "ApexTune updater" }
        return $null
    }
    try {
        if ($manifestUrl.StartsWith('file://', [System.StringComparison]::OrdinalIgnoreCase)) {
            $uri = [Uri]$manifestUrl
            return (Get-Content -Raw -LiteralPath $uri.LocalPath | ConvertFrom-Json)
        }
        if ($manifestUrl -match '^[A-Za-z]:\\') {
            return (Get-Content -Raw -LiteralPath $manifestUrl | ConvertFrom-Json)
        }
        if ($manifestUrl -notmatch '^https://') {
            if (-not $Silent) { Show-Toast "Update manifest must be HTTPS or file://." "ApexTune updater" }
            return $null
        }
        $client = New-Object System.Net.WebClient
        $client.Headers.Add('Cache-Control','no-cache')
        $json = $client.DownloadString($manifestUrl)
        return ($json | ConvertFrom-Json)
    } catch {
        if (-not $Silent) { Show-Toast ("Update check failed: " + $_.Exception.Message) "ApexTune updater" }
        return $null
    }
}

function Test-ApexUpdateAvailable([switch]$Silent) {
    $manifest = Get-ApexLatestManifest -Silent:$Silent
    if ($null -eq $manifest) { return $null }
    $currentText = Get-AppLocalVersionNumber
    $latestText = [string]$manifest.version
    $current = Convert-ToApexVersion $currentText
    $latest = Convert-ToApexVersion $latestText
    return [pscustomobject]@{
        Available = ($latest -gt $current)
        CurrentText = $currentText
        LatestText = $latestText
        Current = $current
        Latest = $latest
        Manifest = $manifest
        Required = [bool]($manifest.required -or $manifest.updateRequired)
        Notes = [string]$manifest.notes
    }
}

function Start-ApexTuneUpdaterProcess($Manifest) {
    try {
        $updater = Join-Path $PSScriptRoot "ApexTune-Updater.ps1"
        if (!(Test-Path -LiteralPath $updater)) { Show-Toast "ApexTune-Updater.ps1 was not found." "Updater"; return }
        $source = Get-ApexUpdateSourceObject
        $manifestUrl = [string]$source.manifestUrl
        $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $updater + '"'),'-InstallDir',('"' + $PSScriptRoot + '"'),'-Gui')
        if (-not (Test-ApexPlaceholderUpdateUrl $manifestUrl)) { $args += @('-ManifestUrl',('"' + $manifestUrl + '"')) }
        Start-Process -FilePath 'powershell.exe' -ArgumentList ($args -join ' ') -WorkingDirectory $PSScriptRoot
        $script:Form.Close()
    } catch {
        Show-Toast ("Could not start updater: " + $_.Exception.Message) "Updater"
    }
}

function Show-ApexUpdatePrompt($Result) {
    if ($null -eq $Result -or -not $Result.Available) { return }
    if ($script:LastUpdateVersionPrompted -eq $Result.LatestText -and -not $Result.Required) { return }
    $script:LastUpdateVersionPrompted = $Result.LatestText

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "ApexTune update available"
    $dialog.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterParent
    $dialog.Size = New-Object System.Drawing.Size(560, 360)
    $dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.BackColor = $script:Colors.Panel
    $dialog.ForeColor = $script:Colors.Text
    $dialog.Font = New-Font 9
    $dialog.Padding = New-Object System.Windows.Forms.Padding(22)

    $root = New-Table 5 1 $script:Colors.Panel
    Add-Column $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $root ([System.Windows.Forms.SizeType]::Absolute) 54
    Add-Row $root ([System.Windows.Forms.SizeType]::Absolute) 76
    Add-Row $root ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Row $root ([System.Windows.Forms.SizeType]::Absolute) 42
    Add-Row $root ([System.Windows.Forms.SizeType]::Absolute) 48
    $dialog.Controls.Add($root)

    $header = New-Table 1 3 $script:Colors.Panel
    Add-Column $header ([System.Windows.Forms.SizeType]::Absolute) 44
    Add-Column $header ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $header ([System.Windows.Forms.SizeType]::Absolute) 88
    Add-Row $header ([System.Windows.Forms.SizeType]::Percent) 100
    $dot = New-AutoLabel "*" 25 ([System.Drawing.FontStyle]::Bold) $script:Colors.Red
    $dot.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $header.Controls.Add($dot,0,0)
    $title = New-FillLabel $(if ($Result.Required) { "UPDATE REQUIRED" } else { "Update available" }) 18 ([System.Drawing.FontStyle]::Bold) $script:Colors.Text
    $title.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $header.Controls.Add($title,1,0)
    $badge = New-AutoLabel "LIVE" 9 ([System.Drawing.FontStyle]::Bold) $script:Colors.Red
    $badge.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $badge.BackColor = $script:Colors.Field
    $header.Controls.Add($badge,2,0)
    $root.Controls.Add($header,0,0)

    $versions = New-Table 1 3 $script:Colors.Card
    $versions.Padding = New-Object System.Windows.Forms.Padding(12, 10, 12, 10)
    Add-Column $versions ([System.Windows.Forms.SizeType]::Percent) 45
    Add-Column $versions ([System.Windows.Forms.SizeType]::Absolute) 56
    Add-Column $versions ([System.Windows.Forms.SizeType]::Percent) 45
    Add-Row $versions ([System.Windows.Forms.SizeType]::Percent) 100
    $old = New-FillLabel $Result.CurrentText 17 ([System.Drawing.FontStyle]::Bold) $script:Colors.Red
    $old.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $arrow = New-FillLabel "---->" 15 ([System.Drawing.FontStyle]::Bold) $script:Colors.Muted
    $arrow.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $new = New-FillLabel $Result.LatestText 17 ([System.Drawing.FontStyle]::Bold) $script:Colors.Green
    $new.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $versions.Controls.Add($old,0,0); $versions.Controls.Add($arrow,1,0); $versions.Controls.Add($new,2,0)
    $root.Controls.Add($versions,0,1)

    $notes = New-Object System.Windows.Forms.TextBox
    $notes.Multiline = $true
    $notes.ReadOnly = $true
    $notes.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    $notes.BackColor = $script:Colors.Field
    $notes.ForeColor = $script:Colors.Muted
    $notes.Text = if ($Result.Notes) { $Result.Notes } else { "This update will download the newest ApexTune package, validate it, create a backup, remove old app files, and extract the newest files." }
    $notes.Dock = [System.Windows.Forms.DockStyle]::Fill
    $notes.Margin = New-Object System.Windows.Forms.Padding(0, 12, 0, 10)
    $root.Controls.Add($notes,0,2)

    $fine = New-FillLabel "You can decline and keep using this version. ApexTune will only show this again for a newer version or a required update." 8.4 ([System.Drawing.FontStyle]::Regular) $script:Colors.Muted
    $fine.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $root.Controls.Add($fine,0,3)

    $actions = New-Table 1 3 $script:Colors.Panel
    Add-Column $actions ([System.Windows.Forms.SizeType]::Percent) 100
    Add-Column $actions ([System.Windows.Forms.SizeType]::Absolute) 120
    Add-Column $actions ([System.Windows.Forms.SizeType]::Absolute) 150
    Add-Row $actions ([System.Windows.Forms.SizeType]::Percent) 100
    $later = New-Button "Decline" 0 0 0 0 "ghost"
    $now = New-Button "Update now" 0 0 0 0 "primary"
    $later.Dock = [System.Windows.Forms.DockStyle]::Fill
    $now.Dock = [System.Windows.Forms.DockStyle]::Fill
    $later.Margin = New-Object System.Windows.Forms.Padding(0, 4, 10, 0)
    $now.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
    $later.Add_Click({ $dialog.Close() })
    $now.Add_Click({ $dialog.Close(); Start-ApexTuneUpdaterProcess $Result.Manifest })
    $actions.Controls.Add($later,1,0)
    $actions.Controls.Add($now,2,0)
    $root.Controls.Add($actions,0,4)

    [void]$dialog.ShowDialog($script:Form)
}

function Start-ApexUpdatePolling {
    try {
        if ($script:UpdateCheckTimer) { $script:UpdateCheckTimer.Stop(); $script:UpdateCheckTimer.Dispose(); $script:UpdateCheckTimer = $null }
        $source = Get-ApexUpdateSourceObject
        if ($source.checkOnStartup -eq $false) { return }
        $script:UpdateCheckTimer = New-Object System.Windows.Forms.Timer
        $intervalMinutes = 3
        try { if ($source.checkIntervalMinutes) { $intervalMinutes = [Math]::Max(1, [int]$source.checkIntervalMinutes) } } catch {}
        $script:UpdateCheckTimer.Interval = 4500
        $script:UpdateCheckTimer.Add_Tick({
            try {
                $script:UpdateCheckTimer.Stop()
                $result = Test-ApexUpdateAvailable -Silent
                if ($result -and $result.Available) { Show-ApexUpdatePrompt $result }
                $script:UpdateCheckTimer.Interval = [Math]::Max(60000, $intervalMinutes * 60000)
                if ($script:Form -and -not $script:Form.IsDisposed) { $script:UpdateCheckTimer.Start() }
            } catch { }
        })
        $script:UpdateCheckTimer.Start()
    } catch { }
}

function Stop-ApexUpdatePolling {
    try { if ($script:UpdateCheckTimer) { $script:UpdateCheckTimer.Stop(); $script:UpdateCheckTimer.Dispose(); $script:UpdateCheckTimer = $null } } catch {}
}


function Get-TweakSafetySummary($Tweaks) {
    $items = @($Tweaks)
    $medium = @($items | Where-Object { $_.Risk -eq "Medium" }).Count
    $high = @($items | Where-Object { $_.Risk -eq "High" }).Count
    $experimental = @($items | Where-Object { $_.Experimental }).Count
    $restart = @($items | Where-Object { $_.Restart }).Count
    $registry = @($items | Where-Object { $_.BackupKeys -and @($_.BackupKeys).Count -gt 0 }).Count
    $destructive = 0
    $boot = 0
    $service = 0
    foreach ($tweak in $items) {
        $commands = (($tweak.Commands -join [Environment]::NewLine) + [Environment]::NewLine + ($tweak.Rollback -join [Environment]::NewLine))
        if ($commands -match 'Clear-RecycleBin|Remove-Item|Delete-DeliveryOptimizationCache|powercfg\s+/hibernate|DISM\s+/Online\s+/Cleanup-Image\s+/RestoreHealth|sfc\s+/scannow') { $destructive++ }
        if ($commands -match '\bbcdedit\b|useplatformclock|tscsyncpolicy|disabledynamictick') { $boot++ }
        if ($commands -match 'Set-Service|Stop-Service|Disable-NetAdapter|Set-NetAdapterAdvancedProperty') { $service++ }
    }
    return [pscustomobject]@{
        Count = $items.Count
        Medium = $medium
        High = $high
        Experimental = $experimental
        Restart = $restart
        Registry = $registry
        Destructive = $destructive
        Boot = $boot
        Service = $service
    }
}

function Confirm-ApexApplySafety($SelectedTweaks) {
    $selected = @($SelectedTweaks)
    if ($selected.Count -eq 0) { return $false }
    $safety = Get-TweakSafetySummary $selected
    $strict = $true
    try { if ($script:State.Settings.ContainsKey("StrictSafety")) { $strict = [bool]$script:State.Settings.StrictSafety } } catch {}

    $warnings = @()
    if ($safety.High -gt 0) { $warnings += ("High risk tweaks: " + $safety.High) }
    if ($safety.Experimental -gt 0) { $warnings += ("Experimental tweaks: " + $safety.Experimental) }
    if ($safety.Destructive -gt 0) { $warnings += ("Cleanup/repair actions that may not be automatically reversible: " + $safety.Destructive) }
    if ($safety.Boot -gt 0) { $warnings += ("Boot/timer commands: " + $safety.Boot) }
    if ($safety.Service -gt 0) { $warnings += ("Service/adapter commands: " + $safety.Service) }
    if ($safety.Restart -gt 0) { $warnings += ("Restart recommended by cards: " + $safety.Restart) }
    if (-not [bool]$script:State.Settings.RestorePoint) { $warnings += "Restore point step is OFF" }
    if (-not [bool]$script:State.Settings.RegistryBackup) { $warnings += "Registry backup step is OFF" }

    $warningText = $(if ($warnings.Count -gt 0) { ($warnings -join [Environment]::NewLine) } else { "No elevated safety warnings in this batch." })
    $confirmText = @(
        "Apply $($selected.Count) selected tweak(s) now?",
        "",
        "ApexTune will save a readable plan, rollback script, JSON run manifest, and targeted registry backups under:",
        $script:BackupsRoot,
        "",
        "Safety summary:",
        $warningText,
        "",
        "Best practice: apply a small batch, restart, benchmark, then continue only if frametime/FPS/ping improved."
    ) -join [Environment]::NewLine

    $confirm = [System.Windows.Forms.MessageBox]::Show($script:Form, $confirmText, "Apply selected tweaks", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }

    if ($strict -and $selected.Count -gt $script:MaxStrictApplyCount) {
        $batchText = "Strict safety is ON and this batch has $($selected.Count) tweaks. ApexTune recommends $script:MaxStrictApplyCount or fewer at a time so regressions are easy to isolate.`n`nApply this large batch anyway?"
        $batchChoice = [System.Windows.Forms.MessageBox]::Show($script:Form, $batchText, "Large batch warning", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($batchChoice -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
    }

    if ($strict -and ($safety.High -gt 0 -or $safety.Boot -gt 0 -or $safety.Destructive -gt 0 -or -not [bool]$script:State.Settings.RestorePoint -or -not [bool]$script:State.Settings.RegistryBackup)) {
        $extraText = @(
            "Final safety gate:",
            "",
            "This run includes higher-impact changes or disabled safety rails.",
            "Only continue if you have reviewed the exported plan and are ready to benchmark/rollback.",
            "",
            "Continue?"
        ) -join [Environment]::NewLine
        $extra = [System.Windows.Forms.MessageBox]::Show($script:Form, $extraText, "Strict safety confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($extra -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
    }

    return $true
}

function Apply-SelectedTweaks {
    $selected = @(Get-SelectedTweaks)
    if ($selected.Count -eq 0) { return }

    if (-not (Test-Admin)) {
        $choice = [System.Windows.Forms.MessageBox]::Show(
            $script:Form,
            "Applying registry, power, and network tweaks requires administrator rights. Relaunch ApexTune as administrator?",
            "Administrator required",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) {
            Save-CurrentUser
            Save-Session $script:State.User.Username $true
            Relaunch-AsAdmin
            $script:Form.Close()
        }
        return
    }

    if (-not (Confirm-ApexApplySafety $selected)) { return }

    Ensure-AppData
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupDir = Join-Path $script:BackupsRoot $stamp
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

    Set-Content -Path (Join-Path $backupDir "ApexTune-Plan.ps1") -Value (Build-PlanScript $selected) -Encoding UTF8
    Set-Content -Path (Join-Path $backupDir "ApexTune-Rollback.ps1") -Value (Build-RollbackScript $selected) -Encoding UTF8
    $safety = Get-TweakSafetySummary $selected
    $runManifest = [pscustomobject]@{
        AppVersion = $script:AppVersion
        AppVersionNumber = $script:AppVersionNumber
        GeneratedAt = (Get-Date).ToString("o")
        User = $(if ($script:State.User -and $script:State.User.Username) { [string]$script:State.User.Username } else { "unknown" })
        RestorePointEnabled = [bool]$script:State.Settings.RestorePoint
        RegistryBackupEnabled = [bool]$script:State.Settings.RegistryBackup
        StrictSafetyEnabled = [bool]$script:State.Settings.StrictSafety
        Safety = $safety
        Tweaks = @($selected | ForEach-Object { [pscustomobject]@{ Id = $_.Id; Title = $_.Title; Category = $_.Category; Risk = $_.Risk; Restart = $_.Restart; Experimental = $_.Experimental } })
    }
    $runManifest | ConvertTo-Json -Depth 8 | Set-Content -Path (Join-Path $backupDir "ApexTune-RunManifest.json") -Encoding UTF8
    Append-Log "Saved plan, rollback, and run manifest files to $backupDir"

    if ($script:State.Settings.RestorePoint) {
        Append-Log "Creating restore point"
        try {
            $output = Checkpoint-Computer -Description "ApexTune before tweaks" -RestorePointType "MODIFY_SETTINGS" 2>&1
            foreach ($line in $output) { Append-Log ($line.ToString()) }
        } catch {
            Append-Log ("Restore point warning: " + $_.Exception.Message)
        }
    }

    foreach ($tweak in $selected) {
        Backup-RegistryKeys $tweak $backupDir
        Invoke-Tweak $tweak
    }

    Add-Activity "Applied optimization plan" $selected.Count
    Save-CurrentUser
    Append-Log "Done. Restart Windows before benchmarking."
    Show-Toast "Selected tweaks were applied. Restart Windows before benchmarking."
}

Ensure-AppData
$script:State["Users"] = Load-Users

$script:Form = New-Object System.Windows.Forms.Form
$script:Form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
$script:Form.AutoSize = $false
$script:Form.Size = New-Object System.Drawing.Size(1480, 900)
$script:Form.MinimumSize = New-Object System.Drawing.Size(1180, 720)
$script:Form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$script:Form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$script:Form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
$script:Form.ShowIcon = $true
try {
    $iconPath = Join-Path $PSScriptRoot 'assets\ApexTune-AppIcon.ico'
    if (Test-Path $iconPath) { $script:Form.Icon = New-Object System.Drawing.Icon($iconPath) }
} catch {}
$script:Form.BackColor = $script:Colors.Bg
$script:Form.ForeColor = $script:Colors.Text
$script:Form.Font = New-Font 9
$script:Form.Add_FormClosing({
    Stop-PageSlideTransition
    Stop-LiveStatsTimer
    Stop-ApexUpdatePolling
})

try {
    $session = Load-Session
    if ($session -and $session.Username) {
        Sign-In $session.Username
        if ($null -ne $script:State.User) {
            Show-App
        } else {
            Build-AuthView
        }
    } else {
        Build-AuthView
    }
} catch {
    try {
        Ensure-AppData
        $logPath = Write-ApexErrorLog "ApexTune-StartupError.txt" $_ $_.Exception.Message
    } catch {}
    [System.Windows.Forms.MessageBox]::Show("ApexTune hit a startup UI error and saved it to %APPDATA%\ApexTune\ApexTune-StartupError.txt`n`n" + $_.Exception.Message, "ApexTune startup guard", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
    Build-AuthView
}

try {
    [System.Windows.Forms.Application]::Run($script:Form)
} catch {
    try {
        Ensure-AppData
        $logPath = Write-ApexErrorLog "ApexTune-FatalError.txt" $_ $_.Exception.Message
    } catch {}
    [System.Windows.Forms.MessageBox]::Show("ApexTune hit a fatal error and saved it to %APPDATA%\ApexTune\ApexTune-FatalError.txt`n`n" + $_.Exception.Message, "ApexTune fatal error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
}


function Get-ApexTuneUpdateManifestPath {
    $local = Join-Path $PSScriptRoot "UPDATE-MANIFEST.json"
    if (Test-Path $local) { return $local }
    return $null
}

function Test-ApexTuneUpdateAvailable {
    try {
        $manifestPath = Get-ApexTuneUpdateManifestPath
        if (-not $manifestPath) { return @{ Available = $false; Message = "No update manifest configured yet." } }
        $manifest = Get-Content -Raw -Path $manifestPath | ConvertFrom-Json
        $current = "14.0.0"
        if ([version]$manifest.version -gt [version]$current) { return @{ Available = $true; Message = "Update available: $($manifest.version)"; Manifest = $manifest } }
        return @{ Available = $false; Message = "ApexTune is up to date."; Manifest = $manifest }
    } catch {
        return @{ Available = $false; Message = "Update check failed: $($_.Exception.Message)" }
    }
}

# v23-header-clipping-fix: library header/stat/search rows separated to prevent title clipping.
