@echo off
setlocal
cd /d "%~dp0"
echo Running ApexTune health check...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Debug-ApexTune-HealthCheck.ps1" -NoPause
echo.
pause
