param(
    [switch]$OpenLog,
    [switch]$NoPause
)
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$appData = Join-Path $env:APPDATA 'ApexTune'
$diag = Join-Path $appData 'Diagnostics'
$log = Join-Path $diag 'CommandCenter.log'
$intel = Join-Path $appData 'Intelligence'
$session = Join-Path $appData 'Sessions'
$launchState = Join-Path $appData 'Diagnostics\LaunchState.json'
$lastUrl = Join-Path $appData 'Diagnostics\LastUrl.txt'
$debugLog = Join-Path $appData 'Diagnostics\Launch-Debug.log'
Write-Host 'ApexTune Debug Health Check' -ForegroundColor Cyan
Write-Host "Root: $root"
Write-Host "AppData: $appData"
Write-Host ''
$required = @(
    'ApexTune.CommandCenter.ps1',
    'ApexTune.Desktop.ps1',
    'ApexTune-Updater.ps1',
    'web\index.html',
    'web\app.js',
    'web\styles.css',
    'data\tweaks.json',
    'data\games.json',
    'assets\vendor\nvidia.svg',
    'assets\vendor\amd.svg',
    'assets\vendor\intel.svg'
)
foreach ($item in $required) {
    $path = Join-Path $root $item
    if (Test-Path $path) { Write-Host "OK   $item" -ForegroundColor Green } else { Write-Host "MISS $item" -ForegroundColor Red }
}
Write-Host ''
try {
    $tweaks = Get-Content -Raw -Path (Join-Path $root 'data\tweaks.json') | ConvertFrom-Json
    Write-Host "Tweaks catalog: $(@($tweaks).Count) entries" -ForegroundColor Green
} catch { Write-Host "Tweaks catalog error: $($_.Exception.Message)" -ForegroundColor Red }
try {
    $games = Get-Content -Raw -Path (Join-Path $root 'data\games.json') | ConvertFrom-Json
    Write-Host "Games catalog: $(@($games).Count) entries" -ForegroundColor Green
} catch { Write-Host "Games catalog error: $($_.Exception.Message)" -ForegroundColor Red }

Write-Host ''
Write-Host 'Intelligence Core diagnostics:' -ForegroundColor Cyan
foreach ($folder in @($intel, $session)) {
    if (Test-Path $folder) { Write-Host "OK   $folder" -ForegroundColor Green } else { Write-Host "WAIT $folder will be created on launch" -ForegroundColor Yellow }
}


Write-Host ''
Write-Host 'Settings diagnostics:' -ForegroundColor Cyan
$settingsFile = Join-Path $appData 'Settings.json'
if (Test-Path $settingsFile) {
    Write-Host "OK   Settings file: $settingsFile" -ForegroundColor Green
    try {
        $settings = Get-Content -Raw -LiteralPath $settingsFile | ConvertFrom-Json
        Write-Host ('     autoOpenBrowser: ' + $settings.autoOpenBrowser) -ForegroundColor DarkGray
        Write-Host ('     launchMode: ' + $settings.launchMode) -ForegroundColor DarkGray
        Write-Host ('     simpleDescriptions: ' + $settings.simpleDescriptions) -ForegroundColor DarkGray
    } catch { Write-Host "WARN Could not read Settings.json: $($_.Exception.Message)" -ForegroundColor Yellow }
} else {
    Write-Host 'WAIT Settings.json will be created after changing a setting. Defaults are desktop app-window, not normal browser tab.' -ForegroundColor Yellow
}
try {
    $cc = Get-Content -Raw -LiteralPath (Join-Path $root 'ApexTune.CommandCenter.ps1')
    foreach ($needle in @('Convert-ApexStrictBool','/api/settings/reset','app-window','autoOpenBrowser = $true')) {
        if ($cc.Contains($needle)) { Write-Host "OK   Backend contains $needle" -ForegroundColor Green } else { Write-Host "MISS Backend missing $needle" -ForegroundColor Red }
    }
} catch { Write-Host "Settings backend scan failed: $($_.Exception.Message)" -ForegroundColor Yellow }

Write-Host ''
Write-Host 'PowerShell parser-risk scan:' -ForegroundColor Cyan
try {
    $scopeNames = @('script','env','global','local','private','using','workflow','function','variable','alias')
    $riskHits = @()
    Get-ChildItem -Path $root -Filter '*.ps1' -File -Recurse | ForEach-Object {
        $file = $_.FullName
        $lineNo = 0
        Get-Content -LiteralPath $file | ForEach-Object {
            $lineNo++
            $matches = [regex]::Matches($_, '\$([A-Za-z_][A-Za-z0-9_]*):')
            foreach ($m in $matches) {
                $name = $m.Groups[1].Value.ToLowerInvariant()
                if ($scopeNames -notcontains $name) {
                    $riskHits += [pscustomobject]@{ File = $file; Line = $lineNo; Token = $m.Value; Text = $_ }
                }
            }
        }
    }
    if ($riskHits.Count -eq 0) {
        Write-Host 'OK   No unsafe $variable: parser patterns found in PowerShell files.' -ForegroundColor Green
    } else {
        foreach ($hit in $riskHits) { Write-Host ("RISK {0}:{1} {2}" -f $hit.File, $hit.Line, $hit.Token) -ForegroundColor Red }
    }
} catch { Write-Host "Parser-risk scan error: $($_.Exception.Message)" -ForegroundColor Yellow }


Write-Host ''
Write-Host 'Frontend catalog render diagnostics:' -ForegroundColor Cyan
try {
    $webApp = Get-Content -Raw -LiteralPath (Join-Path $root 'web\app.js')
    $webHtml = Get-Content -Raw -LiteralPath (Join-Path $root 'web\index.html')
        $bootfixPath = Join-Path $root 'webpex-bootfix.js'
    $bootfixJs = if (Test-Path -LiteralPath $bootfixPath) { Get-Content -Raw -LiteralPath $bootfixPath } else { '' }
    $frontendAll = "$webJs`n$webHtml`n$bootfixJs"
    foreach ($needle in @('apexRepairCatalogViews','ApexTuneRepairCatalogViews','window.state','renderTweaks(){','inlineGamesCatalog','ApexTuneBootfix','apexLaunchSplash')) {
        if ($frontendAll.Contains($needle)) { Write-Host "OK   Frontend contains $needle" -ForegroundColor Green } else { Write-Host "MISS Frontend missing $needle" -ForegroundColor Yellow }
    }
    if ($webHtml.Contains('app.js?v=62.49') -and $webHtml.Contains('styles.css?v=62.49') -and $webHtml.Contains('apex-bootfix.js?v=62.49')) { Write-Host 'OK   HTML cache-bust version is 62.49' -ForegroundColor Green } else { Write-Host 'WARN HTML cache-bust version is not 62.49' -ForegroundColor Yellow }
} catch { Write-Host "Frontend catalog scan failed: $($_.Exception.Message)" -ForegroundColor Yellow }

Write-Host ''
Write-Host 'Launch diagnostics:' -ForegroundColor Cyan
foreach ($f in @($launchState, $lastUrl, $debugLog)) {
    if (Test-Path $f) { Write-Host ('OK   ' + $f) -ForegroundColor Green; try { Get-Content $f -Tail 12 | ForEach-Object { Write-Host ('     ' + $_) -ForegroundColor DarkGray } } catch {} }
    else { Write-Host ('WAIT ' + $f) -ForegroundColor Yellow }
}

Write-Host 'Power plan diagnostics:' -ForegroundColor Cyan
try {
    $pcfg = Join-Path $env:SystemRoot 'System32\powercfg.exe'
    if (-not (Test-Path $pcfg)) { $pcfg = 'powercfg.exe' }
    Write-Host "powercfg path: $pcfg"
    Write-Host 'Active plan:' -ForegroundColor Yellow
    & $pcfg /getactivescheme
    Write-Host ''
    Write-Host 'Available plans:' -ForegroundColor Yellow
    & $pcfg /list
    Write-Host ''
    Write-Host 'Aliases:' -ForegroundColor Yellow
    & $pcfg /aliases | Select-Object -First 40
} catch {
    Write-Host "Power plan diagnostic error: $($_.Exception.Message)" -ForegroundColor Red
}

if (Test-Path $log) {
    Write-Host ''
    Write-Host "Recent CommandCenter.log:" -ForegroundColor Yellow
    Get-Content -Path $log -Tail 40
    if ($OpenLog) { Start-Process notepad.exe $log }
} else {
    Write-Host ''
    Write-Host 'No CommandCenter.log found yet. Launch the app once to create it.' -ForegroundColor Yellow
}

Write-Host ''
Write-Host 'Health check finished.' -ForegroundColor Cyan
if (-not $NoPause) {
    Write-Host 'Press Enter to close this window...' -ForegroundColor Yellow
    [void][System.Console]::ReadLine()
}
