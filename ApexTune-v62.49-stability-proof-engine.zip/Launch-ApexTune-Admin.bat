@echo off
setlocal
cd /d "%~dp0"
if not exist "%APPDATA%\ApexTune\Diagnostics" mkdir "%APPDATA%\ApexTune\Diagnostics" >nul 2>nul
echo Starting ApexTune v62.48 as Administrator...
echo ApexTune will open as a desktop-style app window, not a normal browser tab.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File ""%~dp0Launch-ApexTune-Admin.ps1""'"
