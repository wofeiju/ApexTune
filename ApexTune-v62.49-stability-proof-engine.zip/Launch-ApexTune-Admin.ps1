$ErrorActionPreference = 'Stop'
$env:APEXTUNE_FORCE_DESKTOP = '1'
Set-Location -LiteralPath $PSScriptRoot
& (Join-Path $PSScriptRoot 'ApexTune.CommandCenter.ps1')
