@echo off
setlocal
cd /d "%~dp0"
if not exist "%APPDATA%\ApexTune\Diagnostics" mkdir "%APPDATA%\ApexTune\Diagnostics" >nul 2>nul
echo Starting ApexTune v62.48 in background/server-only mode...
echo No UI window will open. Use Open-ApexTune.url or Open-ApexTune-LastUrl.bat when needed.
set APEXTUNE_SUPPRESS_OPEN=1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0ApexTune.CommandCenter.ps1"
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo ApexTune background launch failed. Exit code: %EXITCODE%
  echo Check: %APPDATA%\ApexTune\Diagnostics\CommandCenter.log
  pause
)
