@echo off
setlocal
cd /d "%~dp0"
if not exist "%APPDATA%\ApexTune\Diagnostics" mkdir "%APPDATA%\ApexTune\Diagnostics" >nul 2>nul
set LOG=%APPDATA%\ApexTune\Diagnostics\Launch-Debug.log
echo Starting ApexTune debug launch...
echo Log: %LOG%
echo ===== ApexTune debug launch %DATE% %TIME% ===== > "%LOG%"
set APEXTUNE_FORCE_DESKTOP=1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0ApexTune.CommandCenter.ps1" 1>> "%LOG%" 2>>&1
set EXITCODE=%ERRORLEVEL%
echo Exit code: %EXITCODE% >> "%LOG%"
type "%LOG%"
echo.
echo Debug log saved to: %LOG%
pause
