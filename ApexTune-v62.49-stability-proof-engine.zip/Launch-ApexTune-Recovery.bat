@echo off
setlocal
cd /d "%~dp0"
if not exist "%APPDATA%\ApexTune\Diagnostics" mkdir "%APPDATA%\ApexTune\Diagnostics" >nul 2>nul
echo Starting ApexTune recovery launch...
echo Recovery mode opens the default browser for this launch only.
set APEXTUNE_OPEN_DEFAULT=1
set APEXTUNE_FORCE_OPEN=1
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0ApexTune.CommandCenter.ps1"
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo ApexTune recovery launch failed. Exit code: %EXITCODE%
  echo Check: %APPDATA%\ApexTune\Diagnostics\CommandCenter.log
  pause
)
