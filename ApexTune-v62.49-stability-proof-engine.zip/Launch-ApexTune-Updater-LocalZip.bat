@echo off
cd /d "%~dp0"
if "%~1"=="" (
  echo Drag an ApexTune update ZIP onto this file.
  pause
  exit /b 1
)
powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0ApexTune-Updater.ps1" -Gui -PackagePath "%~1"
