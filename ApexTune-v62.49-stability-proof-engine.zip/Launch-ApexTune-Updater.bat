@echo off
cd /d "%~dp0"
if "%~1"=="" (
  powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0ApexTune-Updater.ps1" -Gui
) else (
  powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0ApexTune-Updater.ps1" -Gui -PackagePath "%~1"
)
