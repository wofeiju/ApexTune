@echo off
cd /d "%~dp0"
wscript.exe "%~dp0ApexTune.vbs"
exit /b 0
