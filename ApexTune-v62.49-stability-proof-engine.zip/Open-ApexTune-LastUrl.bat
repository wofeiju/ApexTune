@echo off
setlocal
set URLFILE=%APPDATA%\ApexTune\Diagnostics\LastUrl.txt
if not exist "%URLFILE%" (
  echo No saved ApexTune URL found yet. Launch ApexTune first.
  pause
  exit /b 1
)
set /p URL=<"%URLFILE%"
start "" "%URL%"
